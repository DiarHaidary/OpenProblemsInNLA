"""Check the SHA-256 manifest of the delivered package, before rebuilding."""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parents[1]
failures = []
for line in (root / "MANIFEST.sha256").read_text().splitlines():
    expected, relative = line.split("  ", 1)
    path = (root / relative).resolve()
    if root not in path.parents:
        raise ValueError(f"Unsafe manifest path: {relative}")
    if not path.is_file():
        failures.append((relative, "missing"))
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        failures.append((relative, "hash mismatch"))
for name, error in failures:
    print(f"FAIL: {name}: {error}")
if failures:
    sys.exit(1)
print("All manifest entries match the delivered bytes.")
