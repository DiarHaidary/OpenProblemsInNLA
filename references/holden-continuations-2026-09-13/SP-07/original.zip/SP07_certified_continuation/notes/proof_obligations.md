# Established results and unresolved proof obligations

## Established by exact finite arithmetic

The rational real-reflection inputs generate exactly normal pairs. Positive rational LDL pivots prove a bound on the **full** difference norm. Hall witnesses retain eigenvalue multiplicity and prove matching-distance lower bounds. Independent standard-library and SymPy computations agree.

- Dimension five: ratio strictly greater than 1.019558.
- Dimension five, stronger certificate: ratio strictly greater than 1.02671.
- Dimension seven: ratio strictly greater than 1.03077.

These statements refute `sqrt(28/27)` as the universal sharp value. They also refute the specific coefficient-27/28 full-unitary inequality singled out as a possible proof target in the supplied archive. They do **not** refute the possibility that the best size-three constant might equal the Krause value; that finite-dimensional question is still unevaluated here.

## Established by written arguments

The report proves rank-one-reflection domination by dimension three, the two-spectral-value-per-Hall-side normal-compression theorem, its arbitrary-multiplicity three-value corollary, and the distinct-value refinement of the truncated singular-value bound. Numerical tests support consistency but do not establish these theorems.

## Still missing

No exact value of the universal constant is given. No sharp universal upper inequality is proved. The displayed numerical optima are not shown to be global optima in dimensions five or seven. The exact size-three constant and the rank-one-reflection constant are not evaluated. No theorem bounds the required dimension or reflection rank globally. No theorem says a contact chain is an extremal spectral configuration.

A local maximum, a successful optimizer status, a dense sample, an auxiliary Schur-multiplier extremizer, or an 80-digit eigensolver output cannot fill these gaps. Every claimed exact lower bound has its own finite algebraic certificate; there is no analogous upper-bound certificate in this package.

## Audit boundaries

There are 1,128 saved new campaign records and two separately audited polished examples. Twenty-five campaign runs have a non-success final status and remain in the files. The audit recomputes all full matrices and matching distances. Its residual tolerances are numerical, not interval proofs. Exact certificate checks are separate and have no floating-point tolerance.

The preserved earlier archive's 288 searches and 637 numerical checks are legacy records, not counted as new work in these totals.
