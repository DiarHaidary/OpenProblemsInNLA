# Source notes and provenance

Public sources were read directly on the web, not through a GitHub plugin.
The consultation date for this package is 13 September 2026. The list below
provides attribution and scope, not an assertion that a literature search proves
novelty or absence of other results. External articles are not redistributed.

## Problem statement

Open Problems in Numerical Linear Algebra, RA-11:
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/RA-11/README.md

The consulted statement specifies arbitrary real PSD inputs, adaptive real
product-vector queries returning the full vector, finite exact arithmetic,
success probability at least 2/3, and universal constant factors simultaneously
in n, q, epsilon. Its status field is Open and its last-checked field is
10 September 2026. This package does not alter the repository.

## Kronecker-query sources

R. A. Meyer, W. Swartworth, and D. P. Woodruff, *Understanding the Kronecker
Matrix-Vector Complexity of Linear Algebra*, arXiv:2502.08029v2:
https://arxiv.org/html/2502.08029v2
https://proceedings.mlr.press/v267/meyer25a.html

The distinction between conditioned scalar quadratic-form information and
unrestricted full-vector responses is material. No scalar lower bound is
transferred to the present oracle. The first package's counterexample addresses
Conjecture 23 as written in this arXiv version, not the paper's conditioned
lower-bound theorems.

R. A. Meyer and H. Avron, *Hutchinson's Estimator is Bad at
Kronecker-Trace-Estimation*, arXiv:2309.04952v2:
https://arxiv.org/html/2309.04952v2
https://doi.org/10.1137/24M1720895

Its partial-trace/partial-transpose variance analysis and distinction between
real and complex probes are relevant precedents. The paper analyzes specified
Hutchinson-type estimators; those rates are not an unrestricted adaptive minimax
characterization. The new hierarchy and fixed-order all-PSD theorem are additional
arguments supplied in this package, not conclusions attributed to that paper.

## Standard ingredients

R. A. Meyer, C. Musco, C. Musco, and D. P. Woodruff, *Hutch++: Optimal
Stochastic Trace Estimation*, arXiv:2010.09649:
https://arxiv.org/abs/2010.09649

This is the ordinary-oracle low-rank variance-reduction precedent. A learned
unstructured vector cannot simply be submitted to RA-11's product-only oracle;
the new construction explicitly avoids that step.

V. Guruswami and A. K. Sinop, *Optimal Column-Based Low-Rank Matrix
Reconstruction*, arXiv:1104.1732:
https://arxiv.org/abs/1104.1732

The column-subset approximation tradeoff is classical. The manuscript gives the
volume-weighted determinant calculation needed for the complex sketch used here
and permits exhaustive selection because only oracle calls are counted.

R. I. Oliveira, *The lower tail of random quadratic forms, with applications to
ordinary least squares and restricted eigenvalue properties*, arXiv:1312.2903:
https://arxiv.org/abs/1312.2903

This is a relevant finite-moment covariance/least-squares reference. The supplied
manuscript proves its own conservative covariance-injection bound from clipped
quadratics, symmetrization, contraction, and Markov's inequality.

## Previous work supplied by the user/conversation

`prior/RA11_round1.zip` is a byte-for-byte copy of the preceding generated
research package. The old manuscript is also copied separately for convenience.
It is a partial-result manuscript prepared with ChatGPT, not an independently
reviewed publication. Its product-subclass result, interpolation identity,
projection counterexample, and blocking lower bound keep their stated scopes.
The present ordinary lower-bound appendix specializes its bounded-probability
Wishart argument; it is not represented as a new lower bound.
