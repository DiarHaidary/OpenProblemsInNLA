#!/usr/bin/env python3
"""Exact finite checks for the third RA-01 note. No external dependencies."""
from fractions import Fraction as F
from pathlib import Path
import json

COUNT = 0
def check(ok, message):
    global COUNT
    COUNT += 1
    if not ok:
        raise AssertionError(message)

def encoded(x):
    return {'numerator': str(x.numerator), 'denominator': str(x.denominator), 'decimal': float(x)}

def trace(A):
    return sum((A[i][i] for i in range(len(A))), F(0))

def pivot(A, j):
    d=A[j][j]
    check(d>0, 'positive pivot')
    n=len(A)
    return tuple(tuple(A[i][l]-A[i][j]*A[j][l]/d for l in range(n)) for i in range(n))

def trajectory_expectations(A):
    A=tuple(tuple(F(x) for x in row) for row in A)
    n=len(A)
    states={frozenset(): (F(1), A)}
    out=[trace(A)]
    for k in range(n):
        nxt={}
        for S,(p,R) in states.items():
            T=trace(R)
            if T==0:
                if S in nxt:
                    op, OR=nxt[S]; check(OR==R, 'absorbing state agreement'); nxt[S]=(op+p,R)
                else: nxt[S]=(p,R)
                continue
            for j in range(n):
                check(R[j][j]>=0, 'nonnegative diagonal')
                if R[j][j]==0:
                    continue
                Rp=pivot(R,j); Sp=S|{j}; pp=p*R[j][j]/T
                check(trace(Rp)<=T, 'monotone trace')
                check(all(Rp[j][i]==0 and Rp[i][j]==0 for i in range(n)), 'zero pivot row')
                if Sp in nxt:
                    op,OR=nxt[Sp]; check(OR==Rp, 'path-independent residual'); nxt[Sp]=(op+pp,Rp)
                else: nxt[Sp]=(pp,Rp)
        states=nxt
        check(sum((p for p,_ in states.values()),F(0))==1, 'probability normalization')
        out.append(sum((p*trace(R) for p,R in states.values()),F(0)))
    check(out[-1]==0, 'termination')
    return out

def block_diag(blocks):
    n=sum(len(B) for B in blocks)
    A=[[F(0) for _ in range(n)] for _ in range(n)]
    offset=0
    for B in blocks:
        for i,row in enumerate(B):
            for j,x in enumerate(row): A[offset+i][offset+j]=F(x)
        offset+=len(B)
    return tuple(tuple(row) for row in A)

clock=[]
for b in [1,2,10]:
    n=10*b+1; r=n-1; L=40*n*n*(n-1); t=F(1,n)
    rates=[]
    for k in range(n):
        m=n-k
        c=-F(L*(L-1),m*L+k)
        T=F(m*L)+m*c
        check(T==F(m*L*((m-1)*L+k+1),m*L+k), 'closed trace formula')
        check(T>0, 'positive holding rate')
        if k<r: check(T>=F((m-1)*L), 'early rate lower bound')
        if k<n-1:
            cp=c*L/(L+c)
            check(cp==-F(L*(L-1),(m-1)*L+k+1), 'Schur coefficient recurrence')
        rates.append(T)
    check(rates[-1]>=F(n,2), 'last rate lower bound')
    mean_early=sum((1/x for x in rates[:-1]),F(0))
    q=2*mean_early/t
    check(q<=F(1,20*n), 'Markov failure bound')
    excess=F(1,5)-q*(r+F(1,5))
    check(excess>F(3,20), 'certified expected-count excess')
    check(F(3,20)>b*t, 'violates proposed r+b*t*tail bound')
    clock.append({'b':b,'n':n,'r':r,'L':L,'t':encoded(t),
                  'early_mean':encoded(mean_early), 'q_upper':encoded(q),
                  'expected_count_excess_strict_lower':encoded(excess),
                  'proposed_excess_upper':encoded(b*t)})

R=((F(3),F(1)),(F(1),F(3)))
D=((F(11,15),F(1,15)),(F(1,15),F(11,15)))
h=F(1); d=trace(D)
actual_drift=F(0)
for j in range(2):
    Rp=pivot(R,j)
    d_after=F(8,11)
    check(trace(Rp)==F(8,3), 'ridge example residual')
    drop=sum((D[j][i]*D[i][j] for i in range(2)),F(0))/D[j][j]
    check(drop==d-d_after, 'ridge trace update')
    actual_drift+=R[j][j]*drop
upper=trace(R)-h*d
check(actual_drift==F(244,55), 'ridge drift exact value')
check(upper==F(68,15), 'ridge comparison exact value')
check(upper-actual_drift==F(16,165), 'strict ridge drift direction')
ridge={'negative_generator_d':encoded(actual_drift),'T_minus_h_d':encoded(upper),'gap':encoded(upper-actual_drift)}

# The conditional level-two clock hazard is not always bounded by its volume-sampling value.
L=F(10); delta=F(1,10)
x=2*L*delta/(L+delta)
p=F(10,111)
z_bad=F(1); z_good=x
a_bad=2+x; a_good=(L+delta+1+3*x)/2
cov=p*(1-p)*(z_bad-z_good)*(a_bad-a_good)
derivative=-cov/3
volume_mean=p*z_bad+(1-p)*z_good
check(volume_mean==F(10,37), 'level-two volume mean')
check(cov<0, 'negative covariance')
check(derivative>0, 'positive conditional hazard derivative')
check(derivative==F(22113,276538), 'exact conditional hazard derivative')
hazard={'matrix':[['101/20','99/20','0'],['99/20','101/20','0'],['0','0','1']],
        'volume_mean':encoded(volume_mean),'covariance':encoded(cov),'right_derivative_at_zero':encoded(derivative)}

B1=((F(4),F(1)),(F(1),F(2)))
B2=((F(3),F(1),F(0)),(F(1),F(3),F(1)),(F(0),F(1),F(3)))
B3=((F(2),F(1),F(1)),(F(1),F(3),F(0)),(F(1),F(0),F(4)))
B4=((F(1),F(1)),(F(1),F(1)))
cases=[([B1,B2],[1,1]),([B2,B3],[2,1]),([B1,B2],[0,2]),([B4,B4],[1,1])]
block_results=[]
for blocks, qs in cases:
    local=[trajectory_expectations(B) for B in blocks]
    budget=sum((vals[min(q,len(vals)-1)] for vals,q in zip(local,qs)),F(0))
    r=sum(qs); A=block_diag(blocks); global_values=trajectory_expectations(A)
    checks=[]
    for k in range(r+1,len(A)+1):
        bound=F(k,k-r)*budget
        check(global_values[k]<=bound, 'sharpened block aggregation')
        checks.append({'k':k,'expectation':encoded(global_values[k]),'bound':encoded(bound)})
    block_results.append({'block_sizes':[len(B) for B in blocks],'q':qs,'r':r,'expected_budget':encoded(budget),'checks':checks})

out={'status':'PASS','arithmetic':'exact rational','explicit_assertions':COUNT,
     'scope':'Finite checks only; not a proof-assistant verification or proof of unrestricted RA-01.',
     'finite_clock_counterexamples':clock,'ridge_drift':ridge,
     'conditional_hazard_counterexample':hazard,'block_aggregation':block_results}
root=Path(__file__).resolve().parents[1]
(root/'verification').mkdir(exist_ok=True)
(root/'verification'/'exact_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','explicit_assertions':COUNT,'report':str(root/'verification'/'exact_results.json')},indent=2))
