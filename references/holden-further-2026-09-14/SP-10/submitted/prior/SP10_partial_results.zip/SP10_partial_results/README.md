# SP-10: verified partial results and exact certificates

**Status: PARTIAL. This is not a complete solution of SP-10.**

The requested statement is

\[
\operatorname{mr}(G)+\operatorname{mr}(\overline G)\le |V(G)|+2
\]

for every finite simple undirected graph. Here the matrices are real symmetric, their off-diagonal entries are nonzero **exactly** on the edges, and their diagonal entries are unrestricted. This package proves specified partial results and supplies exact finite witnesses. It does not prove or disprove the universal statement.

Prepared September 13, 2026. The public repository was read directly through its website/raw public files; no GitHub plugin or repository write was used.

## Start here

Read **`manuscript/sp10_partial_results.pdf`**, an 11-page mathematical report with complete proofs of the deductions made here, explicit matrices, bibliography, computational interpretation, and the precise remaining gap. Its editable LaTeX source is alongside it.

The main universal consequence is

\[
\operatorname{mr}(G)+\operatorname{mr}(\overline G)
\le \operatorname{mr}_{+}(G)+\operatorname{mr}_{+}(\overline G)
\le \left\lfloor1+\sqrt{2n^2-2n+1}\right\rfloor.
\]

This combines Hall's January 2026 strong Delta theorem with the existing degeneracy method of Barioli–Fallat–Gupta–Li. It is a coefficient-\(\sqrt2\) bound, **not** the requested coefficient-one bound, and is not claimed as a new resolution or priority result. Hall's theorem is explicitly imported from its preprint, not re-proved here.

The report also proves sufficient conditions based on degree spread, the second-smallest and second-largest degrees, and a clique-prefix degree test. In particular, the target follows for regular and almost-regular graphs. Elementary proofs establish that paths attain the target exactly. The bull graph disproves a tempting auxiliary greedegree inequality, while itself satisfying SP-10.

## Exact computational results

All **1,252 nonempty NetworkX graph-atlas entries of order at most seven** have saved integer Gram-matrix pairs with rank sum at most `n + 2`. Each entry is checked for exact edge/nonedge support and rank. A separate atlas-coverage check confirms that there are no missing, duplicated, or extra atlas indices and that every edge list and graph6 identifier matches its atlas source.

The package also contains the bull certificate and 17 path certificates for orders four through twenty. Both the standard-library verifier and a second implementation using SymPy accept all **1,270 saved records**. The count includes separately stored examples overlapping the atlas; it is not a count of distinct graph isomorphism classes. All 12 unit tests pass.

These are rank **upper-bound** certificates, not claims to compute the two minimum ranks. The explicit path and bull minima have separate mathematical lower-bound proofs. The finite atlas range is a reproduction/verification exercise, not a new range for the conjecture: prior literature already reports the result through order ten.

No floating-point tolerance is used. No SAP certificate, formal proof-assistant verification, independent human review, or all-graph algorithm is claimed. Search failure is always `UNKNOWN`, never a counterexample.

## Contents

| Path | Purpose |
|---|---|
| `manuscript/sp10_partial_results.pdf` | Mathematical report, proofs, sources, limitations |
| `manuscript/sp10_partial_results.tex` | Editable LaTeX source |
| `CLAIMS.md` | Claim-by-claim status and dependencies |
| `src/sp10.py` | Exact graph/matrix routines, verifier, bounded search CLI |
| `src/explicit_families.py` | Elementary path-complement and bull constructions |
| `src/run_experiments.py` | Reproducible atlas certificate generation |
| `src/crosscheck_sympy.py` | Second exact matrix verifier, using SymPy |
| `src/check_combinatorial_bounds.py` | Finite checks of degree/MCS comparisons |
| `src/check_atlas_coverage.py` | Checks the full certificate set against the atlas |
| `certificates/atlas_pairs.jsonl` | All 1,252 atlas certificate records |
| `certificates/bull.json` | Explicit bull witness and complement permutation |
| `certificates/paths_4_to_20.jsonl` | Seventeen sharp-family witnesses |
| `examples/bull_input.json` | Small input for the custom search |
| `tests/test_sp10.py` | Twelve unit tests |
| `results/` | Exact verification outputs, experiment data, coverage check, logs |
| `notes/sources.md` | Primary sources and exact imported results |
| `notes/research_assessment.md` | What worked, what failed, what remains |
| `notes/repository_status.md` | Why this does not justify a SOLVED status |
| `SHA256SUMS` | Checksums of all delivered files except the checksum file itself |

## Verify with the standard library

Tested with **Python 3.13.5**. The primary verifier and elementary constructions require no third-party Python package. Run these commands from the root directory:

```sh
python -m unittest discover -s tests -v
python src/sp10.py verify certificates/atlas_pairs.jsonl
python src/sp10.py verify certificates/bull.json
python src/sp10.py verify certificates/paths_4_to_20.jsonl
python src/check_combinatorial_bounds.py
```

The atlas verifier should report:

```json
{"verified": 1252, "certified": 1252, "unknown": 0}
```

The bull and path commands should report 1 and 17 certified records, respectively. The combinatorial comparisons should report 219 greedegree-only test failures, 92 degeneracy-only test failures, and 22 failures of the combined sufficient test. These are not conjecture counterexamples.

## Optional second verifier and atlas coverage

The pinned optional dependencies are **NetworkX 3.6.1** and **SymPy 1.14.0**. An isolated environment avoids changing unrelated packages:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-experiments.txt
python src/crosscheck_sympy.py certificates/atlas_pairs.jsonl \
  certificates/bull.json certificates/paths_4_to_20.jsonl
python src/check_atlas_coverage.py
```

The second verifier should report 1,270 records checked. It does not import the primary matrix routines. The coverage checker should report 1,252 matching edge lists and graph6 identifiers, with no missing, duplicate, or extra indices.

## Regenerate certificates

```sh
python src/run_experiments.py --max-n 7 --trials 64 \
  --out-dir /path/to/new/output
python src/explicit_families.py
```

The atlas generator creates the output subdirectories. It uses deterministic seeds `20260913 + atlas_index`, 64 base trials per dimension, and a bounded escalation to 512 trials for unresolved instances. The explicit-family script writes into this package's `certificates/` directory.

A matching interrupted atlas run can be continued using the same command with `--resume`. Saved records are reverified, matched to their atlas graph, and written out along with the newly generated records. During the delivered run, generation was interrupted after 1,047 records and then resumed. The saved metadata discloses this; the reported duration of the resumed invocation is not total generation time. The final verifiers re-read the complete saved certificate file independently of generation progress.

## Search a supplied graph

Input format uses zero-based vertices:

```json
{"n":5,"edges":[[0,1],[0,2],[1,2],[2,3],[0,4]]}
```

Run:

```sh
python src/sp10.py search examples/bull_input.json \
  --trials 96 --seed 0 --out /path/to/bull_result.json
python src/sp10.py verify /path/to/bull_result.json
```

The bounded search is not guaranteed to find a desired witness. A valid result labeled `UNKNOWN` only means the witnesses found did not meet the target. Exact MCS maximization is exponential and is skipped above order 22; even below this cap it can be expensive. The package does not claim an efficient general-purpose minimum-rank optimizer.

## Build the PDF

A standard LaTeX installation with the packages declared in the source is sufficient:

```sh
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error sp10_partial_results.tex
pdflatex -interaction=nonstopmode -halt-on-error sp10_partial_results.tex
```

The delivered PDF was compiled, rendered, and visually checked. Build intermediates are excluded from the ZIP.

## Remaining mathematical gap

For arbitrary graphs not covered by the sufficient conditions, an argument is still needed for

\[
M(G)+M(\overline G)\ge n-2.
\]

The bull graph rules out deriving this simply from `g(G) + g(complement(G)) >= n - 2`. The universal degeneracy bound and the finite matrix checks do not supply the missing all-order proof. The repository should not be marked `SOLVED` on the basis of this package.
