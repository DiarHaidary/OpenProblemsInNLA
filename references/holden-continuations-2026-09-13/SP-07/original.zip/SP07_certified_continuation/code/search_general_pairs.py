"""Continue the earlier archive's full normal-pair search from stronger seeds.
All optimizer results are numerical. They do not establish an upper bound.
"""
import argparse,itertools,json,sys,time
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'prior'/'sp07_partial_results'/'code'))
from search import Model

def best_cut(a,b,p):
    q=len(a)+1-p;cost=abs(a[:,None]-b[None,:]);best=(-1,None,None)
    for I in itertools.combinations(range(len(a)),p):
        mins=cost[list(I)].min(axis=0);J=np.argsort(mins)[-q:];g=mins[J].min()
        if g>best[0]:best=(g,list(I),J.tolist())
    return best

def main(args):
    rec=json.loads(args.base.read_text());z=np.array(rec['z'])@np.array([1,1j]);P=np.array(rec['P_real'])+1j*np.array(rec['P_imag']);S=np.eye(len(z))-2*P
    if np.max(abs(S.imag))>1e-8:raise ValueError('Seed must be real-reflection realization.')
    S=S.real;rng=np.random.default_rng(args.seed);rows=[];start=time.monotonic();args.output.parent.mkdir(parents=True,exist_ok=True)
    for n in args.sizes:
        if n<len(z):raise ValueError('Dimension below seed size')
        a=np.r_[z,5*np.arange(1,n-len(z)+1)];b=np.r_[-z,5*np.arange(1,n-len(z)+1)];U=np.eye(n);U[:len(z),:len(z)]=S
        for p in sorted(set([2,(n+1)//2])):
            _,I,J=best_cut(a,b,p);ri=I+[i for i in range(n) if i not in I];cj=J+[i for i in range(n) if i not in J]
            aa=a[ri];bb=b[cj];UU=U[np.ix_(ri,cj)];rot=np.exp(-1j*np.angle(aa[1]-aa[0]));bb=(bb-aa[0])*rot;aa=(aa-aa[0])*rot
            scale=np.linalg.norm((aa[:,None]-bb[None,:])*UU,2);aa/=scale;bb/=scale
            mod=Model(n,p,args.complex);x0=np.r_[aa[1].real,np.column_stack([aa[2:].real,aa[2:].imag]).ravel(),np.column_stack([bb.real,bb.imag]).ravel(),mod.real_angles(UU),np.min(abs(aa[:p,None]-bb[None,:mod.q]))]
            for k in range(args.runs):
                noise=[0,.02,.08,.2,.5,.9][k%6];x=x0+noise*rng.normal(size=mod.size);x[0]=max(1e-5,x[0]);x[-1]=max(.05,x[-1]);out=mod.optimize(x);row=mod.record(out.x);row.update(run=k,seed=args.seed,noise=noise,success=bool(out.success),message=str(out.message),base=args.base.name);rows.append(row)
                print(n,p,k,row['actual_ratio'],row['minimum_constraint'],row['success'],flush=True)
                args.output.write_text(json.dumps(dict(status='Floating-point local search, not proof of global optimality.',elapsed_seconds=time.monotonic()-start,records=rows),indent=2)+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',type=Path,required=True);p.add_argument('--sizes',nargs='+',type=int,required=True);p.add_argument('--runs',type=int,default=18);p.add_argument('--complex',action='store_true');p.add_argument('--seed',type=int,default=17320508);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a)
