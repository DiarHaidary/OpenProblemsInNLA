#!/usr/bin/env python3
"""Exact symbolic audits for the new analytic reductions (requires SymPy)."""
from pathlib import Path
import json,time
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
start=time.monotonic();checks={}
p,q,P,Q,x,y=s.symbols('p q P Q x y',positive=True)
n=p+q;N=P+Q;R0=n-P**2/p-Q**2/q;K=P**2+2*P*Q-Q**2;g0=q*P/N
h=g0**2+(p-q-K/n)*g0-2*p*q*R0/n
E=s.factor(n*N**2*h).subs({p:P+x,q:Q+y},simultaneous=True)
R=P**2*N*Q**2+P*Q*(2*P**2+5*P*Q+4*Q**2)*x+P*Q*(4*P**2+9*P*Q+6*Q**2)*y+N*Q*(P+2*Q)*x**2+P*(P**2+4*P*Q+5*Q**2)*y**2+2*(P**3+4*P**2*Q+6*P*Q**2+2*Q**3)*x*y+N*(P+2*Q)*x**2*y+(P**2+4*P*Q+2*Q**2)*x*y**2+P*Q*y**3
assert s.factor(E+R)==0
assert all(c>0 for _,c in s.Poly(s.expand(R),P,Q,x,y).terms())
checks['negative_projection_bound_identity']=True
p,y,z,a,eta=s.symbols('p y z a eta',real=True);d=1-a;b=1+a;q=y+z;n=p+q;t=p+a*q
F=lambda k:n*n+d*(2*n*k-(a+3)*k*k)
e2=-d*p*q+d*b*z*(p-q+z);e3=-b*d*d*p*y*z
f=lambda w:w**3-t*w*w+e2*w-e3
g=lambda w:w*w-(p+a*z)*w+a*d*p*z
h0=d*b*z
assert s.factor(f(h0)-h0*(g(h0)-d*b*b*y*z))==0
checks['middle_eigenvalue_substitution']=True
spread2=F(q)-4*d*b*z*(p-q+z)+2*t*eta-3*eta**2
V=(1-b)*F(q)+b*F(y)
assert s.factor(V-spread2-(2*t*(h0-eta)+d*d*b*z*z+3*eta**2))==0
Delta=q-p
assert s.factor(F(p)-spread2-(d*b*(4*(z-Delta/2)**2+2*p*Delta)-2*t*eta+3*eta**2))==0
checks['negative_parameter_comparison_identities']=True
l,m,e,c,r,P,Q,p,q=s.symbols('l m e c r P Q p q',positive=True)
spr=l+m
lp=2*c*r*((P+Q)*l+2*r*q*P)/(spr*(l-e))
mp=2*c*r*((P+Q)*m-2*r*q*P)/(spr*(m+e))
C=2*l*m+e*(l-m);W=l-m-2*e
assert s.factor(lp+mp-2*c*r*(C*(P+Q)-2*r*q*P*W)/(spr*(l-e)*(m+e)))==0
checks['monotonicity_derivative_identity']=True
alpha,beta,gamma,u=s.symbols('alpha beta gamma u');tt=alpha+beta+gamma;ee=alpha*beta+alpha*gamma+beta*gamma;D0=tt**2-3*ee
Disc=(alpha-beta)**2*(alpha-gamma)**2*(beta-gamma)**2
pairpoly=(u-(alpha-beta)**2)*(u-(alpha-gamma)**2)*(u-(beta-gamma)**2)
assert s.factor(pairpoly-(u*(u-D0)**2-Disc))==0
checks['cubic_squared_difference_identity']=True
report={'status':'PASS','arithmetic':'Exact symbolic rational polynomial identities','checks':checks,'seconds':time.monotonic()-start}
(ROOT/'checks'/'analytic_identity_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
