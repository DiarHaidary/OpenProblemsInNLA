"""Convert a numerical search record into exact rational certificate input.
This conversion alone proves nothing: run check_certificate.py afterwards.
"""
import argparse,json,math
from pathlib import Path
import numpy as np
from scipy.linalg import qr
from check_certificate import verify

def main(a):
    rec=json.loads(a.record.read_text());n=rec['n'];r=rec['r'];z=np.array(rec['z'])@np.array([1,1j]);P=np.array(rec['P_real'])+1j*np.array(rec['P_imag'])
    if np.max(abs(P.imag))>1e-8:raise ValueError('This converter expects a real orthogonal reflection.')
    eig,W=np.linalg.eigh(P.real);W=W[:,eig>.5];_,_,perm=qr(W.T,pivoting=True);P=P.real[np.ix_(perm,perm)];z=z[perm];I=[j for j,k in enumerate(perm) if k in rec['I']];J=[j for j,k in enumerate(perm) if k in rec['J']]
    X=P[r:,:r]@np.linalg.inv(P[:r,:r]);low=a.lower or f'{math.floor((rec["cut_ratio"]-3e-7)*1e5)/1e5:.5f}'
    fmt=lambda x:f'{x:.12f}'
    data={'description':'All decimal strings are exact rationals. This is a lower-bound certificate, not a universal upper bound.','z':[[fmt(q.real),fmt(q.imag)] for q in z],'X':[[fmt(x) for x in row] for row in X],'I':I,'J':J,'norm_upper_bound':'1.0000001','ratio_lower_bound':low,'source_record':a.record.name,'coordinate_permutation':perm.tolist()}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(data,indent=2)+'\n');verify(a.output,a.output.with_name(a.output.stem+'_verification.json'))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('record',type=Path);p.add_argument('output',type=Path);p.add_argument('--lower');a=p.parse_args();main(a)
