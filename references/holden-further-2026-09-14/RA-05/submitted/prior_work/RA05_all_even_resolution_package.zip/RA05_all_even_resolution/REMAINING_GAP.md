# The remaining non-even question

The new theorem completely covers all fixed even exponents p=4,6,8,..., including
previously missing intermediate accuracies. It does not cover p=3, p=5, p=2.5, or
any other exponent outside that set. RA-05 quantifies over all real p>2.

Three proof steps explicitly use polynomial structure:

1. The exact finite head-tail expansion of squared distances to the integer power s.
2. A dimension/condition-independent norming set for homogeneous polynomial query maps.
3. Finite interpolation extracting the derivative in the lower-bound constructions.

The constants may depend on the fixed exponent. They cannot depend on an
approximation degree growing with k or 1/epsilon while still proving the same
joint formula. A valid extension needs an error budget for that dependence,
including uniform relative control near zero residuals. Such an analysis has not
been established in this package.

## Approaches not promoted to results

Replacing s by a nearby integer does not compare signed coreset errors at the two
powers. Preserving a finite list of even moments is not sufficient: the saved
certificate is exact at powers 2,4,6,8 yet has a nonzero cubic error in its recorded
normal direction. This is an illustration of nontransfer, not an impossibility
result for a separate non-even construction.

A Euclidean net in the entries of the head map could introduce an unbounded
condition number. The new polynomial proof solves this using an adapted norm and
polarization. A nonpolynomial replacement cannot simply assume the same norming
inequality for arbitrary signed sums.

The earlier packages contain lower bounds for general real p and a refutation of
the subsidiary proposed bound. Those facts do not close the matching non-even
upper/lower gap. They are not used as premises in the present all-even proof.

No percentage of completion is mathematically justified by the number of even
exponents covered. The gap is a missing family of uniform estimates, not an
additional finite verification task.
