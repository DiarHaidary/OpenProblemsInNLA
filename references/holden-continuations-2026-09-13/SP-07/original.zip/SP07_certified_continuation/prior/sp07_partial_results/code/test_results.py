"""Reproducible numerical sanity checks of the proved identities.

These floating-point tests supplement, and do not replace, the written proofs.
"""
from __future__ import annotations
import argparse
from itertools import permutations
import json
from pathlib import Path
import platform
import numpy as np
import scipy
from matching import bottleneck, hall_value


def unitary(rng: np.random.Generator, n: int) -> np.ndarray:
    q, r = np.linalg.qr(rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n)))
    phases = np.diag(r)
    phases = np.where(np.abs(phases) > 0, phases / np.abs(phases), 1)
    return q * phases.conj()[None, :]


def require_close(a: float, b: float, label: str, tol: float = 2e-9) -> float:
    error = float(abs(a - b) / max(1.0, abs(a), abs(b)))
    if error > tol:
        raise RuntimeError(f'{label}: relative error {error:.3g}')
    return error


def main(seed: int = 7072026) -> dict:
    rng = np.random.default_rng(seed)
    counts = dict(matching_vs_bruteforce=0, hall_identity=0, unitary_norm_identity=0,
                  replication=0, real_orthogonal_reduction=0, reflection_reduction=0,
                  truncated_bound=0, two_eigenvalue_bound=0)
    maximum_error = 0.0
    for n in range(1, 7):
        for trial in range(12):
            a = rng.normal(size=n) + 1j * rng.normal(size=n)
            b = rng.normal(size=n) + 1j * rng.normal(size=n)
            if trial % 3 == 0:
                a = np.round(a.real) + 1j * np.round(a.imag)
                b = np.round(b.real) + 1j * np.round(b.imag)
            d, perm = bottleneck(a, b)
            brute = min(max(abs(a[k] - b[p[k]]) for k in range(n))
                        for p in permutations(range(n)))
            maximum_error = max(maximum_error, require_close(d, float(brute), 'matching'))
            counts['matching_vs_bruteforce'] += 1
            hd, rows, cols = hall_value(a, b)
            maximum_error = max(maximum_error, require_close(d, hd, 'Hall identity'))
            counts['hall_identity'] += 1
            dr, _ = bottleneck(np.repeat(a, 2), np.repeat(b, 2))
            maximum_error = max(maximum_error, require_close(d, dr, 'replication'))
            counts['replication'] += 1
            U = unitary(rng, n)
            A, B = np.diag(a), U @ np.diag(b) @ U.conj().T
            M = (a[:, None] - b[None, :]) * U
            eps = np.linalg.norm(A - B, 2)
            maximum_error = max(maximum_error, require_close(eps, np.linalg.norm(M, 2), 'unitary norm'))
            counts['unitary_norm_identity'] += 1
            R = np.block([[U.real, -U.imag], [U.imag, U.real]])
            AR = np.diag(np.tile(a, 2))
            BR = R @ np.diag(np.tile(b, 2)) @ R.T
            maximum_error = max(maximum_error, require_close(eps, np.linalg.norm(AR - BR, 2), 'real reduction'))
            maximum_error = max(maximum_error, require_close(0, np.linalg.norm(R.T @ R - np.eye(2*n), 2), 'orthogonality'))
            counts['real_orthogonal_reduction'] += 1
            c = 5 + max(float(np.max(abs(a))), float(np.max(abs(b)))) + d
            aa, bb = np.r_[a + c, -b - c], np.r_[b + c, -a - c]
            ds, _ = bottleneck(aa, bb)
            maximum_error = max(maximum_error, require_close(d, ds, 'reflection reduction'))
            Z = np.zeros((n, n), complex)
            J = np.block([[Z, np.eye(n)], [np.eye(n), Z]])
            Dhat = np.block([[A+c*np.eye(n), Z], [Z, -B-c*np.eye(n)]])
            Bhat = -J @ Dhat @ J
            maximum_error = max(maximum_error, require_close(eps, np.linalg.norm(Dhat-Bhat, 2), 'reflection norm'))
            P = (np.eye(2*n)+J)/2; Q = np.eye(2*n)-P
            pinching_norm = 2*max(np.linalg.norm(P @ Dhat @ P, 2), np.linalg.norm(Q @ Dhat @ Q, 2))
            maximum_error = max(maximum_error, require_close(eps, pinching_norm, 'pinching identity'))
            counts['reflection_reduction'] += 1
            sv = np.linalg.svd(M, compute_uv=False)
            bound = np.sqrt(np.sum(sv[:(n+1)//2]**2))
            if d > bound + 2e-9 * max(1, bound):
                raise RuntimeError('Truncated singular-value inequality failed.')
            counts['truncated_bound'] += 1
    for n in range(2, 13):
        for trial in range(12):
            vals = rng.normal(size=2) + 1j * rng.normal(size=2)
            a = np.r_[np.repeat(vals[0], n//2), np.repeat(vals[1], n-n//2)]
            b = rng.normal(size=n) + 1j * rng.normal(size=n)
            U = unitary(rng, n)
            d, _ = bottleneck(a, b)
            eps = np.linalg.norm((a[:, None] - b[None, :])*U, 2)
            if d > eps + 2e-9 * max(1, eps):
                raise RuntimeError('Two-eigenvalue bound failed.')
            counts['two_eigenvalue_bound'] += 1
    # Include the nontrivial example, not only generic random pairs.
    a = np.array([1, (4 + 5j*np.sqrt(3))/13, (-1 + 2j*np.sqrt(3))/13])
    v = np.sqrt([5/8, 1/4, 1/8]); U = np.eye(3)-2*np.outer(v, v)
    d, permutation = bottleneck(a, -a)
    norm = np.linalg.norm((a[:, None] + a[None, :])*U, 2)
    maximum_error = max(maximum_error, require_close(d/norm, np.sqrt(28/27), 'Krause ratio'))
    return dict(status='All numerical sanity checks passed; these are not a proof of a universal optimum.',
                seed=seed, checks=counts, total_checks=sum(counts.values())+1,
                largest_relative_identity_error=maximum_error,
                krause_ratio=d/norm, krause_matching=permutation.tolist(),
                environment=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--seed', type=int, default=7072026)
    args = parser.parse_args()
    result = main(args.seed)
    text = json.dumps(result, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text+'\n', encoding='utf-8')
    print(text)
