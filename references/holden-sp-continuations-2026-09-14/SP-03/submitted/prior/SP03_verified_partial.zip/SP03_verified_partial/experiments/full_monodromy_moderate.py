"""Exploratory SP-03 continuation in unreduced polynomial equations.
Residuals and root discoveries are not certified degree computations.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import numpy as np
from numba import njit
import sys,time,json
BASE=Path(__file__).resolve().parent
@njit(cache=True)
def ni(v):return np.max(np.abs(v))
@njit(cache=True)
def evaluate(x,u,du,n):
 m=n//2;X=x.reshape((n,n));U=u.reshape((n,n));DU=du.reshape((n,n))
 JX=np.empty_like(X);XJ=np.empty_like(X)
 for a in range(n):
  for b in range(n):
   JX[a,b]=X[a+m,b] if a<m else -X[a-m,b]
   XJ[a,b]=-X[a,b+m] if b<m else X[a,b-m]
 A=U-X;F=np.empty(n*n,np.complex128);Jac=np.zeros((n*n,n*n),np.complex128);Ft=np.zeros(n*n,np.complex128);row=0
 for i in range(n):
  for j in range(i+1,n):
   v=0j
   for a in range(n):v+=X[a,i]*JX[a,j]
   if i<m and j==i+m:v-=1
   F[row]=v
   for a in range(n):
    Jac[row,a*n+i]+=JX[a,j];Jac[row,a*n+j]-=JX[a,i]
   row+=1
 for i in range(n):
  for j in range(i,n):
   v=0j;vt=0j
   for a in range(n):
    v+=A[a,i]*XJ[a,j]+A[a,j]*XJ[a,i]
    vt+=DU[a,i]*XJ[a,j]+DU[a,j]*XJ[a,i]
   F[row]=v;Ft[row]=vt
   bj=j+m if j<m else j-m;bi=i+m if i<m else i-m
   sj=-1 if j<m else 1;si=-1 if i<m else 1
   for a in range(n):
    Jac[row,a*n+i]-=XJ[a,j];Jac[row,a*n+j]-=XJ[a,i]
    Jac[row,a*n+bj]+=sj*A[a,i];Jac[row,a*n+bi]+=si*A[a,j]
   row+=1
 return F,Jac,Ft
@njit(cache=True)
def track(x0,u0,u1,n):
 x=x0.copy();du=u1-u0;t=0.;h=.015;steps=0
 while t<1.:
  steps+=1
  if steps>4000:return x,False,steps
  F,A,Ft=evaluate(x,u0+t*du,du,n)
  try:v=np.linalg.solve(A,-Ft)
  except:return x,False,steps
  h=min(h,1-t);pred=x+h*v;y=pred.copy();ok=False;olderr=1e300
  for it in range(10):
   G,B,Gt=evaluate(y,u0+(t+h)*du,du,n)
   try:delta=np.linalg.solve(B,G)
   except:break
   err=ni(delta)
   if not np.isfinite(err):break
   y-=delta
   if err<1e-7*(1+ni(y)):ok=True;break
   if it>=3 and err>olderr*.95:break
   olderr=err
  if ok:
   corr=ni(y-pred)/(1+ni(y))
   if corr>.03:h*=.5
   else:
    x=y;t+=h
    if corr<.0005:h*=1.6
    elif corr<.004:h*=1.25
    elif corr>.018:h*=.7
    h=min(h,.15)
  else:h*=.5
  if h<1e-10 or ni(x)>1e10:return x,False,steps
 for it in range(3):
  F,A,Ft=evaluate(x,u1,du,n)
  try:x-=np.linalg.solve(A,F)
  except:return x,False,steps
 F,A,Ft=evaluate(x,u1,du,n)
 return x,ni(F)<1e-9*(1+ni(x)**2),steps

def main(m,seconds=25):
 n=2*m;path=BASE/f'full_m{m}.npz';rng=np.random.default_rng(61550+m+(int(time.time())%100000 if path.exists() else 0))
 def rc(shape,s=1.):return s*(rng.standard_normal(shape)+1j*rng.standard_normal(shape))/np.sqrt(n)
 if path.exists():
  z=np.load(path);roots=list(z['roots']);U=z['U'];loops=int(z['loops'])
 else:
  from bigcell_monodromy import lift,basis
  z=np.load(BASE/f'bigcell_m{m}.npz');I=np.eye(m);P=np.block([[I,1j*I],[1j*I,I]])/np.sqrt(2);Pi=np.linalg.inv(P)
  U=(P@z['U']@Pi).ravel();roots=[(P@lift(a,z['U'],basis(m))[0]@Pi).ravel() for a in z['roots']];loops=0
 F,A,Ft=evaluate(roots[0],U,np.zeros_like(U),n)
 print('START FULL',m,len(roots),ni(F),'cond',np.linalg.cond(A),flush=True)
 proj=rc((n*n,));vals=[np.dot(proj,x) for x in roots]
 def add(y):
  z=np.dot(proj,y)
  for ix,w in enumerate(vals):
   if abs(w-z)<1e-4*(1+abs(z)) and ni(y-roots[ix])<1e-5*(1+ni(y)):return False
  roots.append(y);vals.append(z);return True
 start=time.time();paths=fails=steps=ng=0
 for _ in range(10000):
  old=len(roots);V=rc((n*n,),2.);W=rc((n*n,),2.);ix=0
  # Randomize existing roots so truncated batches do not always repeat the first ones.
  order=list(rng.permutation(len(roots)))
  while ix<len(order):
   y=roots[order[ix]].copy();good=True
   for p,q in [(U,V),(V,W),(W,U)]:
    y,ok,st=track(y,p,q,n);paths+=1;steps+=st
    if not ok:good=False;fails+=1;break
   if good and add(y):order.append(len(roots)-1)
   ix+=1
   if time.time()-start>seconds:break
  loops+=1;info=dict(m=m,loops=loops,roots=len(roots),elapsed=time.time()-start,paths=paths,failures=fails,steps=steps)
  print(json.dumps(info),flush=True)
  np.savez_compressed(path,roots=np.asarray(roots),U=U,loops=np.asarray(loops))
  with open(BASE/f'full_log_m{m}.jsonl','a') as f:f.write(json.dumps(info)+'\n')
  ng=ng+1 if old==len(roots) else 0
  if time.time()-start>seconds or ng>=6:break
 print('FINISH FULL',m,len(roots),flush=True)
if __name__=='__main__':main(int(sys.argv[1]),float(sys.argv[2]) if len(sys.argv)>2 else 25)
