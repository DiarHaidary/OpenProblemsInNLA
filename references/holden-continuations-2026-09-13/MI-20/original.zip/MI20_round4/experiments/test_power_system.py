"""Optional floating-point consistency checks; NOT certificate acceptance."""
from pathlib import Path
import json
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(20260913)

def herm(A):return (A+A.conj().T)/2

def powm(A,s):
    e,U=np.linalg.eigh(herm(A))
    if np.min(e)<=0:raise ValueError('A strictly positive matrix was required')
    return herm((U*(e**s))@U.conj().T)

def spd(n,complex_case):
    X=rng.normal(size=(n,n))
    if complex_case:X=X+1j*rng.normal(size=(n,n))
    U,_=np.linalg.qr(X)
    return herm((U*rng.uniform(.7,1.8,n))@U.conj().T)

def relative(A,B):return float(np.linalg.norm(A-B)/max(1,np.linalg.norm(A),np.linalg.norm(B)))

def run():
    checks=0;max_error=0.;minimum_sum_margin=float('inf');minimum_furuta_margin=float('inf');cases=[]
    for kappa in (1.05,1.2,1.5,2.,3.,5.):
        for m,n,complex_case in ((2,2,False),(2,3,True),(3,3,True)):
            G=[spd(n,complex_case) for _ in range(m)]
            T=sum(powm(g,kappa-1) for g in G);S=sum(powm(g,kappa) for g in G)
            Th=powm(T,.5);Ti=powm(T,-.5)
            D=herm(Ti@powm(Th@S@Th,.5)@Ti)
            Dh=powm(D,.5);Di=powm(D,-.5)
            H=[herm(Di@g@Di) for g in G]
            err=relative(D@T@D,S);assert err<1e-10;checks+=1;max_error=max(max_error,err)
            margin=float(np.linalg.eigvalsh(herm(m*D-sum(H)))[0]);assert margin>-1e-9;checks+=1;minimum_sum_margin=min(minimum_sum_margin,margin)
            a=[herm(Dh@powm(g,kappa-1)@Dh) for g in G];A=sum(a)
            z=float(np.trace(D@D@T).real);K=pow(z,1/(2*kappa))*np.linalg.inv(D)
            r=kappa/(kappa-1);N=z**((2*kappa-1)/(2*kappa))
            alpha=float(np.trace(A@np.linalg.inv(K)).real)
            beta=sum(float(np.trace(powm(powm(aj,.5)@K@powm(aj,.5),r)).real) for aj in a)**(1/r)
            assert abs(alpha/N-1)<1e-9 and abs(beta/N-1)<1e-9;checks+=2
            gradient=np.zeros_like(D)
            for aj,g in zip(a,G):
                ah=powm(aj,.5)
                L=ah@powm(ah@np.linalg.inv(D)@ah,1/(kappa-1))@ah
                R=Dh@powm(g,kappa)@Dh
                err=relative(L,R);assert err<1e-8;checks+=1;max_error=max(max_error,err)
                gradient+=beta**(1-r)*(ah@powm(ah@K@ah,r-1)@ah)
            err=relative(gradient,np.linalg.inv(K)@A@np.linalg.inv(K));assert err<1e-8;checks+=1;max_error=max(max_error,err)
            # Special Furuta inequality on a separate arbitrary noncommuting pair.
            DD=spd(n,complex_case);B=spd(n,complex_case);h=1.3
            B=B*h/(1.15*np.linalg.eigvalsh(B)[-1]);GG=herm(DD@B@DD)
            X=powm(powm(DD,.5)@powm(GG,kappa-1)@powm(DD,.5),1/(2*kappa-1))
            margin=float(np.linalg.eigvalsh(herm(h**((kappa-1)/(2*kappa-1))*DD-X))[0]);assert margin>-1e-8;checks+=1;minimum_furuta_margin=min(minimum_furuta_margin,margin)
            # Commuting positive solutions H_j=D give Lambda=2^(2*kappa-1).
            left=powm(2*DD,2*kappa-1)
            right=2**(2*kappa-1)*powm(DD,.5)@powm(DD@DD,kappa-1)@powm(DD,.5)
            err=relative(left,right);assert err<1e-8;checks+=1;max_error=max(max_error,err)
            cases.append(dict(kappa=kappa,m=m,n=n,complex=complex_case))
    return dict(status='PASS',scope='Optional numerical consistency, not proof acceptance',cases=cases,scalar_checks=checks,maximum_relative_residual=max_error,minimum_sum_constraint_margin=minimum_sum_margin,minimum_special_Furuta_margin=minimum_furuta_margin)

if __name__=='__main__':print(json.dumps(run(),indent=2))
