# Proof status and audit boundaries

## Completed written arguments

1. **Exact classical lower-bound certificate.** The concrete three-by-three pair is normal, has squared matching distance `28/13`, and squared spectral norm `27/13`. The rank-one Gram identity and the six finite matching costs are also checked symbolically. This establishes a lower bound only.

2. **Hall min-max identity.** A bottleneck matching distance equals the maximum cross-gap over sets whose cardinalities sum to `n+1`. The proof uses a closed edge threshold and the strict gap produced by a Hall deficiency. Multiplicities remain separate vertices.

3. **Full-unitary reformulation.** The matrix difference is represented as `D_alpha U - U D_beta`; taking all Hall witnesses gives the exact variational expression for the same universal constant. The denominator is the norm of the full matrix.

4. **Rectangular-compression consequence.** A `p` by `q` block of an `n` by `n` unitary has at least `p+q-n` singular values equal to one when this number is positive. The Frobenius gap estimate and singular-value monotonicity then give the truncated bound. The resulting dimension-dependent spectral-norm bound does not solve the universal question.

5. **Two-distinct-eigenvalue subclass.** Normality gives disk coverage and subspace-intersection counts. With just two spectral types, those counts suffice to construct a matching of distance at most the matrix difference norm. The proof includes the scalar case.

6. **Replication, padding, and exact global realizations.** Replication preserves the threshold graph's Hall deficiencies. Sufficiently distant common padding preserves ratios. Realification preserves the full norm by producing a direct sum of a difference and its transpose, and preserves the spectral matching through duplication. A shifted block construction preserves every original ratio in a balanced-reflection pair. These constructions enlarge the dimension; none bounds it.

7. **Balanced pinching formulation.** For a self-adjoint unitary `J=2P-I`, the difference is twice the block-diagonal pinching of the normal matrix. The exact reflected-pair construction proves equality of the resulting supremum with the original constant. Zero denominators are excluded.

8. **Failure of an operator-norm shortcut.** An exact two-by-two example disproves the claim that entrywise spectral separation lower-bounds a Sylvester image in spectral norm by the same separation times the original norm. The corresponding full normal completion is obstructed by the Hermitian-part matching inequality.

## Missing claims — none may be inferred from the above

- No universal inequality with coefficient `sqrt(28/27)` is proved.
- No global optimum in dimension three is proved.
- No theorem says a rank-one reflection suffices for the global constant.
- No theorem says `c_n` stabilizes in a finite dimension.
- No reverse sharpness implication is proved from an optimal Schur-multiplier or auxiliary Fourier bound to the normal-matrix matching problem.
- No global covering, interval-arithmetic optimization, sum-of-squares certificate, or unbounded-dimension compactness argument is provided for the search parameter space.

## Precise candidate proof obligation

For all `n`, all complex lists `alpha,beta`, all unitary `U`, and all positive `p,q` with `p+q=n+1`, establish

\[
\|D_\alpha U-U D_\beta\|_2^2\ge
\frac{27}{28}\min_{i\le p,j\le q}|\alpha_i-\beta_j|^2.
\]

Together with the lower certificate, this would settle the candidate value. It remains unproved and is not asserted to be correct. A different exact value would require a different universal bound with matching sharpness evidence.

## Computational audit boundaries

- `verify_exact.py` checks explicit algebraic identities; it is not a proof assistant formalizing the entire report.
- `test_results.py` checks numerical instances of statements that have written proofs. Passing those tests is not the reason those statements are asserted generally.
- `search.py` uses finite parameter bounds and a local optimizer. A success flag describes its stopping criteria, not global optimality.
- `audit_saved_results.py` recomputes recorded numerical quantities and their consistency with saved parameters. It does not turn floating-point search results into exact certificates.
- Search failures and random starts that miss the known example remain in the data. No new extremal example or improved universal bound was found.

No novelty, external peer review, or exhaustive literature coverage is claimed.
