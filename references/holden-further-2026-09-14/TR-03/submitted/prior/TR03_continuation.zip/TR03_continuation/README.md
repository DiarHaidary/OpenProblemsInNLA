# TR-03 continuation

**This archive is not a full solution of TR-03.** The sharp joint dependence
on n and k, over all finite positive spectra, remains unproved here.

The main report is `TR03_continuation.pdf`; its editable source is
`TR03_continuation.tex`. The original uploaded analysis package is retained
unchanged under `prior/TR03_analysis/`.

## Main proved claims in the report

Write m=n-k and s=min(k,m).

1. A quantitative real Plücker inequality yields
   F(n,r) <= r + (5/6)r(n-r), for 2 <= r <= n-2. Consequently
   R(n,k) >= 6(k+1)/(5k+6) >= 9/8 in the interior.
2. A Gaussian augmentation and row-multiset construction yields
   H_n(n,r) >= c0*n*sqrt(min(r,n-r)), where c0=2^-74 is sufficient.
   This also lower-bounds the unregularized frame minimax F.
3. Every finite two-level spectrum (L repeated k times, 1 repeated m times)
   has y/x <= 2^75*sqrt(s), uniformly for L >= 1.
4. For any fixed positive tail sigma, when the equal leading k eigenvalues
   tend to infinity, the limiting ratio is at most C*sqrt(s), with an
   explicit universal (extremely large) C.

The last two statements are bounds for specified spectral families, NOT an
upper bound over arbitrary finite positive spectra. A lower bound on F does
NOT establish a growing lower bound for R. These distinctions are explicit
in the report.

## Reproduce the checks

```sh
python -m pip install -r requirements.txt
python code/verify_continuation.py
```

The deterministic seed is 20260913. The recorded run passed all thirteen
check groups. The code checks exact symbolic reductions, matrix identities,
finite examples, and one distribution sanity comparison. It is not a
proof assistant, a global optimizer, or a numerical verification of rare
probability events. Full details are in `results/continuation_verification.json`.

To build the PDF, install a LaTeX distribution with the packages named in
the source, then run `pdflatex TR03_continuation.tex` twice.

## Files and provenance

- `TR03_continuation.pdf`, `.tex`: continuation report and source.
- `verification_table.tex`: table generated from the recorded verification JSON.
- `code/continuation.py`: matrix and frame utilities.
- `code/verify_continuation.py`: reproducible checks.
- `results/`: recorded check outputs and any audit logs.
- `sources.md`: primary-source website references.
- `prior/TR03_analysis/`: unchanged earlier report, source, code, and results.
- `SHA256SUMS`: checksums for the continuation archive (excluding itself).

No claim of novelty, independent human review, or formal certification is
made. The new proofs are written as mathematical arguments; uncertainty
about full problem completion is not concealed by the numerical checks.
