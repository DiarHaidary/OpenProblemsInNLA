#!/usr/bin/env python3
"""Check every retained file against the release manifest."""
import hashlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'MANIFEST.sha256.json'
def retained(p):
    return p.is_file() and p!=MANIFEST and '__pycache__' not in p.parts and p.suffix!='.pyc'
def main():
    expected=json.loads(MANIFEST.read_text())['files']
    actual={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in ROOT.rglob('*') if retained(p)}
    missing=sorted(set(expected)-set(actual)); extra=sorted(set(actual)-set(expected))
    changed=sorted(k for k in set(expected)&set(actual) if expected[k]!=actual[k])
    passed=not(missing or extra or changed)
    print(json.dumps({'status':'PASS' if passed else 'FAIL','checked_files':len(expected),
                      'missing':missing,'extra':extra,'changed':changed},indent=2))
    return 0 if passed else 1
if __name__=='__main__':sys.exit(main())
