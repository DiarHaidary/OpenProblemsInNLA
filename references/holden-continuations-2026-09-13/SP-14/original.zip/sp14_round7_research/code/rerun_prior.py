#!/usr/bin/env python3
"""Rerun nested prior validation suites without changing their archived bytes."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def safe_extract(z: zipfile.ZipFile, destination: Path) -> None:
    root=destination.resolve()
    for member in z.infolist():
        target=(destination/member.filename).resolve()
        if root not in target.parents and target!=root:
            raise ValueError('Unsafe member path: '+member.filename)
    z.extractall(destination)

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-dir',type=Path,default=None)
    args=parser.parse_args()
    work=args.work_dir or Path(tempfile.mkdtemp(prefix='sp14-prior-'))
    work.mkdir(parents=True,exist_ok=True)
    archive=ROOT/'previous/sp14_round6_research_original.zip'
    output=[]
    for iteration in range(6):
        sha=digest(archive)
        dest=work/f'level-{iteration+1}'
        dest.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(archive) as z:
            bad=z.testzip()
            if bad:raise RuntimeError(f'Corrupt ZIP member: {bad}')
            safe_extract(z,dest)
        scripts=list(dest.glob('*/code/validate.py'))
        if len(scripts)!=1:raise RuntimeError(f'Expected one suite, got {scripts}')
        script=scripts[0];package=script.parents[1]
        env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
        proc=subprocess.run([sys.executable,str(script)],cwd=package,env=env,
                            capture_output=True,text=True,timeout=180)
        (work/f'level-{iteration+1}.stdout.txt').write_text(proc.stdout)
        (work/f'level-{iteration+1}.stderr.txt').write_text(proc.stderr)
        reports=list((package/'results').glob('*validation*.json'))
        exact=package/'results/validation.json'
        if exact.exists():reportpath=exact
        else:
            if len(reports)!=1:raise RuntimeError(f'Cannot identify validation report: {reports}')
            reportpath=reports[0]
        report=json.loads(reportpath.read_text())
        def get_count(keys):
            for key in keys:
                if key in report:
                    v=report[key]
                    if isinstance(v,(int,float)): return int(v)
            checks=report.get('checks',[])
            if isinstance(checks,list):
                if 'total' in keys:return len(checks)
                if 'passed' in keys:return sum(bool(c.get('passed',False)) for c in checks)
                if 'failed' in keys:return sum(not bool(c.get('passed',False)) for c in checks)
            return None
        entry={'archive_name':archive.name,'sha256_before':sha,'sha256_after':digest(archive),
               'returncode':proc.returncode,'package':package.name,
               'total':get_count(['total','checks_total']),
               'passed':get_count(['passed','checks_passed']),
               'failed':get_count(['failed','checks_failed'])}
        output.append(entry)
        print(json.dumps(entry),flush=True)
        if proc.returncode!=0:raise RuntimeError('A prior suite failed; see logs.')
        nested=list((package/'previous').glob('*.zip'))
        if iteration<5:
            if len(nested)!=1:raise RuntimeError(f'Expected one nested archive: {nested}')
            archive=nested[0]
    final={'scope':'Separate consistency-suite reruns in extracted working copies; not independent mathematical review. No archived bytes changed.',
           'suites':output,'all_archives_unchanged':all(e['sha256_before']==e['sha256_after'] for e in output)}
    (ROOT/'results/prior_rerun.json').write_text(json.dumps(final,indent=2))

if __name__=='__main__':main()
