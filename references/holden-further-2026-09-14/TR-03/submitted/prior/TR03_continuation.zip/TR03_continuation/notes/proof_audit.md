# Proof-dependency and scope audit

This is a mathematical dependency map for the written report, not a formal
verification certificate. All inequalities below use the real field.

## Quantitative global gap

The six maximal minors in each Johnson octahedron satisfy a three-term real
Plücker relation. Taking absolute values makes the largest of the three
complementary products the sum of the other two. The exact constrained
quadratic minimization gives the local Rayleigh constant 10/3. The patch
multiplicities are (r-1)(n-r-1) per edge and C(r,2)C(n-r,2) per vertex.
The resulting global energy constant is r(n-r)/6. Averaging the basis costs
with weights equal to the FOURTH powers of the minors, not their squares,
gives the claimed frame upper bound. Zero minors receive zero averaging
weight; singular bases retain infinite cost.

## Gaussian construction

The augmentation proof uses a uniform kernel subspace; it does not claim
that a particular kernel basis is orthonormal. Its constrained minimum is
basis-invariant. The Wishart translation comparison needs a nonnegative
determinant exponent, so a square Gaussian matrix is first augmented by one
column. Repeated rows are handled by conditioning on all heavy row types
and compressing away their span; treating repetitions as independent would
be invalid. Whitening is compared in ROW Gram order. Padding is compared
in COLUMN Gram order before using equality of the square Gram spectra.
The union bound includes all row multisets, not only distinct subsets.

## Unequal tails

The weighted Haar bound uses positive-semidefinite order and the convex hull
of fixed-rank projectors before the conditional beta-integral estimate.
The light-tail thresholds ensure both required trace-to-operator-norm ratios
are at least 16. For k >= m, the number of matrix types, not the number of
coordinate subsets, makes the union bound independent of the aspect ratio.
For k <= m <= 3k, the ordinary subset count suffices. For m >= 3k, the group
construction has exactly the prescribed positive tail spectrum; every group
contrast eigenvalue is retained, and all group-nullvector coordinates are
nonzero. Repeated selected groups have infinite limiting cost. For distinct
groups, the row-amplitude factors cancel exactly from the residual formula.

## Direction and limits

- The maximum over eigenvectors precedes the minimum over subsets.
- The infinite-leading limit follows from monotonicity, compactness, and
  evaluation at a maximizing frame; no unproved uniform convergence is used.
- A frame UPPER bound gives a LOWER bound on the flat limiting ratio and R.
- A frame LOWER bound gives an UPPER bound on that limiting ratio only.
- Neither two-level control nor arbitrary-tail infinite-leading control is
  a bound over arbitrary finite spectra.
- No theorem here proves that two-level spectra are extremal.
- No theorem here establishes the sharp joint order of R(n,k).

The report's conclusion and README state these limitations explicitly.
