"""Exact regression tests, including literal noncommuting matrix products."""
from pathlib import Path
from fractions import Fraction as F
import copy,json,sys,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent/'legacy'))
from exact_arithmetic import positive_definite,sparse_model,gram_coefficients
from homogeneous_model import model,canon,interval_equations
from verify_interval import verify
from global_bound_chain import verify as verify_chain

def add(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def scale(a,t):return [[t*x for x in row] for row in a]
def mul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
def trans(a):return list(map(list,zip(*a)))
def trace(a):return sum(a[i][i] for i in range(len(a)))
def eye(n):return [[F(int(i==j)) for j in range(n)] for i in range(n)]
def power(a,n):
    b=eye(len(a))
    for _ in range(n):b=mul(b,a)
    return b

def psd(a):
    a=copy.deepcopy(a)
    for k in range(len(a)):
        if a[k][k]<0:return False
        if a[k][k]==0:
            if any(a[k][i]!=0 or a[i][k]!=0 for i in range(k+1,len(a))):return False
            continue
        for i in range(k+1,len(a)):
            for j in range(i,len(a)):a[j][i]=a[i][j]=a[i][j]-a[i][k]*a[k][j]/a[k][k]
    return True

class ArithmeticTests(unittest.TestCase):
    def test_pd_accept(self):self.assertTrue(positive_definite([[F(2),F(1)],[F(1),F(3)]]))
    def test_pd_reject(self):
        with self.assertRaises(ValueError):positive_definite([[F(1),F(2)],[F(2),F(1)]])
    def test_nonsymmetric_reject(self):
        with self.assertRaises(ValueError):positive_definite([[F(2),F(1)],[F(0),F(2)]])
    def test_word_order_preserved(self):self.assertNotEqual(canon((0,0,1,1)),canon((0,1,0,1)))

class IntervalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.data=json.loads((ROOT/'certificates/interval_d6_861_100.json').read_text())
    def reject(self,change,cap=F(43983,5000)):
        d=copy.deepcopy(self.data);change(d)
        with self.assertRaises((ValueError,KeyError)):verify(d,cap)
    def test_accept_interval(self):
        r=verify(self.data,F(43983,5000));self.assertEqual(r['universal_upper_fourth_power'],'861/800')
    def test_reject_scope(self):self.reject(lambda d:d.update(scope='all p'))
    def test_reject_format(self):self.reject(lambda d:d.update(format='other'))
    def test_reject_unsupported_h(self):self.reject(lambda d:d.update(h='1'))
    def test_reject_uncovered_cap(self):self.reject(lambda d:d.update(right='87/10'))
    def test_reject_bad_order(self):self.reject(lambda d:d.update(left='9'))
    def test_reject_float(self):self.reject(lambda d:d.update(h=1.1855))
    def test_reject_bool_degree(self):self.reject(lambda d:d.update(degree=True))
    def test_reject_missing_gram(self):self.reject(lambda d:d['gram_matrices'].pop())
    def test_reject_nonsymmetric(self):self.reject(lambda d:d['gram_matrices'][0][0].__setitem__(1,'1'))
    def test_reject_negative_gram(self):self.reject(lambda d:d['gram_matrices'][0][0].__setitem__(0,'-1'))
    def test_reject_coefficient_change(self):
        self.reject(lambda d:d['gram_matrices'][0][0].__setitem__(0,str(F(d['gram_matrices'][0][0][0])+1)))
    def test_reject_normalization(self):self.reject(lambda d:d['multipliers'].__setitem__(-1,'0'))
    def test_reject_missing_multiplier(self):self.reject(lambda d:d['multipliers'].pop())
    def test_reject_false_preceding_cap(self):self.reject(lambda d:None,F(483,50))

class PredecessorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.data=json.loads((ROOT/'certificates/predecessor_cubic_chain.json').read_text())
    def test_accept_chain(self):self.assertEqual(verify_chain(self.data)['reported_lambda_upper'],'43983/5000')
    def test_wrong_exception_regression(self):
        d=copy.deepcopy(self.data);d['scope']='all m'
        with self.assertRaises(ValueError):verify_chain(d)
    def test_missing_prior_stage_rejected(self):
        d=copy.deepcopy(self.data);d['stages']=[d['stages'][-1]]
        with self.assertRaises(ValueError):verify_chain(d)
    def test_unjustified_report_rejected(self):
        d=copy.deepcopy(self.data);d['reported_lambda_upper']='8'
        with self.assertRaises(ValueError):verify_chain(d)

class LiteralProductTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.X=[[[F(3),F(0)],[F(0),F(2)]],[[F(1),F(1,4)],[F(1,4),F(1)]],[[F(1,2),F(-1,5)],[F(-1,5),F(1,3)]]]
        cls.md=model();cls.cache={}
        def product(w):
            w=tuple(w)
            if w not in cls.cache:
                a=eye(2)
                for j in w:a=mul(a,cls.X[j])
                cls.cache[w]=a
            return cls.cache[w]
        cls.word=staticmethod(product)
        cls.y=[trace(product(w)) for w in cls.md['keys']]
    def ev(self,v):return sum(a*b for a,b in zip(v,self.y))
    def test_every_canonical_word(self):
        from itertools import product
        index={w:i for i,w in enumerate(self.md['keys'])}
        for w in product(range(3),repeat=6):self.assertEqual(trace(self.word(w)),self.y[index[canon(w)]])
    def test_cubic_and_stationarity_coefficients(self):
        D,H1,H2=self.X;lam=F(861,100)
        g=[add(power(add(D,H),3),scale(mul(mul(D,H),D),-lam)) for H in (H1,H2)]
        f=add(add(mul(mul(H1,D),H1),mul(mul(H2,D),H2)),scale(mul(mul(D,add(H1,H2)),D),-1))
        direct=[]
        for poly in g+[f]:
            direct.extend(trace(mul(self.word(w),poly)) for w in self.md['multiplier_words'])
        direct.append(trace(power(D,6)))
        self.assertEqual([self.ev(v) for v in self.md['equations']],direct)
    def test_every_gram_entry_literal_and_psd(self):
        direct=[];words=self.md['main_words']
        direct.append([[trace(mul(trans(self.word(u)),self.word(v))) for v in words] for u in words])
        weights=[]
        for w in self.md['weights']:
            A=[[F(0),F(0)],[F(0),F(0)]]
            for i,c in w:A=add(A,scale(self.X[i],c))
            positive_definite(A);weights.append(A)
        words=self.md['local_words']
        for i in range(len(weights)):
            for j in range(i,len(weights)):
                direct.append([[trace(mul(mul(mul(trans(self.word(u)),weights[i]),self.word(v)),weights[j])) for v in words] for u in words])
        for symbolic,literal in zip(self.md['matrices'],direct):
            self.assertEqual([[self.ev(cell) for cell in row] for row in symbolic],literal)
            self.assertTrue(psd(literal))
    def test_noncommuting_example_is_genuine(self):self.assertNotEqual(mul(self.X[0],self.X[1]),mul(self.X[1],self.X[0]))

if __name__=='__main__':unittest.main(verbosity=2)
