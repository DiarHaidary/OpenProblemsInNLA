"""Optional generation of the saved finite moment coreset.

Uses an LP to choose a support, then solves and verifies weights over the rationals.
Not an implementation of the asymptotic construction. This overwrites the local
certificate JSON; a different LP basis may change its fractions while staying valid.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction
import numpy as np
import sympy as sp
from scipy.optimize import linprog
import json
ROOT=Path(__file__).resolve().parents[1]
rows=[(1,t,u) for t in range(-4,5) for u in range(-4,5)]
indices=[(8-a-b,a,b) for a in range(9) for b in range(9-a)]
mat=[[int(np.prod([int(x)**j for x,j in zip(row,alpha)])) for row in rows] for alpha in indices]
A=np.array(mat,dtype=float); target=A.sum(axis=1)
scale=np.max(np.abs(A),axis=1)
rng=np.random.default_rng(9052026)
res=linprog(rng.normal(size=len(rows)),A_eq=A/scale[:,None],b_eq=target/scale,bounds=(0,None),method='highs-ds')
assert res.success,res.message
support=np.flatnonzero(res.x>1e-7).tolist()
B=sp.Matrix([[row[i] for i in support] for row in mat]); y=sp.Matrix([sum(row) for row in mat])
sol,pars=B.gauss_jordan_solve(y)
assert len(pars)==0
assert all(w>0 for w in sol)
assert B*sol==y
weights=[Fraction(0) for i in rows]
for i,w in zip(support,sol):weights[i]=Fraction(int(sp.numer(w)),int(sp.denom(w)))
q=(1,2,-1); qq=sum(x*x for x in q)
resids=[Fraction(sum(x*x for x in row))-Fraction(sum(x*y for x,y in zip(row,q))**2,qq) for row in rows]
costs={str(p):{'original':str(sum(x**(p//2) for x in resids)), 'coreset':str(sum(w*x**(p//2) for w,x in zip(weights,resids)))} for p in [2,4,6,8]}
for v in costs.values():assert v['original']==v['coreset']
probes=[]
for normal in [(0,1,0),(0,1,2),(1,2,-1),(1,1,1)]:
    orig=sum(abs(sum(x*y for x,y in zip(row,normal)))**3 for row in rows)
    weighted=sum(w*abs(sum(x*y for x,y in zip(row,normal)))**3 for row,w in zip(rows,weights))
    if weighted != orig:
        probes.append({'normal':normal,'original_unnormalized_cubic_cost':str(orig),'coreset_unnormalized_cubic_cost':str(weighted),'relative_error':str(abs(weighted-orig)/orig)})
assert probes
cert={'description':'Exact degree-eight original-row moment reduction; not an implementation of asymptotic partial coloring.', 'rows':rows,'input_rank':3,'original_count':len(rows),'support_count':len(support),'support_indices_zero_based':support,'weights':[str(w) for w in weights], 'exact_moment_degree':8,'all_even_powers_preserved':[2,4,6,8], 'query_projector':{'type':'line','normal_or_direction':q,'denominator':qq,'rank':1}, 'costs':costs, 'non_even_nontransfer_probe':probes[0], 'non_even_scope':'This finite coreset need not preserve non-even powers exactly. This observation is not an asymptotic lower bound or an impossibility theorem for non-even coresets.'}
(ROOT/'results/exact_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
print('support',len(support),'largest denominator',max(w.denominator for w in weights),'costs',costs,'p3probe',probes[0])
