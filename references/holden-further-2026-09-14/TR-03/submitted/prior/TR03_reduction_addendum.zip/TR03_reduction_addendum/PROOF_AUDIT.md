# Proof audit

## Scope of this addendum

This is a partial mathematical continuation, not a completed solution. The new report supplies its own proofs and does not depend on the correctness of the interrupted round-three derivations.

## Points checked in the written arguments

1. The adversary fixes a single orientation before the subset is chosen.
2. The harmonic-block construction controls every allocation of the k selected indices between the block and its complement.
3. The spectral balance inequality uses inclusion probabilities only for a diagonal-product distribution; it does not assume the matrix eigenvectors are diagonal in the original minimax problem.
4. The finite-limit comparison treats singular limiting principal submatrices separately.
5. The increasing limit is interchanged only with a finite minimum and two suprema; no false compactness argument at singular matrices is required.
6. The conditional reduction requires a rectangular, oversampled, weighted limiting theorem, not merely the earlier square-frame statement.
7. The conditional conclusion is O(sqrt(k)); it is not claimed to establish O(sqrt(min(k,n-k))) in every aspect ratio.
8. No dimension-dependent matching lower bound for R is supplied.

## Tool and provenance limitation

File-reading and browsing attempts in this run did not yield readable tool responses. Consequently the live statement was not freshly confirmed, the interrupted proofs were not audited, and recorded runtime verification output was not independently read back by the assistant. The package-building and verification scripts make their actions and results inspectable. No claim of elapsed research time, successful peer review, formal verification, or complete resolution is made.
