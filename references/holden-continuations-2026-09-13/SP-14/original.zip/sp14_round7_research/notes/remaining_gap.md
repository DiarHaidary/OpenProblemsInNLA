# Exact remaining problem

For a in C(T), put rho_+ = limsup |a_k|^(1/k), rho_- = limsup |a_-k|^(1/k), and
E_n = integral |a|^2 dm - (1/n) sum |lambda_j(T_n(a))|^2.

The universal implication rho_+ = rho_- = 1 => E_n -> 0 remains unproved.

Even for a Jordan-curve range of winding +/-1, the new theorem proves only liminf E_n = 0. The missing assertion is limsup E_n = 0. Thus a counterexample in this subclass would have to exhibit actual nonconvergence: it would have a canonical weak cluster law and at least one other weak cluster law, not an entire sequence converging to a single noncanonical measure.

A direct next target is to exclude an open-region logarithmic potential deficit along any subsequence of the unperturbed finite sections. The inverse-row localization proved here only excludes a deficit that imposes an eventual exponential envelope on every corner order. It does not extend that conclusion to arbitrary subsequences.

For general ranges there are additional issues: absolute winding greater than one gives a boundary determinant of fixed size greater than one, several nonzero-index components require simultaneous control, and positive-area ranges may lack the measure uniqueness used in the Jordan argument.

## Attempted bridges not promoted to theorems

The scalar spectral parameter in the stable core supplies a unit-step shift in an inverse expansion, but no noncancellation inequality was established for arbitrary complex phases. Analytic dependence on the spectral parameter alone does not upgrade pointwise limsup equality to a full limit. Neither a principal-submatrix interlacing law nor an almost-superadditive spectral-energy law is available for arbitrary nonnormal Toeplitz sections; no such law is assumed here. Banded approximation and small perturbation conclusions from earlier packages remain distinct from the unperturbed full-sequence target.
