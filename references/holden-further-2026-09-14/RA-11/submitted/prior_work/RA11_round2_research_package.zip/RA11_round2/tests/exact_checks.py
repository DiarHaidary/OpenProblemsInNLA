#!/usr/bin/env python3
"""Finite exact checks of the identities used in the round-2 proof.

SymPy checks use Gaussian-rational arithmetic. Exhaustive phase checks use
bounded int64 real/imaginary pairs; an explicit absolute-value bound verifies
that no integer accumulator can overflow. These are finite checks, not proofs
of the quantified theorem.
"""
from __future__ import annotations
import json
from fractions import Fraction
from itertools import combinations, product
from math import comb, ceil
from pathlib import Path
import sys
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from ra11_hierarchy import theorem_schedule

records=[]
def report(name, **data):
    records.append({'check':name,'passed':True,**data})

def subs(q):
    return [tuple(s) for k in range(q+1) for s in combinations(range(q),k)]

def pt(A,n,q,S):
    S=tuple(S); outside=tuple(i for i in range(q) if i not in S)
    d=n**len(S); B=sp.zeros(d,d)
    inside=list(product(range(n),repeat=len(S)))
    outs=list(product(range(n),repeat=len(outside)))
    def idx(x):
        z=0
        for a in x:z=n*z+a
        return z
    for a,I in enumerate(inside):
        for b,J in enumerate(inside):
            for O in outs:
                ii=[0]*q;jj=[0]*q
                for h,i in enumerate(S):ii[i]=I[h];jj[i]=J[h]
                for h,i in enumerate(outside):ii[i]=jj[i]=O[h]
                B[a,b]+=A[idx(ii),idx(jj)]
    return B

def lift(A,n,q,S):
    S=tuple(S); O=tuple(i for i in range(q) if i not in S)
    tuples=list(product(range(n),repeat=q)); B=sp.zeros(n**q,n**q)
    def idx(x):
        z=0
        for a in x:z=n*z+a
        return z
    for i,I in enumerate(tuples):
        for j,J in enumerate(tuples):
            if all(I[h]==J[h] for h in O):
                B[i,j]=A[idx([I[h] for h in S]),idx([J[h] for h in S])]/n**len(O)
    return B

def inner(A,B):return sp.expand(sp.trace(A.conjugate().T*B))
def f2(A):return inner(A,A)
def hermitian(d,seed):
    rng=np.random.default_rng(seed)
    X=sp.Matrix(rng.integers(-3,4,(d,d)).tolist())+sp.I*sp.Matrix(rng.integers(-3,4,(d,d)).tolist())
    return X+X.conjugate().T

def all_zero(A):return all(sp.expand(x)==0 for x in A)

def symplectic_checks():
    checked=0; ordered=0
    for n,q in [(2,2),(2,3),(3,2)]:
        R=hermitian(n**q,10*n+q)
        for S in subs(q):
            ES=lift(pt(R,n,q,S),n,q,S)
            assert all_zero(lift(pt(ES,n,q,S),n,q,S)-ES)
            e=hermitian(n**len(S),44+len(S)) / 7
            Rnew=R-ES+lift(e,n,q,S)
            assert all_zero(pt(Rnew,n,q,S)-e)
            for T in subs(q):
                ETES=lift(pt(ES,n,q,T),n,q,T)
                EST=lift(pt(R,n,q,tuple(sorted(set(S)&set(T)))),n,q,tuple(sorted(set(S)&set(T))))
                assert all_zero(ETES-EST)
                first=pt(R-ES,n,q,T); second=pt(lift(e,n,q,S),n,q,T)
                assert inner(first,second)==0
                assert f2(pt(Rnew,n,q,T))==f2(first)+f2(second)
                assert f2(second)<=sp.Rational(n)**(len(S)-len(T))*f2(e)
                if len(T)>=len(S):
                    assert f2(pt(Rnew,n,q,T))<=f2(pt(R,n,q,T))+f2(e)
                    ordered+=1
                checked+=1
    report('Commuting partial expectations and Pythagorean updates',pairs=checked,descending_pairs=ordered,arithmetic='Gaussian rational')

def interpolation_checks():
    for q in range(2,7):
        n=2;N=n**q;rng=np.random.default_rng(100+q)
        M=sp.Matrix(rng.integers(-2,3,(N,N)).tolist())
        A=[sp.Matrix(rng.integers(-2,3,n).tolist()) for _ in range(q)]
        B=[sp.Matrix(rng.integers(-2,3,n).tolist()) for _ in range(q)]
        target=M*sp.kronecker_product(*[a+sp.I*b for a,b in zip(A,B)])
        recovered=sp.zeros(N,1)
        for j in range(q+1):
            w=sp.prod((sp.I-h)/sp.Rational(j-h) for h in range(q+1) if h!=j)
            recovered+=w*M*sp.kronecker_product(*[a+j*b for a,b in zip(A,B)])
        assert all_zero(recovered-target)
    report('Complex product interpolation',orders=list(range(2,7)),real_calls_per_complex='q+1',arithmetic='Gaussian rational')

# Gaussian-integer pairs: (real, imaginary), all arrays int64.
# Check every pair-arithmetic reduction in Python integers before executing it.
# The strict 2**60 ceiling leaves room for subsequent small additions.
INTEGER_GUARD = 2**60

def maxabs(A):
    if A.size == 0:
        return 0
    return max(abs(int(np.min(A))), abs(int(np.max(A))))

def pair_bound(A):
    assert A[0].dtype == np.int64 and A[1].dtype == np.int64
    assert A[0].shape == A[1].shape
    bound=max(maxabs(A[0]), maxabs(A[1]))
    assert bound < INTEGER_GUARD, 'Input exceeds exact int64 safety budget.'
    return bound

def mul(A,B):
    ar,ai=A;br,bi=B
    assert ar.ndim == 2 and br.ndim == 2 and ar.shape[1] == br.shape[0]
    bound=2*ar.shape[1]*pair_bound(A)*pair_bound(B)
    assert bound < INTEGER_GUARD, 'Gaussian-integer matrix product may overflow.'
    return ar@br-ai@bi, ar@bi+ai@br

def adj(A):
    pair_bound(A)
    return A[0].T,-A[1].T

def add(A,B):
    assert pair_bound(A)+pair_bound(B) < INTEGER_GUARD
    return A[0]+B[0],A[1]+B[1]
def phase_vectors(n,q):
    local=[np.array(z,dtype=complex) for z in product((1,-1,1j,-1j),repeat=n)]
    zs=[]
    for ff in product(local,repeat=q):
        z=np.array([1+0j])
        for f in ff:z=np.kron(z,f)
        zs.append(z)
    Z=np.column_stack(zs)
    return Z.real.astype(np.int64),Z.imag.astype(np.int64)

def complex_int_matrix(d,seed):
    rng=np.random.default_rng(seed)
    A=rng.integers(-3,4,(d,d),dtype=np.int64)
    B=rng.integers(-3,4,(d,d),dtype=np.int64)
    return A+A.T,B-B.T

def pt_pair(R,n,q,S):
    assert n**(q-len(S))*pair_bound(R) < INTEGER_GUARD
    def one(A):
        modes=list(range(q));T=A.reshape((n,)*(2*q))
        for mode in sorted(set(modes)-set(S),reverse=True):
            p=modes.index(mode);T=np.trace(T,axis1=p,axis2=p+len(modes));modes.remove(mode)
        return T.reshape((n**len(S),)*2)
    return one(R[0]),one(R[1])

def norm2pair(A):
    assert 2*A[0].size*pair_bound(A)**2 < INTEGER_GUARD
    return int(np.sum(A[0]*A[0]+A[1]*A[1]))

def phase_moment_checks():
    total=0; moments=0
    for n,q in [(2,1),(2,2),(2,3),(3,1)]:
        N=n**q;Z=phase_vectors(n,q);L=Z[0].shape[1]
        # Worst relevant scalar magnitude <= 12 N^2 and fourth aggregate
        # for vector tests <= L*(12 N)^4. All remain safely in int64.
        bound=L*max((12*N*N)**2,(12*N)**4)
        assert bound < 2**63
        R=complex_int_matrix(N,133+q+n)
        Y=mul(R,Z)
        valr=np.sum(Z[0]*Y[0]+Z[1]*Y[1],axis=0)
        vali=np.sum(Z[0]*Y[1]-Z[1]*Y[0],axis=0)
        assert np.all(vali==0)
        tr=int(np.trace(R[0]));assert int(np.sum(valr))==L*tr
        var=Fraction(int(np.sum((valr-tr)**2)),L)
        upper=sum(norm2pair(pt_pair(R,n,q,S)) for S in subs(q) if S)
        assert var<=upper
        covariance=mul(Z,adj(Z));assert np.array_equal(covariance[0],L*np.eye(N,dtype=np.int64));assert np.all(covariance[1]==0)
        proper=mul(Z,(Z[0].T,Z[1].T));assert np.all(proper[0]==0) and np.all(proper[1]==0)
        rng=np.random.default_rng(550+q)
        for _ in range(5):
            u=(rng.integers(-3,4,(N,1),dtype=np.int64),rng.integers(-3,4,(N,1),dtype=np.int64))
            val=mul(adj(u),Z);sq=val[0]**2+val[1]**2
            fourth=Fraction(int(np.sum(sq*sq)),L)
            assert fourth<=Fraction(2*n-1,n)**q*norm2pair(u)**2
            moments+=1
        flat=(np.ones((N,1),dtype=np.int64),np.zeros((N,1),dtype=np.int64))
        values=mul(adj(flat),Z);squared=values[0]**2+values[1]**2
        flat_fourth=Fraction(int(np.sum(squared*squared)),L)
        assert flat_fourth==Fraction(2*n-1,n)**q*N*N
        total+=L
        report('Exhaustive four-phase moments',n=n,q=q,phase_products=L,variance=str(var),variance_upper=upper,overflow_bound=bound)
    report('Phase moment total',phase_products=total,fourth_moment_cases=moments,arithmetic='bounded exact int64 real/imaginary pairs',pair_arithmetic_guard=INTEGER_GUARD)

def contraction_checks():
    from ra11_hierarchy import insertion_matrix
    n,q=2,3;N=n**q;R=complex_int_matrix(N,998);rows=0
    for S in subs(q):
        if not S or len(S)==q:continue
        outside=[i for i in range(q) if i not in S]
        local=[np.array(z,dtype=complex) for z in product((1,-1,1j,-1j),repeat=n)]
        mean=(np.zeros((n**len(S),)*2,dtype=np.int64),np.zeros((n**len(S),)*2,dtype=np.int64))
        target=pt_pair(R,n,q,S);sum_err=0;L=0
        for ff in product(local,repeat=len(outside)):
            Kc=insertion_matrix(n,q,S,dict(zip(outside,ff)))
            K=(Kc.real.astype(np.int64),Kc.imag.astype(np.int64))
            C=mul(adj(K),mul(R,K));mean=add(mean,C)
            err=(C[0]-target[0],C[1]-target[1])
            sum_err+=norm2pair(err);L+=1
        assert np.array_equal(mean[0],L*target[0]) and np.array_equal(mean[1],L*target[1])
        upper=sum(norm2pair(pt_pair(R,n,q,tuple(sorted(set(S)|set(J)))))
                  for k in range(1,len(outside)+1) for J in combinations(outside,k))
        assert Fraction(sum_err,L)<=upper
        rows+=L
        report('Unbiased outside contraction and noise bound',keep=list(S),samples=L,noise=str(Fraction(sum_err,L)),noise_upper=upper)
    report('Outside contraction total',samples=rows,arithmetic='bounded exact int64 pairs')

def column_subset_checks():
    F=sp.Matrix([[sp.I**(i*j)/2 for j in range(4)] for i in range(4)])
    Y=sp.diag(4,3,2,1)*F
    G=Y.conjugate().T*Y
    eigenvalues=[16,9,4,1]
    for r,k in [(1,2),(2,3)]:
        denom=0;numerator=0;errors=[]
        for I in combinations(range(4),k):
            C=Y[:,list(I)];H=C.conjugate().T*C;w=sp.expand(H.det())
            if w==0:continue
            P=C*H.inv()*C.conjugate().T
            err=f2(Y-P*Y)
            denom+=w;numerator+=w*err;errors.append(err)
        ek1=sum(sp.expand(G.extract(I,I).det()) for I in combinations(range(4),k+1))
        assert sp.simplify(numerator-(k+1)*ek1)==0
        expected=sp.simplify(numerator/denom)
        upper=sp.Rational(k+1,k-r+1)*sum(eigenvalues[r:])
        assert expected<=upper and min(errors)<=expected
        report('Column-subset volume identity and tail bound',rank_target=r,selected_columns=k,weighted_error=str(expected),upper=str(upper),minimum_error=str(min(errors)),arithmetic='Gaussian rational')

def interaction(A,n,q,V):
    B=sp.zeros(n**q,n**q)
    for k in range(len(V)+1):
        for T in combinations(V,k):
            B+=(-1)**(len(V)-k)*lift(pt(A,n,q,T),n,q,T)
    return B

def sympy_to_integer_pair(A):
    denominator=sp.ilcm(*[sp.denom(sp.re(x)) for x in A],*[sp.denom(sp.im(x)) for x in A])
    real_list=[[int(sp.re(x)*denominator) for x in row] for row in A.tolist()]
    imag_list=[[int(sp.im(x)*denominator) for x in row] for row in A.tolist()]
    assert all(abs(x) < INTEGER_GUARD for row in real_list+imag_list for x in row)
    real=np.array(real_list,dtype=np.int64)
    imag=np.array(imag_list,dtype=np.int64)
    return (real,imag),int(denominator)

def exact_outside_variance(R,n,q,S):
    from ra11_hierarchy import insertion_matrix
    RI,den=sympy_to_integer_pair(R)
    O=[i for i in range(q) if i not in S]
    target=pt_pair(RI,n,q,S)
    local=[np.array(z,dtype=complex) for z in product((1,-1,1j,-1j),repeat=n)]
    sum_err=0;L=0
    for ff in product(local,repeat=len(O)):
        Kc=insertion_matrix(n,q,S,dict(zip(O,ff)))
        K=(Kc.real.astype(np.int64),Kc.imag.astype(np.int64))
        C=mul(adj(K),mul(RI,K))
        sum_err+=norm2pair((C[0]-target[0],C[1]-target[1]));L+=1
    return Fraction(sum_err,L*den*den),L

def ownership_checks():
    n,q=2,3
    order=[S for size in range(q,0,-1) for S in combinations(range(q),size)]
    R=hermitian(n**q,901);errors={};prefix=[];ownership=0;draws=0
    for step,S in enumerate(order):
        if prefix:
            total=sum(f2(e) for e in errors.values())
            weighted=0
            for V in subs(q):
                if set(V)<=set(S):continue
                owner=next(U for U in reversed(prefix) if set(V)<=set(U))
                assert len(owner)<=len(set(S)|set(V))
                RV=interaction(R,n,q,V)
                assert all_zero(RV-interaction(lift(errors[owner],n,q,owner),n,q,V))
                weighted+=sp.Rational(n)**(q-len(set(S)|set(V)))*f2(RV)
                ownership+=1
            variance,L=exact_outside_variance(R,n,q,S);draws+=L
            assert sp.Rational(variance.numerator,variance.denominator)<=weighted<=total
            report('Interaction ownership noise bound',next_keep=list(S),outside_draws=L,exact_noise=str(variance),interaction_upper=str(weighted),sum_prior_errors=str(total),arithmetic='Gaussian rational plus bounded integer pairs')
        e=hermitian(n**len(S),1600+step)/(step+1)
        R=R-lift(pt(R,n,q,S),n,q,S)+lift(e,n,q,S)
        errors[S]=e;prefix.append(S)
    # Scalar phase variance at the end excludes the deterministic identity part.
    variance,L=exact_outside_variance(R,n,q,());draws+=L
    total=sum(f2(e) for e in errors.values())
    assert sp.Rational(variance.numerator,variance.denominator)<=total
    report('Final interaction variance budget',exact_variance=str(variance),sum_stage_errors=str(total),phase_products=L,arithmetic='Gaussian rational plus bounded integer pairs')
    report('Interaction ownership totals',component_checks=ownership,phase_products=draws)

def schedule_checks():
    for q in range(2,65):
        K=2**q-1;L=8*q+17;J=2**25
        assert 6*J<2**28 and 9*2**13<2**17 and L<=17*q
        assert Fraction(9*L,32)>=3+q
        for n in (2,3,10):
            h=Fraction(2*n-1,n);H=(1+h)**q-1
            assert sum(comb(q,s)*h**s for s in range(1,q+1))==H
            for eps in (Fraction(49,100),Fraction(1,10),Fraction(1,10**7)):
                schedule=theorem_schedule(n,q,eps)
                D=schedule['D'];r=schedule['r']
                assert (D-1)**2<H<=D**2
                rho=2**18*r
                assert Fraction(2**17,rho)+Fraction(2**17*K,2**18*K*r)==Fraction(1,r)
                if eps<=Fraction(1,D):
                    assert r<=Fraction(2,D)/eps
                    logical=2**64*L*K*H*r+schedule['residual_samples']
                else:
                    logical=schedule['plain_complex_samples']
                assert (q+1)*logical<=schedule['hierarchical_linear_envelope']
    report('Certified constants and refined combinatorial count',q_range=[2,64],n_values=[2,3,10],arithmetic='integer/rational')

if __name__=='__main__':
    symplectic_checks();interpolation_checks();phase_moment_checks();contraction_checks();column_subset_checks();ownership_checks();schedule_checks()
    out={'all_passed':True,'checks':records,'limitations':'Finite identities and small examples; not formal verification of the all-parameter theorem.'}
    path=ROOT/'results'/'exact_checks.json';path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
