# Primary sources and their roles

The following sources were checked through ordinary web access during
recovery on September 12, 2026. No GitHub plugin was used. These citations
provide the specification or stated background; they do not independently
certify the new arguments in the recovered manuscript.

1. **OpenProblemsInNLA, IE-20: Precision required for conjugate gradients
   to attain backward accuracy in n steps.**
   Repository page:
   https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/linear-systems-and-elimination/IE-20
   Readable source used when the directory page could not be fetched:
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/linear-systems-and-elimination/IE-20/README.md
   Role: exact problem specification, arithmetic envelope, operation order,
   input restrictions, stopping rule, true-residual criterion, and threshold
   quantifiers. The manuscript uses this editorial specialization.

2. **N. Amsel et al., Linear Systems and Eigenvalue Problems: Open Questions
   from a Simons Workshop**, arXiv:2602.05394v3, August 21, 2026.
   https://arxiv.org/html/2602.05394v3
   Role: Section 2.6, especially Problem 2.17; neighboring Problems 2.15 and
   2.16 discuss residuals and implementation dependence. The detailed IE-20
   conventions belong to the repository formulation, not a verbatim workshop
   specification.

3. **C. Musco, C. Musco, and A. Sidford, Stability of the Lanczos Method for
   Matrix Function Approximation**, SODA 2018; arXiv:1708.07788.
   https://arxiv.org/html/1708.07788
   Role: finite-precision approximation background. The discussion after
   its stable-polynomial lower bound explicitly distinguishes that result
   from a general lower bound on actual Lanczos or CG executions.

4. **S. Chenakkod, M. Derezinski, X. Dong, and M. Rudelson,
   Well-Conditioned Oblivious Perturbations in Linear Space**,
   arXiv:2604.23193, 2026.
   https://arxiv.org/html/2604.23193
   Role: a perturbed solver and an order-`n` matrix-vector-product guarantee.
   This is a different algorithm and iteration requirement from the fixed,
   unperturbed at-most-`n` recurrence in IE-20.

5. **M. Derezinski, Y. Nakatsukasa, and E. Rebrova,
   Towards Universal Convergence of Backward Error in Linear System
   Solvers**, arXiv:2604.16075, 2026.
   https://arxiv.org/html/2604.16075
   Role: Theorem 9 gives the MINBERR bound `3/(k^2-1)` for PSD systems.
   The source states that its theoretical convergence analysis is in exact
   arithmetic. Appendix A uses that result only for an exact-CG comparison.

The recovery check is not an exhaustive new literature or priority search.
The reason the archive is labeled partial is the mathematical parameter gap
in its own results, not merely the repository's status label.
