# Mathematical status

## Not a complete three-parameter solution

RA-11 requires Q(n,q,epsilon) up to **universal** constant factors simultaneously
in all three parameters, for arbitrary PSD matrices and adaptive real full-vector
product queries. This package does not establish a matching dependence on q.
Its correct scope is **partial resolution**.

## Established in the new manuscript

1. An all-PSD real-product-query upper bound
   `min(n**q, ceil(2**71*q*(q+1)*(2**q-1)*ceil(sqrt((3-1/n)**q-1))/epsilon))`,
   with success at least 5/6 and finite random bits.
2. A self-contained ordinary adaptive full-vector lower bound
   `min(n**q,1/epsilon)/80000`, sufficient to prove
   `Theta_q(min(n**q,1/epsilon))` for each fixed q.
3. Orthogonal interaction accounting that pays all later contraction noise and
   the final residual trace variance from the accumulated squared approximation
   errors. This works with indefinite complex Hermitian controls.
4. A finite-arithmetic noisy PSD approximation construction using only permitted
   random/basis input vectors, exhaustive column selection, and two-sided
   regression. No oracle call to an output-derived unstructured vector is used.
5. A restricted variance obstruction to global PSD Nyström residual estimation.
   This is explicitly not a lower bound for all adaptive algorithms.

These conclusions are supported by the supplied mathematical arguments and
finite internal checks. They have not been independently reviewed or verified
in a formal proof assistant.

## Preserved, not newly claimed

The first-round ZIP contains the product-matrix subclass characterization,
exact n-call factor recovery, the counterexample to Conjecture 23 as stated in
arXiv:2502.08029v2, real simulation of complex product calls, and the stronger
blocking lower bound. It is retained unchanged. Those results keep their
original promises and qualifications.

## Specific unresolved issue

There is no proof here of either a polynomial-in-q general upper bound or an
unrestricted exponential-in-q minimax lower bound. At fixed `n=2` and
`epsilon=1/4`, the retained lower and upper scales still differ between
`sqrt(q/log(q))` and `q*(4/3)**q`. Fixed-order optimality cannot remove that gap
by suppressing q-dependent constants.

No repository status was edited. The source statement was read on the public
website; the package's status is not a claim about repository maintainer review.

## Empirical and implementation limitations

The certified constants are very large. The full certified hierarchy was not
executed, and its dense storage, exhaustive subset selection, and interpolation
can be numerically or computationally impractical. Small experiments are
expressly reduced-constant diagnostics. The exact reference is restricted to
rational matrix adapters for executable examples, but that restriction is not
part of the mathematical theorem. All source code is supplied for inspection.
