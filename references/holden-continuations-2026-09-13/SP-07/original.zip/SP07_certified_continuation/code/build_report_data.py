"""Generate the report's exact data tables from the verified certificate files."""
import json
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results';P=ROOT/'paper'

def esc(s):return s.replace('_',r'\_')
def table(z):
 return '\n'.join(f'{i+1} & {a} & {b} \\\\' for i,(a,b) in enumerate(z))
def matrix(X):return '\\\\\n'.join(' & '.join(row) for row in X)

seven=json.loads((R/'certificate_seven.json').read_text());five=json.loads((R/'certificate_five_stronger.json').read_text());sv=json.loads((R/'certificate_seven_verification.json').read_text());fv=json.loads((R/'certificate_five_stronger_verification.json').read_text());audit=json.loads((R/'saved_records_audit.json').read_text());tests=json.loads((R/'reduction_tests.json').read_text())
text='''% Generated from exact input and verification JSON files. Do not edit by hand.\n'''
text+=r'\newcommand{\SevenZRows}{'+table(seven['z'])+'}\n'
text+=r'\newcommand{\SevenX}{'+matrix(seven['X'])+'}\n'
text+=r'\newcommand{\FiveZRows}{'+table(five['z'])+'}\n'
text+=r'\newcommand{\FiveX}{'+matrix(five['X'])+'}\n'
text+=r'\newcommand{\SevenPivotRows}{'+'\n'.join(f'{i+1} & {p["lower_numerator"]} \\\\' for i,p in enumerate(sv['pivot_intervals']))+'}\n'
text+=r'\newcommand{\FivePivotRows}{'+'\n'.join(f'{i+1} & {p["lower_numerator"]} \\\\' for i,p in enumerate(fv['pivot_intervals']))+'}\n'
text+=r'\newcommand{\SearchRuns}{'+f'{audit["campaign_records"]:,}'+'}\n'
text+=r'\newcommand{\SearchSuccesses}{'+f'{audit["optimizer_successes"]:,}'+'}\n'
text+=r'\newcommand{\SearchNonSuccesses}{'+f'{audit["optimizer_nonsuccesses"]:,}'+'}\n'
text+=r'\newcommand{\NumericalChecks}{'+f'{tests["checks"]:,}'+'}\n'
labels={'extension_real.json':'First reflection extensions','extension_seven_real.json':'Second real reflection extensions','extension_seven_complex.json':'Complex reflection extensions','extension_seven_stronger.json':'Stronger-seed reflection extensions','chain_nine.json':'Contact-chain extensions','general_five_complex.json':'Full normal pairs from size five','general_seven_complex.json':'Full complex pairs from size seven','general_seven_real.json':'Full real-basis pairs from size seven','cauchy_starts.json':'Independent Cauchy-based starts'}
rows=[]
for c in audit['campaigns']:
 dims=','.join(map(str,c['dimensions']));rows.append(f'{labels.get(c["file"],esc(c["file"]))} & {dims} & {c["records"]} & {c["optimizer_successes"]} \\\\')
text+=r'\newcommand{\CampaignRows}{'+'\n'.join(rows)+'}\n'
P.mkdir(exist_ok=True);(P/'generated_data.tex').write_text(text)
print('Generated exact report data tables.')
