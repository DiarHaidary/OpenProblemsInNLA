# An improved unrestricted boundary strip

This theorem has no restriction on the rank or inertia of the admissible
matrix. It is nevertheless only a parameter strip, not a full solution of
SP-08. Its proof is analytic and uses only the negative-parameter part of the
centered-rank-two theorem.

**Theorem.** For every integer n>=2 and

    -1 <= a <= -1+(1+sqrt(2))/n^2,

an optimal matrix is B_floor(n/2). In particular the SP-08 rank-two endpoint
conjecture holds throughout this interval. The coefficient 1+sqrt(2) replaces
the coefficient 1/3 in the boundary strip supplied with the earlier work.

## A uniform gap for higher-rank sign matrices

Let S be a symmetric n-by-n sign matrix of rank at least three. There is a
nonsingular 3-by-3 submatrix T. Every nonsingular 3-by-3 sign matrix has singular
values 2,2,1. Indeed its nonzero determinant is divisible by four and has
absolute value at most sqrt(27), so its absolute determinant is four. Its Gram
matrix has diagonal entries three and off-diagonal entries plus or minus one;
the determinant condition forces Gram eigenvalues 4,4,1.

For any rank-at-most-two matrix X, its corresponding submatrix R has a unit
null vector v. Hence

    ||S-X||_F^2 >= ||T-R||_F^2 >= ||Tv||^2 >= 1.

Take X to retain only the extreme eigenvalues of S. The middle spectral energy
is at least one, and therefore

    spread(S)^2 <= 2(n^2-1).                                (1)

## Comparison with a balanced candidate

Write c=(1+a)/2, r=1-c, and L=sqrt(2n^2-2). An endpoint matrix has the form
A=cJ+rS. If rank(S)>=3, subadditivity and (1) imply

    spread(A) <= cn+rL.

Let epsilon=n mod 2 and k=(n-epsilon)/2. Direct calculation gives

    spread(B_k)^2 = n^2+r^2(n-epsilon)^2
                         +2r epsilon(n-epsilon).

Put

    C_epsilon=(n-epsilon)^2-(L-n)^2.

The exact difference is

    spread(B_k)^2-(cn+rL)^2
       = r [(2-epsilon)-c C_epsilon].                       (2)

For even n, C_0=n^2 beta(2-beta)<=n^2, where beta=L/n. Thus the difference is
nonnegative whenever c<=(1+sqrt(2))/(2n^2), since (1+sqrt(2))/2<2.
For odd n,

    C_1=2nL-2n^2-2n+3 < 2(sqrt(2)-1)n^2,

and the same condition gives c C_1<=1. Equation (2) again proves domination.
If rank(S)<=2, the centered-rank-two theorem already bounds spread(A) by M_n(a).
Within this strip the allowed integer nearest n/(a+3) is floor(n/2), so this
bound is attained by the balanced candidate. Finally, convexity of spread
reduces arbitrary admissible entries to endpoint matrices.

## A sharper parity-dependent version

For n>=3, (2) gives the following sufficient conditions directly:

    even n:  c <= 2 / [2n sqrt(2n^2-2)-2n^2+2],
    odd n:   c <= 1 / [2n sqrt(2n^2-2)-2n^2-2n+3].

One may use these conditions with a<=0 so that only the analytic negative-
parameter centered-rank-two theorem is needed. The uniform theorem above is
a simpler common interval. No conclusion outside these intervals follows from
this comparison.
