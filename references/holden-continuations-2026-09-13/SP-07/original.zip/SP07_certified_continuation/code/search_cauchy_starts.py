"""Independent normal-pair searches initialized from separated zigzag chains.

A Cauchy Schur-multiplier iteration proposes a rectangular overlap. A CS-style
unitary completion and a weighted least-squares spectral completion produce a
FULL normal pair. The subsequent objective always uses the full difference.
The rectangular relaxation itself is never claimed to give a matrix lower bound.
"""
import argparse,json,sys,time
from pathlib import Path
import numpy as np
from scipy.linalg import block_diag
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'prior'/'sp07_partial_results'/'code'))
from search import Model as OldModel

class Model(OldModel):
    def __init__(self,n,p,U0):
        super().__init__(n,p,True);self.U0=U0;ds=[]
        for i in range(n):
            for j in range(i+1,n):
                K=np.zeros((n,n),complex);K[i,j]=1;K[j,i]=-1;ds.append(K)
                K=np.zeros((n,n),complex);K[i,j]=1j;K[j,i]=1j;ds.append(K)
        self.dK=np.array(ds);self.nt=len(ds);self.size=self.ns+self.nt+1
    def unitary(self,t,derivative=False):
        K=np.einsum('k,kij->ij',t,self.dK);R=np.linalg.inv(np.eye(self.n)+K);Q=2*R-np.eye(self.n);U=self.U0@Q
        if not derivative:return U
        return U,-2*self.U0@R@self.dK@R
    def record(self,x):
        d=super().record(x);d.update(chart='offdiagonal_skew_Hermitian_Cayley',U0_real=self.U0.real.tolist(),U0_imag=self.U0.imag.tolist());return d

def multiplier_start(a,b,rng):
    C=1/(a[:,None]-b[None,:]);p,q=C.shape;best=None
    for k in range(5):
        Y=rng.normal(size=(p,q))+1j*rng.normal(size=(p,q));u,_,vh=np.linalg.svd(Y,full_matrices=False);Y=u@vh
        for _ in range(25):
            X=C*Y;u,s,vh=np.linalg.svd(X,full_matrices=False);G=C.conj()*np.outer(u[:,0],vh[0,:]);g,_,h=np.linalg.svd(G,full_matrices=False);Y=g@h
        X=C*Y;u,s,vh=np.linalg.svd(X,full_matrices=True)
        if best is None or s[0]>best[0]:best=(s[0],X/s[0])
    return best

def unitary_completion(X):
    p,q=X.shape;n=p+q-1;L,s,Rh=np.linalg.svd(X,full_matrices=True);s=np.clip(s,0,1);s[0]=1
    V=np.zeros((n,n),complex);V[0,0]=1
    for i in range(1,p):
        c=s[i];t=np.sqrt(1-c*c);V[i,i]=c;V[i,q+i-1]=t;V[p+i-1,i]=t;V[p+i-1,q+i-1]=-c
    for j in range(p,q):V[p+j-1,j]=1
    U=block_diag(L,np.eye(q-1))@V@block_diag(Rh,np.eye(p-1))
    if np.linalg.norm(U.conj().T@U-np.eye(n),2)>1e-8:raise AssertionError('Completion not unitary')
    return U

def least_squares_spectra(a,b,U):
    n=U.shape[0];p=len(a);q=len(b);nu=(n-p)+(n-q);rows=[];rhs=[]
    for i in range(n):
        for j in range(n):
            w=abs(U[i,j]);r=np.zeros(nu);v=0j
            if i<p:v+=a[i]
            else:r[i-p]+=1
            if j<q:v-=b[j]
            else:r[n-p+j-q]-=1
            rows.append(w*r);rhs.append(-w*v)
    z=np.linalg.lstsq(np.array(rows),np.array(rhs),rcond=None)[0]
    return np.r_[a,z[:n-p]],np.r_[b,z[n-p:]]

def main(args):
    rng=np.random.default_rng(args.seed);records=[];start=time.monotonic()
    for n in args.sizes:
        p=(n+1)//2;q=n+1-p
        for k in range(args.runs):
            theta=rng.uniform(.1,.75);ang=np.array([(-1)**i*theta for i in range(n)])
            ang+=rng.normal(scale=[0,.025,.07,.15][k%4],size=n)
            points=np.r_[0,np.cumsum(np.exp(1j*ang))];aa=points[1::2];bb=points[0::2]
            if len(aa)!=p:aa,bb=bb,aa
            factor,X=multiplier_start(aa,bb,rng);U=unitary_completion(X);a,b=least_squares_spectra(aa,bb,U)
            rot=np.exp(-1j*np.angle(a[1]-a[0]));b=(b-a[0])*rot;a=(a-a[0])*rot;norm=np.linalg.norm((a[:,None]-b[None,:])*U,2);a/=norm;b/=norm
            mod=Model(n,p,U);x=np.r_[a[1].real,np.column_stack([a[2:].real,a[2:].imag]).ravel(),np.column_stack([b.real,b.imag]).ravel(),np.zeros(mod.nt),np.min(abs(a[:p,None]-b[None,:q]))]
            err=None
            if k==0:
                xx=x+.001*rng.normal(size=len(x));h=1e-6;fd=np.column_stack([(mod.calculate(xx+h*e)[0]-mod.calculate(xx-h*e)[0])/(2*h) for e in np.eye(len(xx))]);err=float(np.max(abs(fd-mod.calculate(xx,True)[1])))
                if err>1e-4:raise AssertionError(('Derivative error',err))
            out=mod.optimize(x);r=mod.record(out.x);r.update(run=k,seed=args.seed,theta=theta,multiplier_initial_factor=float(factor),initial_full_norm=float(norm),success=bool(out.success),message=str(out.message),jacobian_error=err);records.append(r)
            print(n,k,r['actual_ratio'],r['minimum_constraint'],r['success'],flush=True)
            args.output.write_text(json.dumps(dict(status='Independent full normal-pair local searches; no global proof.',elapsed_seconds=time.monotonic()-start,records=records),indent=2)+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sizes',nargs='+',type=int,default=[4,6,8,9]);p.add_argument('--runs',type=int,default=48);p.add_argument('--seed',type=int,default=161803398);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a)
