#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python code/validate.py
command -v pdflatex >/dev/null || { echo "pdflatex is required to build the manuscript." >&2; exit 1; }
(
  cd manuscript
  pdflatex -interaction=nonstopmode -halt-on-error sp14_round7.tex
  pdflatex -interaction=nonstopmode -halt-on-error sp14_round7.tex
)
