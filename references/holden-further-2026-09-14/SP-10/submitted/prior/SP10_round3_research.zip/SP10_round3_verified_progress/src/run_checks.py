"""Run delivered tests/checkers and retain real exit codes and timings."""
from pathlib import Path
import json,subprocess,sys,time,platform,unittest
ROOT=Path(__file__).resolve().parents[1]
commands=[('unit_tests',[sys.executable,'-m','unittest','discover','-s','tests','-v']),
          ('generation',[sys.executable,'src/generate_certificates.py']),
          ('exact_verification',[sys.executable,'src/verify_all.py']),
          ('sympy_verification',[sys.executable,'src/crosscheck_sympy.py']),
          ('build_table',[sys.executable,'src/build_table.py'])]
status=[]
for name,cmd in commands:
    start=time.monotonic()
    with (ROOT/'results'/(name+'.log')).open('w') as f:
        process=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=False)
    item={'name':name,'command':cmd,'returncode':process.returncode,'elapsed_seconds':time.monotonic()-start,'completed':True}
    status.append(item);(ROOT/'results'/'execution_status.json').write_text(json.dumps(status,indent=2)+'\n')
    print(name,process.returncode,flush=True)
    if process.returncode:
        print((ROOT/'results'/(name+'.log')).read_text()[-6000:]);raise SystemExit(process.returncode)
import sympy
sys.path.insert(0,str(ROOT/'src'))
count=unittest.TestLoader().discover(str(ROOT/'tests')).countTestCases()
env={'python':sys.version,'platform':platform.platform(),'sympy':sympy.__version__,'unit_test_count':count}
(ROOT/'results'/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
(ROOT/'requirements-optional.txt').write_text('sympy=='+sympy.__version__+'\n')
print('All checks passed; unit tests:',count)
