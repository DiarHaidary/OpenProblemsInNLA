# RA-01: Arrival-time bounds and limits of clock comparisons

## Abstract and status

This note does **not** prove or refute unrestricted RA-01. It develops the continuous-time approach from the preceding two proof packages. The positive result is an inverse-arrival-time inequality that converts a suitable stochastic bound on the number of pivots into an expected error bound at a deterministic pivot count. Applied to coordinate blocks, it sharpens the previous aggregation estimate to

\[
\mathbb E T_k\le \frac{k}{k-r}\,\mathbb E B,\qquad k>r.
\]

The note also gives an explicit finite counterexample to every proposed universal count estimate of the form \(\mathbb E N(t)\le r+b t\tau_r(A)\). Two further calculations establish the direction of a ridge-potential drift inequality and disprove a volume-sampling comparison for the conditional clock hazard. These are obstructions to particular proof routes, not counterexamples to RA-01. No absolute upper constant for the unrestricted problem is established. The arguments are not independently reviewed or proof-assistant verified.

## 1. Problem and notation

Let \(A\in\mathbb C^{n\times n}\) be Hermitian positive semidefinite, with eigenvalues \(\lambda_1\ge\cdots\ge\lambda_n\ge0\). Put

\[
\tau_r(A)=\sum_{i>r}\lambda_i(A).
\]

The exact RPCholesky process starts at \(R_0=A\). At a nonzero residual \(R\), it chooses coordinate \(j\) with probability \(R_{jj}/\operatorname{tr}R\) and updates

\[
R^{(j)}=R-\frac{Re_je_j^*R}{R_{jj}}.
\]

Write \(T_k=\operatorname{tr}R_k\) and \(f_k=\mathbb E T_k\). Zero is absorbing. Each positive pivot decreases the rank by one; \(0\preceq R_{k+1}\preceq R_k\preceq A\). Residuals are set to zero after termination.

The target in the preceding packages is the existence of an absolute \(C\ge1\) such that, for every allowed input, rank, and \(0<\epsilon<1\),

\[
f_{\min\{n,\lceil Cr/\epsilon\rceil\}}\le(1+\epsilon)\tau_r(A).
\tag{1.1}
\]

The pivot distribution above is part of the question. An upper bound for another column-selection algorithm does not establish (1.1).

For the continuous-time embedding, a nonzero state has holding time exponential with rate \(T\), followed by the original pivot choice. Equivalently, the transition to \(R^{(j)}\) has rate \(R_{jj}\). Let \(N(t)\) be its number of jumps by time \(t\), and let \(\Theta_j\) be the time of the \(j\)-th positive jump. Set \(\Theta_j=\infty\) when fewer than \(j\) jumps occur, and \(1/\infty=0\).

The previous note proves

\[
\mathbb E R(t)\preceq A(I+tA)^{-1},\qquad
\mathbb E\operatorname{tr}R(t)\le\tau_r(A)+r/t.
\tag{1.2}
\]

That is an error bound at a deterministic clock time, not at a deterministic pivot count. The distinction is central below. The preceding note also proves that a constant-factor bound \(f_{\min(n,\lceil ar\rceil)}\le B\tau_r\), with absolute \(a,B\), would imply (1.1). No such unrestricted bound is supplied here.

## 2. An inverse-arrival-time inequality

### Theorem 2.1

For every integer \(k\ge1\),

\[
\boxed{f_k\le k\,\mathbb E[\Theta_{k+1}^{-1}]
= k\int_0^\infty\frac{\Pr\{N(t)\ge k+1\}}{t^2}\,dt.}
\tag{2.1}
\]

The statement allows an infinite right side, in which case it is only a valid, uninformative upper bound.

**Proof.** Pre-sample the entire embedded pivot trajectory, and independently draw \(E_0,E_1,\ldots\) with independent exponential distributions of rate one. Conditional on the trajectory, when \(T_k>0\),

\[
\Theta_{k+1}=\sum_{i=0}^k\frac{E_i}{T_i}
\le\frac{E_0+\cdots+E_k}{T_k},
\]

because the realized traces are nonincreasing. The sum in the numerator is gamma with shape \(k+1\) and rate one. Its reciprocal has mean \(1/k\). Thus

\[
\mathbb E[\Theta_{k+1}^{-1}\mid\text{trajectory}]\ge T_k/k.
\]

If the process terminates before that jump, both the required trace and the reciprocal arrival time are zero. Average over trajectories. Finally, the nonnegative layer-cake identity and \(\{\Theta_{k+1}\le t\}=\{N(t)\ge k+1\}\) give the integral in (2.1). Positive holding times have continuous distributions, so the strict/non-strict endpoint distinction does not affect the integral. ∎

This proof does not assume independence between \(T_k\) and \(N(t)\). It is specifically useful when a bound on the whole count tail is available; a first moment of the count is not being substituted for that tail.

### Theorem 2.2: a sufficient Poisson comparison

Suppose that, for a fixed matrix, some integer \(h\ge0\) and \(\beta\ge0\) satisfy, for all \(t>0\),

\[
N(t)\ \le_{\rm st}\ h+\operatorname{Poisson}(\beta t).
\tag{2.2}
\]

Here stochastic domination means domination of every upper-tail probability. Then, for every integer \(k>h\),

\[
\boxed{f_k\le\frac{k\beta}{k-h}.}
\tag{2.3}
\]

**Proof.** Put \(m=k+1-h\ge2\). Theorem 2.1 bounds the right side by

\[
k\int_0^\infty t^{-2}\Pr\{\operatorname{Poisson}(\beta t)\ge m\}\,dt
=\frac{k\beta}{m-1}.
\]

For \(\beta>0\), the integral is the mean reciprocal of the \(m\)-th arrival of a rate-\(\beta\) Poisson process, namely \(\beta/(m-1)\). Equivalently, integrate by parts using the derivative of the Poisson upper tail. When \(\beta=0\), domination forces at most \(h\) jumps and the result is zero. ∎

### Corollary 2.3: what would suffice for the full problem

If absolute \(a\ge1\) and \(b\ge1\) made (2.2) valid for every input with

\[
h=\lceil ar\rceil,\qquad\beta=b\tau_r(A),
\tag{2.4}
\]

then \(f_{2\lceil ar\rceil}\le2b\tau_r\), unless termination occurs earlier. This would prove RA-01; for example \(C=2a+2b+2\) would suffice.

For completeness, the scalar completion used here is as follows. Write \(\tau=\tau_r(A)>0\). The exact one-step trace identity and \(\tau_r(R)\le\tau\) yield

\[
f_{j+1}\le g(f_j),\quad
 g(x)=x\ (x\le\tau),\quad
 g(x)=x-(x-\tau)^2/(rx)\ (x>\tau).
\]

The map is nondecreasing and concave. If \(f_{j_0}\le B\tau\), set \(u_0=B-1\) and \(u_{s+1}=u_s-u_s^2/[r(1+u_s)]\). Then

\[
f_{j_0+s}\le\tau(1+u_s),\qquad
u_s^{-1}\ge(B-1)^{-1}+s/(rB).
\]

Thus an additional \(rB/\epsilon\) pivots is a sufficient conservative bound. In (2.4), take \(j_0=2\lceil ar\rceil\le2ar+2\) and \(B=2b\). The stated value of \(C\) supplies those extra pivots, and an active dimension cap or zero tail is handled by exact termination.

**Important:** (2.4) is not proved in this note. It is a sufficient condition, not a known property, and not asserted to be equivalent to RA-01. No claim is made that such a strong Poisson comparison must hold if RA-01 holds.

## 3. Sharper aggregation for actual coordinate blocks

Assume \(A=A_1\oplus\cdots\oplus A_M\) in the coordinates used by the algorithm. Fix integers \(q_i\ge0\) with \(r=\sum_iq_i\ge1\). Independently pre-sample each block's local RPCholesky pivot trajectory. Let \(d_i\) be its trace after \(q_i\) local pivots, with value zero after earlier termination; when \(q_i=0\), let \(d_i=\operatorname{tr}A_i\). Define

\[
B=\sum_i d_i.
\]

### Theorem 3.1

For every integer \(k>r\),

\[
\boxed{\mathbb E T_k\le\frac{k}{k-r}\,\mathbb E B.}
\tag{3.1}
\]

**Proof.** Condition on all local trajectories. Their successive trace rates are then fixed and nonincreasing; only their continuous-time interleaving remains random. Call a positive move essential when its block has not yet performed its allotted \(q_i\) pivots. There are at most \(r\) essential moves on any path. After a block completes its allotment, its trace never exceeds \(d_i\). The total rate of all nonessential moves is consequently at most the now fixed number \(B\).

Generate a rate-\(B\) Poisson process, independent of essential clocks, and thin it to generate the nonessential moves with their correct state-dependent rates. This produces the correct conditional block process. At every time,

\[
N(t)\le r+P_B(t)
\]

on the constructed probability space, where \(P_B\) is the candidate Poisson process. Apply Theorem 2.2 conditionally, with \(h=r\) and \(\beta=B\), and average. If \(B=0\), at most \(r\) positive pivots occur, so the result follows without a Poisson clock. ∎

The earlier package proved the coarser factor \(1+r/(k-r-1)\) for \(k\ge r+2\). Equation (3.1) improves that denominator and includes \(k=r+1\). Its hypotheses still concern actual coordinate blocks. Applying a unitary diagonalization to an arbitrary matrix does not preserve the multistep pivot law, so (3.1) cannot be used in that way to settle the unrestricted problem.

The one-phase special bound in the first package can remain stronger than (3.1) on its narrower class. The new inequality is not a claim to supersede every earlier special-case bound.

## 4. No universal count bound with the leading term exactly r

### Theorem 4.1

For every real \(b>0\), there is a finite positive-definite matrix, a target rank \(r\), and a positive time \(t\) such that

\[
\mathbb E N(t)>r+b t\tau_r(A).
\tag{4.1}
\]

**Explicit construction.** Choose an integer \(n\ge2\) with \(n>10b\), and set

\[
r=n-1,\quad L=40n^2(n-1),\quad t=1/n,\quad
A=L I_n-\frac{L-1}{n}\,\mathbf1\mathbf1^*.
\tag{4.2}
\]

The eigenvalues are \(L\), with multiplicity \(n-1\), and \(1\), with multiplicity one. Thus \(\tau_r(A)=1\).

After any \(k\) pivots, put \(m=n-k\). On the unselected coordinates the residual is

\[
L I_m-\frac{L(L-1)}{mL+k}\,\mathbf1\mathbf1^*,
\]

and its trace is the deterministic number

\[
T_k=\frac{mL[(m-1)L+k+1]}{mL+k}.
\tag{4.3}
\]

This follows directly by one Schur update: a coefficient \(c\) in \(L I+c\mathbf1\mathbf1^*\) changes to \(cL/(L+c)\). In particular,

\[
T_k\ge(n-k-1)L\quad(k<r),\qquad
T_r=\frac{nL}{L+n-1}\ge n/2.
\]

Let \(H=\Theta_r\), and let \(Z\) be the final holding time. The deterministic sequence of trace rates makes \(H\) and \(Z\) independent, with \(Z\) exponential of rate \(T_r\). Moreover,

\[
\mathbb EH\le\frac{1}{L}\sum_{j=1}^{n-1}\frac1j\le\frac{n-1}{L}.
\]

Markov's inequality gives

\[
q:=\Pr\{H>t/2\}\le\frac{2n(n-1)}{L}=\frac1{20n}.
\]

Also

\[
p:=\Pr\{Z\le t/2\}\ge1-e^{-1/4}>1/5,
\]

where the last strict inequality follows from \(e^{1/4}>1+1/4\). On \(H\le t/2\), at least \(r\) pivots have occurred by time \(t\), and the last pivot has also occurred if \(Z\le t/2\). Hence

\[
\mathbb EN(t)\ge(r+p)(1-q)
>r+\frac15-\frac1{20}
=r+\frac3{20}.
\]

But \(bt=b/n<1/10\). This proves (4.1) for the explicit finite matrix (4.2). ∎

As an additional explanation of the mechanism, if \(n\) is fixed and \(L\to\infty\), the first \(n-1\) holding times tend to zero, while the last converges to an exponential holding time of rate \(n\). Consequently,

\[
\mathbb EN(t)\longrightarrow n-1+1-e^{-nt},\qquad t>0.
\]

That limit is explanatory only: the proof above already gives finite integer parameters.

**Scope.** This theorem rules out a leading term exactly \(r\) with an absolute linear tail-rate coefficient. It does not rule out a bound with \(ar\) for an absolute \(a>1\), and does not refute the sufficient comparison in Corollary 2.3. These examples have dimension \(r+1\), so the dimension-capped RA-01 target terminates exactly and is satisfied on them.

## 5. Direction of the ridge-potential drift

For \(h>0\), let \(D=R(R+hI)^{-1}\), \(d=\operatorname{tr}D\), and \(T=\operatorname{tr}R\). The fixed-pivot identity from the preceding note is

\[
D_h(R^{(j)})=D-\frac{De_je_j^*D}{D_{jj}}.
\]

One can check it directly with Sherman–Morrison, using \(M=R+hI\), \(v=Re_j/\sqrt{R_{jj}}\), and \(1-v^*M^{-1}v=hD_{jj}/R_{jj}\). Therefore the continuous-time generator satisfies

\[
-\mathcal Ld=\sum_{j:R_{jj}>0}R_{jj}\frac{(D^2)_{jj}}{D_{jj}}.
\]

### Proposition 5.1

For every Hermitian PSD residual,

\[
\boxed{-\mathcal Ld\le T-hd.}
\tag{5.1}
\]

**Proof.** Diagonalize \(R\), and fix a coordinate \(j\) with \(D_{jj}>0\). Let \(w_i\) be its spectral weights, \(d_i=\lambda_i/(\lambda_i+h)\), \(\gamma=\sum_iw_i d_i=D_{jj}\), and \(q_i=w_i d_i/\gamma\). Terms of zero weight may be omitted. Then

\[
(RD)_{jj}-R_{jj}\frac{(D^2)_{jj}}{D_{jj}}
=\gamma\,\operatorname{Cov}_{q}(\lambda,d(\lambda))\ge0.
\]

The covariance is nonnegative because both functions increase with \(\lambda\); its pairwise formula is a sum of nonnegative products. Sum over coordinates and use \(RD=R-hD\). Zero diagonal coordinates contribute zero. ∎

The inequality can be strict. For

\[
R=\begin{pmatrix}3&1\\1&3\end{pmatrix},\qquad h=1,
\]

exact arithmetic gives

\[
-\mathcal Ld=\frac{244}{55},\qquad
T-hd=\frac{68}{15},\qquad
(T-hd)-(-\mathcal Ld)=\frac{16}{165}>0.
\]

Thus reversing (5.1) to force a favorable count drift is invalid.

## 6. Conditioning on the clock does not give a volume-sampling bound

Another possible shortcut is to claim that, conditional on exactly \(k\) clock jumps, the expected current trace is bounded by the size-\(k\) volume-sampling trace. This is false already at \(k=2\).

For a positive-definite matrix, write \(T_S\) for the trace after pivot set \(S\), and \(T_j=T_{\{j\}}\). At level two, define the probability weights

\[
\pi(S)=\frac{\det A(S,S)}{e_2(A)},\quad
z_S=T_S,\quad a_S=T_S+\frac{T_j+T_l}{2},\quad S=\{j,l\}.
\]

Let \(H_2(t)=\mathbb E[\operatorname{tr}R(t)\mid N(t)=2]\). A small-time expansion gives

\[
H_2(0+)=\frac{3e_3(A)}{e_2(A)},\qquad
H_2'(0+)=-\frac13\operatorname{Cov}_{\pi}(z_S,a_S).
\tag{6.1}
\]

To verify the expansion, sum the two ordered arrival paths to \(S\). Their joint density includes the factor \(\det A(S,S)\). Integrating over the two arrival times, including survival in the final state, gives

\[
\Pr\{\text{state at }t=S\}
=\det A(S,S)t^2\left[1-\frac t3(T_0+a_S)+O(t^2)\right].
\]

Divide the trace-weighted sum by the probability of level two. The first identity uses \(\sum_{|S|=2}\det A(S,S)T_S=3e_3(A)\), and the derivative is the covariance in (6.1).

For the explicit rational matrix

\[
A=\begin{pmatrix}
101/20&99/20&0\\
99/20&101/20&0\\
0&0&1
\end{pmatrix},
\]

the eigenvalues are \(10,1,1/10\). The set \(\{1,2\}\) has volume probability \(10/111\), residual trace \(1\), and \(a_S=222/101\). The other two sets together have probability \(101/111\), residual trace \(20/101\), and \(a_S=11811/2020\). Consequently,

\[
H_2(0+)=\frac{10}{37},\qquad
H_2'(0+)=\frac{22113}{276538}>0.
\]

For all sufficiently small positive times, the conditional clock hazard therefore exceeds its volume-sampling value. This excludes the blanket comparison. It does not exclude a different estimate restricted to sufficiently oversampled levels.

## 7. Verification and remaining gap

The accompanying standard-library Python program uses exact rational arithmetic. It checks the finite parameter inequalities in Theorem 4.1, the Schur trace recurrence, the strict ridge-drift example, the conditional-hazard covariance calculation, and the new block aggregation inequality on four small coordinate-block configurations. For the latter tests it enumerates the original pivot distribution on subsets, checks matching residuals before merging paths, checks probability normalization, and checks exact termination.

The saved JSON and run log describe the execution of that program. These checks verify the displayed finite calculations; they are not a formal verification of the general arrival-time theorem, stochastic comparison arguments, or the unrestricted conjecture. No independent mathematical review was performed. No numerical experiment is used as a replacement for a universal proof.

The unrestricted gap remains the existence of absolute \(a,B\) for

\[
\mathbb E\operatorname{tr}R_{\min\{n,\lceil ar\rceil\}}\le B\tau_r(A)
\]

on all Hermitian PSD inputs. The Poisson comparison in Section 2 would suffice, but is unproved. The block comparison in Section 3 proves a restricted result only. The examples in Sections 4–6 invalidate specific shortcuts, not the requested universal guarantee.

The earlier necessary lower bound \(C\ge2\) and bounded-leading-spread upper theorem remain in the previous package; this note does not independently re-audit or strengthen those results. It does not justify marking RA-01 solved, and no repository changes are part of this package.

## References and provenance

[1] Open Problems in Numerical Linear Algebra, RA-01, “Optimal pivot count for RPCholesky trace approximation.” The formal target used here is the one reproduced in the preceding two packages. Canonical location: https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/randomized-and-low-rank-approximation/RA-01/README.md. This note makes no new claim about the repository's current status.

[2] Prior conversation artifact, *RA-01: Sharp column-selection lower bounds and dense-matrix guarantees*, `RA01_round2_proof_package.zip`, report `ra01_round2.pdf`. See Sections 3, 4, and 7 for scalar completion, the clock embedding, ridge commutation, and the unrestricted gap. Unpublished and not independently reviewed.

[3] Prior conversation artifact, *RA-01: Sharp rank-one bounds, diagonal lower bounds, and block-structured guarantees*, `RA-01_partial_proof_package.zip`, report `ra01_partial_results.pdf`. See Section 7 for the original coordinate-block construction and earlier aggregation estimate. Unpublished and not independently reviewed.

No claim of literature priority is made for the arguments in this note.
