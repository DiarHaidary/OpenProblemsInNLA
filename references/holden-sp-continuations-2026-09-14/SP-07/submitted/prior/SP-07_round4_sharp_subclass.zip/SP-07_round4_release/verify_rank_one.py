#!/usr/bin/env python3
"""Run the exact, standard-library proof-certificate audits."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from verify_rank_one import main
if __name__=='__main__':
    main()
