# Sources and provenance

## Problem statement

OpenProblemsInNLA, randomized-and-low-rank-approximation/TR-03/README.md.

https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/randomized-and-low-rank-approximation/TR-03

https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/TR-03/README.md

The definitions used here were available in the preceding conversation and reports. A fresh readable web response was not available in this run, so this file does not assert a new access date or a verified current revision.

## Previous work

- TR03_analysis.zip: first partial report and verification code.
- TR03_continuation.zip: second partial report and verification code.
- TR03_round3: interrupted continuation files, when present in the runtime.

Actual copied files and their hashes are listed in PROVENANCE.json. Their preservation does not establish the correctness of their claims. No new literature theorem beyond the elementary symmetric-polynomial log-concavity used in the self-contained derivation is relied on.
