"""Separate SymPy reconstruction of the extremal matrices and AM-GM identity."""
from pathlib import Path
from itertools import permutations
import json
import sympy as s
ROOT=Path(__file__).resolve().parents[1]

def zero(M):return all(s.simplify(v)==0 for v in M)

def main():
    D=s.diag(1,(4+5*s.I*s.sqrt(3))/7,(2-s.I*s.sqrt(3))/7)
    v=s.Matrix([s.Rational(1,2),s.sqrt(s.Rational(5,8)),s.sqrt(s.Rational(1,8))])
    U=s.eye(3)-2*v*v.T;B=-U*D*U;H=D*U+U*D;G=s.simplify(H.conjugate().T*H)
    checks={
        'unit_vector':(v.T*v)[0]==1,
        'reflection':zero(U*U-s.eye(3)),
        'normal_A':zero(D*D.conjugate().T-D.conjugate().T*D),
        'normal_B':zero(B*B.conjugate().T-B.conjugate().T*B),
        'residual_identity':zero((D-B)*U-H),
        'Gram_polynomial':zero((7*G-27*s.eye(3))*(7*G-4*s.eye(3))),
        'Gram_trace':s.simplify(s.trace(G)-s.Rational(58,7))==0,
    }
    dist=[[s.simplify((D[i,i]+D[j,j])*s.conjugate(D[i,i]+D[j,j])) for j in range(3)] for i in range(3)]
    checks['all_matchings']=min(max(dist[i][p[i]] for i in range(3)) for p in permutations(range(3)))==4
    x,y,z=s.symbols('x y z');S=1+x+2*y
    target=(S+x)*(1+x)*(2*S-1)**2*(7+5*z)**2-28*x*(x*S+56*y)*(2*S-1)*(7+5*z)-392*x*y*(28*(S-1)**2-27*S*S)
    data=json.loads((ROOT/'certificates/rank_one_amgm.json').read_text())
    poly=sum(s.Rational(c)*x**ex[0]*y**ex[1]*z**ex[2] for ex,c in data['positive'])-sum(s.Rational(c)*x**ex[0]*y**ex[1]*z**ex[2] for ex,c in data['negative'])
    checks['independent_polynomial_expansion']=s.expand(poly-target)==0
    if not all(checks.values()):raise RuntimeError(checks)
    print(json.dumps({'status':'PASS','checks':checks,'count':len(checks),'sympy':s.__version__},indent=2))
if __name__=='__main__':main()
