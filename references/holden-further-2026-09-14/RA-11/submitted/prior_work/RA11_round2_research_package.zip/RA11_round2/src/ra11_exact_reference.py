"""Exact-rational reference for the round-2 theorem.

This is an intentionally expensive reference, not an efficient implementation.
All input matrix entries for the provided matrix adapter must be rational.
Default schedules are the certified ones from the manuscript. A query-budget
preflight prevents accidentally starting an enormous hierarchy. The theorem is
about an ideal exact oracle and independent uniform random bits; a seeded PRNG
is useful for reproducible tests, not a formal source of ideal randomness.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import combinations, product
from math import ceil
import random
import secrets
from typing import Callable, Sequence
import sympy as sp
from ra11_hierarchy import theorem_schedule

Matrix = sp.MatrixBase
Bits = Callable[[int], int]
PHASES = (sp.S.One, -sp.S.One, sp.I, -sp.I)

def kron(factors: Sequence[Matrix]) -> Matrix:
    return sp.kronecker_product(*factors) if factors else sp.ones(1, 1)

def digits(j: int, n: int, q: int) -> list[int]:
    out = [0]*q
    for k in range(q-1,-1,-1):
        j,out[k] = divmod(j,n)
    return out

def coordinate_factors(j: int, n: int, q: int) -> list[Matrix]:
    return [sp.eye(n)[:,k] for k in digits(j,n,q)]

def phase_factors(n: int, q: int, bits: Bits) -> list[Matrix]:
    return [sp.Matrix([PHASES[bits(2)] for _ in range(n)]) for _ in range(q)]

def frobenius_squared(A: Matrix) -> sp.Expr:
    return sp.expand(sp.trace(A.conjugate().T*A))

def hermitize(A: Matrix) -> Matrix:
    return ((A+A.conjugate().T)/2).applyfunc(sp.expand)

def partial_trace(A: Matrix, n: int, q: int, keep: tuple[int,...]) -> Matrix:
    outside=tuple(i for i in range(q) if i not in keep)
    inside=list(product(range(n),repeat=len(keep)))
    outs=list(product(range(n),repeat=len(outside)))
    B=sp.zeros(n**len(keep),n**len(keep))
    def index(x):
        j=0
        for h in x:j=n*j+h
        return j
    for a,I in enumerate(inside):
        for b,J in enumerate(inside):
            for O in outs:
                ii=[0]*q;jj=[0]*q
                for h,i in enumerate(keep):ii[i]=I[h];jj[i]=J[h]
                for h,i in enumerate(outside):ii[i]=jj[i]=O[h]
                B[a,b]+=A[index(ii),index(jj)]
    return B

def lift(A: Matrix, n: int, q: int, keep: tuple[int,...]) -> Matrix:
    outside=tuple(i for i in range(q) if i not in keep)
    tuples=list(product(range(n),repeat=q));B=sp.zeros(n**q,n**q)
    def index(x):
        j=0
        for h in x:j=n*j+h
        return j
    for i,I in enumerate(tuples):
        for j,J in enumerate(tuples):
            if all(I[h]==J[h] for h in outside):
                B[i,j]=A[index([I[h] for h in keep]),index([J[h] for h in keep])]/n**len(outside)
    return B

class RealProductOracle:
    """An interface exposing only real product calls and their counter."""
    def __init__(self,n: int,q: int,action: Callable[[Sequence[Matrix]],Matrix]):
        if n<2 or q<2:raise ValueError('Require n,q>=2.')
        self.n,self.q,self.N=n,q,n**q
        self.action=action
        self.calls=0
    def apply(self,factors: Sequence[Matrix]) -> Matrix:
        if len(factors)!=self.q or any(f.shape!=(self.n,1) for f in factors):
            raise ValueError('Wrong factor dimensions.')
        if any(sp.im(x)!=0 for f in factors for x in f):
            raise ValueError('The original oracle accepts real factors only.')
        answer=sp.Matrix(self.action(factors))
        if answer.shape!=(self.N,1):raise ValueError('Oracle returned a wrong-size vector.')
        self.calls+=1
        return answer

class MatrixOracle(RealProductOracle):
    """Adapter for a fixed rational symmetric matrix, assumed PSD by the caller."""
    def __init__(self,M: Matrix,n: int,q: int):
        M=sp.Matrix(M)
        if M.shape!=(n**q,n**q) or M!=M.T:
            raise ValueError('Require a correctly sized real symmetric matrix.')
        if not all(x.is_Rational is True for x in M):
            raise ValueError('This reference adapter requires rational entries.')
        super().__init__(n,q,lambda factors:M*kron(factors))

class ComplexSimulation:
    def __init__(self,oracle: RealProductOracle):
        self.oracle=oracle;self.calls=0
        q=oracle.q
        self.weights=[sp.expand(sp.prod((sp.I-h)/sp.Rational(j-h)
                             for h in range(q+1) if h!=j)) for j in range(q+1)]
    def apply(self,factors: Sequence[Matrix]) -> Matrix:
        answer=sp.zeros(self.oracle.N,1)
        for t,w in enumerate(self.weights):
            real_factors=[f.applyfunc(sp.re)+t*f.applyfunc(sp.im) for f in factors]
            answer+=w*self.oracle.apply(real_factors)
        self.calls+=1
        return answer.applyfunc(sp.expand)

class NoisyPartialOracle:
    def __init__(self,sim: ComplexSimulation,B: Matrix,keep: tuple[int,...],averages: int,bits: Bits):
        self.sim,self.B,self.keep,self.averages,self.bits=sim,sp.Matrix(B),keep,averages,bits
        self.n,self.q=sim.oracle.n,sim.oracle.q
        self.d=self.n**len(keep)
        self.outside=tuple(i for i in range(self.q) if i not in keep)
        self.partial_B=partial_trace(B,self.n,self.q,keep)
    def apply(self,inside: Sequence[Matrix]) -> Matrix:
        if not self.outside:return self.sim.apply(inside)
        x=kron(inside);answer=sp.zeros(self.d,1)
        for _ in range(self.averages):
            outside=dict(zip(self.outside,phase_factors(self.n,len(self.outside),self.bits)))
            full=[None]*self.q
            for i,f in zip(self.keep,inside):full[i]=f
            for i,f in outside.items():full[i]=f
            z=kron(full)
            residual=self.sim.apply(full)-self.B*z
            columns=[]
            for j in range(self.d):
                basis=coordinate_factors(j,self.n,len(self.keep));ff=[None]*self.q
                for i,f in zip(self.keep,basis):ff[i]=f
                for i,f in outside.items():ff[i]=f
                columns.append(kron(ff))
            K=sp.Matrix.hstack(*columns)
            answer+=K.conjugate().T*residual
        return (answer/self.averages+self.partial_B*x).applyfunc(sp.expand)

def selected_columns(Y: Matrix,rho: int) -> Matrix:
    """Exact exhaustive implementation of the column-subset lemma."""
    columns=Y.columnspace()
    if not columns:return sp.zeros(Y.rows,0)
    k=min(len(columns),2*rho)
    if len(columns)<=2*rho:return sp.Matrix.hstack(*columns)
    best=None;best_error=None
    for indices in combinations(range(Y.cols),k):
        F=Y[:,list(indices)];G=F.conjugate().T*F
        if G.det()==0:continue
        residual=Y-F*G.inv()*F.conjugate().T*Y
        error=frobenius_squared(residual)
        if best is None or error<best_error:best,best_error=F,error
    if best is None:raise ArithmeticError('Exact independent-column search failed.')
    return best

def noisy_approximation(oracle: NoisyPartialOracle,rho: int,bits: Bits,
                        embedding_constant: int=2**25) -> Matrix:
    """Default constant is certified. A smaller override is diagnostic only."""
    n,s,d=oracle.n,len(oracle.keep),oracle.d
    if rho>=d:
        Y=sp.Matrix.hstack(*[oracle.apply(coordinate_factors(j,n,s)) for j in range(d)])
        return hermitize(Y)
    h=Fraction(2*n-1,n)**s
    m=ceil(embedding_constant*h*rho)
    Y=sp.Matrix.hstack(*[oracle.apply(phase_factors(n,s,bits)) for _ in range(m)])
    F=selected_columns(Y,rho);k=F.cols
    if k==0:return sp.zeros(d,d)
    m2=ceil(embedding_constant*h*k)
    probes=[];responses=[]
    for _ in range(m2):
        ff=phase_factors(n,s,bits);probes.append(kron(ff));responses.append(oracle.apply(ff))
    Psi=sp.Matrix.hstack(*probes);Z=sp.Matrix.hstack(*responses)
    gram=F.conjugate().T*Psi*Psi.conjugate().T*F
    if gram.det()==0:return sp.zeros(d,d)
    return hermitize(F*gram.inv()*F.conjugate().T*Psi*Z.conjugate().T)

def metric_median(candidates: Sequence[Matrix]) -> Matrix:
    if not candidates or len(candidates)%2!=1:raise ValueError('Need an odd positive number of candidates.')
    scores=[]
    for A in candidates:
        scores.append(sorted(frobenius_squared(A-B) for B in candidates)[len(candidates)//2])
    return candidates[min(range(len(candidates)),key=lambda i:scores[i])]

def estimate_trace(oracle: RealProductOracle,epsilon: Fraction | str,
                   bits: Bits | None=None,max_queries: int=100000) -> tuple[sp.Expr,dict]:
    """Run the certified schedule, or exact basis when its bound is cheaper.

    A preflight limit raises before any queries. No reduced-constant fallback is
    silently substituted. Using a very large max_queries can be computationally
    prohibitive even though every prescribed operation is finite.
    """
    if oracle.calls:raise ValueError('Use a fresh oracle for a complete query audit.')
    bits=bits or secrets.randbits
    plan=theorem_schedule(oracle.n,oracle.q,epsilon)
    eps=Fraction(plan['epsilon']);K=plan['K'];L=plan['candidates']
    H=Fraction(plan['H']);r=plan['r'];q=oracle.q
    if plan['branch']=='plain phase':
        complex_bound=plan['plain_complex_samples']
    else:
        complex_bound=ceil(2**64*L*K*H*r)+plan['residual_samples']
    proposed=(q+1)*complex_bound
    use_basis=oracle.N<=proposed
    budget=oracle.N if use_basis else proposed
    if budget>max_queries:
        raise ValueError(f'Certified preflight budget {budget} exceeds max_queries={max_queries}.')
    if use_basis:
        trace=sp.S.Zero
        for j in range(oracle.N):trace+=oracle.apply(coordinate_factors(j,oracle.n,q))[j]
        return sp.expand(trace),{'branch':'exact basis','real_calls':oracle.calls,
                               'preflight_upper':budget,'certified_parameters':True}
    sim=ComplexSimulation(oracle)
    if plan['branch']=='plain phase':
        total=sp.S.Zero
        for _ in range(plan['plain_complex_samples']):
            ff=phase_factors(oracle.n,q,bits);z=kron(ff)
            total+=(z.conjugate().T*sim.apply(ff))[0]
        result=sp.expand(total/plan['plain_complex_samples'])
    else:
        B=sp.zeros(oracle.N,oracle.N)
        for size in range(q,0,-1):
            for S in combinations(range(q),size):
                noisy=NoisyPartialOracle(sim,B,S,plan['outside_averages'],bits)
                candidates=[noisy_approximation(noisy,plan['rank_target'],bits) for _ in range(L)]
                Ahat=metric_median(candidates)
                B=hermitize(B+lift(Ahat-partial_trace(B,oracle.n,q,S),oracle.n,q,S))
        total=sp.S.Zero
        for _ in range(plan['residual_samples']):
            ff=phase_factors(oracle.n,q,bits);z=kron(ff)
            total+=(z.conjugate().T*(sim.apply(ff)-B*z))[0]
        result=sp.expand(sp.trace(B)+total/plan['residual_samples'])
    assert sp.im(result)==0
    assert oracle.calls==(q+1)*sim.calls and oracle.calls<=budget
    return result,{'branch':plan['branch'],'real_calls':oracle.calls,
                  'complex_calls':sim.calls,'preflight_upper':budget,'certified_parameters':True}
