# Sources and attribution

Public website contents were consulted on 13 September 2026. These are source pointers and scope notes, not redistributed copies of the papers. Bibliographic dates or arXiv versions below identify the documents consulted; no claim is made that every cited preprint has undergone journal peer review.

## 1. The requested problem

**Open Problems in Numerical Linear Algebra, SP-07: The sharp spectral-matching constant for normal matrices.**

- Website: https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/eigenvalues-and-inverse-problems/SP-07
- Plain-text entry read: https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/eigenvalues-and-inverse-problems/SP-07/README.md

Used for the exact problem statement, the spectral-norm convention, the requirement to retain multiplicity, and the distinction between the sharp universal constant and the already-refuted constant-one assertion. The entry's status check is dated 12 September 2026. Its displayed status is context, not a mathematical argument for the incompleteness of this attempt.

## 2. Truncated singular-value bound and numerical interval

**Qiyue Tang, A Truncated Singular-Value Bound for Spectral Variation of Normal Matrices, arXiv:2609.09177v1.**

https://arxiv.org/html/2609.09177v1

Used for Theorem 1.1, the Hall/compression approach, the precise cited upper estimate `C_normal < 2.9038872828`, and the recollection of Krause's squared distance and norm values `28/13` and `27/13`. Section 3 distinguishes the unknown universal constant from the unknown fixed-dimensional constant `c_3`. The report provides its own written derivations of the elementary Hall/compression statements and an exact algebraic check of the explicit example; it does not claim a new truncated-bound theorem.

## 3. Classical dimension-free context

**Adam Parusinski and Armin Rainer, Eigenvalue stability of Hermitian and normal matrices, arXiv:2603.23056v1.**

https://arxiv.org/html/2603.23056v1

Proposition 3.4 states a dimension-independent normal-matrix matching estimate with a constant strictly between one and three. Used as context for the existence of a finite universal bound, not to evaluate the sharp value. The Hermitian spectral-norm matching inequality is also used in the report's explanation of the failed completion shortcut.

## 4. Auxiliary Fourier extremal problem

**Andriy Bondarenko, Joaquim Ortega-Cerda, Danylo Radchenko, and Kristian Seip, The Hormander-Bernhardsson extremal function, arXiv:2504.05205v2.**

https://arxiv.org/html/2504.05205v2

Used to distinguish the solved auxiliary extremal-function question from the original matrix-matching sharpness question. The report does not identify the matrix constant with an auxiliary Fourier constant, and does not assert that an auxiliary extremizer admits the required full normal-matrix completion.

## 5. Two-eigenvalue supporting subclass

**Sidney Holden, SP-07 supporting subclass result, repository note dated 12 September 2026.**

https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/references/holden-spectral-2026-09-12/SP-07/result.md

Used to attribute the repository's recorded sharp constant-one subclass when either normal input has at most two distinct eigenvalues. The report includes a direct proof using spectral subspaces and disk counts. It does not claim novelty, nor does it mistake the subclass result for a universal solution.

## Attribution limitations

The historical Krause example is attributed through Tang's exposition and its cited source. The report does not claim to have recovered an original Krause manuscript. The exact construction and Gram identity were checked directly, independently of a numerical citation. Written reductions in the report are not claimed to be previously unknown. The upper-bound literature is cited, not re-proved in full.
