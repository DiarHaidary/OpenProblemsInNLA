"""Standard-library exact verifier for a dimension-independent MI-20 bound.

The proof interpretation is in proofs/global_bound_certificate.md.
Every acceptance test uses integers and fractions, not floating point.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys
from moment_model import model

def need(b,msg):
    if not b:raise ValueError(msg)

def rational(x):
    need(isinstance(x,str),'Rational values must be strings')
    y=F(x);need(len(x)<10000,'Oversized rational');return y

def positive_definite(a):
    n=len(a);need(n>0 and all(len(row)==n for row in a),'Square Gram matrix required')
    need(all(a[i][j]==a[j][i] for i in range(n) for j in range(n)),'Nonsymmetric Gram matrix')
    # Exact LDL^T elimination; positive pivots prove positive definiteness.
    b=[row[:] for row in a];pivots=[]
    for k in range(n):
        p=b[k][k];need(p>0,'Nonpositive exact LDL pivot');pivots.append(p)
        for i in range(k+1,n):
            for j in range(i,n):
                b[i][j]-=b[i][k]*b[j][k]/p;b[j][i]=b[i][j]
    return pivots

def verify(data):
    need(data.get('format')=='MI20-homogeneous-cubic-Gram-v1','Incorrect format')
    need(data.get('scope')=='all dimensions, p=4/3, m=2','Incorrect scope')
    lam=rational(data['lambda0']);h=rational(data['h'])
    need(F(8)<=lam<F(483,50),'Target outside the established starting enclosure')
    need(h==F(7,5),'This verifier uses the proved h=7/5 bound')
    need((1+h)**3/h>F(483,50),'Invalid bound on the positive cubic root')
    mdl=model(lam,h);mats=mdl['matrices'];eq=mdl['equations'];nv=len(mdl['keys'])
    raw=data['gram_matrices'];need(len(raw)==len(mats),'Gram count mismatch')
    w=[rational(x) for x in data['multipliers']]
    need(len(w)==10 and w[-1]==-1,'The trace normalization multiplier must be -1')
    lhs=[F(0)]*nv;smallest=[]
    for rawz,mat in zip(raw,mats):
        n=len(mat);need(len(rawz)==n and all(len(row)==n for row in rawz),'Gram order mismatch')
        Z=[[rational(x) for x in row] for row in rawz]
        smallest.append(min(positive_definite(Z)))
        for i in range(n):
            for j in range(n):
                for k in range(nv):lhs[k]+=Z[i][j]*mat[i][j][k]
    rhs=[sum(w[i]*eq[i][k] for i in range(10)) for k in range(nv)]
    need(lhs==rhs,'The proposed polynomial Gram identity is not exact')
    # For actual positive cubic solutions, x=tr(D H1 D H2) satisfies
    # 0 <= x <= z/2 and sum_j tr(D Hj D Hj) = z.
    monotone=max(w[0],w[3])+max(w[1],w[5])+max(F(0),(w[2]+w[4])/2)
    need(monotone<=0,'Certificate does not extend to every Lambda >= lambda0')
    return {'status':'PASS','scope':data['scope'],'lambda0':str(lam),
            'universal_upper_fourth_power':str(lam/8),
            'upper_bound_expression':f'({lam/8})^(1/4)',
            'monotonicity_coefficient':str(monotone),
            'positive_definite_Gram_matrices':len(mats),
            'exact_coefficient_identities':nv,
            'dependence':'Uses the proved cubic characterization and the retained interpolation upper bound.'}

if __name__=='__main__':
    p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'certificates/global_p4_3_m2.json'
    print(json.dumps(verify(json.loads(p.read_text())),indent=2))
