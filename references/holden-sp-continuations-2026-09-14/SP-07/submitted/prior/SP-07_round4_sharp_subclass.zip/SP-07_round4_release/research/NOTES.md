# Research boundary

The successful line in this continuation is the exact rank-one-reflection class.
After the full anticommutator is written as a pinching, the two-outlier lemma
forces every ratio above one into a three-coordinate completion problem. Boundary
reduction leaves a scalar unit-circle parameter. Eliminating the final diagonal
coordinate produces a quadratic polynomial whose nonnegativity certificate can
be found by linear programming and checked exactly by weighted AM–GM.

The arbitrary-rank extension does not repeat that normal compression step:
compressing the remaining diagonal data to an r-dimensional block need not be
normal for r>1. The six-moment/inertia proof instead replaces interior spectral
atoms while keeping the required block contraction and Hall deficiency.

This is not a proof of an unrestricted constant. The dimension bound is quadratic
in a fixed reflection rank and gives no rank cutoff. The delivered rank-two
counterexample already rules out treating the sharp rank-one number as universal.

No new global numerical-search optimum is claimed in this round. The prior
193-dimensional example remains the strongest certified global lower endpoint
in these packages. Equivalent variational formulations, a finite-rank hierarchy,
and exact subclass constants are not a replacement for the missing uniform
all-rank inequality and matching limiting construction.
