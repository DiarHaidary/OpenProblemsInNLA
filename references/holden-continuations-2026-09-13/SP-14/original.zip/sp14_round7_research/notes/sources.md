# Source-access ledger

All repository access in this round used public web pages, not a GitHub connector. The references below were checked on 13 September 2026 in the user's America/New_York timezone. The source status is descriptive, not independent validation of the proofs here.

## Load-bearing and target sources

1. **OpenProblemsInNLA, SP-14 README.**
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/eigenvalues-and-inverse-problems/SP-14/README.md
   Read directly on the public web. Identifies the universal continuous-symbol annular nonextension problem and records “Partially resolved,” last checked 11 September 2026. Used only for the precise target and recorded status.

2. **J. M. Bogoya, A. Böttcher, S. M. Grudsky (2012), Asymptotics of individual eigenvalues of a class of large Hessenberg Toeplitz matrices.**
   https://www.math.cinvestav.mx/~grudsky/Papers/116.pdf
   Author manuscript, introduction on printed page 2. Parsed text and a web screenshot of PDF page 2 were inspected for the explicit two-annulus formulation. Used for target corroboration, not as a proof of the universal conjecture.

3. **J. L. Walsh (1935), Approximation by polynomials in the complex domain.**
   https://www.numdam.org/item/MSM_1935__73__1_0.pdf
   Section 4, printed page 9 (PDF page 12). The original page was inspected via a web screenshot. It states uniform approximation of arbitrary continuous functions on a Jordan curve by polynomials in z and 1/z when the origin is inside the curve. Translation gives the rational approximation input used in the manuscript. No rectifiability or area-zero hypothesis is added.

4. **Sixth SP-14 package supplied in this conversation.**
   sp14_round6_research.zip; sp14_round6.pdf, 20 pages.
   The entire manuscript was read. It retains an extra branching assumption and does not establish the universal implication. The new inverse-row argument does not use that unproved implication. The archive is preserved unchanged with its predecessors.

5. **Third SP-14 package, nested in the previous archive.**
   sp14_round3_research.zip; Section 6 of its manuscript proves full convergence for the earlier smooth congruence example. This is referenced only to contextualize why exact zeros at one anchor do not preclude weak convergence. None of the new inverse-corner or subsequence theorems depends on that particular example's full convergence.

## Exploratory sources not used as proof dependencies

- A. Böttcher and S. M. Grudsky, author manuscript on localized pseudomodes:
  https://www.math.cinvestav.mx/~grudsky/Papers/83.pdf
  Read for context on truncating half-line kernel vectors. The needed kernel and min-max argument is proved in the new manuscript.
- J. S. Geronimo, arXiv:math/0508224:
  https://arxiv.org/pdf/math/0508224
  Consulted for context on exponential decay and recurrence coefficients. No theorem from this paper is imported.
- Public searches on Toeplitz nonanalytic symbols, canonical subsequences, determinant decay, and nonconvergence did not supply a theorem closing the new subsequence-to-full-sequence gap. Unrelated results also named “Widom's conjecture” were not used.

The mathematical results in this package have written proofs. No novelty or priority claim is made, and a complete prior-literature classification has not been established.

## Additional comparison investigated

Byung-Geun Oh, *Zeros of the Derivatives of Faber Polynomials Associated with a Universal Covering Map*, arXiv:math/0401165v2 (2004): https://arxiv.org/pdf/math/0401165. Its generating-function and subsequence statements were read while testing whether the determinant limsup could be upgraded by a known polynomial-zero theorem. The paper concerns a special Hessenberg/Faber setting. No theorem from it is used in the manuscript, and it did not supply the missing full-sequence implication here.
