"""Finite-dimensional utilities for the TR-03 continuation.

These routines perform numerical checks. They do not certify global maxima,
probability bounds, or theorems. Singular bases are assigned infinite cost;
no pseudoinverse is substituted for an inverse in the minimax objective.
"""
from __future__ import annotations

from itertools import combinations
from typing import Iterable, Sequence
import math
import numpy as np
from numpy.typing import NDArray
from scipy.linalg import null_space
from scipy.special import gammaln, logsumexp

Array = NDArray[np.float64]


def orthogonal(n: int, rng: np.random.Generator) -> Array:
    if n < 1:
        raise ValueError("n must be positive")
    q, r = np.linalg.qr(rng.standard_normal((n, n)))
    signs = np.where(np.diag(r) < 0.0, -1.0, 1.0)
    return q * signs


def frame(n: int, r: int, rng: np.random.Generator) -> Array:
    if not 1 <= r <= n:
        raise ValueError("require 1 <= r <= n")
    return orthogonal(n, rng)[:, :r]


def inverse_trace(b: Array) -> float:
    b = np.asarray(b, dtype=float)
    ev = np.linalg.eigvalsh((b + b.T) / 2.0)
    if np.min(ev) <= 0.0:
        return math.inf
    return float(np.sum(1.0 / ev))


def basis_cost(q: Array, j: Sequence[int], L: float = math.inf) -> float:
    block = q[np.asarray(j, dtype=int), :]
    if block.shape[0] != block.shape[1]:
        raise ValueError("a square row block is required")
    sv = np.linalg.svd(block, compute_uv=False)
    if math.isinf(L):
        # This tolerance is for numerical rank detection, not a mathematical
        # redefinition of singularity. Tests record when it is used.
        if sv[-1] <= 1e-13 * max(1.0, sv[0]):
            return math.inf
        return float(np.sum(sv ** -2))
    if L < 1.0:
        raise ValueError("L must be at least one")
    return float(np.sum(1.0 / (1.0 / L + (1.0 - 1.0 / L) * sv**2)))


def minors_and_johnson(q: Array) -> tuple[list[tuple[int, ...]], Array, Array]:
    n, r = q.shape
    subsets = list(combinations(range(n), r))
    locations = {j: i for i, j in enumerate(subsets)}
    w = np.array([np.linalg.det(q[list(j), :]) ** 2 for j in subsets])
    aw = np.zeros_like(w)
    for idx, j in enumerate(subsets):
        js = set(j)
        for removed in j:
            for added in range(n):
                if added not in js:
                    neighbor = tuple(sorted((js - {removed}) | {added}))
                    aw[idx] += w[locations[neighbor]]
    return subsets, w, aw


def octahedral_energy(weights: Array) -> tuple[float, float]:
    w = np.asarray(weights, dtype=float).reshape(3, 2)
    sums = w.sum(axis=1)
    adjacency = float(sums.sum() ** 2 - np.dot(sums, sums))
    return adjacency, float(np.sum(w * w))


def flat_distribution(k: int, m: int, L: float) -> tuple[Array, Array]:
    if k < 1 or m < 1 or L < 1.0:
        raise ValueError("require positive k,m and L >= 1")
    q = np.arange(min(k, m) + 1, dtype=float)
    def log_binomial(n: int) -> Array:
        return gammaln(n + 1) - gammaln(q + 1) - gammaln(n - q + 1)
    log_weights = log_binomial(k) + log_binomial(m) + (k - q) * math.log(L)
    return q, np.exp(log_weights - logsumexp(log_weights))


def hollow_basis(a: Array) -> Array:
    """Return a basis making a real trace-zero symmetric matrix hollow.

    Floating-point residuals are inevitable. Raises on a materially nonzero
    input trace rather than silently altering the supplied matrix.
    """
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        raise ValueError("a must be square")
    if not np.allclose(a, a.T, rtol=1e-11, atol=1e-12):
        raise ValueError("a must be symmetric")
    d = len(a)
    if abs(np.trace(a)) > 1e-9 * max(1.0, np.linalg.norm(a)):
        raise ValueError("a must have trace zero")
    if d == 1:
        return np.ones((1, 1))
    ev, vec = np.linalg.eigh(a)
    tol = 1e-13 * max(1.0, np.linalg.norm(a))
    nearest = int(np.argmin(np.abs(ev)))
    if abs(ev[nearest]) <= tol:
        u = vec[:, nearest]
    else:
        lo, hi = float(ev[0]), float(ev[-1])
        if not lo < 0.0 < hi:
            raise ArithmeticError("roundoff destroyed the zero-Rayleigh bracket")
        u = math.sqrt(hi / (hi - lo)) * vec[:, 0] + math.sqrt(-lo / (hi - lo)) * vec[:, -1]
    complement = null_space(u.reshape(1, -1))
    recursive = hollow_basis(complement.T @ a @ complement)
    return np.column_stack([u, complement @ recursive])


def group_matrix(alpha: Iterable[float]) -> tuple[Array, Array]:
    alpha = np.asarray(list(alpha), dtype=float)
    if len(alpha) == 0 or np.any(alpha <= 0.0):
        raise ValueError("each group needs at least one positive contrast value")
    c = float(alpha.sum())
    diagonal = np.diag(np.r_[alpha, -c])
    rotation = hollow_basis(diagonal)
    u = rotation[-1, :].copy()
    b = rotation.T @ diagonal @ rotation + c * np.outer(u, u)
    return u, (b + b.T) / 2.0


def grouped_tail(k: int, sigma: Sequence[float], rng: np.random.Generator) -> dict:
    sigma = np.sort(np.asarray(sigma, dtype=float))[::-1]
    n = k + len(sigma)
    if k < 1 or n < 4 * k or np.any(sigma <= 0.0):
        raise ValueError("require k >= 1, n >= 4k, and a positive tail")
    groups = [sigma[k + g :: 2 * k] for g in range(2 * k)]
    core = orthogonal(2 * k, rng)
    u0, v0 = core[:, :k], core[:, k:]
    t = np.zeros((n, 2 * k))
    contrast = np.zeros((n, n))
    row_group = np.empty(n, dtype=int)
    offsets = [0]
    sums = []
    start = 0
    for g, vals in enumerate(groups):
        u, b = group_matrix(vals)
        stop = start + len(u)
        t[start:stop, g] = u
        contrast[start:stop, start:stop] = b
        row_group[start:stop] = g
        sums.append(float(np.sum(vals)))
        start = stop
        offsets.append(stop)
    if start != n:
        raise AssertionError("group dimensions do not sum to n")
    core_tail = v0 @ np.diag(sigma[:k]) @ v0.T
    tail = t @ core_tail @ t.T + contrast
    return dict(n=n, k=k, sigma=sigma, U=t @ u0, U0=u0, V0=v0,
                tail=tail, core_tail=core_tail, row_group=row_group,
                sums=np.asarray(sums), offsets=offsets, T=t)


def infinite_leading_cost(u: Array, tail: Array, selected: Sequence[int]) -> float:
    i = np.asarray(selected, dtype=int)
    ui = u[i, :]
    if np.linalg.matrix_rank(ui, tol=1e-11) < ui.shape[1]:
        return math.inf
    ui_inv = np.linalg.inv(ui)
    return float(np.trace(tail) + np.trace(ui_inv @ tail[np.ix_(i, i)] @ ui_inv.T))
