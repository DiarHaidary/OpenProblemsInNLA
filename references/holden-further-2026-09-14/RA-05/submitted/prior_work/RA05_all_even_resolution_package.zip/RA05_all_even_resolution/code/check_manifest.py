"""Check every file recorded in SHA256SUMS without external dependencies."""
from __future__ import annotations
import hashlib
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]

def main() -> None:
    checked=0
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        if not line.strip():
            continue
        expected, relative=line.split('  ',1)
        path=(ROOT/relative).resolve()
        if ROOT not in path.parents:
            raise ValueError(f'Path outside package: {relative}')
        if not path.is_file():
            raise FileNotFoundError(relative)
        found=hashlib.sha256(path.read_bytes()).hexdigest()
        if found!=expected:
            raise AssertionError(f'SHA-256 mismatch: {relative}')
        checked+=1
    print(json.dumps({'status':'PASS','sha256_files_checked':checked},indent=2))

if __name__=='__main__': main()
