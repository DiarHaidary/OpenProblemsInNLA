#!/usr/bin/env python3
"""Check that the certificate collection exactly covers the nonempty atlas.

Requires NetworkX. Matrix-rank checking is performed by the separate verifiers.
"""
import json
from pathlib import Path
import networkx as nx


def main():
    root = Path(__file__).resolve().parents[1]
    records = [json.loads(line) for line in (root/'certificates'/'atlas_pairs.jsonl').read_text().splitlines()]
    by_index = {}
    for rec in records:
        idx = rec['atlas_index']
        if idx in by_index:
            raise ValueError('Duplicate atlas index.')
        by_index[idx] = rec
    expected = {i:g for i,g in enumerate(nx.graph_atlas_g()) if len(g)>=1}
    if set(by_index) != set(expected):
        raise ValueError('Missing or extra atlas indices.')
    for i,g in expected.items():
        rec = by_index[i]
        if rec['n'] != len(g):
            raise ValueError('Incorrect graph order.')
        actual_edges = {tuple(e) for e in rec['edges']}
        atlas_edges = {tuple(sorted(e)) for e in g.edges()}
        if actual_edges != atlas_edges or len(rec['edges']) != len(atlas_edges):
            raise ValueError('Certificate graph differs from atlas graph.')
        if rec['graph6'] != nx.to_graph6_bytes(g, header=False).decode().strip():
            raise ValueError('Incorrect graph6 identifier.')
    print(json.dumps({'networkx_version':nx.__version__,
        'nonempty_atlas_entries':len(expected), 'certificate_records':len(records),
        'matching_edge_lists':len(records), 'matching_graph6_identifiers':len(records),
        'missing_indices':0,'duplicate_indices':0,'extra_indices':0},indent=2))


if __name__ == '__main__':
    main()
