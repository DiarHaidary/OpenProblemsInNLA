"""Heuristic search extending a contact-chain Hall witness by one spectral pair.
Does not presume the chain family is globally extremal.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.linalg import null_space
from search_reflections import Model

def main(a):
    rec=json.loads(a.base.read_text());z0=np.array(rec['z'])@np.array([1,1j]);P0=np.array(rec['P_real'])+1j*np.array(rec['P_imag']);nb=len(z0);r0=rec['r'];I0=rec['I'];gap=min(abs(z0[np.array(I0),None]+z0[None,np.array(I0)]).ravel())
    cross=abs(z0[np.array(I0),None]+z0[None,np.array(I0)]);adj=cross<gap*(1+1e-5);degrees=adj.sum(axis=1)-np.diag(adj)
    endpoints=[I0[k] for k in range(len(I0)) if degrees[k]==1 and not adj[k,k]]
    if not endpoints:raise ValueError('No unlooped chain endpoint found')
    endpoint=endpoints[0];angles=np.linspace(0,2*np.pi,4096,endpoint=False);cand=-z0[endpoint]+gap*np.exp(1j*angles)
    ok=(abs(cand[:,None]+z0[np.array(I0)][None,:]).min(axis=1)>=gap*(1-1e-9))&(2*abs(cand)>=gap)
    angles=angles[ok]
    if len(angles)==0:raise ValueError('No separated extension angle found')
    eig,V=np.linalg.eigh(P0);W0=V[:,eig>.5];rng=np.random.default_rng(a.seed);start=time.monotonic();records=[];n=nb+2;r=r0+1
    W=np.zeros((n,r),complex);W[:nb,:r0]=W0;W[nb:,r0]=[1/np.sqrt(2),-1/np.sqrt(2)];O=np.column_stack([W,null_space(W.conj().T)]);I=I0+[nb]
    print('endpoint',endpoint,'feasible angle count',len(angles),flush=True)
    for k in range(a.runs):
        theta=angles[rng.integers(len(angles))];v=-z0[endpoint]+gap*np.exp(1j*theta);z=np.r_[z0,v,-v];model=Model(n,r,I,I,O,a.complex)
        x=np.zeros(model.nv);x[0]=z[0].real
        for i in range(1,n):x[2*i-1:2*i+1]=[z[i].real,z[i].imag]
        x[-1]=gap*.99999;noise=[.001,.005,.02,.05,.1,.2,.4,.7][k%8];x[:-1]+=noise*rng.normal(size=model.nv-1);x[0]=max(.01,x[0])
        out=model.optimize(x,maxiter=350);rr=model.record(out.x);rr.update(seed=a.seed,run=k,noise=noise,theta=float(theta),endpoint=int(endpoint),base=a.base.name,success=bool(out.success),message=str(out.message));records.append(rr)
        print(k,rr['ratio'],rr['minimum_constraint'],rr['success'],flush=True)
        a.output.write_text(json.dumps(dict(status='Exploratory contact-chain extension searches; no global certificate.',elapsed_seconds=time.monotonic()-start,records=records),indent=2)+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--runs',type=int,default=96);p.add_argument('--seed',type=int,default=24494897);p.add_argument('--complex',action='store_true');a=p.parse_args();main(a)
