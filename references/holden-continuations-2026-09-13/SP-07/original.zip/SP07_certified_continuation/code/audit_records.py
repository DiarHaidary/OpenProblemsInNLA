"""Independently recompute saved numerical records without rerunning optimizers.
The results are floating-point consistency checks, not proof certificates.
"""
import argparse,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'prior'/'sp07_partial_results'/'code'))
from matching import bottleneck

def audit(r):
    n=r['n']
    if 'z' in r:
        z=np.array(r['z'])@np.array([1,1j]);P=np.array(r['P_real'])+1j*np.array(r['P_imag']);S=np.eye(n)-2*P
        A=np.diag(z);B=-S@A@S;alpha=z;beta=-z
        unit=np.linalg.norm(S.conj().T@S-np.eye(n),2);proj=np.linalg.norm(P@P-P,2)
        gap=float(min(abs(z[np.array(r['I']),None]+z[None,np.array(r['J'])]).ravel()))
        oldratio=r['ratio'];chart_error=0.
        if all(k in r for k in ['O_real','O_imag','x']):
            from search_reflections import Model
            model=Model(n,r['r'],r['I'],r['J'],np.array(r['O_real'])+1j*np.array(r['O_imag']),r['complex_chart'])
            zz,_,_,PP,_,_,_=model.decode(np.array(r['x']));chart_error=max(np.linalg.norm(PP-P,2),np.max(abs(zz-z)))
    else:
        alpha=np.array(r['a'])@np.array([1,1j]);beta=np.array(r['b'])@np.array([1,1j]);U=np.array(r['U_real'])+1j*np.array(r['U_imag'])
        A=np.diag(alpha);B=U@np.diag(beta)@U.conj().T
        unit=np.linalg.norm(U.conj().T@U-np.eye(n),2);proj=0.;chart_error=0.
        if 'x' in r:
            if r.get('chart')=='offdiagonal_skew_Hermitian_Cayley':
                from search_cauchy_starts import Model as PairModel
                model=PairModel(n,r['p'],np.array(r['U0_real'])+1j*np.array(r['U0_imag']))
            else:
                from search import Model as PairModel
                model=PairModel(n,r['p'],r['complex_unitary'])
            _,(aa,bb,UU,_,_)=model.calculate(np.array(r['x']))
            chart_error=max(np.max(abs(aa-alpha)),np.max(abs(bb-beta)),np.linalg.norm(UU-U,2))
        gap=float(min(abs(alpha[:r['p'],None]-beta[None,:r['q']]).ravel()));oldratio=r['actual_ratio']
    norm=float(np.linalg.norm(A-B,2));distance,perm=bottleneck(alpha,beta);ratio=float(distance/norm)
    normal=np.linalg.norm(B@B.conj().T-B.conj().T@B,2)
    errors=dict(unitarity_residual=float(unit),projection_residual=float(proj),normality_residual=float(normal),
                chart_reconstruction_error=float(chart_error),norm_error=abs(norm-r['norm']),
                ratio_error=abs(ratio-oldratio),gap_error=abs(gap-r['gap']))
    for key,val in errors.items():
        if val>2e-8:raise AssertionError(f'{key}: {val}')
    if gap>distance+1e-8:raise AssertionError('Hall gap exceeds matching distance')
    return ratio,errors

def main(folder,output):
    start=time.monotonic();campaigns=[];worst={};count=0;success=0;allmax=0
    files=[]
    for f in sorted(folder.glob('*.json')):
        data=json.loads(f.read_text())
        if isinstance(data,dict) and isinstance(data.get('records'),list) and data['records'] and 'n' in data['records'][0]:files.append((f,data))
    for f,data in files:
        values=[]
        for r in data['records']:
            ratio,err=audit(r);values.append(ratio);count+=1;success+=bool(r.get('success',False));allmax=max(allmax,ratio)
            for k,v in err.items():worst[k]=max(worst.get(k,0),v)
        campaigns.append(dict(file=f.name,records=len(values),optimizer_successes=sum(bool(r.get('success',False)) for r in data['records']),
                              dimensions=sorted({r['n'] for r in data['records']}),maximum_recomputed_ratio=max(values)))
    polished=[]
    for name in ['best_five_stronger.json','best_seven_stronger.json']:
        r=json.loads((folder/name).read_text());ratio,err=audit(r);polished.append(dict(file=name,dimension=r['n'],ratio=ratio,errors=err))
    result=dict(status='PASSED: saved-record floating-point audit; not an upper-bound proof.',campaign_records=count,
                optimizer_successes=success,optimizer_nonsuccesses=count-success,campaigns=campaigns,
                maximum_campaign_ratio=allmax,maximum_errors=worst,polished_records=polished,
                elapsed_seconds=time.monotonic()-start)
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--folder',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a.folder,a.output)
