#!/usr/bin/env python3
"""Recheck the finite degree/MCS comparisons used in the report.

No external dependencies. Counts concern finite tests, not universal proofs.
"""
from collections import Counter
from itertools import permutations
import json
from pathlib import Path
import sp10


def main():
    root = Path(__file__).resolve().parents[1]
    records = [json.loads(s) for s in (root/'certificates'/'atlas_pairs.jsonl').read_text().splitlines()]
    counts = Counter()
    by_n = Counter()
    failures_combined = []
    for rec in records:
        g = sp10.from_edges(rec['n'], rec['edges'])
        b = sp10.complement(g)
        n = len(g)
        by_n[n] += 1
        gs = [sp10.best_mcs(h)[0] for h in (g, b)]
        ds = [sp10.degeneracy(h) for h in (g, b)]
        counts['mcs_sum_below_n_minus_2'] += sum(gs) < n-2
        counts['degeneracy_sum_below_n_minus_2'] += sum(ds) < n-2
        if sum(max(x, y) for x, y in zip(gs, ds)) < n-2:
            counts['combined_bound_sum_below_n_minus_2'] += 1
            failures_combined.append(rec['atlas_index'])
        for h, greedegree in zip((g,b),gs):
            degrees = sorted(x.bit_count() for x in h)
            if n >= 2:
                assert greedegree >= degrees[1]
            if any(h) and any(sp10.complement(h)):
                a, beta, bound = sp10.degree_threshold_bound(h)
                assert greedegree >= a
                ac, bc, _ = sp10.degree_threshold_bound(sp10.complement(h))
                assert ac == n-1-beta and bc == n-1-a
                counts['clique_prefix_comparisons_checked'] += 1
    bull = sp10.from_edges(5,[[0,1],[0,2],[1,2],[2,3],[0,4]])
    bull_mcs = [p for p in permutations(range(5)) if sp10.check_mcs(bull,p)]
    assert max(bull[p[-1]].bit_count() for p in bull_mcs) == 1
    print(json.dumps({'graphs_checked':len(records), 'graphs_by_order':dict(sorted(by_n.items())),
        **counts, 'combined_bound_failing_atlas_indices':failures_combined,
        'bull_mcs_orders_checked':len(bull_mcs),
        'bull_maximal_final_degree':1,
        'meaning':'Exact finite combinatorial checks, not a proof of SP-10 for arbitrary graphs.'}, indent=2))


if __name__ == '__main__':
    main()
