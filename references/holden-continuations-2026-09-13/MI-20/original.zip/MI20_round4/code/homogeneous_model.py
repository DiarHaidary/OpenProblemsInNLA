"""Exact homogeneous trace-polynomial model; no commutation is assumed."""
from fractions import Fraction as F
from itertools import product

def canon(word):
    w=tuple(word);v=w[::-1]
    if not w:raise ValueError('Empty word')
    return min([w[i:]+w[:i] for i in range(len(w))]+[v[i:]+v[:i] for i in range(len(v))])

def model(lam=F(861,100),h=F(2371,2000),degree=6,m=2):
    if degree not in (4,6,8) or m not in (2,3):raise ValueError('Unsupported model')
    lam,h=F(lam),F(h);alphabet=range(m+1)
    keys=sorted({canon(w) for w in product(alphabet,repeat=degree)})
    ind={w:i for i,w in enumerate(keys)};nv=len(keys)
    def vector(terms):
        out=[F(0)]*nv
        for w,c in terms:out[ind[canon(w)]]+=c
        return out
    polys=[]
    for j in range(1,m+1):
        polys.append([(w,F(1)) for w in product((0,j),repeat=3)]+[((0,j,0),-lam)])
    polys.append([((j,0,j),F(1)) for j in range(1,m+1)]+[((0,j,0),F(-1)) for j in range(1,m+1)])
    mult=list(product(alphabet,repeat=degree-3))
    eq=[vector([(w+v,c) for v,c in poly]) for poly in polys for w in mult]
    eq.append(vector([((0,)*degree,F(1))]))
    forbidden={tuple([j]*3) for j in range(1,m+1)}|{(m,0,m)}
    def basis(length):
        return [w for w in product(alphabet,repeat=length) if not any(w[i:i+3] in forbidden for i in range(length-2))]
    words=basis(degree//2)
    mats=[[[vector([(wi[::-1]+wj,F(1))]) for wj in words] for wi in words]]
    weights=[[(i,F(1))] for i in alphabet]
    weights.append([(0,F(m))]+[(j,F(-1)) for j in range(1,m+1)])
    weights.extend([[(0,h),(j,F(-1))] for j in range(1,m+1)])
    loc=basis((degree-2)//2)
    for a in range(len(weights)):
        for b in range(a,len(weights)):
            mats.append([[vector([(wi[::-1]+(a0,)+wj+(b0,),a1*b1) for a0,a1 in weights[a] for b0,b1 in weights[b]]) for wj in loc] for wi in loc])
    return dict(keys=keys,equations=eq,matrices=mats,main_words=words,local_words=loc,multiplier_words=mult,polynomials=polys,weights=weights,lambda0=lam,h=h,degree=degree,m=m)

def interval_equations(left,right,h,degree=6,m=2):
    a=model(left,h,degree,m);b=model(right,h,degree,m)
    n=len(a['keys']);z=[F(0)]*n;k=len(a['multiplier_words']);c=m*k
    eq=[x+y for x,y in zip(a['equations'][:c],b['equations'][:c])]
    eq += [x+z for x in a['equations'][c:-1]]
    eq += [z+x for x in b['equations'][c:-1]]
    eq += [a['equations'][-1]+b['equations'][-1]]
    return a,b,eq
