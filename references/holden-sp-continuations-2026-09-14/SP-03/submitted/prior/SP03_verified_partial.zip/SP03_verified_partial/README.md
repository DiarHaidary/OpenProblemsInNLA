# SP-03: reduction, bounds, and certificates

**Status: verified computational certificates and written partial results; not a complete solution of SP-03.**

The target is the generic complex critical-point count for Frobenius distance to the standard symplectic group:

\[
D_m\stackrel{?}{=}2^{m^2}+2^{2m-1}.
\]

This package neither proves nor refutes that identity. The mathematical arguments are session-derived, have not received an independent referee audit, and are not formalized in Lean. “Exact verification” refers to the supplied rational/integer calculations and root certificates, not to a formal verification of every written theorem.

## Contents

`report.pdf` is the 11-page mathematical report; `report.tex` is its editable source. It proves a regular reduction to an explicitly given rational critical function in an m-by-m matrix, including generic exclusion of both denominator loci. It derives its gradient and Schur-complement Hessian, proves supermultiplicativity `D_(a+b) >= D_a D_b`, and derives the upper bound

\[
D_m\leq2^m\det\left[\binom{2i+2j-2}{2i-1}\right]_{i,j=1}^m.
\]

The determinant here is the **ordinary degree** of the symplectic group, supplied by the cited primary paper. It must not be substituted for the ED degree.

`src/reduction.py` implements the rational reduction with ordinary complex transposes. `verify/exact_checks.py` checks the structural identities with rational arithmetic at ranks 1–4, and exact Hessian directional identities at ranks 1–3. The all-rank proofs are in the report; finitely many tests are not substitutes for those proofs.

`certificates/` contains binary64 data, root centers, and approximate inverse matrices interpreted as **exact dyadic rationals**. `verify/verify_certificates.py` verifies contraction inequalities using Python integers and fractions, and proves that the resulting simple roots lie in pairwise disjoint polydiscs. It does not trust floating-point residuals or the numerical path tracker.

The included certificates prove **4, 24, and 542 distinct simple critical points** at ranks 1, 2, and 3, respectively. Each is a rigorous lower bound on the generic degree. The rank-3 certificates do not establish the published count of 544 independently. The rank-one equality is proved separately by an explicit quartic.

`results/` contains the verification outputs and exploratory search logs. `experiments/` contains continuation code, its saved numerical states, and the certificate generator. Numerical counts and stopping criteria in that directory do not prove completeness. `sources/REFERENCES.md` distinguishes the external inputs from the results developed here.

## Run the exact verification

From this directory, with Python 3.11 or later:

```bash
python -m pip install -r verify/requirements.txt
python verify/exact_checks.py
python verify/verify_certificates.py certificates/certificates_m1.npz certificates/certificates_m2.npz certificates/certificates_m3.npz --out results/certification.json
```

The verifier uses NumPy for data files and arrays; the proof inequalities themselves use arbitrary-precision integers and rational fractions. Certificate generation is not required to verify the supplied certificates. The verification routine rejects inconsistent shapes, nonfinite values, failed contraction inequalities, and non-disjoint certificate balls.

For each certificate, the data matrix `U` is in **ordinary Frobenius coordinates**, flattened in row-major order. Centers are rows of `roots`; `inverses[i]` is the proposed inverse used at `roots[i]`. Every array is complex binary64. No uncertainty interval around the stored data is assumed: those dyadic entries specify the exact data instance.

## Use the reduction

```python
import numpy as np
from src.reduction import reduce_at, to_q_coordinates

U_standard = np.array([[2.0, 0.1], [0.2, 3.0]], dtype=complex)
U_q = to_q_coordinates(U_standard)
point = reduce_at(np.array([[1.5]], dtype=complex), U_q)
print(point.value, point.gradient, point.hessian)
```

This evaluates the reduced function at a trial matrix. It is not a root solver. The reconstructed symplectic matrix is in the Q-metric coordinates, and is fully critical only when the reduced gradient vanishes. Invertibility of `A` and `L(A)` is necessary; near these divisors, the rational formulas can be ill-conditioned.

## Numerical exploration

The experimental programs additionally require the packages in `experiments/requirements.txt`. A saved search can be continued, for example, with:

```bash
python experiments/full_monodromy.py 3 25
```

The last argument is a per-invocation time budget in seconds, not a completeness condition. The program writes its state beside its source file. Restarted exploratory searches use time-mixed random seeds, so their trajectories are not a deterministic replay; the saved certificates and exact verifier are the reproducible evidence. A stopped search cannot justify an upper bound.

`full_monodromy_strict.py`, `full_monodromy_moderate.py`, and `full_monodromy_relaxed.py` retain successive numerical tolerances used during exploration. The final `full_monodromy.py` uses a deliberately loose corrector stopping tolerance to generate candidates near ill-conditioned branches. This can cause branch jumping; it is harmless only for a candidate generator followed by exact verification, and must not be called a certified homotopy tracker.

The generator can propose a new certificate file from a numerical snapshot:

```bash
python experiments/certify_roots.py 3
```

It writes into `experiments/`, not over the canonical certificates. Its high-precision Newton refinement is only a proposal step. The subsequently checked integer-arithmetic inequalities are the proof step.

## What remains unresolved

The regular critical scheme of the reduced rational function must be counted exactly for generic data. No all-rank degree formula, rank-4 completeness certificate, or counterexample to the conjecture is supplied.

Using the published small-rank inputs, the written bounds give

\[
2,176\le D_4\le12,310,528,
\]

which do not decide the prediction `D_4 = 65,664`. Using only the included lower-bound certificates and the block-product theorem gives the self-contained lower bound `D_4 >= 4*542 = 2,168`.

No repository changes were made. This package does not justify a `SOLVED` status.

## Build the PDF and check integrity

```bash
sha256sum -c SHA256SUMS
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Running scripts that overwrite result JSON files or rebuilding the PDF changes their hashes. Check the supplied manifest before modifying outputs.
