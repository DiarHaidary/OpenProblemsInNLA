#!/usr/bin/env python3
"""Reproduce the finite graph-atlas experiment; generation requires NetworkX.
Exact verification of the resulting certificates does NOT require NetworkX.
"""
from __future__ import annotations
import argparse
import csv
import json
import platform
import time
from pathlib import Path
import networkx as nx
import sp10

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-n', type=int, default=7)
    parser.add_argument('--trials', type=int, default=64)
    parser.add_argument('--out-dir', type=Path, default=ROOT)
    parser.add_argument('--resume', action='store_true', help='Reuse and reverify existing certificates.')
    args = parser.parse_args()
    if not 1 <= args.max_n <= 7:
        parser.error('The bundled NetworkX atlas covers at most seven vertices.')
    output = args.out_dir
    (output / 'certificates').mkdir(parents=True, exist_ok=True)
    (output / 'results').mkdir(parents=True, exist_ok=True)
    records = []
    checked = 0
    certified = 0
    mcs_failures = 0
    threshold_certified = 0
    t0 = time.monotonic()
    certificate_path = output / 'certificates' / 'atlas_pairs.jsonl'
    existing = {}
    if args.resume and certificate_path.exists():
        for line in certificate_path.read_text().splitlines():
            old = json.loads(line)
            sp10.verify_pair(old)
            if old['atlas_index'] in existing:
                raise ValueError('Duplicate atlas index in resumed data.')
            existing[old['atlas_index']] = old
    # Rewrite loaded records too, so an improved UNKNOWN record is persisted.
    # Each line is flushed, permitting another resume after interruption.
    with certificate_path.open('w') as cert_file:
        for atlas_index, graph in enumerate(nx.graph_atlas_g()):
            n = len(graph)
            if not 1 <= n <= args.max_n:
                continue
            a = sp10.from_edges(n, list(graph.edges()))
            b = sp10.complement(a)
            ga, oa = sp10.best_mcs(a)
            gb, ob = sp10.best_mcs(b)
            if ga + gb < n - 2:
                mcs_failures += 1
            if any(a) and any(b):
                aa, bb, bound = sp10.degree_threshold_bound(a)
            else:
                aa, bb, bound = '', '', 1 if n >= 2 else 0
            threshold_certified += bound <= n + 2
            cert = existing.get(atlas_index)
            if cert is not None:
                cached_graph = sp10.from_edges(cert['n'], cert['edges'])
                if cached_graph != a:
                    raise ValueError('Resumed certificate does not match its atlas index.')
            if cert is None:
                cert = sp10.search_pair(a, trials=args.trials, seed=20260913 + atlas_index)
            # Escalation is deterministic and explicitly bounded.
            if cert['status'] != 'CERTIFIED':
                cert = sp10.search_pair(a, trials=512, seed=20260913 + atlas_index)
            cert['atlas_index'] = atlas_index
            cert['graph6'] = nx.to_graph6_bytes(graph, header=False).decode().strip()
            sp10.verify_pair(cert)
            cert_file.write(json.dumps(cert, separators=(',', ':')) + '\n')
            cert_file.flush()
            checked += 1
            certified += cert['status'] == 'CERTIFIED'
            row = {'atlas_index': atlas_index, 'graph6': cert['graph6'], 'n': n,
                   'm': graph.number_of_edges(), 'delta': min(dict(graph.degree()).values()),
                   'Delta': max(dict(graph.degree()).values()),
                   'degeneracy_G': sp10.degeneracy(a), 'degeneracy_complement': sp10.degeneracy(b),
                   'greedegree_G': ga, 'greedegree_complement': gb,
                   'a_degree_threshold': aa, 'b_degree_threshold': bb,
                   'threshold_rank_sum_bound': bound,
                   'certified_rank_G': cert['rank_G'],
                   'certified_rank_complement': cert['rank_complement'],
                   'certified_rank_sum': cert['rank_sum'], 'target': n + 2,
                   'status': cert['status']}
            records.append(row)
            if checked % 100 == 0 or cert['status'] != 'CERTIFIED':
                print(f'{checked} graphs, {certified} certified, {time.monotonic()-t0:.1f}s', flush=True)
    with (output / 'results' / 'atlas_summary.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    summary = {'graphs_checked': checked, 'graphs_certified': certified,
               'graphs_unknown': checked - certified,
               'max_n': args.max_n, 'base_trials_per_dimension': args.trials,
               'mcs_degree_sum_failures': mcs_failures,
               'degree_threshold_certified': threshold_certified,
               'python_version': platform.python_version(), 'networkx_version': nx.__version__,
               'elapsed_seconds_this_invocation': round(time.monotonic()-t0, 3),
               'reused_and_reverified_certificates': len(existing),
               'interpretation': 'Exact PSD witness upper bounds, not computed minimum ranks; a finite check, not an all-graph proof.'}
    (output / 'results' / 'experiment_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
