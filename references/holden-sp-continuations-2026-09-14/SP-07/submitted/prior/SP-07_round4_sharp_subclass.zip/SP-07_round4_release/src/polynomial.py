"""Small exact sparse-polynomial implementation used by the proof checker.

Only integer/rational arithmetic is used. Exponents are tuples of nonnegative
integers. This module has no external dependencies and no dynamic evaluation.
"""
from fractions import Fraction
from typing import Union

Number = Union[int, Fraction]

class Poly:
    def __init__(self, nvars: int, terms=None):
        if not isinstance(nvars, int) or nvars < 1:
            raise ValueError('nvars must be positive')
        self.nvars = nvars
        self.terms = {}
        for ex, c in (terms or {}).items():
            ex = tuple(ex)
            if len(ex) != nvars or any(not isinstance(e, int) or e < 0 for e in ex):
                raise ValueError('invalid exponent')
            c = Fraction(c)
            if c:
                self.terms[ex] = c

    @classmethod
    def const(cls, nvars: int, c: Number):
        return cls(nvars, {(0,)*nvars: Fraction(c)})

    @classmethod
    def var(cls, nvars: int, i: int):
        if not 0 <= i < nvars:
            raise ValueError('invalid variable index')
        ex = [0]*nvars
        ex[i] = 1
        return cls(nvars, {tuple(ex): 1})

    def _coerce(self, other):
        if isinstance(other, Poly):
            if other.nvars != self.nvars:
                raise ValueError('variable counts differ')
            return other
        return Poly.const(self.nvars, other)

    def __add__(self, other):
        other = self._coerce(other)
        d = dict(self.terms)
        for e,c in other.terms.items():
            d[e] = d.get(e, 0) + c
        return Poly(self.nvars, d)

    __radd__ = __add__

    def __neg__(self):
        return Poly(self.nvars, {e:-c for e,c in self.terms.items()})

    def __sub__(self, other):
        return self + (-self._coerce(other))

    def __rsub__(self, other):
        return self._coerce(other) + (-self)

    def __mul__(self, other):
        other = self._coerce(other)
        d = {}
        for ex,c in self.terms.items():
            for ey,v in other.terms.items():
                e = tuple(a+b for a,b in zip(ex,ey))
                d[e] = d.get(e,0) + c*v
        return Poly(self.nvars, d)

    __rmul__ = __mul__

    def __pow__(self, k: int):
        if not isinstance(k, int) or k < 0:
            raise ValueError('power must be a nonnegative integer')
        out = Poly.const(self.nvars,1)
        base = self
        while k:
            if k & 1:
                out = out*base
            base = base*base
            k >>= 1
        return out

    def __truediv__(self, c: Number):
        c = Fraction(c)
        if not c:
            raise ZeroDivisionError()
        return self* (1/c)

    def __eq__(self, other):
        try:
            other = self._coerce(other)
        except (TypeError, ValueError):
            return False
        return self.terms == other.terms

    def evaluate(self, values):
        if len(values) != self.nvars:
            raise ValueError('wrong number of values')
        total = Fraction(0)
        for ex,c in self.terms.items():
            term = c
            for val, power in zip(values,ex):
                term *= Fraction(val)**power
            total += term
        return total

    def substitute(self, images):
        if len(images) != self.nvars or not images:
            raise ValueError('wrong number of images')
        m = images[0].nvars
        out = Poly.const(m,0)
        for ex,c in self.terms.items():
            term = Poly.const(m,c)
            for image,power in zip(images,ex):
                term *= image**power
            out += term
        return out
