"""Reconstruct exact cubic inequalities. Exploration, not itself a universal proof."""
import sympy as s,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p,y,z,a,u,v,w,t=s.symbols('p y z a u v w t',nonnegative=True)
d=1-a;n=p+y+z;tr=p+a*(y+z)
e2=d*(-p*y+a*p*z-(1+a)*y*z);e3=-(1+a)*d*d*p*y*z
D=tr*tr-3*e2;disc=tr*tr*e2*e2-4*e2**3-4*tr**3*e3-27*e3**2+18*tr*e2*e3
U=4*n*n/(a+3)-d*(a+3)/4
Q=s.factor(64*(a+3)**3*(U*(U-D)**2-disc)/d**2)
B=s.factor(4*(a+3)*(U-D)/d)
(ROOT/'exploration/typeA_Q.txt').write_text(str(Q));(ROOT/'exploration/typeA_B.txt').write_text(str(B))
subs={'plus':{p:(a+2)*v+u,y:v,z:1+w},'minus':{p:1+v,y:(1+v+u)/(a+2),z:1+w},'far':{p:1+v,y:1+v+u,z:1+w}}
for name,sub in subs.items():
 for label,expr in [('Q',Q),('B',B)]:
  qq=s.factor(expr.subs(sub,simultaneous=True));num,den=s.fraction(qq);pp=s.Poly(num,a);degree=pp.degree()
  nn=s.Poly(s.expand(sum(co*t**mon[0]*(1+t)**(degree-mon[0]) for mon,co in pp.terms())),u,v,w,t)
  neg=[(m,c) for m,c in nn.terms() if c<0]
  data={'variables':['u','v','w','t'],'terms':[[list(m),str(c)] for m,c in nn.terms()],'negative':len(neg),'a_degree':degree,'denominator':str(den),'substitution':{str(k):str(val) for k,val in sub.items()},'source_expression':label}
  (ROOT/f'exploration/typeA_{name}_{label}.json').write_text(json.dumps(data,indent=2))
  print(name,label,'monomials',len(nn.terms()),'negative',len(neg),'den',den,'examples',neg[:8],flush=True)
