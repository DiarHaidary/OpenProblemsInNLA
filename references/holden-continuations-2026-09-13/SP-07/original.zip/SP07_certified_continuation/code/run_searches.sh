#!/usr/bin/env bash
# Rerun saved campaign configurations using the shipped starting records.
# Numerical outcomes may vary across platforms. This does not prove an upper bound.
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
mkdir -p rechecked/searches
python code/search_reflections.py --sizes 7 9 11 13 --runs 32 --seed 31415926 --output rechecked/searches/extension_real.json
python code/search_reflections.py --base results/best_7.json --sizes 7 9 11 13 15 --runs 32 --seed 27182818 --output rechecked/searches/extension_seven_real.json
python code/search_reflections.py --base results/best_7.json --sizes 7 9 --runs 24 --seed 16180339 --complex --output rechecked/searches/extension_seven_complex.json
python code/search_reflections.py --base results/best_seven_stronger.json --sizes 9 11 13 15 --runs 48 --seed 14142135 --output rechecked/searches/extension_seven_stronger.json
python code/search_general_pairs.py --base results/best_five_stronger.json --sizes 5 6 --runs 24 --seed 17320508 --complex --output rechecked/searches/general_five_complex.json
python code/search_general_pairs.py --base results/best_seven_stronger.json --sizes 7 8 9 --runs 24 --seed 17320508 --output rechecked/searches/general_seven_real.json
python code/search_general_pairs.py --base results/best_seven_stronger.json --sizes 7 8 --runs 18 --seed 22360679 --complex --output rechecked/searches/general_seven_complex.json
python code/search_chain_extensions.py --base results/best_seven_stronger.json --runs 96 --seed 24494897 --output rechecked/searches/chain_nine.json
python code/search_cauchy_starts.py --sizes 4 5 6 7 8 9 --runs 32 --seed 161803398 --output rechecked/searches/cauchy_starts.json
