# RA-05: all-accuracy unrestricted even-power classification

## Scope

This is a research proof claim, **not a full solution of the original RA-05 entry**.
The manuscript gives matching bounds up to logarithms for every fixed **even**
exponent p=2s>=4, every k>=1, and 0<epsilon<1/2, with arbitrary input rank:

    R_s(k,epsilon) = min(k^s/epsilon^2,
                         k^(s+1/2)/epsilon + k^(s-1)/epsilon^2)

    c_s R_s <= S_(2s)(k,epsilon)
            <= C_s R_s log^(2s+5)(2k/epsilon).

The improved second upper branch separately has log exponent 5. Constants depend
only on the fixed exponent. All upper bounds use nonnegative original-row weights.
The even-power intermediate-accuracy gap in the preceding package is closed by a
new structured polynomial Gaussian estimate and scalar matrix-Hilbert constraints.
The proof does not assume earlier unreviewed asymptotic upper/lower results.

**Non-even real p>2 remains unclassified.** Whole-entry status: PARTIAL, subject to
review. No independent peer review, proof-assistant verification, efficient full
implementation, or first-discovery priority is claimed. No repository files changed.

## Files

- `manuscript.pdf`, `manuscript.tex`: complete proof, including both lower families.
- `PROOF_AUDIT.md`: dependency and error-sensitive proof checks.
- `REMAINING_GAP.md`, `STATUS.md`: exact scope; no unjustified even-to-real transfer.
- `SOURCES.md`: primary sources and exact imported theorem locations.
- `code/verify.py`: finite checks of the new covariance/protection/query arguments.
- `code/check_exact_certificate.py`: standalone integer/Fraction checker.
- `code/generate_exact_certificate.py`: optional regeneration using SciPy/SymPy.
- `code/even_features.py`: unchanged finite tensor helpers from the prior package.
- `results/`: recorded test results and the exact 81-to-45 row certificate.
- `prior_work/RA05_even_power_high_accuracy_package.zip`: unchanged predecessor.

## Reproduce

From the package root, with Python 3.10 or later:

```sh
python -m pip install -r requirements.txt
sh run_checks.sh
```

The checks print fresh results without overwriting the recorded JSON reports.
An explicit `python code/verify.py --record` refreshes those reports locally and
therefore invalidates their original manifest hashes. Floating-point diagnostics
can differ slightly across numerical-library versions.

The standalone exact checker needs only the Python standard library:

```sh
python code/check_exact_certificate.py
```

To build the PDF (TeX Live with the packages used in the source):

```sh
make pdf
```

The optional certificate generator requires SciPy and SymPy. The saved certificate
is checked exactly without them. A different LP basis under another library
version can produce a different valid certificate; the saved one is authoritative
for the recorded fractions. Running the generator overwrites that local JSON.

## What the finite checks establish

The new suite records 87,932 assertions, of which 86,450 are repeated monomial/rank
bookkeeping. The remaining 1,482 test algebra, maps, covariance contractions,
polarization, and regimes. The exact checker separately records 135 assertions.
These counts are not independent mathematical verifications. They do not replace
the all-direction Gaussian proof or certify asymptotic core existence or external
partial-coloring/restricted-invertibility results.

The exact certificate preserves degrees 2,4,6,8 and all corresponding subspace
costs. It also has a nonzero cubic error on a stated direction, illustrating why
one cannot simply claim that these even moments imply exact non-even preservation.
That observation does not rule out another cubic coreset.
