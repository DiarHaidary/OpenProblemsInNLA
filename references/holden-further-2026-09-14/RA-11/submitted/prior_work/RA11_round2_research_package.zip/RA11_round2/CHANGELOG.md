# Round 2 changes relative to the preserved first package

## New mathematical result

An all-PSD `O_q(1/epsilon)` upper bound is added. It is independent of n for fixed
q until the exact `n**q` cap is cheaper. An ordinary-oracle lower-bound proof is
included to derive `Theta_q(min(n**q,1/epsilon))` without needing to unpack the
first manuscript for that corollary.

## New mechanism

Controls are learned for every nonempty original PSD partial trace, in descending
subset size. Orthogonal identity/traceless components keep track of which
approximation error controls each residual component. This converts the later
matrix-contraction noise and final scalar variance into a sum of squared errors.
Four-phase probes give finite randomness and deterministic local norms.

The approximation lemma uses deterministic column-subset selection and an
independent two-sided regression sketch. The implementation does not request
matvecs on its learned basis vectors. Classical column-selection and sketching
ingredients are cited rather than claimed as new.

## Deliverable additions

The new manuscript, an exact-rational reference, a smaller numerical reference,
three executed test suites, recorded results, source notes, proof audit, and
reproduction scripts are included. The first ZIP is unchanged.

## What has not changed

The unrestricted q-dependence is still unmatched. The product-matrix promise
from round 1 is not imposed on the new theorem and is not imposed silently on
RA-11. The package is not labeled a full solution. No claim of independent
review, formal verification, or exhaustive novelty checking is made.
