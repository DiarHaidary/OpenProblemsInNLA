"""Deterministic finite checks of the NEW all-even proof ingredients.

The randomized numerical instances use a fixed seed. Assertions on monomial
bookkeeping are not independent proof verifications. No tail-probability theorem
or asymptotic existence result is inferred from finite samples.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import json
import argparse
import numpy as np
from even_features import Features, protected_maps, protected_indices, monomials
from check_exact_certificate import check as check_certificate

ROOT=Path(__file__).resolve().parents[1]
COUNTS=Counter()
WORST={}
RNG=np.random.default_rng(13090526)

def require(condition: bool, category: str, detail: str='') -> None:
    COUNTS[category]+=1
    if not condition:
        raise AssertionError(f'{category}: {detail}')

def close(a,b,category:str,detail:str='',tol:float=2e-8) -> None:
    a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
    error=float(np.linalg.norm(a-b)/max(1.,float(np.linalg.norm(a)),float(np.linalg.norm(b))))
    WORST[category]=max(WORST.get(category,0.),error)
    require(error<tol,category,f'{detail}; scaled error {error}')

def psd_le(a,b,category:str,detail:str='') -> None:
    delta=(b-a + (b-a).T)/2
    scale=max(1.,float(np.linalg.norm(a,2)),float(np.linalg.norm(b,2)))
    violation=max(0.,-float(np.linalg.eigvalsh(delta)[0]))/scale
    WORST[category]=max(WORST.get(category,0.),violation)
    require(violation<3e-8,category,f'{detail}; scaled PSD violation {violation}')

def projected_coefficient_space(rows:np.ndarray,n:int) -> np.ndarray:
    _,sing,vh=np.linalg.svd(rows,full_matrices=False)
    rank=int(np.sum(sing>1e-11*max(1.,float(sing[0]))))
    return np.eye(n)-vh[:rank].T@vh[:rank]

def query(k:int,q:int,rank:int):
    U,_=np.linalg.qr(RNG.normal(size=(k+q,rank)))
    eig=RNG.uniform(.1,.95,size=rank)
    P=(U*eig)@U.T
    ev,E=np.linalg.eigh(np.eye(k+q)-P)
    Q=(E*np.sqrt(np.maximum(ev,0)))@E.T
    return Q[:,:k],Q[:,k:],P[k:,k:]

def rank_bookkeeping():
    for s in range(2,21):
        for a,b,c,d in monomials(s):
            if a>=1 and b+c:
                l,nu,h,e,j,t=protected_indices(s,a,b,c,d)
                tests=[(l==2*h+nu,'left degree'),(j==2*e+b+nu,'right degree'),
                       (h+e+nu==a,'inner-product degree'),(t==b+2*c,'tail degree'),
                       (0<=j<=s-1,'mixed rank'),(j+c<=s-1,'base rank bound'),
                       (l+j+c==s+a-d,'new exact degree identity'),
                       (l+j+c<=2*s-1,'new protected exponent'),
                       (F(2+l+j+c,2)<=F(2*s+1,2),'new rank exponent'),
                       (e>=0,'nonnegative exponent')]
                for cond,label in tests: require(cond,'monomial_rank_identities',label)
    # Algebra of the three branches, on rational polynomial exponents.
    for s in range(2,15):
        for q in [F(j,8) for j in range(1,41)]:
            A=F(s)+2*q; B=F(2*s+1,2)+q; D=F(s-1)+2*q
            exact=min(A,max(B,D))
            desired=A if q<=F(1,2) else B if q<=F(3,2) else D
            require(exact==desired,'rate_regimes',f's={s}, accuracy=k^-{q}')

def polarization():
    Bs=[(1,0),(0,1),(1,1),(2,-1)]
    coeff=[2,-1,3,1]
    def matadd(mats,signs):
        return tuple(sum(F(sign)*mat[i] for mat,sign in zip(mats,signs)) for i in range(4))
    for degree in range(1,7):
        outdim=1 if degree%2==0 else 2
        def P(V):
            out=[F(0) for _ in range(outdim)]
            for b,z in zip(Bs,coeff):
                x=[V[0]*b[0]+V[1]*b[1], V[2]*b[0]+V[3]*b[1]]
                power=sum(t*t for t in x)**(degree//2)
                vals=[power] if degree%2==0 else [power*t for t in x]
                out=[v+z*t for v,t in zip(out,vals)]
            return tuple(out)
        def A(mats):
            total=[F(0) for _ in range(outdim)]
            for signs in product((-1,1),repeat=degree):
                vals=P(matadd(mats,signs)); sign=int(np.prod(signs))
                total=[x+sign*y for x,y in zip(total,vals)]
            return tuple(x/F(2**degree*factorial(degree)) for x in total)
        for trial in range(3):
            mats=[tuple(F(int(v),2) for v in RNG.integers(-3,4,size=4)) for _ in range(degree)]
            require(A([mats[0]]*degree)==P(mats[0]),'exact_polarization','diagonal')
            w=tuple(F(int(v),3) for v in RNG.integers(-2,3,size=4))
            combined=tuple(x+y for x,y in zip(mats[0],w))
            lhs=A([combined]+mats[1:]); x=A(mats); y=A([w]+mats[1:])
            require(lhs==tuple(u+v for u,v in zip(x,y)),'exact_polarization','additivity')
            require(A([tuple(3*x for x in mats[0])]+mats[1:])==tuple(3*x for x in A(mats)),
                    'exact_polarization','scaling')

def tensor_and_covariance():
    summaries=[]
    for s in range(2,7):
        k=3 if s==3 else 2; qtail=2; n=32
        B=RNG.normal(size=(n,k)); B/=np.linalg.norm(B,axis=1)[:,None]
        B*=RNG.uniform(.7,1.3,size=(n,1))
        C=RNG.normal(size=(n,qtail)); C/=np.linalg.norm(C,axis=1)[:,None]
        C*=RNG.uniform(.45,.9,size=(n,1))
        omega=RNG.uniform(.5,1.5,size=n); omega/=omega.sum()
        feat=Features(B,C,omega,s)
        close(feat.pi.sum(),1.,'feature_state','density mass')
        for E in feat.E.values(): close(E.T@E,np.eye(E.shape[1]),'feature_state','head covariance')
        V,W,PC=query(k,qtail,k)
        AV=np.sum((B@V.T)**2,axis=1)
        XV=np.sum((B@V.T)*(C@W.T),axis=1)
        RV=np.einsum('ni,ij,nj->n',C,PC,C)
        H=float(omega@(AV**s))
        chosen={(s-1,1,0,0),(s-1,0,1,0),(1,1,s-2,0),(1,0,s-1,0)}
        covariance_count=0
        for a,b,c,d in monomials(s):
            if a<1 or b+c==0: continue
            L,J,(l,nu,h,e,j,t)=protected_maps(feat,V,W,PC,a,b,c,d)
            E=feat.E[l]; FF=feat.F[j,t]
            left=E@L.T; right=FF@J.T
            direct=omega*AV**a*XV**b*RV**c*feat.r**(2*d)
            contracted=feat.r**(2*d)*np.sum(left*right,axis=1)
            close(contracted,direct,'mixed_factorization',f'{s,a,b,c,d}')
            close(np.linalg.norm(L)**2,omega@(AV**l),'structured_query_maps','adapted norm identity')
            require(np.linalg.norm(J)**2 <= k**c * float(omega@(feat.r**(2*t)*AV**j))*(1+2e-7)+1e-10,
                    'structured_query_maps','right map norm bound')
            # Homogeneity in the k-by-k parameter after replacing by a square Gram factor.
            ev,U=np.linalg.eigh(V.T@V); V0=(U*np.sqrt(np.maximum(ev,0)))@U.T
            zeroW=np.zeros((k,qtail)); zeroPC=np.zeros((qtail,qtail))
            L0,_,_=protected_maps(feat,V0,zeroW,zeroPC,a,b,c,d)
            ztest=RNG.normal(size=(L.shape[1],3))
            close(np.linalg.norm(L@ztest),np.linalg.norm(L0@ztest),'output_isometry','arbitrary output dimension')
            Lscaled,_,_=protected_maps(feat,1.7*V0,zeroW,zeroPC,a,b,c,d)
            close(Lscaled,1.7**l*L0,'polynomial_homogeneity','matrix-valued query')
            if (a,b,c,d) not in chosen: continue
            covariance_count+=1
            atoms=(feat.r**(2*d)/feat.pi)[:,None,None]*E[:,:,None]*FF[:,None,:]
            # A strict fractional subset tests domination and output protection together.
            subset=np.arange(n)[::1 if covariance_count%2 else 2]
            atoms=atoms[subset]; m=len(subset); D,R=atoms.shape[1:]
            T=atoms.reshape(m,-1).T
            U,sv,vh=np.linalg.svd(T,full_matrices=False)
            protected=min(3,m-4)
            constraints=np.vstack((vh[:protected], np.ones((1,m)), RNG.normal(size=(1,m))))
            Pi=projected_coefficient_space(constraints,m)
            Y=T@Pi; mixed=Y.T.reshape(m,D,R)
            close(Pi@Pi,Pi,'coefficient_projection','idempotence')
            close(Pi,Pi.T,'coefficient_projection','symmetry')
            close(U[:,:protected].T@Y,np.zeros((protected,m)),'full_covariance_protection','protected outputs')
            unprotected=float(sv[protected]**2)
            vactual=float(np.linalg.eigvalsh(Y.T@Y)[-1])
            require(vactual<=unprotected*(1+2e-7)+1e-8,'full_covariance_protection','spectral cutoff')
            require(unprotected<=float(np.sum(sv*sv))/(protected+1)*(1+1e-12),
                    'full_covariance_protection','trace/codimension bound')
            require(np.linalg.matrix_rank(U[:,:protected].T@T,tol=1e-8)<=protected,
                    'full_covariance_protection','scalar equation count')
            A0=np.einsum('ndr,ner->de',atoms,atoms)
            A1=np.einsum('ndr,ner->de',mixed,mixed)
            psd_le(A1,A0,'left_variance_contraction','additional exact constraints')
            sigma=float(np.linalg.eigvalsh(A0)[-1])
            LY=np.einsum('od,ndr->nor',L,mixed)
            mean=float(np.sum(LY**2))
            require(mean<=sigma*np.linalg.norm(L)**2*(1+1e-7)+1e-8,
                    'structured_gaussian_moments','trace bound')
            YL=LY.reshape(m,-1).T
            top=float(np.linalg.eigvalsh(YL.T@YL)[-1])
            require(top<=vactual*np.linalg.norm(L,2)**2*(1+1e-7)+1e-8,
                    'structured_gaussian_moments','full covariance bound')
            coeff=Pi@RNG.normal(size=m)
            Z=np.einsum('n,ndr->dr',coeff,atoms)
            err=float(np.trace(L@Z@J.T))
            directerror=float(np.sum(coeff*direct[subset]/feat.pi[subset]))
            close(err,directerror,'projected_trace_identity','actual monomial error')
            require(abs(err)<=np.linalg.norm(L@Z)*np.linalg.norm(J)*(1+1e-10)+1e-10,
                    'structured_gaussian_moments','query-only Frobenius pairing')
        # Rank-deficient and badly scaled parameterizations, tested without numerical inverse truncation.
        for l in range(1,s+1):
            scale=np.diag(np.geomspace(1e-3,1e3,k))
            Vtest=RNG.normal(size=(k,k)); Vtest[-1]=0
            response=B@Vtest.T
            transformed=(B@scale.T)@(Vtest@np.linalg.inv(scale)).T
            close(transformed,response,'condition_change','row/parameter inverse transformations')
            norm1=float((omega@np.sum(response**2,axis=1)**l)**(1/(2*l)))
            norm2=float((omega@np.sum(transformed**2,axis=1)**l)**(1/(2*l)))
            close(norm1,norm2,'condition_change','adapted norm invariance')
        summaries.append({'s':s,'p':2*s,'head_dimension':k,'tail_dimension':qtail,
                          'rows':n,'tested_covariance_families':covariance_count,
                          'head_optimality':'not asserted; these checks do not use optimality'})
    return summaries

def mgf_checks():
    # Deterministic checks of the analytic inequality, not a probability estimate.
    for n in (1,3,10):
        for _ in range(5):
            eig=RNG.uniform(0,3,size=n); eig[0]=0 if n>1 else eig[0]
            b=float(eig.max()); v=float(eig@eig)
            for f in (.01,.1,.25,.45):
                t=f/b
                logmgf=float(np.sum(-t*eig-.5*np.log1p(-2*t*eig)))
                require(logmgf <= t*t*v/(1-2*b*t)+1e-10,'gaussian_mgf_algebra','series bound')
                u=2.7; tc=np.sqrt(u)/(np.sqrt(v)+2*b*np.sqrt(u))
                exponent=-tc*(2*np.sqrt(v*u)+2*b*u)+tc**2*v/(1-2*b*tc)
                close(exponent,-u,'gaussian_mgf_algebra','Chernoff optimizer')

def main(record: bool = False):
    rank_bookkeeping(); polarization(); summaries=tensor_and_covariance(); mgf_checks()
    exact=check_certificate()
    result={'status':'PASS','new_assertions':sum(COUNTS.values()),'categories':dict(COUNTS),
            'worst_scaled_residuals':WORST,'finite_feature_instances':summaries,
            'separate_exact_certificate':exact,
            'seed':13090526,
            'scope':'Finite algebra and implementation checks only. Counts are not independent proof audits. The structured probability theorem, arbitrary-norm net, and all asymptotic results rest on the manuscript proofs.'}
    if record:
        (ROOT/'results/verification.json').write_text(json.dumps(result,indent=2)+'\n')
        (ROOT/'results/exact_certificate_check.json').write_text(json.dumps(exact,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--record',action='store_true',help='Overwrite recorded JSON reports (invalidates the original manifest).')
    main(parser.parse_args().record)
