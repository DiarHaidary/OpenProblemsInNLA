# Primary sources consulted on the website

Access date: September 13, 2026.

1. Exact TR-03 statement and scope:
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/TR-03/README.md
   https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/randomized-and-low-rank-approximation/TR-03
2. Workshop collection, Problem 4.7:
   https://arxiv.org/html/2602.05394v3
3. Fornace and Lindsey, determinantal subset sampling and volume identities:
   https://arxiv.org/html/2407.01698v2
4. Kozyrev and Osinsky, related orthonormal-submatrix minimax notation:
   https://arxiv.org/html/2507.20435

The mathematical arguments for the quantitative octahedral bound, Gaussian
augmentation construction, and weighted-tail construction are supplied in
full in the report. These sources are contextual references, not assertions
that the sources contain or endorse those new arguments. No comprehensive
literature-priority claim is made.

The previous uploaded package `TR03_analysis.zip` is preserved by extracting
its contents unchanged under `prior/`. A SHA-256 provenance check is recorded
in `results/prior_provenance.json`.
