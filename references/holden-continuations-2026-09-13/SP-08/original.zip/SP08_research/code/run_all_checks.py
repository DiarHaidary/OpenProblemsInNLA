#!/usr/bin/env python3
"""Run the reproducible checks included with this partial SP-08 continuation.

A successful report checks the stated identities and certificates, not SP-08
in full. NumPy sweeps are supplementary and never substitute for proofs.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--numerical', action='store_true', help='Also run supplementary NumPy sweeps.')
    args = parser.parse_args()
    names = ['verify_typeA_certificate.py', 'check_analytic_identities.py', 'check_improved_boundary_strip.py']
    if args.numerical:
        names.append('check_centered_rank_two_numerically.py')
    results = []
    env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    for name in names:
        script = ROOT / 'code' / name
        started = time.monotonic()
        if not script.exists():
            results.append({'script': name, 'status': 'MISSING'})
            continue
        try:
            process = subprocess.run([sys.executable, str(script)], cwd=ROOT, env=env,
                                     capture_output=True, text=True, timeout=240)
            stdout = ROOT / 'checks' / (script.stem + '.stdout.txt')
            stderr = ROOT / 'checks' / (script.stem + '.stderr.txt')
            stdout.write_text(process.stdout)
            stderr.write_text(process.stderr)
            results.append({'script': name, 'status': 'PASS' if process.returncode == 0 else 'FAIL',
                            'returncode': process.returncode, 'seconds': round(time.monotonic()-started, 3),
                            'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest()})
        except subprocess.TimeoutExpired:
            results.append({'script': name, 'status': 'TIMEOUT', 'seconds': round(time.monotonic()-started, 3)})
    report = {'scope': 'Included exact identities and subclass certificates only; not unrestricted SP-08.',
              'status': 'PASS' if all(r['status'] == 'PASS' for r in results) else 'FAIL',
              'results': results}
    (ROOT / 'checks' / 'final_reproduction_report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    return 0 if report['status'] == 'PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
