# Proof-scope audit

This audit accompanies a recovered research manuscript, not a claim that
IE-20 has been completely solved. Section and theorem numbers below refer
to the supplied PDF.

## Target

The target is the least threshold `P_CG(n,K,epsilon)` that guarantees a
successful produced iterate by step `n` at every greater precision, for
every admissible stored input and every permitted operation-error sequence.
Success uses the true residual, not the recursive residual. The fixed
short recurrence, multiplication/addition separation, left-to-right sums,
input representability, and zero-divisor stopping rule all matter.

## Analytic arguments recovered

| Location | Statement and scope |
| --- | --- |
| Theorem 2.1 | Lower bound from erroneous accumulation on an identity matrix; an exactly zero recursive residual can conceal true backward-error failure. |
| Theorem 2.2 | Lower bound from an exactly representable SPD matrix with condition number `2**(p+1)-1` and an admissible first-step breakdown. |
| Theorem 3.1 | First-step upper bound when `K=1`; together with Theorem 2.1, sharp orders for `K=1` and `n=1`. |
| Theorem 4.1 | Explicit sufficient precision of order `n log(2K) + log(n/epsilon)` using a local-error bootstrap, orthogonality-defect estimates, a dimension contradiction, and a true-residual gap bound. |
| Theorem 5.2 | For each fixed dimension, the path/outlier family has the stated dyadic large-outlier limits. Constants in intermediate asymptotics may depend on the dimension. |
| Corollary 5.3 | Matching order `n log K` on the specified joint regime, not on every parameter triple. The sufficiently-large exponent threshold is not made dimension-uniform. |
| Corollary 5.4 | Consequence of that family: no universal bound `C log(nK/epsilon)` can hold on all triples in this model. |
| Appendix A | An exact-arithmetic comparison with the cited MINBERR theorem; not a finite-precision transfer theorem. |

For `n >= 2`, the general lower and upper expressions in the manuscript are

```text
c [log2(n/epsilon) + log2(K)]
    <= P_CG(n,K,epsilon)
    <= C [n log2(2K) + log2(n/epsilon)].
```

They leave a genuine all-parameter gap. In particular, the upper expression
cannot itself be the sharp uniform order because it is too large in the
condition-number-one regime. No complete replacement formula is asserted.

## What the code establishes on the recorded examples

The executor uses exact rational arithmetic to check input representability
and SPD status, to implement the scalar-error equations, and to verify the
error magnitudes. The witness checker tests the stopping outcome and the
failure certificate for each produced iterate in its path/outlier examples.
The supplied logs record 15 passing witnesses and ten passing regression
tests, regenerated during recovery.

Positive rational certificate margins are sufficient for failure because
`(a+b)^2 <= 2(a^2+b^2)`. They are not claimed to equal the backward error.
The operator norm/condition-number facts used for the input families are
analytic facts established in the manuscript; the generic executor is not
an arbitrary-matrix condition-number certifier.

## What is not established by these tests

The finite checks do not validate the general upper bound for all inputs,
prove the large-outlier limits in every dimension, find a uniform exponent
threshold, establish a sharp formula for arbitrary parameters, or prove a
lower bound for IEEE round-to-nearest. The proofs in the manuscript remain
human-readable mathematical arguments, not proof-assistant certificates.
No independent referee review or priority claim is represented by this
recovery package.
