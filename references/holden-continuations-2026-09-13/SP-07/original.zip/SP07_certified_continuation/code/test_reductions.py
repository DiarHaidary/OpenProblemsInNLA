"""Seeded floating-point consistency checks for the written reduction proofs.
These tests are not interval certificates or substitutes for the proofs.
"""
from __future__ import annotations
import argparse,json,sys,time
from pathlib import Path
import numpy as np
from scipy.linalg import block_diag,expm
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'prior'/'sp07_partial_results'/'code'))
from matching import bottleneck

def main(output:Path,seed:int=20260913):
    rng=np.random.default_rng(seed);start=time.monotonic();checks=0;counts={};res={}
    def check(ok,msg):
        nonlocal checks
        checks+=1
        if not ok:raise AssertionError(msg)
    def track(name,value):res[name]=max(res.get(name,0.),float(value))
    zK=np.array([1,(4+5j*np.sqrt(3))/13,(-1+2j*np.sqrt(3))/13]);vK=np.sqrt([5/8,1/4,1/8]);SK=np.eye(3)-2*np.outer(vK,vK)
    violations=0;counts['rank_one_cases']=0
    for n in [3,4,5,7,9,12]:
        for k in range(12):
            z=np.r_[zK,np.full(n-3,.719*np.exp(1j*np.angle(zK[1])))]
            v=np.r_[vK,np.zeros(n-3)].astype(complex)
            v+=(0,.0002,.001,.003)[k%4]*(rng.normal(size=n)+1j*rng.normal(size=n));v/=np.linalg.norm(v)
            P=np.outer(v,v.conj());Q=np.eye(n)-P;S=np.eye(n)-2*P;D=np.diag(z);M=D+S@D@S
            norm=np.linalg.norm(M,2);t=norm/2;outer=np.flatnonzero(abs(z)>t+1e-10)
            check(len(outer)<=2,'More than two exterior entries in rank-one case')
            d,_=bottleneck(z,-z);counts['rank_one_cases']+=1
            if d<=norm+1e-8:continue
            violations+=1;check(len(outer)==2,'Violating rank-one case has wrong exterior count')
            rem=[i for i in range(n) if i not in outer];g=np.zeros(n,complex);g[rem]=v[rem];g/=np.linalg.norm(g)
            T=np.column_stack([np.eye(n)[:,outer],g]);Dp=T.conj().T@D@T;vp=T.conj().T@v;Sp=np.eye(3)-2*np.outer(vp,vp.conj());Mp=Dp+Sp@Dp@Sp
            err=np.linalg.norm(Mp-T.conj().T@M@T,2);track('rank_one_compression_identity_error',err)
            check(err<2e-10,'Rank-one compression identity')
            check(np.linalg.norm(Dp-np.diag(np.diag(Dp)),2)<1e-10,'Reduced D not diagonal')
            dp,_=bottleneck(np.diag(Dp),-np.diag(Dp))
            check(dp+2e-9>=d,'Rank-one reduced matching distance decreased')
            check(np.linalg.norm(Mp,2)<=norm+2e-9,'Rank-one reduced norm increased')
    counts['rank_one_violating_cases_reduced']=violations
    counts['three_spectral_type_cases']=0
    for copies in [1,2,3,4,6]:
        n=3*copies;z=np.tile(zK,copies);A=np.diag(z);U0=block_diag(*([SK]*copies))
        I=np.array([j for j in range(n) if j%3 in (0,1)]);EA=np.eye(n)[:,I]
        for k in range(12):
            R=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));K=R-R.conj().T;K/=max(np.linalg.norm(K,2),1.)
            U=expm([0,.0005,.002,.005][k%4]*K)@U0;B=U@np.diag(-z)@U.conj().T;eps=np.linalg.norm(A-B,2)
            gap=float(min(abs(z[I,None]+z[None,I]).ravel()));check(gap>eps,'Seed lost strict Hall gap')
            F=U[:,I];L,s,Vh=np.linalg.svd(EA.conj().T@F,full_matrices=False);x=EA@L[:,0]
            inter=np.linalg.norm(x-F@(F.conj().T@x));track('hall_intersection_residual',inter);check(inter<2e-9,'Intersection vector residual')
            parts=[]
            for typ in [0,1]:
                a=np.zeros(n,complex);a[np.arange(n)%3==typ]=x[np.arange(n)%3==typ];parts.append(a)
            for typ in [0,1]:
                EV=U[:,np.arange(n)%3==typ];parts.append(EV@(EV.conj().T@x))
            V,s,_=np.linalg.svd(np.column_stack(parts),full_matrices=False);dim=int(np.sum(s>1e-9));check(dim==3,'Hall compression dimension not three')
            T=V[:,:3];Ap=T.conj().T@A@T;Bp=T.conj().T@B@T
            na=np.linalg.norm(Ap@Ap.conj().T-Ap.conj().T@Ap,2);nb=np.linalg.norm(Bp@Bp.conj().T-Bp.conj().T@Bp,2)
            track('reduced_normality_residual',max(na,nb));check(max(na,nb)<2e-9,'Compression not normal')
            dp,_=bottleneck(np.linalg.eigvals(Ap),np.linalg.eigvals(Bp));check(dp+2e-8>=gap,'Compressed Hall gap lost')
            check(np.linalg.norm(Ap-Bp,2)<=eps+2e-9,'Compressed difference norm increased')
            counts['three_spectral_type_cases']+=1
    counts['distinct_value_truncated_cases']=0
    for n in [2,3,4,5,7,9,12]:
        for _ in range(36):
            ka=int(rng.integers(1,n+1));kb=int(rng.integers(1,n+1))
            av=rng.normal(size=ka)+1j*rng.normal(size=ka);bv=rng.normal(size=kb)+1j*rng.normal(size=kb)
            alpha=av[np.r_[np.arange(ka),rng.integers(ka,size=n-ka)]];beta=bv[np.r_[np.arange(kb),rng.integers(kb,size=n-kb)]]
            U,_=np.linalg.qr(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))
            M=(alpha[:,None]-beta[None,:])*U;sing=np.linalg.svd(M,compute_uv=False);d,_=bottleneck(alpha,beta)
            r=max(1,min((n+1)//2,ka-1,kb-1));check(d*d<=sum(sing[:r]**2)+2e-8,'Distinct-value truncated bound')
            counts['distinct_value_truncated_cases']+=1
    out=dict(status='PASSED: floating-point consistency tests, not proof certificates.',seed=seed,checks=checks,cases=counts,maximum_residuals=res,elapsed_seconds=time.monotonic()-start)
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--seed',type=int,default=20260913);a=p.parse_args();main(a.output,a.seed)
