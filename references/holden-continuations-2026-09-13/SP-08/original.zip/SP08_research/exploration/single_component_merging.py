import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,json
from pathlib import Path
rng=np.random.default_rng(457010)
def sp(K,m,vec=False):
 W=np.sqrt(m);T=K*W[:,None]*W[None,:]
 if vec:return np.linalg.eigh(T)
 e=np.linalg.eigvalsh(T);return max(e[-1],0)-min(e[0],0)
stats={'total':0,'stationary':0,'all_bad':0,'stationary_bad':0};bad=[]
for k in range(100000):
 b=int(rng.integers(3,11));idx=np.minimum(np.arange(b)[:,None],np.arange(b)[None,:]);H=np.zeros((b+1,b+1));H[:b,:b]=(idx%2==0)
 m=rng.integers(1,70,b+1).astype(float);a=float(rng.choice([0,.01,.2,.4,.7,.9,.99]));K=1-(1-a)*H
 ev,V=sp(K,m,True);val=ev[-1]-ev[0];x=V[:,-1]/np.sqrt(m);y=V[:,0]/np.sqrt(m);C=np.outer(x,x)-np.outer(y,y)
 good=bool(np.all((K-a)*C>=-1e-8) and np.all((1-K)*C<=1e-8));stats['total']+=1;stats['stationary']+=good
 gain=-np.inf;pair=None
 for i in range(b):
  for j in range(i+2,b,2):
   m1=m.copy();m1[i]+=m1[j];m1[j]=0;m2=m.copy();m2[j]+=m2[i];m2[i]=0
   new=max(sp(K,m1),sp(K,m2))-val
   if new>gain:gain=new;pair=(i,j)
 if gain< -1e-8:
  stats['all_bad']+=1
  if good:
   stats['stationary_bad']+=1
   if len(bad)<20:bad.append({'runs':b,'m':m.tolist(),'a':a,'s':val,'bestgain':gain,'bestpair':pair,'x':x.tolist(),'y':y.tolist()})
 if k in [9999,49999,99999]:print(k,stats,bad[:1],flush=True)
Path('/mnt/data/SP08_research/checks/single_component_merging.json').write_text(json.dumps({'status':'NUMERICAL_EXPLORATION_NOT_PROOF','stats':stats,'counterexamples':bad},indent=2))
