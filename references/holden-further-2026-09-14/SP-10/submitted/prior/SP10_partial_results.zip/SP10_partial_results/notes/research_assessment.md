# Research assessment

## Established mathematical content

Hall's strong Delta theorem is sufficient to activate the existing degeneracy argument without leaving Delta as an unproved hypothesis. The complete derivation is in the report. It gives the PSD and unrestricted rank-sum bound

`floor(1 + sqrt(2*n*n - 2*n + 1))`.

Applying the same input directly to a graph and its complement gives `n+1+Delta-delta`, proving the target for regular and almost-regular graphs. Starting MCS at a smallest-degree vertex improves the degree spread to the middle-degree spread. Starting MCS with all vertices below the endpoint-degree threshold gives the clique-prefix refinement. Each statement is proved as a corollary of the imported theorem; none is called a complete solution of SP-10.

The path construction has no imported Delta dependence. Pairwise nonparallel integer vectors in three dimensions can be extended while imposing exactly the consecutive orthogonalities, by avoiding finitely many lines in a rational plane. Together with the irreducible tridiagonal lower bound, this proves the sharp constant for all path orders, not merely the saved examples.

## A failed proof route, with a rigorous obstruction

The hoped-for universal relation `g(G)+g(complement(G)) >= n-2` is false. The bull graph has five vertices and both greedegrees equal to one. Its actual minimum ranks are both three, so it satisfies SP-10. The report gives a hand proof of the greedegree claim, explicit rank-three Gram matrices, and minimum-rank lower bounds.

Combining degeneracy and greedegree helps, but still leaves 22 atlas entries with

`max(d(G),g(G)) + max(d(complement(G)),g(complement(G))) < n-2`.

Their indices are in `results/combinatorial_checks.json`. Every one has an exact PSD matrix-pair certificate meeting the target. This distinguishes weakness of an auxiliary estimate from failure of the conjecture.

## Computational work

The search enforces nonedges by exact nullspace constraints. It checks required nonzero edge products before accepting a local choice. A local choice can obstruct a future step, so the algorithm is a bounded search, not an existence proof. The program always retains a valid Laplacian fallback and returns `UNKNOWN` rather than asserting infeasibility.

Two exact implementations verify all 1,270 saved records. The primary one uses `fractions.Fraction`; the second forms integer Gram matrices separately and uses SymPy exact-domain rank. A third check matches the 1,252 atlas records to their source graphs. These checks are implementation evidence and finite mathematical witnesses, not formal proof-assistant verification or independent human review.

The generator was resumed after an interrupted invocation had saved 1,047 records. All saved records were reverified. The final complete file was checked afresh by both rank implementations. Generation metadata distinguishes the resumed invocation's duration from total generation time. A later maintenance adjustment makes the resume path rewrite all checked records and reject mismatched cached graph identities; a small generation/resume smoke test was run after that adjustment.

## What remains

A completion requires `M(G)+M(complement(G)) >= n-2` for arbitrary graphs, or a counterexample proved by valid lower bounds for both minimum ranks. No such complete argument or counterexample is present.

The general square-root bound has coefficient sqrt(2), which is too large. The degree tests require hypotheses not enjoyed by every graph. The finite atlas cannot establish an all-order claim. The rank-spread lemma in the report is only a necessary condition for a minimum-order counterexample; it does not complete an induction.

The delivered status is therefore **PARTIAL**. No research priority, repository status upgrade, elapsed multi-hour work claim, independent referee endorsement, or complete general algorithm is asserted.
