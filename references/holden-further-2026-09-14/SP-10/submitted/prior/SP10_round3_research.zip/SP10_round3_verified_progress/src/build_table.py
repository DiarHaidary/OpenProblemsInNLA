from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
summary=json.loads((ROOT/'results'/'exact_verification.json').read_text())
other=json.loads((ROOT/'results'/'sympy_verification.json').read_text())
assert summary['verified_rank_pairs']==other['verified_rank_pairs']
a={r['id']:r['ranks'] for r in summary['rank_pairs']};b={r['id']:r['ranks'] for r in other['records']};assert a==b
lines=[r'\begin{longtable}{@{}p{0.48\textwidth}rrrr@{}}',r'\toprule',r'Certificate & Order & Rank $G$ & Rank $\overline G$ & Sum\\',r'\midrule',r'\endhead']
for row in summary['rank_pairs']:
 name=row['id'].replace('_',r'\_');r,s=row['ranks']
 lines.append(f'{name} & {row["n"]} & {r} & {s} & {r+s}'+r'\\')
lines += [r'\bottomrule',r'\end{longtable}',f'The two exact implementations accept all {len(a)} saved rank-pair records. '+f'The primary implementation also verifies {summary["verified_degeneracy_pairs"]} graph/complement degeneracy certificates.']
(ROOT/'manuscript'/'computed_table.tex').write_text('\n'.join(lines)+'\n')
print('Generated table for',len(a),'exact records.')
