"""Reference routines for the RA-11 partial-trace control-variate construction.

The theorem is an exact-arithmetic query result. These NumPy routines are a
finite-precision experimental implementation, not a replacement for its proof.
No routine that estimates a trace accesses matrix entries except through the
RealProductOracle's permitted real-product apply method. Dense known control
matrices are allowed, since RA-11 counts queries rather than arithmetic/memory.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations
from math import ceil, isqrt
from fractions import Fraction
from typing import Callable, Sequence
import numpy as np

Array = np.ndarray


def _subset(keep: Sequence[int], q: int) -> tuple[int, ...]:
    s = tuple(sorted(set(int(i) for i in keep)))
    if len(s) != len(keep) or any(i < 0 or i >= q for i in s):
        raise ValueError("Modes must be distinct integers in [0,q).")
    return s


def kron_all(factors: Sequence[Array]) -> Array:
    z = np.array([1.0 + 0.0j])
    for x in factors:
        z = np.kron(z, np.asarray(x).reshape(-1))
    return z


def partial_trace(a: Array, n: int, q: int, keep: Sequence[int]) -> Array:
    """Unnormalized partial trace, retaining the sorted modes in keep."""
    keep = _subset(keep, q)
    a = np.asarray(a)
    if a.shape != (n**q, n**q):
        raise ValueError("Matrix shape does not match n and q.")
    modes = list(range(q))
    t = a.reshape((n,) * (2 * q))
    for mode in sorted(set(modes) - set(keep), reverse=True):
        pos = modes.index(mode)
        t = np.trace(t, axis1=pos, axis2=pos + len(modes))
        modes.remove(mode)
    return t.reshape((n**len(keep),) * 2)


def lift(a: Array, n: int, q: int, keep: Sequence[int]) -> Array:
    """Normalized lift A tensor I/n^(q-|keep|), in the original mode order."""
    keep = _subset(keep, q)
    a = np.asarray(a)
    if a.shape != (n**len(keep),) * 2:
        raise ValueError("Retained matrix has the wrong shape.")
    outside = tuple(i for i in range(q) if i not in keep)
    order = keep + outside
    t = np.kron(a, np.eye(n**len(outside)) / n**len(outside))
    t = t.reshape((n,) * (2*q))
    p = [order.index(i) for i in range(q)]
    return t.transpose(p + [q+i for i in p]).reshape(n**q, n**q)


def conditional_expectation(a: Array, n: int, q: int, keep: Sequence[int]) -> Array:
    return lift(partial_trace(a, n, q, keep), n, q, keep)


def contract_output(y: Array, n: int, q: int,
                    outside: dict[int, Array]) -> Array:
    """Apply K_y^* to a full vector by conjugate contractions."""
    modes = list(range(q))
    t = np.asarray(y).reshape((n,) * q)
    for mode in sorted(outside, reverse=True):
        pos = modes.index(mode)
        t = np.tensordot(np.conjugate(outside[mode]), t, axes=(0, pos))
        modes.remove(mode)
    return t.reshape(-1)


def insertion_matrix(n: int, q: int, keep: Sequence[int],
                     outside: dict[int, Array]) -> Array:
    """Explicit K_y, only for tests and diagnostics."""
    keep = _subset(keep, q)
    d = n**len(keep)
    cols = []
    for j in range(d):
        indices = np.unravel_index(j, (n,)*len(keep)) if keep else ()
        inside = {mode: np.eye(n)[:, index] for mode, index in zip(keep, indices)}
        cols.append(kron_all([inside[i] if i in inside else outside[i]
                              for i in range(q)]))
    return np.column_stack(cols)


PHASES = np.array([1.0, -1.0, 1.0j, -1.0j], dtype=complex)


def phase_factors(n: int, s: int, rng: np.random.Generator) -> list[Array]:
    """Independent entries uniform in {1,-1,i,-i}; finite random bits suffice."""
    return [PHASES[rng.integers(0, 4, size=n)] for _ in range(s)]


class RealProductOracle:
    """Auditable real, full-vector, product-query interface."""
    def __init__(self, matrix: Array, n: int, q: int,
                 max_calls: int | None = None) -> None:
        matrix = np.asarray(matrix)
        if matrix.shape != (n**q, n**q) or np.max(np.abs(np.imag(matrix))) != 0:
            raise ValueError("A real matrix of shape (n^q,n^q) is required.")
        self._matrix = np.real(matrix).copy()
        self.n, self.q, self.calls = n, q, 0
        self.max_calls = max_calls

    def apply(self, factors: Sequence[Array]) -> Array:
        if len(factors) != self.q:
            raise ValueError("One real factor is required per mode.")
        fs = []
        for x in factors:
            x = np.asarray(x).reshape(-1)
            if x.size != self.n or np.any(np.imag(x) != 0):
                raise ValueError("The original oracle accepts real factors only.")
            fs.append(np.real(x))
        if self.max_calls is not None and self.calls >= self.max_calls:
            raise RuntimeError("The specified oracle budget has been exhausted.")
        self.calls += 1
        return self._matrix @ np.real(kron_all(fs))


@lru_cache(None)
def interpolation_weights(q: int) -> Array:
    """Floating representations of exact Gaussian-rational Lagrange weights."""
    w = np.ones(q+1, dtype=complex)
    for j in range(q+1):
        for h in range(q+1):
            if h != j:
                w[j] *= (1j-h)/(j-h)
    return w


class ComplexSimulation:
    def __init__(self, oracle: RealProductOracle) -> None:
        self.oracle = oracle
        self.calls = 0

    def apply(self, factors: Sequence[Array]) -> Array:
        if len(factors) != self.oracle.q:
            raise ValueError("Wrong number of factors.")
        result = np.zeros(self.oracle.n**self.oracle.q, dtype=complex)
        for t, weight in enumerate(interpolation_weights(self.oracle.q)):
            actual = [np.real(x) + t*np.imag(x) for x in factors]
            result += weight * self.oracle.apply(actual)
        self.calls += 1
        return result


class NoisyPartialOracle:
    """Unbiased access to the ORIGINAL partial trace using a known control B."""
    def __init__(self, simulated: ComplexSimulation, control: Array,
                 keep: Sequence[int], averages: int,
                 rng: np.random.Generator) -> None:
        self.sim = simulated
        self.n, self.q = simulated.oracle.n, simulated.oracle.q
        self.keep = _subset(keep, self.q)
        self.outside = tuple(i for i in range(self.q) if i not in self.keep)
        self.control = np.asarray(control).copy()  # frozen throughout this stage
        self.control_partial = partial_trace(control, self.n, self.q, self.keep)
        if averages < 1:
            raise ValueError("At least one outside sample is required.")
        self.averages = averages if self.outside else 1
        self.rng = rng
        self.calls = 0

    def apply(self, inside_factors: Sequence[Array]) -> Array:
        if len(inside_factors) != len(self.keep):
            raise ValueError("Wrong number of retained factors.")
        inside = dict(zip(self.keep, inside_factors))
        x = kron_all(inside_factors)
        answer = np.zeros_like(x)
        for _ in range(self.averages):
            outside = dict(zip(self.outside,
                               phase_factors(self.n, len(self.outside), self.rng)))
            full = [inside[i] if i in inside else outside[i] for i in range(self.q)]
            z = kron_all(full)
            residual = self.sim.apply(full) - self.control @ z
            answer += contract_output(residual, self.n, self.q, outside)
        self.calls += 1
        return answer/self.averages + self.control_partial @ x


@dataclass(frozen=True)
class ExperimentalSchedule:
    """Small experimental settings, NOT the enormous certified constants."""
    rank_target: int = 2
    range_columns: int = 4
    regression_columns: int = 12
    outside_averages: int = 4
    candidates: int = 3
    residual_samples: int = 32
    rank_tolerance: float = 1e-11

    def validate(self) -> None:
        vals = (self.rank_target, self.range_columns, self.regression_columns,
                self.outside_averages, self.candidates, self.residual_samples)
        if any(x < 1 for x in vals) or self.candidates % 2 != 1:
            raise ValueError("Counts must be positive and candidates must be odd.")


def selected_column_basis(Y: Array, rank_target: int, tolerance: float) -> Array:
    """Best span of <=2*rank_target sampled columns, by finite enumeration.

    The proof uses exact ranks, Gram inverses and residual comparisons. This
    experimental version uses SVD for numerical rank/basis computations.
    Enumeration is deliberately not advertised as computationally efficient.
    """
    U, singular, _ = np.linalg.svd(Y, full_matrices=False)
    if singular.size == 0 or singular[0] == 0:
        return np.zeros((Y.shape[0], 0), dtype=complex)
    numerical_rank = int(np.sum(singular > tolerance*singular[0]))
    target = 2*rank_target
    if numerical_rank <= target:
        return U[:, :numerical_rank]
    best_Q = None
    best_error = np.inf
    for indices in combinations(range(Y.shape[1]), target):
        F = Y[:, indices]
        Q, values, _ = np.linalg.svd(F, full_matrices=False)
        if values[-1] <= tolerance*values[0]:
            continue
        error = float(np.linalg.norm(Y-Q@(Q.conj().T@Y), 'fro')**2)
        if error < best_error:
            best_Q, best_error = Q, error
    if best_Q is None:
        # Numerical degeneracy only; exact arithmetic always finds a basis.
        return U[:, :min(numerical_rank, target)]
    return best_Q


def noisy_approximation(oracle: NoisyPartialOracle, schedule: ExperimentalSchedule,
                        rng: np.random.Generator) -> Array:
    n, s = oracle.n, len(oracle.keep)
    d = n**s
    if schedule.rank_target >= d:
        ys = []
        for j in range(d):
            indices = np.unravel_index(j, (n,)*s)
            ys.append(oracle.apply([np.eye(n)[:, i] for i in indices]))
        raw = np.column_stack(ys)
        return (raw + raw.conj().T)/2
    xs = [phase_factors(n, s, rng) for _ in range(schedule.range_columns)]
    Y = np.column_stack([oracle.apply(x) for x in xs])
    Q = selected_column_basis(Y, schedule.rank_target, schedule.rank_tolerance)
    if Q.shape[1] == 0:
        return np.zeros((d, d), dtype=complex)
    count = max(schedule.regression_columns, Q.shape[1])
    fs = [phase_factors(n, s, rng) for _ in range(count)]
    Psi = np.column_stack([kron_all(x) for x in fs])
    Z = np.column_stack([oracle.apply(x) for x in fs])
    G = Psi.conj().T @ Q
    if np.linalg.matrix_rank(G, tol=schedule.rank_tolerance) < Q.shape[1]:
        return np.zeros((d, d), dtype=complex)
    raw = Q @ np.linalg.pinv(G, rcond=schedule.rank_tolerance) @ Z.conj().T
    return (raw + raw.conj().T)/2


def metric_median(candidates: Sequence[Array]) -> Array:
    if len(candidates) % 2 != 1 or not candidates:
        raise ValueError("A nonempty odd number of candidates is required.")
    distances = np.array([[np.linalg.norm(a-b, 'fro')**2 for b in candidates]
                          for a in candidates])
    i = int(np.argmin(np.median(distances, axis=1)))
    return np.asarray(candidates[i]).copy()


def experimental_hierarchy(oracle: RealProductOracle,
                           schedule: ExperimentalSchedule,
                           seed: int = 0,
                           callback: Callable[[tuple[int, ...], Array], None] | None = None
                           ) -> tuple[float, dict]:
    """Run the hierarchy at user-supplied experimental (uncertified) settings."""
    schedule.validate()
    rng = np.random.default_rng(seed)
    sim = ComplexSimulation(oracle)
    n, q = oracle.n, oracle.q
    B = np.zeros((n**q, n**q), dtype=complex)
    stages = []
    for size in range(q, 0, -1):
        for keep in combinations(range(q), size):
            no = NoisyPartialOracle(sim, B, keep, schedule.outside_averages, rng)
            before = oracle.calls
            candidates = [noisy_approximation(no, schedule, rng)
                          for _ in range(schedule.candidates)]
            estimate = metric_median(candidates)
            B += lift(estimate - partial_trace(B, n, q, keep), n, q, keep)
            B = (B + B.conj().T)/2
            stages.append({"keep": list(keep), "real_calls": oracle.calls-before})
            if callback is not None:
                callback(keep, B.copy())
    residual = []
    for _ in range(schedule.residual_samples):
        fs = phase_factors(n, q, rng)
        z = kron_all(fs)
        residual.append(float(np.real(np.vdot(z, sim.apply(fs) - B @ z))))
    estimate = float(np.real(np.trace(B))) + float(np.mean(residual))
    return estimate, {"real_calls": oracle.calls, "complex_calls": sim.calls,
                      "stages": stages, "certified_constants_used": False}


def theorem_schedule(n: int, q: int, epsilon: float | str | Fraction) -> dict:
    """Symbolic certified schedule; never allocate its enormous sketches.

    Decimal strings/Fractions preserve the requested accuracy exactly. D is
    obtained with integer operations, not a numerical square-root rounding.
    """
    eps = epsilon if isinstance(epsilon, Fraction) else Fraction(str(epsilon))
    if n < 2 or q < 2 or not (0 < eps < Fraction(1, 2)):
        raise ValueError("RA-11 requires n,q>=2 and 0<epsilon<1/2.")
    K = 2**q-1
    H = Fraction(3*n-1, n)**q-1
    D = isqrt(H.numerator//H.denominator)
    if D*D*H.denominator < H.numerator:
        D += 1
    r = ceil(1/(D*eps))
    bound = ceil(Fraction(2**71*q*(q+1)*K*D, 1)/eps)
    return {"n": n, "q": q, "epsilon": str(eps), "K": K,
            "H": str(H), "D": D,
            "branch": "plain phase" if eps > Fraction(1,D) else "hierarchy",
            "r": r, "candidates": 8*q+17,
            "rank_target": 2**18*r, "embedding_constant": 2**25,
            "h_by_size": {s: str(Fraction(2*n-1,n)**s) for s in range(1,q+1)},
            "outside_averages": 2**18*K,
            "full_set_outside_averages": 1,
            "residual_samples": ceil(Fraction(12*K,r)/eps**2),
            "plain_complex_samples": ceil(Fraction(6*K,1)/eps**2),
            "safe_real_query_upper": min(n**q,bound),
            "hierarchical_linear_envelope": bound,
            "basis_real_calls": n**q}
