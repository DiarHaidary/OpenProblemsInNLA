#!/usr/bin/env python3
"""Independent exact verifier for SP-08 parameter-interval certificates.

Python standard library only. No generator modules are imported. Coverage
is reconstructed independently, matrix inequalities use symmetric congruence
and fraction-free Schur complements with gcd cancellation, and polynomial
checks use the local interval coordinate t in [0,1]. The manuscript supplies
the structural proofs and the all-dimensions analytic skipped subclasses.
"""
from __future__ import annotations
import argparse,gzip,hashlib,itertools,json,math,time
from fractions import Fraction as R
from pathlib import Path


def unsigned_words(size):
    for tail in itertools.product((0,1),repeat=size-1):
        word=(1,)+tuple(reversed(tail))
        yield tuple(sum(1 for _ in grp) for _,grp in itertools.groupby(word))


def unsigned_patterns(n):
    def build(x,y,r):
        mult=x+y+((r,) if r else ())
        h=[[0]*len(mult) for _ in mult]
        for offset,length in ((0,len(x)),(len(x),len(y))):
            creation=[1-(j%2) for j in range(length)]
            for i in range(length):
                for j in range(length):h[offset+i][offset+j]=creation[min(i,j)]
        return mult,h,len(x)+len(y)<=2,False
    yield build((),(),n)
    for p in range(1,n+1):
        for x in unsigned_words(p):yield build(x,(),n-p)
    for p in range(1,n//2+1):
        for q in range(p,n-p+1):
            for i,x in enumerate(unsigned_words(p)):
                for j,y in enumerate(unsigned_words(q)):
                    if p!=q or j>=i:yield build(x,y,n-p-q)


def independent_compositions(n):
    for flags in itertools.product((False,True),repeat=n-1):
        cuts=[0]+[j+1 for j,cut in enumerate(reversed(flags)) if cut]+[n]
        yield tuple(b-a for a,b in zip(cuts,cuts[1:]))


def is_psd_01(h):
    """Connected-component clique characterization, not the generator test."""
    n=len(h);visited=set()
    for start in range(n):
        if start in visited:continue
        component={start};pending=[start];visited.add(start)
        while pending:
            i=pending.pop()
            for j in range(n):
                if i!=j and h[i][j] and j not in visited:
                    visited.add(j);component.add(j);pending.append(j)
        if len(component)==1 and h[start][start]==0:continue
        if any(h[i][j]!=1 for i in component for j in component):return False
    return True


def rank_two_from_pivot(matrix,i,j):
    a,b,c=matrix[i][i],matrix[i][j],matrix[j][j]
    det=a*c-b*b
    if det==0:return False
    n=len(matrix)
    for k in range(n):
        for l in range(n):
            reconstructed=c*matrix[i][k]*matrix[i][l]-b*(matrix[i][k]*matrix[j][l]+matrix[j][k]*matrix[i][l])+a*matrix[j][k]*matrix[j][l]
            if det*matrix[k][l]!=reconstructed:return False
    return True


def is_indefinite_rank_two_01(h):
    n=len(h)
    for i in range(n):
        for j in range(i):
            if h[i][i]*h[j][j]-h[i][j]**2<0:return rank_two_from_pivot(h,i,j)
    return False


def is_endpoint_equality(h,mult,n):
    s=[[1-2*v for v in row] for row in h]
    trace=sum(m*s[i][i] for i,m in enumerate(mult))
    if trace*trace!=n%2:return False
    for i in range(len(s)):
        for j in range(i):
            if s[i][i]*s[j][j]-s[i][j]**2!=0:return rank_two_from_pivot(s,i,j)
    return False


def signed_patterns(n):
    for parts in independent_compositions(n):
        ranges=[range((parts[0]+1)//2,parts[0]+1)]+[range(m+1) for m in parts[1:]]
        for first in (-1,1):
            eps=[]
            for j,m in enumerate(parts):eps.extend([first if j%2==0 else -first]*m)
            for positive_counts in itertools.product(*ranges):
                delta=[];representatives=[];mult=[]
                for m,p in zip(parts,positive_counts):
                    if p:representatives.append(len(delta));mult.append(p);delta.extend([1]*p)
                    if p<m:representatives.append(len(delta));mult.append(m-p);delta.extend([-1]*(m-p))
                h=[[(1-delta[i]*delta[j]*eps[min(i,j)])//2 for j in representatives] for i in representatives]
                if is_psd_01(h):kind='psd'
                elif is_indefinite_rank_two_01(h):kind='rank2'
                else:kind='certificate'
                eq=is_endpoint_equality(h,mult,n) if kind=='certificate' else False
                yield tuple(mult),h,kind,eq


def unsigned_count(n):
    ans=2**n
    for p in range(1,n//2+1):
        for q in range(p,n-p+1):
            x,y=2**(p-1),2**(q-1)
            ans+=x*y if p<q else x*(x+1)//2
    return ans


def signed_count(n):
    # Weighted-composition recurrence, independent of enumeration.
    f=[1]
    for k in range(1,n+1):f.append(sum((m+1)*f[k-m] for m in range(1,k+1)))
    return 2*sum((m//2+1)*f[n-m] for m in range(1,n+1))


def schur_positive(matrix):
    b=[row[:] for row in matrix]
    while b:
        pivot=b[0][0]
        if pivot<=0:return False
        if len(b)==1:return True
        out=[[pivot*b[i][j]-b[i][0]*b[0][j] for j in range(1,len(b))] for i in range(1,len(b))]
        gcd=0
        for row in out:
            for entry in row:gcd=math.gcd(gcd,entry)
        if not gcd:return False
        b=[[entry//gcd for entry in row] for row in out]
    return True


def verify_node(h,mult,d,grid,L,U):
    q,t=d.denominator,d.numerator;n=len(mult)
    low=[[0]*n for _ in range(n)];high=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            entry=grid*(q-t*h[i][j])*mult[i]*mult[j]
            low[i][j]=entry-(L*q*mult[i] if i==j else 0)
            high[i][j]=-entry+(U*q*mult[i] if i==j else 0)
    return schur_positive(low) and schur_positive(high)


def Fk(n,k,d):return n*n+d*(2*n*k-(4-d)*k*k)


def compare_regular(n,k,d0,d1,w0,w1):
    step=d1-d0;change=w1-w0
    C=Fk(n,k,d0)-w0*w0
    B=step*(2*n*k-4*k*k+2*k*k*d0)-2*w0*change
    A=k*k*step*step-change*change
    if C<0 or A+B+C<0:return False
    if A>0 and -2*A<B<0 and 4*A*C-B*B<0:return False
    return True


def compare_equality_endpoint(n,k,d0,w0):
    radicand=2*n*n-n%2
    if Fk(n,k,R(2))!=radicand:return False
    c=Fk(n,k,d0)-w0*w0
    # q(t)=(1-t)(c-A*t). Check c>=0 and c-A>=0 without radicals.
    left=Fk(n,k,d0)+radicand-k*k*(2-d0)**2
    right_squared=4*w0*w0*radicand
    return c>=0 and left>=0 and left*left>=right_squared


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('metadata',type=Path);args=p.parse_args()
    meta=json.loads(args.metadata.read_text());n=int(meta['n']);grid=int(meta['grid_denominator']);start=time.time()
    signed=meta['schema']=='all-parameter-compressed-v1'
    if not signed and meta['schema']!='nonnegative-parameter-v1':raise ValueError('Unsupported schema')
    if n<2 or grid<=0:raise ValueError('Invalid parameters')
    end=R(2 if signed else 1);hashobj=hashlib.sha256()
    counts={'enumerated':0}
    if signed:counts.update({'analytic_psd_deficit':0,'analytic_indefinite_rank_two_deficit':0,'exact_certified':0,'endpoint_equalities':0,'spectral_nodes':0,'parameter_intervals':0})
    else:counts.update({'analytic_rank_le_2':0,'exact_certified':0,'spectral_nodes':0,'parameter_intervals':0})
    iterator=signed_patterns(n) if signed else unsigned_patterns(n)
    with gzip.open(args.metadata.parent/meta['certificate_file'],'rb') as stream:
        for mult,h,skip,eq in iterator:
            counts['enumerated']+=1
            if signed and skip!='certificate':
                counts['analytic_psd_deficit' if skip=='psd' else 'analytic_indefinite_rank_two_deficit']+=1;continue
            if not signed and skip:counts['analytic_rank_le_2']+=1;continue
            raw=stream.readline()
            if not raw:raise ArithmeticError('Missing record')
            hashobj.update(raw);nodes,ks=json.loads(raw);ds=[R(z[0],z[1]) for z in nodes]
            if ds[0]!=0 or ds[-1]!=end or len(ks)!=len(nodes)-1 or any(x>=y for x,y in zip(ds,ds[1:])):raise ArithmeticError('Incomplete partition')
            for node,d in zip(nodes,ds):
                _,_,L,U=node
                if d==0:
                    if (L,U)!=(0,n*grid):raise ArithmeticError('Invalid zero-parameter endpoint')
                elif d==2 and eq:
                    if (L,U)!=(None,None):raise ArithmeticError('Invalid algebraic endpoint marker')
                else:
                    if not isinstance(L,int) or not isinstance(U,int) or not L<0<U:raise ArithmeticError('Invalid spectral interval')
                    if not verify_node(h,mult,d,grid,L,U):raise ArithmeticError('Spectral interval not proved')
            for j,k in enumerate(ks):
                if not isinstance(k,int) or not 1<=k<n:raise ArithmeticError('Invalid k')
                w0=R(nodes[j][3]-nodes[j][2],grid)
                if ds[j+1]==2 and eq:ok=compare_equality_endpoint(n,k,ds[j],w0)
                else:ok=compare_regular(n,k,ds[j],ds[j+1],w0,R(nodes[j+1][3]-nodes[j+1][2],grid))
                if not ok:raise ArithmeticError('Parameter interval not proved')
            counts['exact_certified']+=1;counts['spectral_nodes']+=len(nodes)-int(eq);counts['parameter_intervals']+=len(ks)
            if signed:counts['endpoint_equalities']+=int(eq)
            if counts['exact_certified']%100000==0:print(n,counts['exact_certified'],'seconds',round(time.time()-start,1),flush=True)
        if stream.read(1):raise ArithmeticError('Unused certificate record')
    expected=signed_count(n) if signed else unsigned_count(n)
    if counts!=meta['counts'] or counts['enumerated']!=expected or hashobj.hexdigest()!=meta['uncompressed_sha256']:raise ArithmeticError('Coverage/hash mismatch')
    result={'status':'INDEPENDENT_EXACT_VERIFICATION_PASS','schema':meta['schema'],'n':n,'a_range':meta['a_range'],'counts':counts,'seconds':time.time()-start,
            'arithmetic':'Python standard-library exact integers and fractions; no floating-point computation',
            'independence':'Separate coverage enumeration, skipped-class tests, symmetric-congruence Schur test, and local-coordinate quadratic comparison; no generator imports.'}
    out=args.metadata.with_name(args.metadata.stem+'_independent_verification.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':main()
