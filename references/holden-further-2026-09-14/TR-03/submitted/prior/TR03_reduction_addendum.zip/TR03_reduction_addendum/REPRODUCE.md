# Reproduction

Use Python 3.10 or newer. No third-party dependencies are required.

From this directory:

```sh
python code/verify.py
python code/build_archive.py
```

The first command runs deterministic exact-fraction checks and writes `results/verification.json` only after all assertions succeed. The second computes SHA-256 checksums, rebuilds the ZIP in the parent directory, and checks its CRC integrity.

`results/execution.json`, when present, records the package-generation attempt to run the verification script, including its return code and any timeout. `results/verification.log` contains the captured output. These records should be inspected rather than replacing an unavailable tool readback with an assumed success.

The tests do not test or prove hypothesis H(c), the conditional reduction's unproved input. They also do not certify earlier packages, determine R exactly, or supply a missing matching lower bound.
