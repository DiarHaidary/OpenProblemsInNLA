"""Exact graph/Gram verification. All numerical decisions use rational arithmetic."""
from __future__ import annotations
from fractions import Fraction as F
from math import gcd, lcm
from pathlib import Path
import json


def number(x):
    if type(x) is int or isinstance(x, str):
        return F(x)
    if isinstance(x, F):
        return x
    raise ValueError('Coordinates must be integers or rational strings; floats are forbidden')


def matrix(rows):
    if not isinstance(rows, list) or not rows:
        raise ValueError('Expected a nonempty matrix')
    if not all(isinstance(r, list) for r in rows):
        raise ValueError('Expected rows')
    w=len(rows[0])
    if not w or any(len(r)!=w for r in rows):
        raise ValueError('Empty or ragged matrix')
    return [[number(x) for x in r] for r in rows]


def dot(u,v):
    if len(u)!=len(v):
        raise ValueError('Vector dimension mismatch')
    return sum((a*b for a,b in zip(u,v)), F(0))


def rank(rows):
    if not rows:
        return 0
    a=[[number(x) for x in r] for r in rows]
    w=len(a[0])
    if any(len(r)!=w for r in a):
        raise ValueError('Ragged matrix')
    p=0
    for c in range(w):
        q=next((i for i in range(p,len(a)) if a[i][c]),None)
        if q is None:
            continue
        a[p],a[q]=a[q],a[p]
        z=a[p][c]
        a[p]=[x/z for x in a[p]]
        for i in range(p+1,len(a)):
            if a[i][c]:
                z=a[i][c]
                a[i]=[x-z*y for x,y in zip(a[i],a[p])]
        p+=1
        if p==len(a):
            break
    return p


def edges(n, data):
    if type(n) is not int or n<1:
        raise ValueError('Graph order must be a positive integer')
    result=set()
    for e in data:
        if not isinstance(e,(list,tuple)) or len(e)!=2:
            raise ValueError('Invalid edge')
        a,b=e
        if type(a) is not int or type(b) is not int or not (0<=a<n and 0<=b<n) or a==b:
            raise ValueError('Invalid endpoint')
        e=tuple(sorted((a,b)))
        if e in result:
            raise ValueError('Duplicate edge')
        result.add(e)
    return result


def complement(n,E):
    return {(i,j) for i in range(n) for j in range(i+1,n) if (i,j) not in E}


def serialize(a):
    return [[str(number(x)) for x in r] for r in a]


def verify_pair(record):
    n=record['n']; E=edges(n,record['edges'])
    factors=[matrix(record[k]) for k in ('gram_G','gram_complement')]
    for side,V in enumerate(factors):
        if len(V)!=n or any(not any(r) for r in V):
            raise ValueError('Every vertex must have a nonzero Gram vector')
        support=E if side==0 else complement(n,E)
        for i in range(n):
            for j in range(i+1,n):
                if bool(dot(V[i],V[j])) != ((i,j) in support):
                    raise ValueError(f'Wrong support: side={side}, pair={(i,j)}')
    ranks=list(map(rank,factors))
    if sum(ranks)>n+2:
        raise ValueError(f'Rank sum {sum(ranks)} exceeds {n+2}')
    return {'id':record.get('id','unnamed'),'n':n,'ranks':ranks,'rank_sum':sum(ranks),'target':n+2}


def peeling(n,E):
    E=set(E); left=set(range(n)); order=[]; degrees=[]; d=-1; core=[]
    while left:
        deg={v:sum((min(v,w),max(v,w)) in E for w in left if w!=v) for v in left}
        v=min(left,key=lambda x:(deg[x],x))
        if deg[v]>d:
            d=deg[v]; core=sorted(left)
        order.append(v); degrees.append(deg[v]); left.remove(v)
    return {'degeneracy':d,'order':order,'deletion_degrees':degrees,'core':core}


def verify_peeling(n,E,c):
    E=edges(n,list(E)); order=c['order']; d=c['degeneracy']; core=c['core']
    if sorted(order)!=list(range(n)) or type(d) is not int or d<0:
        raise ValueError('Invalid degeneracy certificate')
    left=set(range(n)); ds=[]
    for v in order:
        deg=sum((min(v,w),max(v,w)) in E for w in left if w!=v)
        ds.append(deg); left.remove(v)
    if max(ds)!=d or ds!=c['deletion_degrees']:
        raise ValueError('Peeling does not establish claimed upper bound')
    if not core or len(set(core))!=len(core) or not set(core)<=set(range(n)):
        raise ValueError('Invalid core')
    if min(sum((min(v,w),max(v,w)) in E for w in core if w!=v) for v in core)<d:
        raise ValueError('Core does not establish claimed lower bound')
    return d


def plane_basis(v,weights=None):
    weights=weights or [F(1)]*len(v)
    a=[number(x)*number(w) for x,w in zip(v,weights)]
    k=next(i for i,x in enumerate(a) if x)
    out=[]
    for j in range(len(v)):
        if j!=k:
            b=[F(0)]*len(v); b[j]=F(1); b[k]=-a[j]/a[k]; out.append(b)
    return out


def parallel(u,v):
    return all(u[i]*v[j]==u[j]*v[i] for i in range(len(u)) for j in range(i+1,len(u)))


def primitive(v):
    den=lcm(*(x.denominator for x in v)); out=[int(x*den) for x in v]
    g=gcd(*out)
    return [F(x//g) for x in out]


def incidence(n,E):
    ee=sorted(E)
    if not ee:
        return [[F(int(i==j)) for j in range(n)] for i in range(n)]
    isolates=[i for i in range(n) if not any(i in e for e in ee)]
    V=[[F(0)]*(len(ee)+len(isolates)) for _ in range(n)]
    for j,(a,b) in enumerate(ee):
        V[a][j]=F(1);V[b][j]=F(-1)
    for j,v in enumerate(isolates):V[v][len(ee)+j]=F(1)
    return V


def read_records(path):
    text=Path(path).read_text()
    if Path(path).suffix=='.jsonl':
        return [json.loads(s) for s in text.splitlines() if s.strip()]
    return [json.loads(text)]
