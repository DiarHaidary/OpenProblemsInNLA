"""Numerical proposal, exact rational correction, and independent acceptance."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from homogeneous_model import interval_equations
from exact_arithmetic import sparse_model,gram_coefficients
from verify_interval import verify,FORMAT,SCOPE
from barrier_sdp import solve

def serial(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,list):return [serial(x) for x in v]
    if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
    return v

def selectors(mats,Z):
    n=len(mats[0][0][0]);best=[None]*n;scores=np.zeros(n)
    for si,(mat,z) in enumerate(zip(mats,Z)):
        inv=np.linalg.inv(z)
        for i,row in enumerate(mat):
            for j in range(i,len(row)):
                support=[(k,c) for k,c in enumerate(row[j]) if c]
                if len(support)!=1:continue
                k,c=support[0];fac=1 if i==j else 2
                cost=inv[i,i] if i==j else np.sqrt(max(0,inv[i,i]*inv[j,j]))+abs(inv[i,j])
                score=abs(float(c))*fac/max(cost,1e-100)
                if score>scores[k]:scores[k]=score;best[k]=(si,i,j,c*fac)
    if any(x is None for x in best):raise ValueError('Missing correction coordinate')
    return best

def round_exact(a,eq,Z,w,left,right,h,cap,digits):
    mats=a['matrices'];n=len(a['keys']);count=len(mats);scale=10**digits
    rnd=lambda x:F(int(round(float(x)*scale)),scale)
    grams=[[[rnd(v) for v in row] for row in (z+z.T)/2] for z in Z]
    ww=[rnd(v) for v in w];ww[-1]=F(-1);sparse=sparse_model(mats)
    rhs=[sum(wi*row[k] for wi,row in zip(ww,eq)) for k in range(2*n)]
    for side in (0,1):
        zz=grams[side*count:(side+1)*count];lhs=gram_coefficients(zz,sparse,n)
        choices=selectors(mats,Z[side*count:(side+1)*count])
        for k,(si,i,j,factor) in enumerate(choices):
            delta=(rhs[side*n+k]-lhs[k])/factor;zz[si][i][j]+=delta
            if i!=j:zz[si][j][i]+=delta
    data=dict(format=FORMAT,scope=SCOPE,degree=a['degree'],m=a['m'],left=str(left),right=str(right),h=str(h),gram_matrices=[[[str(v) for v in row] for row in z] for z in grams],multipliers=[str(v) for v in ww],construction='Numerical proposal, rational rounding, exact coefficient correction, independent exact acceptance.')
    return data,verify(data,cap)

def main(left=F(861,100),right=F(43983,5000),h=F(2371,2000),degree=6):
    start=time.monotonic();a,b,eq=interval_equations(left,right,h,degree,2);n=len(a['keys']);A=np.array(eq,float);rhs=np.zeros(len(eq));rhs[-1]=1;mats=[]
    for side in (0,1):
        for Z in a['matrices']:
            z=np.array(Z,float);M=np.zeros(z.shape[:-1]+(2*n,));M[:,:,side*n:(side+1)*n]=z;mats.append(M)
    out=solve(mats,A,rhs,True,store=True)
    (ROOT/'experiments'/'barrier_records.json').write_text(json.dumps(out['records'],indent=2)+'\n')
    for i,snap in enumerate(out['snapshots']):
        w=snap['w']
        if w[-1]>=0:continue
        scale=-1/w[-1];Z=[z*scale for z in snap['Z']];w=w*scale
        print('Snapshot',i,'scale',scale,flush=True)
        for digits in (9,11,13,15):
            try:data,result=round_exact(a,eq,Z,w,left,right,h,right,digits)
            except Exception as exc:print('REJECTED',digits,str(exc),flush=True);continue
            path=ROOT/'certificates'/('interval_d'+str(degree)+'_'+str(left).replace('/','_')+'.json')
            path.write_text(json.dumps(data,indent=2)+'\n')
            (ROOT/'verification'/(path.stem+'.json')).write_text(json.dumps(result,indent=2)+'\n')
            print('EXACT ACCEPTANCE',json.dumps(result),'seconds',time.monotonic()-start,flush=True);return result
    raise ValueError('No exact certificate accepted')
if __name__=='__main__':
    main(*([F(x) for x in sys.argv[1:4]]+([int(sys.argv[4])] if len(sys.argv)>4 else [])))
