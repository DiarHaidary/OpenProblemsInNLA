# IE-20 — Recovered manuscript and exact verification package

**Status: partial mathematical results, not a complete solution to IE-20.**

Start with `IE20_bounds_and_counterexamples.pdf` (16 pages). The editable
LaTeX source is included beside it. Section 7 states the remaining gap.

This archive restores the manuscript and Python code from the interrupted
run's execution records and rebuilds the PDF. It is not a byte-for-byte
recovery of an earlier ZIP. Details and the two surviving preview images
are in `recovery/`.

## What the manuscript contains

The recovered arguments give an explicit general sufficient precision,
elementary lower bounds, sharp orders in the scalar, condition-number-one,
and two-dimensional cases, and a one-error path/outlier family. The family
has a necessary order `n log K` in a specified joint regime and rules out a
uniform `O(log(nK/epsilon))` guarantee under the stated error-envelope model.

The general bounds do not match for all `(n, K, epsilon)`. The all-parameter
characterization requested by IE-20 is therefore **not supplied**. The
analytic arguments have not been independently refereed or formally
verified. Passing finite-example checks does not establish a universal
asymptotic theorem.

## Files

| File | Contents |
| --- | --- |
| `IE20_bounds_and_counterexamples.pdf` | Rebuilt 16-page manuscript |
| `IE20_bounds_and_counterexamples.tex` | Editable manuscript source |
| `code/envelope_cg.py` | Exact rational execution of the specified scalar-error envelope |
| `code/verify.py` | Counterexample checks and reproducible certificate report |
| `code/test_envelope.py` | Ten regression tests |
| `code/build_pdf.py` | Optional PDF rebuilding helper |
| `results/exact_checks.json` | Regenerated certificate summaries for 15 witnesses |
| `results/verification_run.txt` | Output from the verification rerun |
| `results/unittest_run.txt` | Output from the regression-test rerun |
| `PROOF_SCOPE.md` | Claims, quantifiers, and verification limits |
| `SOURCES.md` | Primary sources and their roles |
| `recovery/RECOVERY_NOTES.md` | Recovery provenance and changes |
| `recovery/contact_1.jpg`, `recovery/contact_2.jpg` | Original surviving manuscript preview sheets |
| `MANIFEST.sha256` | SHA-256 checksums for package contents other than the manifest itself |

## Reproduce the exact checks

From this directory, with Python 3.10 or later:

```sh
python code/verify.py
python -m unittest discover -s code -v
```

No third-party Python package is required. Run without `-O`; the witness
verifier uses assertions. The command-line verifier rejects optimized mode.

The recovery rerun passed **all 15 witnesses and all 10 regression tests**.
The report checks one identity witness, one immediate-breakdown witness,
nine path/outlier witnesses with `n = 2,...,10` and `ell = 12`, and four
additional `n = 6` witnesses with `ell = 4, 8, 16, 24`.

For the path/outlier family, every produced iterate, including the initial
one, is checked with an exact sufficient certificate of backward-error
failure. True and recursive residuals are compared exactly. The decimal
residual values are for display only. Large rational values are summarized
by sign, numerator and denominator bit lengths, and SHA-256 of the ASCII
encoding `signed_hex_numerator/positive_hex_denominator`; rerunning the
code reconstructs the exact rationals.

## Arithmetic model

This is the adversarial scalar relative-error **envelope** specified by
IE-20, not IEEE round-to-nearest. The errors satisfy `|delta| <= 2**(-p)`.
The inputs must have at most `p` binary significant bits, but intermediate
results are exact rational values of the permitted error equations.
The code includes additions of zero and separates every product and sum.
A lower bound proved using these error schedules is not automatically a
lower bound for a stricter correctly rounded implementation.

## Rebuild the PDF

The supplied PDF is ready to read. With `pdflatex` and the packages listed
in the source preamble installed:

```sh
python code/build_pdf.py
```

The helper performs three LaTeX passes in a temporary directory and writes
the PDF beside the source. It requires no Python dependency beyond the
standard library. Rebuilding may change PDF metadata and therefore checksums.

## Integrity

On systems with `sha256sum`, run `sha256sum -c MANIFEST.sha256` before
regenerating files. The manifest covers the delivered files, not future
regenerated versions. Tests and compilation are reproducibility aids, not
formal verification of the mathematical arguments.
