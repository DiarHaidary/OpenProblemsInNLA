#!/usr/bin/env python3
"""Exact SP-10 family constructions. Python standard library only.

Search failure is inconclusive. Verification recomputes every support and rank.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import argparse, json, math, random


def normalize(n, edges):
    if not isinstance(n,int) or isinstance(n,bool) or n<1:
        raise ValueError('n must be a positive integer')
    E=set()
    for a,b in edges:
        if not (isinstance(a,int) and isinstance(b,int) and 0<=a<n and 0<=b<n and a!=b):
            raise ValueError('invalid edge')
        E.add(tuple(sorted((a,b))))
    return E


def complement(n,E):
    return set(combinations(range(n),2))-set(E)


def dot(x,y):
    return sum((a*b for a,b in zip(x,y)),F(0))


def rank(M):
    if not M: return 0
    A=[[F(x) for x in row] for row in M]
    n,m=len(A),len(A[0]); r=0
    if any(len(row)!=m for row in A): raise ValueError('ragged matrix')
    for c in range(m):
        p=next((i for i in range(r,n) if A[i][c]),None)
        if p is None: continue
        A[r],A[p]=A[p],A[r]
        a=A[r][c]; A[r]=[x/a for x in A[r]]
        for i in range(r+1,n):
            a=A[i][c]
            if a: A[i]=[x-a*y for x,y in zip(A[i],A[r])]
        r+=1
        if r==n: break
    return r


def encode(M): return [[str(F(x)) for x in row] for row in M]


def verify(rec):
    n=rec['n']; E=normalize(n,rec['edges'])
    target=rec.get('target',n+2)
    if not isinstance(target,int) or isinstance(target,bool) or target<0 or target>n+2:
        raise ValueError('target must be an integer between zero and n+2')
    ranks=[]
    for key,T in [('V',E),('W',complement(n,E))]:
        M=[[F(x) for x in row] for row in rec[key]]
        if len(M)!=n or not M or not M[0] or any(len(r)!=len(M[0]) for r in M):
            raise ValueError('invalid dimensions')
        if any(not any(row) for row in M):
            raise ValueError('this certificate format requires nonzero vectors')
        for i,j in combinations(range(n),2):
            if bool(dot(M[i],M[j])) != ((i,j) in T):
                raise ValueError(f'{key}: support mismatch at {i},{j}')
        ranks.append(rank(M))
    if sum(ranks)>rec.get('target',n+2):
        raise ValueError(f'rank sum {sum(ranks)} exceeds target')
    return ranks


def halfgraph(k):
    if k<2: raise ValueError('half-graph theorem requires k >= 2')
    V=[]; W=[]
    for i in range(1,k+1):
        v=[0]*(k+1); v[i]=1; V.append(v)
        w=[1]+[0]*k
        for h in range(i,k+1): w[h]=-1
        W.append(w)
    for j in range(1,k+1):
        v=[1]+[0]*k
        for h in range(1,j): v[h]=1
        v[j]=-j; V.append(v)
        w=[1]+[0]*k; w[j]=1; W.append(w)
    E=[(i-1,k+j-1) for i in range(1,k+1) for j in range(i,k+1)]
    rec={'family':'half_graph','k':k,'n':2*k,'edges':E,'V':encode(V),'W':encode(W),'target':2*k+2}
    rec['checked_ranks']=verify(rec)
    if rec['checked_ranks'] != [k+1,k+1]: raise AssertionError('unexpected family rank')
    return rec


def degeneracy(n,E):
    remaining=set(range(n)); ans=0
    while remaining:
        deg={v:sum(tuple(sorted((v,w))) in E for w in remaining if w!=v) for v in remaining}
        v=min(remaining,key=lambda x:(deg[x],x)); ans=max(ans,deg[v]); remaining.remove(v)
    return ans


def optimal_coloring(vertices,E):
    vertices=list(vertices)
    if not vertices: return {}
    order=sorted(vertices,key=lambda v:-sum(tuple(sorted((v,w))) in E for w in vertices if w!=v))
    for k in range(1,len(vertices)+1):
        C={}
        def visit(idx):
            if idx==len(order): return True
            v=order[idx]
            forbidden={C[w] for w in C if tuple(sorted((v,w))) in E}
            for c in range(k):
                if c not in forbidden:
                    C[v]=c
                    if visit(idx+1): return True
                    del C[v]
            return False
        if visit(0): return dict(C)
    raise AssertionError('coloring not found')


def quotient_vectors(t,E):
    if len(E)==t*(t-1)//2:
        return [[F(1)] for _ in range(t)]
    edges=sorted(E); iso=[i for i in range(t) if not any(i in e for e in edges)]
    U=[[F(0)]*(len(edges)+len(iso)) for _ in range(t)]
    for c,(i,j) in enumerate(edges): U[i][c]=F(1); U[j][c]=F(-1)
    for z,i in enumerate(iso): U[i][len(edges)+z]=F(1)
    return U


def weighted_dot(x,y,weights): return sum((a*b*c for a,b,c in zip(x,y,weights)),F(0))


def parallel(x,y):
    return all(x[i]*y[j]==x[j]*y[i] for i,j in combinations(range(len(x)),2))


def complement_path(m,d):
    weights=[F(d),F(1),F(1)]
    V=[[F(1),F(0),F(0)],[F(0),F(1),F(0)],[F(1),F(0),F(1)]]
    while len(V)<m:
        normal=[a*b for a,b in zip(V[-1],weights)]
        p=next(i for i,a in enumerate(normal) if a)
        basis=[]
        for j in range(3):
            if j!=p:
                b=[F(0)]*3; b[j]=normal[p]; b[p]=-normal[j]; basis.append(b)
        found=False
        for t in range(2*len(V)+4):
            x=[a+t*b for a,b in zip(basis[0],basis[1])]
            if (any(x) and all(weighted_dot(x,y,weights) for y in V[:-1])
                    and all(not parallel(x,y) for y in V)):
                V.append(x); found=True; break
        if not found: raise AssertionError('finite avoidance bound failed')
    return V


def local_path(m,d,comp):
    if comp: return complement_path(m,d)
    V=[[F(0)]*(m-1) for _ in range(m)]
    for i in range(m-1): V[i][i]=F(1); V[i+1][i]=F(-1)
    return V


def rotated(V,weights,rng):
    X=[row[:] for row in V]
    r=len(weights)
    for a,b in combinations(range(r),2):
        t=F(rng.choice([-4,-3,-2,-1,1,2,3,4]),rng.choice([1,2,3]))
        den=1+weights[a]*weights[b]*t*t
        c=(1-weights[a]*weights[b]*t*t)/den
        qa=2*weights[a]*t/den; qb=-2*weights[b]*t/den
        for row in X:
            x,y=row[a],row[b]
            row[a]=c*x+qb*y; row[b]=qa*x+c*y
    return X


def substituted_edges(t,E,sizes,comp_modules=False):
    starts=[]; N=0
    for m in sizes: starts.append(N); N+=m
    out=set()
    for i,m in enumerate(sizes):
        for a,b in combinations(range(m),2):
            if ((b==a+1) != comp_modules): out.add((starts[i]+a,starts[i]+b))
    for i,j in E:
        for a in range(sizes[i]):
            for b in range(sizes[j]): out.add((starts[i]+a,starts[j]+b))
    return N,out


def substitution_factor(t,E,sizes,comp_modules,seed):
    U=quotient_vectors(t,E); udim=len(U[0])
    S=[i for i,m in enumerate(sizes) if m>=4]
    colors=optimal_coloring(S,complement(t,E))
    c=1+max(colors.values()) if colors else 0
    priv={}; dim=udim+2*c
    for i,m in enumerate(sizes):
        r=1 if m==1 else (3 if comp_modules else m-1)
        priv[i]=dim; dim+=max(0,r-3)
    prior=[]; owners=[]; rng=random.Random(seed)
    for i,m in enumerate(sizes):
        d=dot(U[i],U[i])
        if m==1:
            row=U[i]+[F(0)]*(dim-udim); prior.append(row); owners.append(i); continue
        base=local_path(m,d,comp_modules); r=len(base[0]); weights=[d]+[F(1)]*(r-1)
        chosen=None
        for attempt in range(256):
            X=rotated(base,weights,rng)
            if any(not x[0] for x in X): continue
            embedded=[]
            for x in X:
                row=[F(0)]*dim
                for a,u in enumerate(U[i]): row[a]=x[0]*u
                row[udim+2*colors[i]]=x[1]; row[udim+2*colors[i]+1]=x[2]
                for j in range(3,r): row[priv[i]+j-3]=x[j]
                embedded.append(row)
            if all(dot(x,y) for x in embedded for y,j in zip(prior,owners)
                   if tuple(sorted((i,j))) in E):
                chosen=embedded; break
        if chosen is None: raise RuntimeError('UNKNOWN: bounded rational orientation search failed')
        prior.extend(chosen); owners.extend([i]*m)
    return prior


def substitution(t,edges,sizes,seed=20260913):
    if len(sizes)!=t or any(m!=1 and m<4 for m in sizes): raise ValueError('sizes must be 1 or >=4')
    E=normalize(t,edges)
    N,A=substituted_edges(t,E,sizes)
    V=substitution_factor(t,E,sizes,False,seed)
    W=substitution_factor(t,complement(t,E),sizes,True,seed+1)
    q=sum(m==1 for m in sizes)
    target=N if q==0 and t>=3 else (N+1 if q==0 and t==2 else N+2)
    rec={'family':'path_substitution','quotient_n':t,'quotient_edges':sorted(E),
         'module_sizes':sizes,'n':N,'edges':sorted(A),'V':encode(V),'W':encode(W),'target':target}
    rec['checked_ranks']=verify(rec)
    return rec


def generate(out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    with (out/'halfgraphs.jsonl').open('w') as f:
        for k in range(2,21):
            rec=halfgraph(k)
            assert degeneracy(2*k,set(map(tuple,rec['edges'])))==(k+1)//2
            f.write(json.dumps(rec,separators=(',',':'))+'\n')
            print('HALFGRAPH',k,rec['checked_ranks'],flush=True)
    fixtures=[(1,[],[4]),(2,[(0,1)],[4,5]),(3,[],[4,4,4]),
              (3,[(0,1),(0,2),(1,2)],[4,4,4]),
              (4,[(0,1),(1,2),(2,3)],[4,4,4,4]),
              (4,[(0,1),(1,2),(2,3)],[4,1,4,1]),
              (5,[(0,1),(1,2),(2,3),(3,4),(0,4)],[4,4,4,4,4])]
    with (out/'substitutions.jsonl').open('w') as f:
        for idx,(t,E,sizes) in enumerate(fixtures):
            rec=substitution(t,E,sizes,20260913+100*idx)
            f.write(json.dumps(rec,separators=(',',':'))+'\n')
            print('SUBSTITUTION',idx,'n',rec['n'],'ranks',rec['checked_ranks'],'target',rec['target'],flush=True)


def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    g=sub.add_parser('generate'); g.add_argument('out')
    v=sub.add_parser('verify'); v.add_argument('files',nargs='+')
    args=ap.parse_args()
    if args.cmd=='generate': generate(args.out)
    else:
        count=0
        for name in args.files:
            for line in Path(name).read_text().splitlines():
                if line.strip(): verify(json.loads(line)); count+=1
        print(json.dumps({'verified_records':count,'arithmetic':'exact rational'}))

if __name__=='__main__': main()
