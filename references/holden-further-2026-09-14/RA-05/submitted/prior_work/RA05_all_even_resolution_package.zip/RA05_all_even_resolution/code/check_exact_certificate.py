"""Verify the saved finite certificate with Python integers and Fractions only.

This does not implement or certify the asymptotic partial-coloring theorem.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]

def matrix_rank(rows: list[list[int]]) -> int:
    a = [[F(x) for x in row] for row in rows]
    pivot = 0
    for j in range(len(a[0])):
        i = next((i for i in range(pivot, len(a)) if a[i][j]), None)
        if i is None:
            continue
        a[pivot], a[i] = a[i], a[pivot]
        scale = a[pivot][j]
        a[pivot] = [x/scale for x in a[pivot]]
        for i in range(pivot+1, len(a)):
            scale = a[i][j]
            a[i] = [x-scale*y for x,y in zip(a[i], a[pivot])]
        pivot += 1
        if pivot == len(a):
            break
    return pivot

def check(path: Path | None = None) -> dict:
    cert = json.loads((path or ROOT/'results/exact_certificate.json').read_text())
    rows = cert['rows']
    weights = [F(x) for x in cert['weights']]
    count = 0
    def require(test: bool, message: str) -> None:
        nonlocal count
        count += 1
        if not test:
            raise AssertionError(message)
    require(len(rows) == len(weights) == cert['original_count'], 'Row count')
    require(all(w>=0 for w in weights), 'Nonnegative weights')
    support = [i for i,w in enumerate(weights) if w]
    require(len(support) == cert['support_count'], 'Support count')
    require(support == cert['support_indices_zero_based'], 'Support indices')
    require(matrix_rank(rows) == cert['input_rank'] == 3, 'Input rank')
    # Check each even degree directly, not merely infer it from degree eight.
    moments = {}
    for degree in cert['all_even_powers_preserved']:
        num = 0
        for a in range(degree+1):
            for b in range(degree+1-a):
                alpha = (a,b,degree-a-b)
                values = [row[0]**alpha[0]*row[1]**alpha[1]*row[2]**alpha[2] for row in rows]
                require(sum(values) == sum(w*v for w,v in zip(weights,values)), f'Moment {alpha}')
                num += 1
        moments[str(degree)] = num
    q = cert['query_projector']['normal_or_direction']
    qq = sum(x*x for x in q)
    require(qq == cert['query_projector']['denominator'], 'Projector denominator')
    P = [[F(x*y,qq) for y in q] for x in q]
    for i in range(3):
        for j in range(3):
            require(P[i][j] == P[j][i], 'Projector symmetry')
            require(sum(P[i][h]*P[h][j] for h in range(3)) == P[i][j], 'Projector idempotence')
    require(sum(P[i][i] for i in range(3)) == 1, 'Projector trace')
    squares = []
    for row in rows:
        residual = [F(row[i])-sum(P[i][j]*row[j] for j in range(3)) for i in range(3)]
        squares.append(sum(x*x for x in residual))
    costs = {}
    for p,expected in cert['costs'].items():
        vals = [x**(int(p)//2) for x in squares]
        original, weighted = sum(vals), sum(w*v for w,v in zip(weights,vals))
        require(original == weighted, 'Exact residual cost')
        require(str(original) == expected['original'], 'Recorded original cost')
        require(str(weighted) == expected['coreset'], 'Recorded coreset cost')
        costs[p] = str(original)
    probe = cert['non_even_nontransfer_probe']
    z = probe['normal']
    vals = [abs(sum(x*y for x,y in zip(row,z)))**3 for row in rows]
    original, weighted = F(sum(vals)), sum(w*v for w,v in zip(weights,vals))
    require(original != weighted, 'Non-even nontransfer')
    require(str(original) == probe['original_unnormalized_cubic_cost'], 'Recorded cubic original')
    require(str(weighted) == probe['coreset_unnormalized_cubic_cost'], 'Recorded cubic coreset')
    require(str(abs(weighted-original)/original) == probe['relative_error'], 'Recorded cubic relative error')
    return {'status':'PASS','exact_assertions':count,'rows':len(rows),'support':len(support),
            'input_rank':3,'query_rank':1,'moments_per_degree':moments,'exact_costs':costs,
            'scope':'Finite exact original-row certificate; not a formalization of the asymptotic proof.'}

if __name__ == '__main__':
    result = check(Path(sys.argv[1]) if len(sys.argv)>1 else None)
    print(json.dumps(result,indent=2))
