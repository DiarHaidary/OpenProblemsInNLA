# Proof guide: partial-trace controls with an explicit error budget

This is a mathematical outline of the final manuscript, not a replacement for
its proofs. It establishes fixed-order optimality, not a full q-uniform solution.

## Known controls and unknown PSD means

For a subset S, let T_S be the unnormalized partial trace retaining S and let
L_S(A)=A tensor I/n**(q-|S|). The operators E_S=L_S T_S are commuting Frobenius
orthogonal projections, with E_S E_T=E_(S intersection T).

At a stage S, the algorithm approximates A_S=T_S M, which is PSD and has the
same trace tau as M. It updates its known matrix by

    B_new = B + L_S(Ahat_S - T_S B).

Writing R=M-B and e_S=A_S-Ahat_S gives the exact identity

    R_new = (I-E_S)R + L_S(e_S).

The controls and residuals may be indefinite. Their positivity is never assumed.

## Why later noise stays controlled

Split each local matrix space orthogonally into the identity and traceless
subspaces. Index the resulting global interaction components by V, with a
traceless local factor precisely on V. The projection is

    P_V = sum_{T subset V} (-1)**(|V|-|T|) E_T.

A stage S replaces exactly the components with V subset S. Thus each current
component comes from the most recently processed superset U of V. Process every
nonempty S in descending cardinality.

Outside four-phase contractions have deterministic action on identity factors
and mean-zero action on traceless factors. Different components are orthogonal
in mean-square Frobenius norm. Just before S, a random outside contraction obeys

    E ||C_y(R)-T_S R||_F**2
      <= sum_{V not subset S} n**(q-|S union V|) ||R_V||_F**2.

For each term's current superset U, descending order gives
`|U| <= |S union V|`. The lifting normalization cancels the dimensional factor,
and orthogonality of the components inside each e_U yields

    E ||C_y(R)-T_S R||_F**2 <= sum_{U previously processed} ||e_U||_F**2.

After all nonempty subsets, each nonempty component V is assigned to e_V itself.
The scalar component is deterministic under fixed-norm phase probes, so

    Var(z* R z) <= sum_{S nonempty} ||e_S||_F**2.

## A permitted noisy matrix-vector oracle

Freeze B. For an inside product vector x, return the average of a independent
outside contractions of (M-B), then add `(T_S B)x`. Its mean is `(T_S M)x`.
The random Hermitian noise matrix is independent of x and has one common law
for all inside vectors. Each outside sample is one internal complex full-product
response. It is obtained by q+1 real product calls using polynomial interpolation.
All operations on B are computations on known data.

## Noisy low-rank approximation

For an original PSD mean A, trace tau, rank target r0, and fourth-moment bound h,
the approximation lemma uses at most `2**28*h*r0` noisy responses. It returns
squared Frobenius error at most `2**13*(tau**2/r0+nu)` with probability at least
7/8, where nu bounds the mean-square Frobenius noise matrix.

The range sketch is reduced to at most 2r0 sampled columns by exact finite
column-subset selection. A second, independent product sketch fits the missing
coefficient matrix. This two-sided formula uses only already observed responses;
no multiplication of A by the selected output columns is requested. Small
matrix dimensions use noisy coordinate-basis sweeps. Exact rank tests and Gram
inverses suffice. Metric-median boosting multiplies the error bound by a constant
without requiring the unknown trace or error radius.

## Parameters and scope

For phase products on s modes, h_s=(2-1/n)**s. Let K=2**q-1,
H=sum_S h_|S|=(3-1/n)**q-1, D=ceil(sqrt(H)). If epsilon<=1/D, choose

    r = ceil(1/(D*epsilon))
    r0 = 2**18*r
    a = 2**18*K       # a=1 for the full set
    L = 8*q+17       # independent metric-median candidates
    ell = ceil(12*K/(r*epsilon**2)).

Each stage has error squared at most tau**2/r, with conditional failure at most
1/(12K). The total stage-failure probability is at most 1/12. The final ell fresh
residual probes fail with conditional probability at most 1/12. For larger
errors a plain phase average suffices. Charge q+1 real calls per complex product
and compare with exact basis recovery to obtain

    Q <= min(n**q, ceil(2**71*q*(q+1)*K*D/epsilon)).

The supplied ordinary-oracle lower proof then gives
`Theta_q(min(n**q,1/epsilon))`. The q-dependent constants in this conclusion
remain unmatched by the unrestricted lower bound. Nothing in this guide removes
that qualification.
