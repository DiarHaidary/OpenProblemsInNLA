"""Search only: a later exact verifier must validate any output certificate."""
from pathlib import Path
from fractions import Fraction
import json,sys,itertools,time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
ROOT=Path(__file__).resolve().parents[1]
def run(path):
 data=json.loads(path.read_text());poly={tuple(m):Fraction(c) for m,c in data['terms']};pos={m:c for m,c in poly.items() if c>0};neg={m:-c for m,c in poly.items() if c<0}
 pp=list(pos);nn=list(neg);rows={m:i for i,m in enumerate(pp)};negrows={m:len(pp)+i for i,m in enumerate(nn)}
 pairs=[];row=[];col=[];vals=[]
 for g in nn:
  count=0
  for aa in pp:
   bb=tuple(2*x-y for x,y in zip(g,aa))
   if any(x<0 for x in bb) or bb not in pos or aa>=bb:continue
   for k in range(-5,6):
    rr=Fraction(4)**k;j=len(pairs);pairs.append((g,aa,bb,k));count+=1
    row.extend([rows[aa],rows[bb],negrows[g]]);col.extend([j,j,j])
    vals.extend([float(rr*neg[g]/(2*pos[aa])),float(neg[g]/(2*rr*pos[bb])),-1.0])
  print(path.name,'negative',g,'pairs',count,flush=True)
 A=coo_matrix((vals,(row,col)),shape=(len(pp)+len(nn),len(pairs))).tocsc()
 bounds=np.r_[np.full(len(pp),.999),np.full(len(nn),-1.001)]
 costs=np.ones(len(pairs))
 sol=linprog(costs,A_ub=A,b_ub=bounds,bounds=(0,None),method='highs')
 print(path.name,sol.message,'vars',len(pairs),flush=True)
 if not sol.success:return False
 residual=poly.copy();terms=[]
 for (g,aa,bb,k),value in zip(pairs,sol.x):
  if value<=1e-10:continue
  weight=Fraction(round(float(value)*10**6),10**6)*neg[g]/2;rr=Fraction(4)**k
  residual[aa]-=weight*rr;residual[bb]-=weight/rr;residual[g]+=2*weight
  terms.append({'alpha':list(aa),'beta':list(bb),'gamma':list(g),'k':k,'weight':str(weight)})
 bad={m:c for m,c in residual.items() if c<0}
 print('exact residual negatives',len(bad),'terms',len(terms),'minimum',min(residual.values()),flush=True)
 if bad:print(list(bad.items())[:5]);return False
 cert={'schema':'nonnegative-binomial-squares-v1','source':path.name,'polynomial':data,'squares':terms,'nonnegative_remainder':[[list(m),str(c)] for m,c in residual.items() if c]}
 out=ROOT/'checks'/(path.stem+'_certificate.json');out.write_text(json.dumps(cert,indent=2));return True
if __name__=='__main__':
 for name in sys.argv[1:] if len(sys.argv)>1 else ['typeA_minus_Q.json','typeA_minus_B.json','typeA_far_Q.json','typeA_far_B.json']:
  run(ROOT/'exploration'/name)
