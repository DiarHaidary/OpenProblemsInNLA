"""SP-03 experimental continuation using the m^2-variable Schur reduction.
Numerical discoveries are NOT completeness or root-certification proofs.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import numpy as np
from numba import njit
import sys,time,json
BASE=Path(__file__).resolve().parent

@njit(cache=True)
def basis(m):
    k=m*(m+1)//2;E=np.zeros((k,m,m),np.complex128);p=0
    for i in range(m):
        for j in range(i,m):E[p,i,j]=1;E[p,j,i]=1;p+=1
    return E

@njit(cache=True)
def evaluate(a,U,du,E):
    m=E.shape[1];k=E.shape[0];d=m*m
    A=a.reshape((m,m));Ua=U[:m,:m].copy();Ub=U[:m,m:].copy();Uc=U[m:,:m].copy();Ud=U[m:,m:].copy()
    da=du[:m,:m].copy();db=du[:m,m:].copy();dc=du[m:,:m].copy();dd=du[m:,m:].copy()
    Ai=np.linalg.inv(A);Y=Ai.T.copy();L=np.empty((k,k),np.complex128);Lp=np.empty_like(L)
    b=np.empty(k,np.complex128);c=np.empty_like(b);bp=np.empty_like(b);cp=np.empty_like(b)
    for i in range(k):
        AE=A@E[i]
        B=2*AE@A.T-AE@Ua.T
        Bp=-AE@da.T
        for j in range(k):L[i,j]=np.sum(B*E[j]);Lp[i,j]=np.sum(Bp*E[j])
        b[i]=np.sum(AE*Uc);bp[i]=np.sum(AE*dc)
        EA=E[i]@A
        c[i]=np.sum(EA*Ub);cp[i]=np.sum(EA*db)
    t=np.linalg.solve(L,b);s=np.linalg.solve(L.T,c)
    T=np.zeros((m,m),np.complex128);S=np.zeros_like(T)
    for i in range(k):S+=s[i]*E[i];T+=t[i]*E[i]
    V=4*A-Ua;W=Y@Ua.T@Y
    g=T@V@S-Uc@S-T@Ub-Ud+W
    HS=np.empty((d,k),np.complex128);HT=np.empty_like(HS)
    AA=T@V-Uc;BB=V@S-Ub
    for i in range(k):HS[:,i]=(AA@E[i]).ravel();HT[:,i]=(E[i]@BB).ravel()
    H0=np.empty((d,d),np.complex128)
    for i in range(m):
        for j in range(m):
            Vv=np.zeros((m,m),np.complex128);Vv[i,j]=1
            H0[:,i*m+j]=(4*T@Vv@S-Y@Vv.T@W-W@Vv.T@Y).ravel()
    R=HT@np.linalg.solve(L,HS.T)
    H=H0-R-R.T
    tp=np.linalg.solve(L,bp-Lp@t);sp=np.linalg.solve(L.T,cp-Lp.T@s)
    gp=HS@sp+HT@tp+(-T@da@S-dc@S-T@db-dd+Y@da.T@Y).ravel()
    return g.ravel(),H,gp,S,T

@njit(cache=True)
def ni(x):return np.max(np.abs(x))

@njit(cache=True)
def track(a0,u0,u1,E):
    a=a0.copy();du=u1-u0;t=0.;h=.015;steps=0
    while t<1.:
        steps+=1
        if steps>4000:return a,False,steps
        try:g,H,gp,S,T=evaluate(a,u0+t*du,du,E);v=np.linalg.solve(H,-gp)
        except:return a,False,steps
        h=min(h,1.-t);pred=a+h*v;y=pred.copy();ok=False;olderr=1e300
        for it in range(8):
            try:g,H,gp,S,T=evaluate(y,u0+(t+h)*du,du,E);delta=np.linalg.solve(H,g)
            except:break
            err=ni(delta)
            if not np.isfinite(err):break
            y-=delta
            if err<1e-11*(1+ni(y)):ok=True;break
            if it>=2 and err>olderr*.8:break
            olderr=err
        if ok:
            corr=ni(y-pred)/(1+ni(y))
            if corr>.03:h*=.5
            else:
                a=y;t+=h
                if corr<.0005:h*=1.6
                elif corr<.004:h*=1.25
                elif corr>.018:h*=.7
                h=min(h,.12)
        else:h*=.5
        if h<1e-9 or ni(a)>1e9:return a,False,steps
    for it in range(3):
        try:g,H,gp,S,T=evaluate(a,u1,du,E);a-=np.linalg.solve(H,g)
        except:return a,False,steps
    try:g,H,gp,S,T=evaluate(a,u1,du,E)
    except:return a,False,steps
    return a,ni(g)<1e-6,steps

def lift(a,U,E):
    m=E.shape[1];A=a.reshape(m,m)
    g,H,gp,S,T=evaluate(a,U,np.zeros_like(U),E)
    X=np.block([[A,A@S],[T@A,T@A@S+np.linalg.inv(A).T]])
    return X,g,H

def validate(a,U,E):
    m=E.shape[1];J=np.block([[np.zeros((m,m)),np.eye(m)],[-np.eye(m),np.zeros((m,m))]])
    Q=np.block([[np.zeros((m,m)),np.eye(m)],[np.eye(m),np.zeros((m,m))]])
    try:
        X,g,H=lift(a,U,E);K=np.linalg.solve(X,Q@J@(U-X)@Q)
        err=max(ni(K+K.T),ni(X.T@J@X-J),ni(g))
        return err<1e-5,float(err)
    except np.linalg.LinAlgError:return False,np.inf

def main(m,seconds=25,maxloops=1000,seed=88132):
    n=2*m;E=basis(m);d=m*m;path=BASE/f'bigcell_m{m}.npz'
    rng=np.random.default_rng(seed+m+(int(time.time())%100000 if path.exists() else 0))
    def rc(shape,scale=1.):return scale*(rng.standard_normal(shape)+1j*rng.standard_normal(shape))/np.sqrt(2*m)
    if path.exists():
        z=np.load(path);roots=list(z['roots']);U=z['U'];loops=int(z['loops'])
    else:
        A=np.eye(m)+rc((m,m),.3);S=rc((m,m),.25);S=(S+S.T)/2;T=rc((m,m),.25);T=(T+T.T)/2
        X=np.block([[A,A@S],[T@A,T@A@S+np.linalg.inv(A).T]])
        J=np.block([[np.zeros((m,m)),np.eye(m)],[-np.eye(m),np.zeros((m,m))]])
        Q=np.block([[np.zeros((m,m)),np.eye(m)],[np.eye(m),np.zeros((m,m))]])
        K=rc((n,n),1.);K=(K-K.T)/2
        U=X+Q@J@X@K@Q;roots=[A.ravel().copy()];loops=0
        target=rc((n,n),2.)
        y,ok,st=track(roots[0],U,target,E)
        if ok and validate(y,target,E)[0]:U=target;roots=[y]
    g,H,gp,S,T=evaluate(roots[0],U,np.zeros_like(U),E)
    print('START',m,'roots',len(roots),'resid',ni(g),'condH',np.linalg.cond(H),'validate',validate(roots[0],U,E),flush=True)
    v=rc((d,));du=rc((n,n));h=1e-6
    gp0=evaluate(roots[0],U,du,E)[2]
    fp=evaluate(roots[0]+h*v,U,du,E)[0];fm=evaluate(roots[0]-h*v,U,du,E)[0]
    pp=evaluate(roots[0],U+h*du,du,E)[0];pm=evaluate(roots[0],U-h*du,du,E)[0]
    print('DERIV',ni((fp-fm)/(2*h)-H@v),ni((pp-pm)/(2*h)-gp0),flush=True)
    proj=rc((d,));bucket={};width=.0001
    def key(z):return(int(np.floor(z.real/width)),int(np.floor(z.imag/width)))
    for i,a in enumerate(roots):bucket.setdefault(key(np.dot(proj,a)),[]).append(i)
    def add(y):
        z=np.dot(proj,y);a,b=key(z)
        for aa in range(a-1,a+2):
            for bb in range(b-1,b+2):
                for ix in bucket.get((aa,bb),[]):
                    if ni(y-roots[ix])<1e-6*(1+ni(y)):return False
        if not validate(y,U,E)[0]:return False
        bucket.setdefault((a,b),[]).append(len(roots));roots.append(y);return True
    start=time.time();paths=fail=stotal=0;ng=0
    for _ in range(maxloops):
        old=len(roots);V=rc((n,n),2.);W=rc((n,n),2.);ix=0
        while ix<len(roots):
            y=roots[ix].copy();good=True
            for p,q in [(U,V),(V,W),(W,U)]:
                y,ok,st=track(y,p,q,E);paths+=1;stotal+=st
                if not ok:good=False;fail+=1;break
            if good:add(y)
            ix+=1
            if time.time()-start>seconds:break
        loops+=1
        info=dict(m=m,loops=loops,roots=len(roots),elapsed=time.time()-start,paths=paths,failures=fail,steps=stotal)
        print(json.dumps(info),flush=True)
        np.savez_compressed(path,roots=np.asarray(roots),U=U,loops=np.asarray(loops))
        with open(BASE/f'bigcell_log_m{m}.jsonl','a') as f:f.write(json.dumps(info)+'\n')
        ng=ng+1 if len(roots)==old else 0
        if time.time()-start>seconds or (ng>=5 and loops>=8):break
    print('FINISH',m,len(roots),flush=True)

if __name__=='__main__':main(int(sys.argv[1]),float(sys.argv[2]) if len(sys.argv)>2 else 25)
