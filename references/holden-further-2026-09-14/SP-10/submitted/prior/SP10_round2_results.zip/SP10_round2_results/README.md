# SP-10: second continuation (PARTIAL)

Read **REPORT.md** first. This archive does not prove or disprove the full graph complement conjecture.

The self-contained report proves a path-substitution theorem for arbitrary quotient graphs, a mixed path/singleton extension, exact complementary minimum ranks of half graphs, and a sharp 2d+1 auxiliary dimension theorem. The previous archive is retained unmodified when available.

## Reproduce the exact checks

```sh
python -m unittest discover -s tests -v
python src/exact_families.py generate certificates
python src/exact_families.py verify certificates/halfgraphs.jsonl certificates/substitutions.jsonl
```

Python's standard library is sufficient. The optional construction searches only for rational orientations, reports UNKNOWN on bounded search failure, and never interprets a search failure as a counterexample. Verification uses rational arithmetic, checks every off-diagonal zero and nonzero, and recomputes ranks rather than trusting stored values.

`EXECUTION_LOG.txt` and `execution_status.json`, when present, describe the actual local executions. Read those files rather than assuming success from the existence of a source file. Source files and theorem proofs are distinct from finite verification outcomes.

No repository edit or full-resolution status change is included.
