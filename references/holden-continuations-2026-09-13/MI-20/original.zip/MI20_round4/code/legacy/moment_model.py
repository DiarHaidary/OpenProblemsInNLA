"""Exact homogeneous tracial moment model for the cubic MI-20 equations.

All coefficients are rational. Numerical search using this model is not a
proof; exact_global_bound.py checks a proposed Gram identity independently.
"""
from fractions import Fraction as F
from itertools import product

def canon(w):
    w=tuple(w);v=w[::-1]
    return min([w[i:]+w[:i] for i in range(len(w))]+[v[i:]+v[:i] for i in range(len(v))])

def model(lam=F(91,10),h=F(7,5)):
    keys=sorted(set(canon(w) for w in product(range(3),repeat=4)))
    ind={w:i for i,w in enumerate(keys)};nv=len(keys)
    def moment(w):
        out=[F(0)]*nv;out[ind[canon(w)]]=F(1);return out
    def add(a,b,scale=F(1)):return [x+scale*y for x,y in zip(a,b)]
    eq=[]
    for j in (1,2):
        for i in range(3):
            v=[F(0)]*nv
            for w in product((0,j),repeat=3):v=add(v,moment((i,)+w))
            v=add(v,moment((i,0,j,0)),-lam);eq.append(v)
    for i in range(3):
        v=[F(0)]*nv
        for j in (1,2):v=add(add(v,moment((i,j,0,j))),moment((i,0,j,0)),-1)
        eq.append(v)
    z=add(moment((0,0,0,1)),moment((0,0,0,2)));eq.append(z)
    wb=list(product(range(3),repeat=2))
    mats=[[[moment(wi[::-1]+wj) for wj in wb] for wi in wb]]
    weights=[[F(1),F(0),F(0)],[F(0),F(1),F(0)],[F(0),F(0),F(1)],
             [F(2),F(-1),F(-1)],[h,F(-1),F(0)],[h,F(0),F(-1)]]
    for aa in range(6):
        for bb in range(aa,6):
            mat=[]
            for i in range(3):
                row=[]
                for j in range(3):
                    v=[F(0)]*nv
                    for a in range(3):
                        for b in range(3):
                            v=add(v,moment((i,a,j,b)),weights[aa][a]*weights[bb][b])
                    row.append(v)
                mat.append(row)
            mats.append(mat)
    return {'keys':keys,'equations':eq,'matrices':mats,'weights':weights,
            'lambda0':lam,'h':h}
