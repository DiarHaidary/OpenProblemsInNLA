#!/usr/bin/env python3
"""Supplementary checks for the proved all-dimensions boundary strip.
Exact identities and finite tests only; the universal proof is in the manuscript.
"""
import itertools,json,time
from pathlib import Path
import numpy as np
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
start=time.time();n,c,r,tau,K,eta=s.symbols('n c r tau K eta',real=True)
base=c*c*n*n+r*r*(2*n*n-tau*tau)+4*c*r*K-2*c*r*n*tau+2*(c*n+r*tau)*eta-3*eta*eta
assert s.expand(base-(2*((c*c+r*r)*n*n+2*c*r*K)-(c*n+r*tau-eta)**2-2*eta**2))==0
m=s.symbols('m',integer=True,positive=True)
Kplus=2*m*m+4*m+1;Kminus=2*m*m-1
assert s.expand(base.subs({n:2*m+1,tau:-1,K:Kminus,eta:0})-base.subs({n:2*m+1,tau:1,K:Kplus,eta:0})+4*c*r*(2*m+1))==0
minor_count=0
for bits in itertools.product((-1,1),repeat=9):
 T=s.Matrix(3,3,bits)
 if T.det()!=0:
  assert T.det()**2==16
  assert (T*T.T).charpoly().as_expr().factor()==(s.Symbol('lambda')-1)*(s.Symbol('lambda')-4)**2
  minor_count+=1
checks=0;smallest=1e99;closest=None
for nn in range(3,81):
 pairs=[(nn//2,nn//2)] if nn%2==0 else [(nn//2+1,nn//2),(nn//2,nn//2+1)]
 for p,q in pairs:
  tt=p-q
  for P in range(-p,p+1,2):
   for Q in range(-q,q+1,2):
    RR=nn-P*P/p-Q*Q/q;KK=P*P+2*P*Q-Q*Q
    if tt>=0:
     Kstar=nn*nn-2*q*q
     assert RR<=Kstar-KK+1e-9
    v=np.array([P/np.sqrt(p),Q/np.sqrt(q),np.sqrt(max(0,RR))])
    S=np.array([[p,np.sqrt(p*q),0],[np.sqrt(p*q),-q,0],[0,0,0.]])
    for cc in [1/(12*nn*nn),1/(6*nn*nn),1/(2*(nn+7)),1/(nn+7)]:
     rr=1-cc;A=rr*S+cc*np.outer(v,v);ev=np.linalg.eigvalsh(A);spread=ev[-1]-ev[0];dd=2*rr;kk=nn//2
     M2=nn*nn+dd*(2*nn*kk-(4-dd)*kk*kk);gap=M2-spread*spread
     assert gap>=-1e-7,(nn,p,q,P,Q,cc,gap)
     if gap<smallest:smallest=gap;closest=[nn,p,q,P,Q,cc]
     checks+=1
result={'status':'PASS','exact_symbolic_identities':2,'invertible_sign_3x3_matrices_checked_exactly':minor_count,'balanced_rank_two_compressions_checked':checks,'minimum_numerical_squared_gap':smallest,'closest':closest,'seconds':time.time()-start,'scope':'Supplementary tests; universal assertions are proved analytically.'}
(ROOT/'logs/boundary_strip_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
