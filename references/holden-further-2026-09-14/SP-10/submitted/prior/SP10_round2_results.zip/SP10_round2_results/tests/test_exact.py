import sys, unittest
from pathlib import Path
from fractions import Fraction as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import exact_families as e

class ExactTests(unittest.TestCase):
    def test_halfgraph_small(self):
        self.assertEqual(e.verify(e.halfgraph(2)),[3,3])
    def test_halfgraph_eight(self):
        rec=e.halfgraph(4)
        self.assertEqual(e.verify(rec),[5,5])
        self.assertEqual(e.degeneracy(8,set(map(tuple,rec['edges']))),2)
    def test_degeneracy_formula(self):
        for k in range(2,9):
            r=e.halfgraph(k)
            self.assertEqual(e.degeneracy(2*k,set(map(tuple,r['edges']))),(k+1)//2)
    def test_reject_corruption(self):
        r=e.halfgraph(2); r['V'][0]=['0']*3
        with self.assertRaises(ValueError): e.verify(r)
    def test_reject_inflated_target(self):
        r=e.halfgraph(2); r['target']=100
        with self.assertRaises(ValueError): e.verify(r)
    def test_rank(self):
        self.assertEqual(e.rank([[1,2,3],[2,4,6],[0,1,1]]),2)
    def test_weighted_rotation(self):
        import random
        X=[[F(1),F(2),F(3)],[F(-2),F(1),F(0)]]; weights=[F(3),F(1),F(1)]
        Y=e.rotated(X,weights,random.Random(7))
        for i in range(2):
            for j in range(2):
                self.assertEqual(e.weighted_dot(X[i],X[j],weights),e.weighted_dot(Y[i],Y[j],weights))
    def test_weighted_complement_path(self):
        X=e.complement_path(7,F(3)); w=[F(3),F(1),F(1)]
        for i in range(7):
            for j in range(i+1,7): self.assertEqual(bool(e.weighted_dot(X[i],X[j],w)),j-i!=1)
    def test_path_substitution(self):
        r=e.substitution(3,[(0,1),(1,2)],[4,4,4],11)
        self.assertLessEqual(sum(e.verify(r)),12)
    def test_mixed_substitution(self):
        r=e.substitution(3,[(0,1),(1,2)],[4,1,1],19)
        self.assertLessEqual(sum(e.verify(r)),8)

if __name__=='__main__': unittest.main()
