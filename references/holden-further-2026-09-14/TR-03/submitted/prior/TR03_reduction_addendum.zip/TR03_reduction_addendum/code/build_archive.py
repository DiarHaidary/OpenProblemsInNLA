#!/usr/bin/env python3
"""Build an integrity-checked archive of this addendum; standard library only."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[1]
archive = root.parent / (root.name + '.zip')
files = [p for p in sorted(root.rglob('*')) if p.is_file()
         and '__pycache__' not in p.parts and p.name != 'SHA256SUMS.txt']
(root / 'SHA256SUMS.txt').write_text(''.join(
    hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + str(p.relative_to(root)) + '\n'
    for p in files))
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            z.write(p, p.relative_to(root.parent))
with zipfile.ZipFile(archive) as z:
    bad = z.testzip()
    if bad is not None:
        raise RuntimeError('Archive integrity failure: ' + bad)
print(str(archive))
print(str(archive.stat().st_size) + ' bytes')
