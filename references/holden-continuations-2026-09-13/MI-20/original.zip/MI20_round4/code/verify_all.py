"""Recheck every certificate used in the fourth-round report.

The preceding cap is recomputed, not trusted from a report or manifest.
Acceptance is by integers and fractions; numerical searches are not run.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent/'legacy'))

def verify_all():
    from global_bound_chain import verify as verify_chain
    from verify_interval import verify as verify_new
    from fiber_certificate import load_verify
    chain=verify_chain(json.loads((ROOT/'certificates/predecessor_cubic_chain.json').read_text()))
    cap=F(chain['reported_lambda_upper'])
    new=verify_new(json.loads((ROOT/'certificates/interval_d6_861_100.json').read_text()),cap)
    fibers=[]
    for name in ('p3_2_m2_n16','p4_3_m2_n16','p6_5_m2_n64','p6_5_m3_n36'):
        p=ROOT/'certificates'/f'{name}_upper.json'
        fibers.append({'file':str(p.relative_to(ROOT)),'result':load_verify(p)})
    return {'status':'PASS','full_solution_obtained':False,
            'universal_upper_bound_expression':new['upper_bound_expression'],
            'universal_upper_fourth_power':new['universal_upper_fourth_power'],
            'inherited_Gram_chain':chain,'new_interval_certificate':new,
            'fixed_moduli_intervals':fibers,
            'scope_note':'Fiber upper endpoints are not universal upper bounds. The new interval bound is universal.'}

if __name__=='__main__':
    try:print(json.dumps(verify_all(),indent=2))
    except Exception:
        print(json.dumps({'status':'FAIL','error':traceback.format_exc()},indent=2));sys.exit(1)
