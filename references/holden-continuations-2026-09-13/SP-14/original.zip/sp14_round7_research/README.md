# SP-14 — seventh research package

**Status: partial. This package is not a full proof or counterexample to SP-14.**

Read `manuscript/sp14_round7.pdf` for the self-contained mathematical arguments. The source is `manuscript/sp14_round7.tex`.

## Main conclusions

For a continuous nonvanishing zero-winding symbol c, geometric decay of every sufficiently large top-right inverse corner of T_(n+1)(c) is equivalent to an inner-annulus analytic extension. Reflection gives the outer-annulus version. The proof uses an exact inverse-row bordering identity and Hardy-space analytic localization.

At each off-range point of winding +1, absence of inner extension forces the canonical normalized logarithmic determinant value in the limsup. Winding -1 uses outer nonextension. Explicit inequalities compare the inverse corner with the least singular value. A finite unperturbed certificate is proved for unit-circle-valued symbols, including an explicit stability bound when the first weighted squared Fourier moment is less than one.

For every continuous symbol with Jordan-curve range and winding +1, absence of inner extension is equivalent to the existence of a canonical subsequence of its actual unperturbed Toeplitz eigenvalue measures. Winding -1 uses outer extension. Positive-area Jordan curves are permitted through the classical Walsh rational approximation theorem. Conversely, an extension in the winding direction forces a strictly positive liminf energy deficit.

These are deterministic fixed-symbol statements, not probability-one statements, Baire-category statements, perturbed-matrix laws, or iterated limits. They still concern a subsequence. The implication from both annular nonextensions to full-sequence convergence remains unproved.

## Reproduction

Python 3.13.5 was used with the versions pinned in `code/requirements.txt`.

```sh
python -m pip install -r code/requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/validate.py
bash build.sh
```

The last command also requires a working pdfLaTeX installation with standard AMS, Latin Modern, microtype, geometry, booktabs, and hyperref packages. It creates compilation intermediates in `manuscript/`. It does not install packages automatically.

To rerun the six earlier suites in extracted temporary copies:

```sh
python code/rerun_prior.py --work-dir /tmp/sp14-prior-checks
```

To verify the delivered bytes, run `python code/verify_manifest.py` **before** rebuilding or regenerating reports. Rebuilding may legitimately change PDF metadata or result files, after which the original delivery manifest no longer describes those new bytes.

## Verification boundary

`results/validation.json` records each new executed finite check, its category, and any numerical tolerance. Exact symbolic checks, 100-decimal-digit calculations, ordinary floating-point tests, and software checks are distinguished. The functions in `code/boundary.py` that evaluate corners or eigenvalues in floating point explicitly return diagnostics, not certified enclosures. The analytical theorems are not established by finite tests. No independent referee or proof-assistant verification is claimed.

The six earlier archives are preserved unchanged, nested inside `previous/sp14_round6_research_original.zip`. Their rerun counts are recorded separately in `results/prior_rerun.json`, not added to the new count. Preservation and repeated execution are not independent verification of their mathematical claims.

## Contents

- `manuscript/`: PDF and editable LaTeX.
- `code/`: boundary diagnostics, validation suite, prior-suite rerunner, build dependencies, manifest checker.
- `results/`: machine-readable checks, numerical tables, prior-suite rerun report, artifact verification.
- `notes/`: claim audit, unresolved implications, sources and execution record.
- `previous/`: unchanged sixth ZIP with its five nested predecessors.
- `MANIFEST.sha256`: hashes of delivered files other than the manifest itself.

No repository file has been edited and no solved-status claim is made.
