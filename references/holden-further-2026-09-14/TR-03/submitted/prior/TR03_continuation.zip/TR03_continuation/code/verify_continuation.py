"""Run reproducible checks, not proof-assistant verification, for TR-03.

Usage (from this directory): python verify_continuation.py
Output: ../results/continuation_verification.json
"""
from __future__ import annotations
from itertools import combinations
from pathlib import Path
import json
import math
import platform
import time
import numpy as np
import scipy
from scipy.linalg import null_space
from scipy.special import gammaln
from scipy.stats import ks_2samp
import sympy as sp
from continuation import (basis_cost, flat_distribution, frame, group_matrix,
    grouped_tail, hollow_basis, infinite_leading_cost, minors_and_johnson,
    octahedral_energy, orthogonal)

SEED = 20260913
rng = np.random.default_rng(SEED)
checks: dict[str, dict] = {}
started = time.time()


def record(name: str, passed: bool, **details: object) -> None:
    checks[name] = {"passed": bool(passed), **details}
    print(f"{'PASS' if passed else 'FAIL'} {name}", flush=True)


def relerr(a: float, b: float) -> float:
    return abs(a - b) / max(1.0, abs(a), abs(b))

# Exact local minimization and first-order conditions.
b, c = sp.symbols("b c", nonnegative=True)
s1 = sp.Matrix([2*(b+c), 2*b, 2*c])
s2 = sp.Matrix([2*(b+c), 2*b, sp.Rational(3,5)*(2*b+c)])
C = (b+c)**2+b**2+c**2
phi = lambda s: sp.expand(13*(s.dot(s))-3*sum(s)**2-20*C)
identities = [
    sp.simplify(phi(s1)-16*(b-c)**2) == 0,
    sp.simplify(phi(s2)-sp.Rational(2,5)*(4*b*b+4*b*c-9*c*c)) == 0,
    sp.simplify(26*s2[2]-6*sum(s2)) == 0,
    sp.simplify((4+4*c-9*c*c).subs(c,sp.Rational(6,7))-sp.Rational(40,49)) == 0,
]
record("symbolic_octahedral_minimization", all(identities), identities=len(identities))

max_local = 0.0
for _ in range(10000):
    b0, c0 = np.sort(rng.random(2))[::-1]
    products = np.array([b0+c0,b0,c0])
    imbalance = rng.uniform(-8.0,8.0,3)
    w = np.column_stack([products*np.exp(imbalance), products*np.exp(-imbalance)]).ravel()
    energy, squared_norm = octahedral_energy(w)
    max_local = max(max_local,energy/squared_norm)
energy, norm2 = octahedral_energy(np.array([2.,2.,1.,1.,1.,1.]))
record("octahedral_random_and_sharp_case", max_local <= 10/3+1e-12 and abs(energy/norm2-10/3)<1e-12,
       random_cases=10000, maximum_random_rayleigh=max_local, sharp_case_rayleigh=energy/norm2)

max_johnson_error = 0.0
max_rayleigh_fraction = 0.0
max_cb_error = 0.0
frames_checked = 0
for n in range(4,10):
    for r in range(2,n-1):
        samples = [frame(n,r,rng) for _ in range(6)]
        samples.append(np.eye(n,r))
        for qmat in samples:
            subsets,w,aw = minors_and_johnson(qmat)
            max_cb_error = max(max_cb_error,abs(float(w.sum())-1.0))
            frac = float(w @ aw / (w @ w)) / (r*(n-r))
            max_rayleigh_fraction = max(max_rayleigh_fraction,frac)
            for j,wi,awi in zip(subsets,w,aw):
                if wi > 1e-16:
                    max_johnson_error = max(max_johnson_error,relerr(basis_cost(qmat,j),r+awi/wi))
            frames_checked += 1
record("johnson_identity_and_global_rayleigh", max_johnson_error<2e-7 and max_cb_error<1e-11 and max_rayleigh_fraction<=5/6+1e-12,
       frames=frames_checked, maximum_relative_identity_error=max_johnson_error,
       maximum_cauchy_binet_error=max_cb_error, maximum_rayleigh_divided_by_degree=max_rayleigh_fraction)

max_dual = 0.0
num_dual = 0
for n in range(3,10):
    full = orthogonal(n,rng)
    for r in range(1,n):
        qmat,umat = full[:,:r],full[:,r:]
        for L in [1.,1.3,10.,10000.]:
            for j in combinations(range(n),r):
                ic = tuple(i for i in range(n) if i not in j)
                left,right = basis_cost(qmat,j,L),basis_cost(umat,ic,L)
                max_dual=max(max_dual,abs((left-right)-(2*r-n))/max(1.0,left,right))
                num_dual+=1
record("finite_regularization_complement_duality",max_dual<2e-8,
       comparisons=num_dual,maximum_scaled_error=max_dual)

max_moment = 0.0
max_volume_violation = 0.0
for k in range(1,21):
    for m in range(1,21):
        for L in [1.,1.01,2.,10.,1000.]:
            vals,prob=flat_distribution(k,m,L)
            mean=float(vals @ prob); second=float((vals**2) @ prob)
            max_moment=max(max_moment,relerr((L-1)*second+(k+m)*mean,k*m))
            y=m+(L-1)*mean
            upper=min(m*L,(k+1)*m,m+math.sqrt((L-1)*k*m))
            max_volume_violation=max(max_volume_violation,(y-upper)/max(1.,y,upper))
record("two_level_moment_and_volume_bounds",max_moment<2e-11 and max_volume_violation<2e-11,
       cases=20*20*5,maximum_relative_moment_error=max_moment,maximum_scaled_bound_violation=max_volume_violation)

# Pointwise kernel identity in the augmentation proof.
max_kernel=0.0
for _ in range(100):
    d,q,p=8,2,2
    w=rng.standard_normal((d,d+q)); z=rng.standard_normal((d,p))
    cost=float(np.linalg.norm(np.linalg.lstsq(w,z,rcond=None)[0])**2)
    ker=null_space(np.column_stack([w,z]))
    aa,bb=ker[:d+q,:],ker[d+q:,:]
    gram=aa.T@aa
    minimum=float(np.trace(np.linalg.inv(bb@np.linalg.solve(gram,bb.T))))
    max_kernel=max(max_kernel,relerr(cost,minimum))
record("augmentation_kernel_identity",max_kernel<1e-10,cases=100,maximum_relative_error=max_kernel)

left_samples=[];right_samples=[]
for _ in range(2000):
    d,q,p=8,2,2
    w=rng.standard_normal((d,d+q));z=rng.standard_normal((d,p))
    left_samples.append(float(np.linalg.norm(np.linalg.lstsq(w,z,rcond=None)[0])**2))
    aa=rng.standard_normal((d+q,p+q));bb=rng.standard_normal((p,p+q))
    right_samples.append(float(np.trace(np.linalg.inv(bb@np.linalg.solve(aa.T@aa,bb.T)))))
ks=ks_2samp(left_samples,right_samples)
record("augmentation_distribution_sanity",ks.statistic<0.08,samples_per_side=2000,
       ks_statistic=float(ks.statistic),ks_pvalue=float(ks.pvalue),
       limitation="A fixed-seed distribution sanity check; not a test of exponentially small tails.")

max_repeat_violation=0.0;max_pad_violation=0.0;max_compression_violation=0.0
for _ in range(100):
    r=6;qrepeat=2;n=2*r*qrepeat+3
    g=rng.standard_normal((2*r,r));normalizer=g.T@g
    ev,rot=np.linalg.eigh(normalizer)
    qbase=g@(rot@np.diag(ev**-0.5)@rot.T)
    full=np.vstack([np.repeat(qbase,qrepeat,axis=0)/math.sqrt(qrepeat),np.zeros((3,r))])
    delta=min(.1,float(ev[0])/(2*r))
    j=np.sort(rng.choice(n,r,replace=False))
    raw=np.vstack([g[idx//qrepeat] if idx<2*r*qrepeat else np.zeros(r) for idx in j])
    denom=np.eye(r)/n+(1-1/n)*full[j]@full[j].T
    rhs=(raw@raw.T+np.eye(r))/(2*delta*qrepeat*r)
    max_repeat_violation=max(max_repeat_violation,-float(np.linalg.eigvalsh(rhs-denom)[0]))
    filled=raw.copy()
    for pos,idx in enumerate(j):
        if idx>=2*r*qrepeat: filled[pos]=g[0]
    cost_raw=float(np.trace(np.linalg.inv(raw.T@raw+np.eye(r))))
    cost_filled=float(np.trace(np.linalg.inv(filled.T@filled+np.eye(r))))
    max_pad_violation=max(max_pad_violation,cost_filled-cost_raw)
    # Multiplicity pattern (3,1,1,1) has u=2,h=1 and compression dimension 5.
    mult=g[[0,0,0,1,2,3]]
    comp=null_space(g[[0]])
    compressed=comp.T@(mult.T@mult+np.eye(r))@comp
    fullcost=float(np.trace(np.linalg.inv(mult.T@mult+np.eye(r))))
    compcost=float(np.trace(np.linalg.inv(compressed)))
    max_compression_violation=max(max_compression_violation,compcost-fullcost)
record("repeated_rows_padding_and_compression",max(max_repeat_violation,max_pad_violation,max_compression_violation)<1e-9,
       cases=100,maximum_row_gram_order_violation=max_repeat_violation,
       maximum_padding_violation=max_pad_violation,maximum_compression_violation=max_compression_violation)

max_hollow=0.;max_spectrum=0.;max_group_diag=0.;max_null=0.
for t in range(2,15):
    for _ in range(10):
        alpha=np.exp(rng.uniform(-2,2,t-1))
        u,mat=group_matrix(alpha)
        max_hollow=max(max_hollow,float(np.max(np.abs(np.diag(mat-alpha.sum()*np.outer(u,u))))))
        max_group_diag=max(max_group_diag,float(np.max(np.abs(np.diag(mat)-alpha.sum()*u*u))))
        max_null=max(max_null,float(np.linalg.norm(mat@u)))
        max_spectrum=max(max_spectrum,float(np.max(np.abs(np.linalg.eigvalsh(mat)-np.sort(np.r_[alpha,0.])))))
record("group_hollowing_and_exact_spectrum",max(max_hollow,max_group_diag,max_null,max_spectrum)<2e-10,
       cases=130,maximum_hollow_diagonal_error=max_hollow,maximum_group_diagonal_error=max_group_diag,
       maximum_nullvector_error=max_null,maximum_eigenvalue_error=max_spectrum)

max_cost_error=0.;max_full_spec=0.;max_subspace=0.;max_spread_violation=0.;group_comparisons=0;singular_count=0
for n,k in [(8,2),(9,2),(12,3),(13,3),(17,3)]:
    for _ in range(3):
        sigma=np.exp(rng.uniform(-2,2,n-k))
        obj=grouped_tail(k,sigma,rng)
        tail,u,u0=obj['tail'],obj['U'],obj['U0']
        max_full_spec=max(max_full_spec,float(np.max(np.abs(np.linalg.eigvalsh(tail)-np.sort(np.r_[np.zeros(k),sigma])))))
        max_subspace=max(max_subspace,float(np.linalg.norm(tail@u)),float(np.linalg.norm(u.T@u-np.eye(k))))
        max_spread_violation=max(max_spread_violation,float(np.ptp(obj['sums'])-obj['sigma'][k]))
        for chosen in combinations(range(n),k):
            groups=obj['row_group'][list(chosen)]
            direct=infinite_leading_cost(u,tail,chosen)
            if len(set(groups))<k:
                singular_count+=1
                if math.isfinite(direct): raise AssertionError("repeated group incorrectly has a finite limit")
                continue
            block=u0[groups,:]
            invblock=np.linalg.inv(block)
            core=obj['core_tail'][np.ix_(groups,groups)]+np.diag(obj['sums'][groups])
            predicted=float(np.sum(sigma)+np.trace(invblock@core@invblock.T))
            max_cost_error=max(max_cost_error,relerr(direct,predicted))
            # Independently recover the tail frame and the weighted complementary inverse.
            ev,vec=np.linalg.eigh(tail)
            v=vec[:,k:]
            remaining=[j for j in range(n) if j not in chosen]
            vj=v[remaining,:]
            weighted=float(np.trace(np.diag(ev[k:])@np.linalg.inv(vj.T@vj)))
            max_cost_error=max(max_cost_error,relerr(direct,weighted))
            group_comparisons+=1
record("arbitrary_tail_group_residual_and_spectrum",max_cost_error<2e-7 and max(max_full_spec,max_subspace,max_spread_violation)<2e-9,
       finite_selections=group_comparisons,singular_selections=singular_count,
       maximum_relative_cost_error=max_cost_error,maximum_spectrum_error=max_full_spec,
       maximum_subspace_error=max_subspace,maximum_group_sum_spread_violation=max_spread_violation)

# Deterministic arithmetic used in the Haar and Gaussian bounds.
min_rank_fraction=1.0
for _ in range(10000):
    d=int(rng.integers(16,10000));u=rng.uniform(16,d);v=rng.uniform(16,d)
    p=min(math.floor(u),d//2);q=min(math.floor(v),d//2)
    P,Q=max(p,q),min(p,q)//2
    min_rank_fraction=min(min_rank_fraction,P*Q/(u*v))
net_quarter=.25*math.log(33)+.5*math.log(4*math.e)+.375*math.log(2**-32)
net_half=.5*math.log(33)+.5*math.log(4*math.e)+.25*math.log(2**-32)
haar_exponent=1-(2048+math.log(2))/512
record("explicit_constant_arithmetic",min_rank_fraction>=1/128 and net_quarter < -6 and net_half < -2 and haar_exponent < -3,
       minimum_sampled_rank_product_fraction=min_rank_fraction,
       quarter_aspect_net_exponent=net_quarter,half_aspect_net_exponent=net_half,
       haar_probability_exponent_per_uv=haar_exponent,
       constants={"delta":"2^-32","a":"2^-39","c0":"2^-74","epsilon":"exp(-2048)","c_star":"exp(-2048)*2^-74/16"})

# The target's finite positive-definite identities, independent of frame limits.
max_schur=0.;max_volume=0.;max_minimum_violation=0.;finite_matrices=0
for n in range(3,9):
    for k in range(1,n):
        for _ in range(3):
            lam=np.exp(rng.uniform(-3,3,n))
            ort=orthogonal(n,rng)
            mat=ort@np.diag(lam)@ort.T
            precision=ort@np.diag(1/lam)@ort.T
            elementary=np.zeros(n+1);elementary[0]=1.
            for value in lam:
                for degree in range(n,0,-1):
                    elementary[degree]+=value*elementary[degree-1]
            y=(k+1)*elementary[k+1]/elementary[k]
            numerator=0.;denominator=0.;minimum=math.inf
            for selected in combinations(range(n),k):
                ii=list(selected);jj=[i for i in range(n) if i not in selected]
                principal=mat[np.ix_(ii,ii)]
                direct=float(np.trace(mat)-np.trace(mat[:,ii]@np.linalg.solve(principal,mat[ii,:])))
                complement=float(np.trace(np.linalg.inv(precision[np.ix_(jj,jj)])))
                max_schur=max(max_schur,relerr(direct,complement))
                determinant=float(np.linalg.det(principal))
                numerator+=determinant*direct;denominator+=determinant
                minimum=min(minimum,direct)
            max_volume=max(max_volume,relerr(numerator/denominator,y),relerr(denominator,elementary[k]))
            tau=float(np.sort(lam)[:n-k].sum())
            max_minimum_violation=max(max_minimum_violation,(tau-minimum)/max(1.,tau,minimum),(minimum-y)/max(1.,minimum,y))
            finite_matrices+=1
record("finite_spectrum_schur_volume_and_tail_identities",max_schur<2e-9 and max_volume<2e-9 and max_minimum_violation<2e-9,
       matrices=finite_matrices,maximum_relative_schur_error=max_schur,
       maximum_relative_volume_error=max_volume,maximum_scaled_minimum_violation=max_minimum_violation)

# Pointwise density comparison and beta-integral bound used in the probability proofs.
from scipy.integrate import quad
max_density_violation=0.;max_beta_violation=0.;integrals=0
for d in range(1,9):
    zz=rng.standard_normal((d,d+2));ss=zz@zz.T
    for q in [1,2,5]:
        logratio=(q-1)/2*(np.linalg.slogdet(ss)[1]-np.linalg.slogdet(ss+np.eye(d))[1])
        max_density_violation=max(max_density_violation,float(logratio))
for d in [16,32,80]:
    for ell in [2,4,6]:
        D=d-2;aa=ell/2;bb=(D-ell)/2
        logbeta=gammaln(aa)+gammaln(bb)-gammaln(aa+bb)
        for theta in [1.,2.,5.]:
            def integrand(z):
                if z<=0 or z>=1: return 0.
                return math.exp(-theta*d*z+(aa-1)*math.log(z)+(bb-1)*math.log1p(-z)-logbeta)
            value,error=quad(integrand,0.,1.,epsabs=1e-13,epsrel=1e-11)
            upper=(2*theta)**(-aa)
            max_beta_violation=max(max_beta_violation,(value-upper)/max(1.,value,upper))
            integrals+=1
record("wishart_density_shift_and_haar_beta_integral",max_density_violation<1e-12 and max_beta_violation<1e-10,
       beta_integrals=integrals,maximum_log_density_ratio_violation=max_density_violation,
       maximum_scaled_beta_bound_violation=max_beta_violation)

output={"seed":SEED,"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,
        "sympy":sp.__version__,"elapsed_seconds":time.time()-started,
        "all_checks_passed":all(item['passed'] for item in checks.values()),"checks":checks,
        "scope":"Numerical and symbolic checks of identities and finite examples; not a complete proof, a global optimizer, or proof-assistant verification."}
path=Path(__file__).resolve().parents[1]/'results'/'continuation_verification.json'
path.parent.mkdir(parents=True,exist_ok=True)
path.write_text(json.dumps(output,indent=2)+'\n')
print(path,flush=True)
if not output['all_checks_passed']: raise SystemExit(1)
