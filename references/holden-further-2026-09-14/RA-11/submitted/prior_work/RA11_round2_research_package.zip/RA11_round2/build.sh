#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
command -v pdflatex >/dev/null || { echo "pdflatex is required." >&2; exit 1; }
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
mkdir -p "$ROOT/results"
: > "$ROOT/results/manuscript_build.log"
for pass in 1 2 3; do
  if ! pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
      -output-directory="$BUILD" "$ROOT/manuscript/ra11_linear_accuracy.tex" \
      > "$BUILD/pass${pass}.txt" 2>&1; then
    cat "$BUILD/pass${pass}.txt" >&2
    exit 1
  fi
  printf '\n--- PASS %s ---\n' "$pass" >> "$ROOT/results/manuscript_build.log"
  cat "$BUILD/pass${pass}.txt" >> "$ROOT/results/manuscript_build.log"
done
cp "$BUILD/ra11_linear_accuracy.pdf" "$ROOT/manuscript/ra11_linear_accuracy.pdf"
if grep -E 'Overfull|Underfull|LaTeX Warning|Package .* Warning' "$BUILD/pass3.txt"; then
  echo "Review the final-pass warnings above." >&2
fi
echo "Built manuscript/ra11_linear_accuracy.pdf"
