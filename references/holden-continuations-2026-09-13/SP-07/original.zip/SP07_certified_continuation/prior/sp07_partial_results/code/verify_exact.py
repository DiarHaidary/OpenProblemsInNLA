"""Exact symbolic certificates used in the SP-07 report.

Run from any directory:
    python path/to/code/verify_exact.py --output verification.json
All asserted matrix identities are evaluated over exact algebraic numbers.
This verifies the displayed certificates, not the unresolved universal claim.
"""
from __future__ import annotations
import argparse
from itertools import permutations
import json
from pathlib import Path
import sympy as s


def require_zero(matrix: s.Matrix, label: str) -> None:
    if any(s.simplify(z) != 0 for z in matrix):
        raise RuntimeError(f'Exact identity failed: {label}')


def main() -> dict:
    i, root = s.I, s.sqrt
    alpha = [s.Integer(1), (4 + 5 * root(3) * i) / 13,
             (-1 + 2 * root(3) * i) / 13]
    A = s.diag(*alpha)
    v = s.Matrix([root(10) / 4, s.Rational(1, 2), root(2) / 4])
    U = s.eye(3) - 2 * v * v.T
    B = -U * A * U
    M = A * U + U * A
    w = s.Matrix([root(10), 1 - root(3) * i, -6 * root(2) + root(6) * i])
    require_zero(v.T * v - s.ones(1, 1), 'v is a unit vector')
    require_zero(U.T * U - s.eye(3), 'orthogonality')
    require_zero(A * A.H - A.H * A, 'normality of A')
    require_zero(B * B.H - B.H * B, 'normality of B')
    require_zero((A - B) * U - M, 'norm-preserving factorization')
    require_zero(M.H * M - (108 * s.eye(3) - w * w.H) / 52,
                 'rank-one Gram certificate')
    if s.simplify((w.H * w)[0]) != 92:
        raise RuntimeError('The Gram certificate vector has the wrong norm.')
    costs = s.Matrix(3, 3, lambda j, k: s.simplify(
        (alpha[j] + alpha[k]) * s.conjugate(alpha[j] + alpha[k])))
    expected = s.Matrix([[52, 28, 12], [28, 28, 12], [12, 12, 4]]) / 13
    require_zero(costs - expected, 'squared spectral distances')
    matching_values = [max(costs[j, p[j]] for j in range(3))
                       for p in permutations(range(3))]
    d_squared = min(matching_values)
    if d_squared != s.Rational(28, 13):
        raise RuntimeError('Incorrect exact bottleneck distance.')
    lam = s.Symbol('lambda')
    gram_poly = s.factor((M.H * M).charpoly(lam).as_expr())
    if s.simplify(gram_poly - (lam - s.Rational(27, 13))**2 *
                  (lam - s.Rational(4, 13))) != 0:
        raise RuntimeError('Incorrect Gram characteristic polynomial.')

    P, Q = s.diag(-1, 1), s.diag(0, 2)
    Y = s.Matrix([[1, 1], [-1, 1]]) / root(2)
    Z = -s.Matrix([[1, s.Rational(1, 3)], [1, 1]]) / root(2)
    require_zero(P * Z - Z * Q - Y, 'Sylvester counterexample')
    require_zero(Y.H * Y - s.eye(2), 'unitarity of Y')
    zpoly = s.factor((Z.H * Z).charpoly(lam).as_expr())
    zlarge = (7 + 2 * root(10)) / 9
    zsmall = (7 - 2 * root(10)) / 9
    if s.simplify(zpoly - (lam - zlarge) * (lam - zsmall)) != 0:
        raise RuntimeError('Incorrect singular values for Schur example.')
    return {
        'status': 'All exact certificate checks passed; the global constant is not determined.',
        'arithmetic': 'SymPy exact rational and algebraic-number expressions',
        'sympy_version': s.__version__,
        'krause': {
            'alpha': [str(z) for z in alpha],
            'v': [str(z) for z in v],
            'gram_certificate_vector': [str(z) for z in w],
            'gram_certificate': 'M^* M = (108 I - w w^*) / 52; w^*w = 92',
            'distance_squared': str(d_squared),
            'norm_squared': '27/13',
            'ratio_squared': '28/27',
            'ratio_decimal': str(s.N(root(s.Rational(28, 27)), 40)),
            'squared_singular_values': ['27/13', '27/13', '4/13'],
            'permutation_squared_bottlenecks': [str(x) for x in matching_values],
            'gram_characteristic_polynomial': str(gram_poly),
        },
        'schur_counterexample': {
            'separation': '1', 'norm_of_PZ_minus_ZQ': '1',
            'norm_Z_squared': str(zlarge),
            'gram_characteristic_polynomial': str(zpoly),
        },
        'not_verified': ['C_normal = sqrt(28/27)', 'Any sharp universal upper bound'],
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = main()
    text = json.dumps(result, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + '\n', encoding='utf-8')
    print(text)
