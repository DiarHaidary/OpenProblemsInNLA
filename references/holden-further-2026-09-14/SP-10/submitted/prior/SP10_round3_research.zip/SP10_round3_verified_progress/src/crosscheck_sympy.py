"""Second exact implementation; intentionally imports no local matrix code."""
from pathlib import Path
import json
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]

def main():
    checked=[]
    for name in ('layered_pairs.jsonl','cubic_tree_pairs.jsonl','J9_rank_pair.json'):
        p=ROOT/'certificates'/name
        records=[json.loads(line) for line in p.read_text().splitlines() if line.strip()] if p.suffix=='.jsonl' else [json.loads(p.read_text())]
        for record in records:
            n=record['n'];E={tuple(sorted(e)) for e in record['edges']};ranks=[]
            for side,key in enumerate(('gram_G','gram_complement')):
                values=record[key]
                assert len(values)==n and all(values) and len({len(row) for row in values})==1
                assert all(type(x) is int or isinstance(x,str) for row in values for x in row)
                M=sp.Matrix([[sp.Rational(x) for x in row] for row in values])
                for i in range(n):
                    assert any(M[i,k]!=0 for k in range(M.cols))
                    for j in range(i+1,n):
                        product=sum(M[i,k]*M[j,k] for k in range(M.cols))
                        expected=((i,j) in E) if side==0 else ((i,j) not in E)
                        assert bool(product!=0)==expected,(record['id'],side,i,j)
                ranks.append(int(M.to_DM().rank()))
            assert sum(ranks)<=n+2
            checked.append({'id':record['id'],'ranks':ranks,'n':n})
    result={'verified_rank_pairs':len(checked),'implementation':'SymPy exact DomainMatrix rank','sympy_version':sp.__version__,'records':checked}
    (ROOT/'results'/'sympy_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
