"""Verify a rational normal-pair lower-bound certificate, using only Python's
standard library. The spectral norm is bounded by exact positive-definiteness;
no numerical eigensolver or tolerance is used in any proof check.
"""
from __future__ import annotations
import argparse,json,hashlib,time
from fractions import Fraction as F
from pathlib import Path
from check_five_stdlib import G

def inv(A):
    n=len(A);B=[row.copy()+[F(i==j) for j in range(n)] for i,row in enumerate(A)]
    for k in range(n):
        p=next((j for j in range(k,n) if B[j][k]),None)
        if p is None:raise ValueError('Singular matrix')
        B[k],B[p]=B[p],B[k];s=B[k][k];B[k]=[x/s for x in B[k]]
        for i in range(n):
            if i!=k:
                s=B[i][k]
                if s:B[i]=[x-s*y for x,y in zip(B[i],B[k])]
    return [row[n:] for row in B]

def matching_at(costs,threshold):
    n=len(costs);owner=[-1]*n
    def visit(i,seen):
        for j in range(n):
            if not seen[j] and costs[i][j]<=threshold:
                seen[j]=True
                if owner[j]<0 or visit(owner[j],seen):owner[j]=i;return True
        return False
    for i in range(n):
        if not visit(i,[False]*n):return None
    p=[-1]*n
    for j,i in enumerate(owner):p[i]=j
    return p

def verify(input_path,output_path):
    start=time.monotonic();raw=input_path.read_bytes();data=json.loads(raw)
    z=[G(F(a),F(b)) for a,b in data['z']];n=len(z);X=[[F(x) for x in row] for row in data['X']];r=len(X[0]);assert len(X)==n-r
    Y=[[F(i==j) for j in range(r)] for i in range(r)]+X
    T=[[sum(Y[k][i]*Y[k][j] for k in range(n)) for j in range(r)] for i in range(r)];Ti=inv(T)
    Z=[[sum(Y[i][a]*Ti[a][b] for a in range(r)) for b in range(r)] for i in range(n)]
    P=[[sum(Z[i][a]*Y[j][a] for a in range(r)) for j in range(n)] for i in range(n)]
    S=[[F(i==j)-2*P[i][j] for j in range(n)] for i in range(n)]
    assert all(S[i][j]==S[j][i] for i in range(n) for j in range(n))
    assert all(sum(S[i][k]*S[k][j] for k in range(n))==F(i==j) for i in range(n) for j in range(n))
    M=[[z[i]*F(i==j)+sum((S[i][k]*z[k]*S[k][j] for k in range(n)),G()) for j in range(n)] for i in range(n)]
    t=F(data['norm_upper_bound']);lower=F(data['ratio_lower_bound'])
    H=[[G(t*t*F(i==j))-sum((M[k][i].conj()*M[k][j] for k in range(n)),G()) for j in range(n)] for i in range(n)]
    assert all(H[i][j]==H[j][i].conj() for i in range(n) for j in range(n))
    L=[[G(F(i==j)) for j in range(n)] for i in range(n)];piv=[]
    for k in range(n):
        dk=H[k][k]-sum((L[k][j]*piv[j]*L[k][j].conj() for j in range(k)),G())
        assert dk.b==0 and dk.a>0, f'Non-positive pivot {k}'
        piv.append(dk.a)
        for i in range(k+1,n):L[i][k]=(H[i][k]-sum((L[i][j]*piv[j]*L[k][j].conj() for j in range(k)),G()))/dk
    assert all(H[i][j]==sum((L[i][k]*piv[k]*L[j][k].conj() for k in range(n)),G()) for i in range(n) for j in range(n))
    I=data['I'];J=data['J'];assert len(set(I))==len(I) and len(set(J))==len(J);assert len(I)+len(J)>n
    costs=[[(z[i]+z[j]).abs2() for j in range(n)] for i in range(n)];gap=min(costs[i][j] for i in I for j in J)
    assert gap>lower*lower*t*t
    thresholds=sorted({x for row in costs for x in row});lo=0;hi=len(thresholds)-1
    while lo<hi:
        mid=(lo+hi)//2
        if matching_at(costs,thresholds[mid]) is None:lo=mid+1
        else:hi=mid
    distance=thresholds[lo];perm=matching_at(costs,distance);assert perm is not None;assert distance>=gap
    scale=10**18;intervals=[]
    for p in piv:
        num=p.numerator*scale//p.denominator;assert F(num,scale)<p<F(num+1,scale)
        intervals.append({'lower_numerator':str(num),'upper_numerator':str(num+1),'denominator':str(scale)})
    result={'status':'PASSED: exact lower-bound certificate, not a full SP-07 solution.','dimension':n,'rank':r,'input_sha256':hashlib.sha256(raw).hexdigest(),'strict_norm_upper_bound':str(t),'strict_ratio_lower_bound':str(lower),'strict_ratio_lower_bound_decimal':data['ratio_lower_bound'],'orthogonality_passed':True,'ldl_reconstruction_passed':True,'all_pivots_strictly_positive':True,'pivot_intervals':intervals,'exact_pivots':[str(p) for p in piv],'hall_gap_squared':str(gap),'exact_matching_squared':str(distance),'matching':perm,'I':I,'J':J,'elapsed_seconds':time.monotonic()-start}
    output_path.parent.mkdir(parents=True,exist_ok=True);output_path.write_text(json.dumps(result,indent=2)+'\n')
    print(f'Exact certificate PASSED: dimension {n}; C_normal > {data["ratio_lower_bound"]}; seconds {time.monotonic()-start:.3f}',flush=True)
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args();verify(a.input,a.output)
