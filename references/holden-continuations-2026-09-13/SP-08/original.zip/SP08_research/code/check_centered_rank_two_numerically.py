#!/usr/bin/env python3
"""Numerical audits only; these tests are not a substitute for the proofs."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(20260913)
def compressed(p,q,P,Q,a):
 c=(1+a)/2;r=(1-a)/2;R0=max(0,p+q-P*P/p-Q*Q/q)
 v=np.array([P/np.sqrt(p),Q/np.sqrt(q),np.sqrt(R0)])
 base=np.array([[p,np.sqrt(p*q),0],[np.sqrt(p*q),-q,0],[0,0,0]],float)
 return np.linalg.eigvalsh(r*base+c*np.outer(v,v))
def candidate(n,a):
 d=1-a;target=n/(a+3)
 ks={max(1,min(n-1,int(np.floor(target)))),max(1,min(n-1,int(np.ceil(target))))}
 return max(n*n+d*(2*n*k-(a+3)*k*k) for k in ks)
start=time.monotonic();count=0;worst=0.0;mono=0;negative_bound=0
for n in range(2,15):
 for p in range(1,n):
  q=n-p
  for P in range(-p,p+1,2):
   for Q in range(-q,q+1,2):
    for a in [-1.,-.999,-.8,-.4,0.,.25,.75,.999]:
     eig=compressed(p,q,P,Q,a);val=(eig[-1]-eig[0])**2;upper=candidate(n,a)
     err=val-upper;worst=max(worst,err);assert err<=1e-9*max(1,upper),(n,p,P,Q,a,val,upper)
     count+=1
for _ in range(50000):
 p=float(rng.uniform(.001,500));q=float(rng.uniform(.001,500));P=float(rng.uniform(0,p));Q=float(rng.uniform(0,q));a=float(rng.uniform(-.99999,.99999))
 eig=compressed(p,q,P,Q,a);P2=float(rng.uniform(P,p));eig2=compressed(p,q,P2,Q,a)
 assert eig2[-1]-eig2[0]>=eig[-1]-eig[0]-1e-9*(p+q)
 mono+=1
 g=(1-a)/2*q*P/(P+Q)
 assert -eig[0]>=g-1e-9*(p+q)
 negative_bound+=1
report={'status':'PASS','warning':'Floating-point sanity checks, not mathematical proof','integer_endpoint_cases':count,'continuous_monotonicity_cases':mono,'negative_eigenvalue_bound_cases':negative_bound,'largest_candidate_excess':worst,'seconds':time.monotonic()-start}
(ROOT/'checks'/'centered_rank_two_numerical_checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
