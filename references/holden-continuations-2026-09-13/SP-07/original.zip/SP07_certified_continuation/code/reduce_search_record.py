"""Numerically identify nearly decoupled blocks and re-optimize a reflection record.
The thresholded block identification is a search heuristic, not a proof step.
"""
import argparse,json
from pathlib import Path
import numpy as np
from scipy.linalg import qr
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from search_reflections import Model

def reduce_record(input_path,output_path,threshold=1e-3):
 rec=json.loads(input_path.read_text());n=rec['n'];zall=np.array(rec['z'])@np.array([1,1j]);Pall=np.array(rec['P_real'])+1j*np.array(rec['P_imag']);count,labels=connected_components(csr_matrix(abs(Pall)>threshold),directed=False)
 records=[]
 for label in range(count):
  inds=np.flatnonzero(labels==label);m=len(inds);Iold=[i for i in rec['I'] if i in inds]
  if m<3 or m%2==0 or len(Iold)*2<=m:continue
  P=Pall[np.ix_(inds,inds)];lam,V=np.linalg.eigh(P);rank=int(np.sum(lam>.5))
  if rank>(m-1)//2:W=V[:,lam<.5]
  else:W=V[:,lam>.5]
  r=W.shape[1]
  if r!=(m-1)//2:continue
  _,_,perm=qr(W.conj().T,pivoting=True);W=W[perm];P=W@W.conj().T;z=zall[inds[perm]]
  z=z*np.exp(-1j*np.angle(z[0]));I=[i for i,j in enumerate(inds[perm]) if j in rec['I']]
  X=P[r:,:r]@np.linalg.inv(P[:r,:r]);cplx=float(np.max(abs(X.imag)))>1e-8;model=Model(m,r,I,I,complex_chart=cplx)
  x=np.zeros(model.nv);x[0]=z[0].real
  for i in range(1,m):x[2*i-1:2*i+1]=[z[i].real,z[i].imag]
  x[model.ns:model.ns+model.nx]=X.real.ravel()
  if cplx:x[model.ns+model.nx:-1]=X.imag.ravel()
  x[-1]=min(abs(z[np.array(I),None]+z[None,np.array(I)]).ravel())
  out=model.optimize(x,maxiter=500,rhos=(250000.,2e6,2e7,2e8));rr=model.record(out.x);rr.update(success=bool(out.success),message=str(out.message),source=str(input_path.name),retained_indices=inds[perm].tolist(),component_threshold=threshold);records.append(rr)
  print('component',inds.tolist(),'dimension',m,'rank',r,'ratio',rr['ratio'],flush=True)
 if not records:raise ValueError('No eligible odd-dimensional component found.')
 best=max(records,key=lambda x:x['ratio']);output_path.write_text(json.dumps(best,indent=2)+'\n');return best
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('output',type=Path);p.add_argument('--threshold',type=float,default=1e-3);a=p.parse_args();reduce_record(a.input,a.output,a.threshold)
