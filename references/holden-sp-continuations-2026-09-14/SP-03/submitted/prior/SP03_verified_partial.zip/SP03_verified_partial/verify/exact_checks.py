"""Deterministic exact-arithmetic checks accompanying the symbolic proofs.
Finite examples check implementation and algebra; they are not all-rank proofs.
Run: python verify/exact_checks.py
"""
from pathlib import Path
import json
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]

def forms(m):
    I = sp.eye(m); Z = sp.zeros(m)
    return Z.row_join(I).col_join((-I).row_join(Z)), Z.row_join(I).col_join(I.row_join(Z))

def sbasis(m):
    result=[]
    for i in range(m):
        for j in range(i,m):
            E=sp.zeros(m); E[i,j]=E[j,i]=1; result.append(E)
    return result

def vec(M):
    return sp.Matrix([M[i,j] for i in range(M.rows) for j in range(M.cols)])

def blocks(U,m):return U[:m,:m],U[:m,m:],U[m:,:m],U[m:,m:]

def coefficients(A,U,E):
    m=A.rows; Ua,Ub,Uc,Ud=blocks(U,m)
    L=sp.Matrix([[2*sp.trace(A*e*A.T*f)-sp.trace(f*A*e*Ua.T) for f in E] for e in E])
    b=sp.Matrix([sp.trace(A*e*Uc.T) for e in E])
    c=sp.Matrix([sp.trace(e*A*Ub.T) for e in E])
    h=-sp.trace(A*Ud.T)-sp.trace(Ua*A.inv())
    return L,b,c,h

def check_case(m):
    J,Q=forms(m); I=sp.eye(m); E=sbasis(m); k=len(E)
    A=sp.diag(*range(2,m+2))
    for i in range(m-1):A[i,i+1]=1
    S=sp.Matrix(m,m,lambda i,j:sp.Rational(i+j+1,7))
    T=sp.Matrix(m,m,lambda i,j:sp.Rational((i+1)*(j+1),11))
    B=A*S; C=T*A; D=T*A*S+A.inv().T
    X=A.row_join(B).col_join(C.row_join(D))
    K=sp.zeros(2*m)
    for i in range(2*m):
        for j in range(i+1,2*m):K[i,j]=sp.Rational(i+2*j+1,101); K[j,i]=-K[i,j]
    U=X+Q*J*X*K*Q
    assert X.T*J*X==J
    Ua,Ub,Uc,Ud=blocks(U,m)
    L,b,c,h=coefficients(A,U,E)
    assert L.det()!=0
    t=L.inv()*b; s=L.T.inv()*c
    SS=sum((s[i]*E[i] for i in range(k)),sp.zeros(m))
    TT=sum((t[i]*E[i] for i in range(k)),sp.zeros(m))
    assert SS==S and TT==T
    Y=A.inv().T; W=Y*Ua.T*Y
    g=T*(4*A-Ua)*S-Uc*S-T*Ub-Ud+W
    assert g==sp.zeros(m)
    F=(2*sp.trace(A*S*A.T*T)-sp.trace(T*A*S*Ua.T)
       -sp.trace(A*Ud.T)-sp.trace(A.inv().T*Ua.T)
       -sp.trace(A*S*Uc.T)-sp.trace(T*A*Ub.T))
    assert F==(s.T*L*t-b.T*s-c.T*t)[0]+h
    assert F==h-(c.T*L.inv()*b)[0]
    distance=sp.trace(Q*(X-U).T*Q*(X-U))
    assert distance==2*m+sp.trace(Q*U.T*Q*U)+2*F
    recovered_K=X.inv()*Q*J*(U-X)*Q
    assert recovered_K==K and K+K.T==sp.zeros(2*m)
    # A separate nonspecial data matrix checks the Hessian through exact
    # differentiated linear systems, rather than finite differences.
    hessian_checks=0
    if m<=3:
        Vdata=sp.Matrix(2*m,2*m,lambda i,j:sp.Rational((i+1)**2+3*j+1,13))
        va,vb,vc,vd=blocks(Vdata,m)
        LL,bb,cc,hh=coefficients(A,Vdata,E)
        assert LL.det()!=0
        Li=LL.inv();tt=Li*bb;ss=Li.T*cc
        SS=sum((ss[i]*E[i] for i in range(k)),sp.zeros(m))
        TT=sum((tt[i]*E[i] for i in range(k)),sp.zeros(m))
        V=4*A-va;WW=Y*va.T*Y
        HS=sp.Matrix.hstack(*[vec((TT*V-vc)*e) for e in E])
        HT=sp.Matrix.hstack(*[vec(e*(V*SS-vb)) for e in E])
        H0=sp.zeros(m*m)
        for j in range(m*m):
            dA=sp.zeros(m);dA[j//m,j%m]=1
            H0[:,j]=vec(4*TT*dA*SS-Y*dA.T*WW-WW*dA.T*Y)
        R=HT*Li*HS.T; Hred=H0-R-R.T
        assert Hred==Hred.T
        for j in range(m*m):
            dA=sp.zeros(m);dA[j//m,j%m]=1
            dL=sp.Matrix([[2*sp.trace(dA*e*A.T*f+A*e*dA.T*f)-sp.trace(f*dA*e*va.T) for f in E] for e in E])
            db=sp.Matrix([sp.trace(dA*e*vc.T) for e in E])
            dc=sp.Matrix([sp.trace(e*dA*vb.T) for e in E])
            dt=Li*(db-dL*tt);ds=Li.T*(dc-dL.T*ss)
            dT=sum((dt[i]*E[i] for i in range(k)),sp.zeros(m))
            dS=sum((ds[i]*E[i] for i in range(k)),sp.zeros(m))
            dg=dT*V*SS+4*TT*dA*SS+TT*V*dS-vc*dS-dT*vb-Y*dA.T*WW-WW*dA.T*Y
            assert Hred[:,j]==vec(dg)
            hessian_checks+=1
    return {'m':m,'symplectic_and_normal_identities':True,'reduction_and_objective_identities':True,'exact_hessian_directions_checked':hessian_checks,'det_L_at_critical_witness':str(L.det())}

def main():
    cases=[check_case(m) for m in range(1,5)]
    t=sp.symbols('t');q=t**4-8*t**2-13*t-5
    assert sp.discriminant(q,t)==-16075
    assert q.subs(t,1)==-25 and q.subs(t,-1)==1
    degrees=[]
    base=[1,4,24]
    for m in range(1,7):
        delta=int(sp.det(sp.Matrix([[sp.binomial(2*i+2*j-2,2*i-1) for j in range(1,m+1)] for i in range(1,m+1)])))
        lower=544**(m//3)*base[m%3]
        degrees.append({'m':m,'ordinary_degree':delta,'proved_upper_bound':2**m*delta,'lower_bound_using_published_D3':lower,'lower_bound_using_rank_one_only':4**m,'conjectured_ED_degree':2**(m*m)+2**(2*m-1)})
    report={'status':'PASS','warning':'Finite checks do not prove the conjecture or replace the written all-rank arguments.','exact_cases':cases,'rank_one_quartic':str(q),'rank_one_discriminant':-16075,'bounds':degrees}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/'exact_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
