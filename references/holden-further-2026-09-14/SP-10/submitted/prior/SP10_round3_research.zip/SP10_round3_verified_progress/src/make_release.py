"""Package only after required exact checks, PDF existence, and provenance checks."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,re,datetime
ROOT=Path(__file__).resolve().parents[1]
status=json.loads((ROOT/'results'/'execution_status.json').read_text())
assert len(status)==5 and all(s['completed'] and s['returncode']==0 for s in status),status
exact=json.loads((ROOT/'results'/'exact_verification.json').read_text())
second=json.loads((ROOT/'results'/'sympy_verification.json').read_text())
env=json.loads((ROOT/'results'/'environment.json').read_text())
assert exact['verified_rank_pairs']==second['verified_rank_pairs']==18
assert exact['verified_degeneracy_pairs']==4
assert env['unit_test_count']==24
assert {r['id']:r['ranks'] for r in exact['rank_pairs']}=={r['id']:r['ranks'] for r in second['records']}
for name in ('SP10_partial_results.zip','SP10_round2_results.zip'):
    assert (ROOT/'prior'/name).read_bytes()==(ROOT.parent/name).read_bytes()
pdf=ROOT/'manuscript'/'report.pdf';assert pdf.is_file() and pdf.stat().st_size>10000
import fitz
D=fitz.open(pdf);assert len(D)>=8
bad=[]
for pi,p in enumerate(D):
    for w in p.get_text('words'):
        if w[0]<-0.5 or w[1]<-0.5 or w[2]>p.rect.width+0.5 or w[3]>p.rect.height+0.5:
            bad.append({'page':pi+1,'word':w[4],'bbox':list(w[:4])})
assert not bad, bad
text='\n'.join(p.get_text() for p in D)
assert 'singleton' in text.lower() and 'partial' in text.lower() and 'nontrivial' in text.lower()
preview=ROOT.parent/'work3'/'preview';preview.mkdir(parents=True,exist_ok=True)
for i,p in enumerate(D):p.get_pixmap(matrix=fitz.Matrix(1.15,1.15)).save(preview/f'page-{i+1:02d}.png')
from PIL import Image,ImageOps,ImageDraw
thumbs=[]
for i in range(len(D)):
    im=Image.open(preview/f'page-{i+1:02d}.png').convert('RGB');im.thumbnail((300,420))
    tile=Image.new('RGB',(320,455),'white');tile.paste(im,((320-im.width)//2,10));ImageDraw.Draw(tile).text((12,432),f'Page {i+1}',fill='black');thumbs.append(tile)
cols=4;rows=(len(thumbs)+cols-1)//cols
sheet=Image.new('RGB',(cols*320,rows*455),(220,220,220))
for i,im in enumerate(thumbs):sheet.paste(im,((i%cols)*320,(i//cols)*455))
sheet.save(preview/'contact_sheet.png')
log=(ROOT/'results'/'latex_pass2.log').read_text(errors='replace')
qa={'pdf_pages':len(D),'outside_page_words':bad,'latex_overfull_messages':re.findall(r'Overfull[^\n]*',log),
    'rendered_pages':len(D),'rendered_preview_location':'Not included in archive; local render QA only'}
(ROOT/'results'/'pdf_qa.json').write_text(json.dumps(qa,indent=2)+'\n')
release={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PARTIAL','rank_pair_certificates':18,
         'degeneracy_pair_certificates':4,'unit_tests':24,'pdf_pages':len(D),'prior_archives_preserved_byte_for_byte':True,
         'full_solution':False}
(ROOT/'results'/'release_summary.json').write_text(json.dumps(release,indent=2)+'\n')
# Do not deliver interpreter caches, transient TeX files, or standalone fonts.
def delivered(p):
    return p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.aux','.out','.log','.ttf','.otf','.woff','.woff2'} or (p.is_file() and p.parent==ROOT/'results' and p.suffix=='.log')
files=sorted(p for p in ROOT.rglob('*') if delivered(p) and p.name!='SHA256SUMS')
lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT)) for p in files]
(ROOT/'SHA256SUMS').write_text('\n'.join(lines)+'\n');files.append(ROOT/'SHA256SUMS')
archive=ROOT.parent/(ROOT.name+'.zip')
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,arcname=str(Path(ROOT.name)/p.relative_to(ROOT)))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for name in z.namelist():assert not name.endswith(('.ttf','.otf','.woff','.woff2'))
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'pdf':str(pdf),**release},indent=2))
