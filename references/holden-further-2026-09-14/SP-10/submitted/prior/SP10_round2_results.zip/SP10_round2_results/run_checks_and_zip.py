from pathlib import Path
import subprocess, sys, json, hashlib, zipfile
R=Path(__file__).resolve().parent
commands=[
 [sys.executable,'-m','unittest','discover','-s','tests','-v'],
 [sys.executable,'src/exact_families.py','generate','certificates'],
 [sys.executable,'src/exact_families.py','verify','certificates/halfgraphs.jsonl','certificates/substitutions.jsonl'],
]
status=[]
with (R/'EXECUTION_LOG.txt').open('w') as log:
 for cmd in commands:
  log.write('\nCOMMAND: '+' '.join(cmd)+'\n'); log.flush()
  try:
   p=subprocess.run(cmd,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=40)
   log.write(p.stdout); log.flush()
   status.append({'command':cmd,'returncode':p.returncode,'completed':True})
   print(p.stdout,flush=True)
  except subprocess.TimeoutExpired as e:
   text=e.stdout or b''
   if isinstance(text,bytes): text=text.decode(errors='replace')
   log.write(text+'\nTIMEOUT: this command did not complete.\n'); log.flush()
   status.append({'command':cmd,'completed':False,'reason':'timeout'})
  except Exception as e:
   log.write(repr(e)+'\n'); log.flush()
   status.append({'command':cmd,'completed':False,'reason':repr(e)})
(R/'execution_status.json').write_text(json.dumps(status,indent=2))
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS.txt']
(R/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R)) for p in sorted(files))+'\n')
out=R.parent/'SP10_round2_results.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(R.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   z.write(p,arcname=str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert 'SP10_round2_results/REPORT.md' in z.namelist()
assert out.is_file() and out.stat().st_size>0
print('ARTIFACT_CONFIRMED',out,'BYTES',out.stat().st_size,'SHA256',hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
print('EXECUTION_STATUS',json.dumps(status),flush=True)
