"""Execute exact identities and labelled numerical consistency checks.

Run from the package root: python code/validate.py
No numerical result in this program certifies an asymptotic or universal claim.
"""
from __future__ import annotations
import csv
import json
import platform
import sys
from pathlib import Path
import numpy as np
import scipy
from scipy.linalg import svdvals, eigvals
import sympy as sp
import mpmath as mp
from boundary import matrix, first_inverse_row, row_increment, boundary_block, unimodular_certificate_diagnostic

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
checks: list[dict] = []


def check(name: str, passed: bool, category: str, **details) -> None:
    checks.append(dict(name=name, passed=bool(passed), category=category, **details))


def close(name: str, lhs, rhs, tol: float = 1e-10, category="floating-point consistency"):
    err = float(np.linalg.norm(np.asarray(lhs, dtype=complex) - np.asarray(rhs, dtype=complex)))
    scale = max(1.0, float(np.linalg.norm(np.asarray(rhs, dtype=complex))))
    check(name, err <= tol * scale, category, error=err, tolerance=tol * scale)


def sym_matrix(c, n, shift=0):
    return sp.Matrix(n, n, lambda i,j: c.get(i-j-shift, sp.S.Zero))


I = sp.I
c = {0: sp.Integer(4), 1: sp.Rational(1,5)+I/7,
     -1: -sp.Rational(1,6)+I/9, 2: I/11, -3: sp.Rational(1,13)}
# Small exact sizes are intentional: exact rational inversion grows expensive.
for n in range(1, 7):
    C = sym_matrix(c, n)
    D = sym_matrix(c, n+1)
    Ci, Di = C.inv(), D.inv()
    y, z = Ci[0, :], Di[0, :]
    k = Di[0, n]
    actual = z - y.row_join(sp.zeros(1,1))
    predicted = k * (-D[n, :n] * Ci).row_join(sp.ones(1,1))
    residual = actual - predicted
    check(f"exact bordering row n={n}", all(sp.cancel(x)==0 for x in residual), "exact symbolic")
    A = sym_matrix(c, n, shift=1)
    check(f"exact cofactor n={n}", sp.cancel(A.det()-(-1)**n*D.det()*k)==0, "exact symbolic")
    check(f"exact reflection n={n}", D.inv()[n,0] == sym_matrix({-k:v for k,v in c.items()},n+1).inv()[0,n], "exact symbolic")

# Jacobi complementary-minor formula, including a genuinely nontrivial p=3 block.
real_c = {0:sp.Integer(3), 1:sp.Rational(1,4), -1:sp.Rational(-1,5),
          2:sp.Rational(1,7), -2:sp.Rational(1,9), -3:sp.Rational(1,11)}
for p in (1,2,3):
    for n in (2,3,5):
        C = sym_matrix(real_c, n+p)
        K = C.inv()[:p, n:n+p]
        A = sym_matrix(real_c,n,shift=p)
        check(f"exact Jacobi n={n} p={p}", sp.cancel(A.det()-(-1)**(n*p)*C.det()*K.det())==0, "exact symbolic")

r=sp.Rational(1,3)
for n in (1,2,3,5,8,12):
    C = sym_matrix({0:1,-1:-r},n+1)
    k=C.inv()[0,n]
    check(f"geometric corner n={n}", k==r**n, "exact symbolic")
    A=sym_matrix({1:1,0:-r},n)
    check(f"shifted nilpotent determinant n={n}", A.det()==(-r)**n, "exact symbolic")
    # A reciprocal linear symbol has finitely supported inverse rows instead.
    D=sp.Matrix(n+1,n+1,lambda i,j: r**(j-i) if j>=i else 0)
    wanted=-r if n==1 else 0
    check(f"reciprocal-symbol corner n={n}", D.inv()[0,n]==wanted, "exact symbolic")

# Exact congruence zeros are checked on a rational finite proxy, not on an
# artificially truncated proxy identified with the smooth infinite symbol.
proxy={0:sp.Integer(1), 3:sp.Rational(1,100), -3:sp.Rational(1,100),
       6:sp.Rational(1,300), -6:sp.Rational(1,300)}
for n in range(1,13):
    C=sym_matrix(proxy,n+1)
    if n%3:
        check(f"proxy congruence inverse zero n={n}", C.inv()[0,n]==0, "exact symbolic proxy")
        check(f"proxy congruence determinant zero n={n}", sym_matrix(proxy,n,1).det()==0, "exact symbolic proxy")

rng=np.random.default_rng(142607)
for trial in range(4):
    cn={0:3+0.1j}
    for k in (-3,-2,-1,1,2,3):
        cn[k]=0.06*(rng.normal()+1j*rng.normal())
    tail=sum(abs(v) for k,v in cn.items() if k)
    gamma=abs(cn[0])-tail
    M=abs(cn[0])+tail
    K=1/gamma
    for n in (4,9,17,31):
        rep=row_increment(cn,n)
        close(f"numeric row update trial={trial} n={n}",rep["identity_residual"],0,2e-12)
        close(f"numeric row norm trial={trial} n={n}",rep["increment_norm"],rep["predicted_norm"],2e-12)
        C=matrix(cn,n+1)
        A=C[:n,1:]
        ka=abs(first_inverse_row(C)[-1])
        s=float(svdvals(A)[-1])
        # At very small scales only test the inequality with explicitly stated
        # roundoff allowance, never logarithms of a numerical zero.
        allowance=2e-13*M
        check(f"corner-singular sandwich trial={trial} n={n}",
              ka/(2*K*K) <= s+allowance and s <= 2*M*M*ka+allowance,
              "floating-point consistency", corner_abs=float(ka), smin=s, roundoff_allowance=allowance)
        check(f"stable core trial={trial} n={n}",float(svdvals(C)[-1])>=gamma-allowance,
              "floating-point consistency", analytic_lower_bound=gamma)
    for p in (1,2,3):
        n=19
        C=matrix(cn,n+p)
        A=C[:n,p:]
        s=np.sort(svdvals(A))
        check(f"at most p small singular values trial={trial} p={p}",s[p]>=gamma-1e-12,
              "floating-point consistency", s_p_plus_one=float(s[p]), analytic_lower_bound=gamma)
        Kblock=boundary_block(cn,n,p)
        close(f"numeric Jacobi trial={trial} p={p}",np.linalg.det(A),(-1)**(n*p)*np.linalg.det(C)*np.linalg.det(Kblock),2e-11)

# Verify radial similarity exactly for several positive rational radii.
c2={-3:sp.Rational(1,7),-1:sp.Rational(2,9),0:sp.Rational(-1,4),1:1,2:sp.Rational(1,8)}
for n in (2,4,7):
    for rad in (sp.Rational(3,4), sp.Rational(5,4)):
        A=sym_matrix(c2,n)
        D=sp.diag(*[rad**j for j in range(n)])
        B=sym_matrix({k:v*rad**k for k,v in c2.items()},n)
        check(f"exact radial similarity n={n} radius={rad}",B==D*A*D.inv(),"exact symbolic")

# A 100-digit check of the corner/singular-value comparison at an exponential scale.
mp.mp.dps=100
for n in (12,30):
    rr=mp.mpf('0.35')
    C=mp.eye(n+1)
    for j in range(n): C[j,j+1]=-rr
    Ci=C**-1
    ka=abs(Ci[0,n])
    check(f"100-digit geometric corner n={n}",abs(ka-rr**n)<mp.mpf('1e-95'),"100-digit calculation")
    A=mp.matrix(n,n)
    for i in range(n):
        for j in range(n): A[i,j]=C[i,j+1]
    _,sing,_=mp.svd(A)
    sm=sing[n-1]
    M=1+rr; K=1/(1-rr)
    check(f"100-digit singular sandwich n={n}",ka/(2*K*K)<=sm<=2*M*M*ka,
          "100-digit calculation", corner=mp.nstr(ka,35), smin=mp.nstr(sm,35))

# Actual continuous plateau symbol: 1 on half the circle, one full turn on
# the other half. Its canonical energy equals 1 and its index is +1.
def plateau(k):
    if k in (0,2): return 0.5
    if k%2: return 2j/(np.pi*k*(2-k))
    return 0.0

# Fourier integral checks do not use an FFT or approximate the plateau by a jump.
for k in (-7,-3,-1,0,1,2,3,6):
    f=lambda t: (mp.e**(2j*t) if t<=mp.pi else 1)*mp.e**(-1j*k*t)
    integ=(mp.quad(f,[0,mp.pi])+mp.quad(f,[mp.pi,2*mp.pi]))/(2*mp.pi)
    close(f"plateau Fourier coefficient k={k}",complex(integ),plateau(k),1e-13,"100-digit quadrature")

plateau_rows=[]
for n in (8,16,32,64,128,256):
    A=matrix(plateau,n)
    ev=eigvals(A)
    energy=float(np.mean(abs(ev)**2))
    cfun=lambda k: plateau(k+1)
    C=matrix(cfun,n+1)
    ka=first_inverse_row(C)[-1]
    signA,logA=np.linalg.slogdet(A)
    signC,logC=np.linalg.slogdet(C)
    close(f"plateau log cofactor n={n}",logA,logC+np.log(abs(ka)),2e-10)
    check(f"plateau Schur energy n={n}",energy<=1+2e-11 and energy>=-2e-11,"floating-point diagnostic", energy=energy)
    # Bounds for a unimodular symbol when the determinant is nonzero.
    check(f"plateau determinant energy bound n={n}",1-energy<=-2*logA/n+2e-10,
          "floating-point consistency")
    plateau_rows.append(dict(n=n,energy_deficit=1-energy,log_determinant_per_n=float(logA/n),
                             corner_abs=float(abs(ka)),smin_core=float(svdvals(C)[-1])))

# The plateau has a symbolically computable first squared Fourier moment.
# This is a finite inequality for the unperturbed matrix, not an asymptotic fit.
j=sp.symbols("j", integer=True, positive=True)
telescoper=j/(4*j*j-1)**2-sp.Rational(1,8)*(1/(2*j-1)**2-1/(2*j+1)**2)
check("plateau Hankel sum telescoping identity",sp.cancel(telescoper)==0,"exact symbolic")
for last in (1,2,7,20):
    finite=sum(sp.Rational(k,(4*k*k-1)**2) for k in range(1,last+1))
    check(f"plateau finite Hankel sum N={last}",
          finite==sp.Rational(1,8)*(1-sp.Rational(1,(2*last+1)**2)),"exact rational")
c1=0.5+2/np.pi**2
gamma2=1-c1
check("plateau explicit stability constant positive",gamma2>0,"scalar consistency")
cfun=lambda k: plateau(k+1)
for row in plateau_rows:
    n=row["n"]
    C=matrix(cfun,n+1)
    leakage=float((n+1)-np.linalg.norm(C,'fro')**2)
    check(f"plateau uniform squared stability n={n}",row["smin_core"]**2>=gamma2-2e-12,
          "floating-point consistency",analytic_lower_bound=float(gamma2))
    check(f"plateau leakage bounded by C1 n={n}",leakage>=-2e-11 and leakage<=c1+2e-11,
          "floating-point consistency",leakage=leakage,c1=float(c1))
    cert=unimodular_certificate_diagnostic(cfun,n,c1)
    check(f"plateau finite unperturbed certificate n={n}",
          row["energy_deficit"]<=cert["energy_upper_bound_diagnostic"]+2e-10,
          "floating-point consistency",bound=cert["energy_upper_bound_diagnostic"],
          energy_deficit=row["energy_deficit"])
    check(f"plateau certificate remains diagnostic n={n}",not cert["certified"],"software status check")
    row["explicit_certificate_bound"]=cert["energy_upper_bound_diagnostic"]
# High-precision checks avoid deriving the stability margin from a rounded pi.
cc1=mp.mpf('0.5')+2/mp.pi**2
check("100-digit plateau stability margin",0 < 1-cc1 < mp.mpf('0.3'),"100-digit scalar")
for bad in (-1,1,float('nan')):
    caught=False
    try: unimodular_certificate_diagnostic(cfun,4,bad)
    except ValueError: caught=True
    check(f"reject certificate moment {bad}",caught,"software input validation")

# Smooth exact symbol from the earlier defective example; entries only at
# indices divisible by 3 force inverse-corner zeros at all other indices.
tau=1/128

def smooth_c(k):
    if k==0: return 1.0
    if k%3: return 0.0
    j=abs(k)//3
    return tau*np.exp(-np.sqrt(j))/(j*j)

smooth_rows=[]
for n in (8,9,10,17,18,19,35,36,37,71,72,73):
    C=matrix(smooth_c,n+1)
    ka=first_inverse_row(C)[-1]
    if n%3:
        check(f"actual smooth congruence zero n={n}",ka==0,"structural zero with floating-point coefficients")
    else:
        # Only a diagnostic nonzero check; the infinite root-limsup theorem is analytic.
        check(f"actual smooth visible corner n={n}",abs(ka)>0,"floating-point diagnostic",corner_abs=float(abs(ka)))
    check(f"actual smooth stable core n={n}",svdvals(C)[-1]>=1-4*tau-1e-12,"floating-point consistency")
    smooth_rows.append(dict(n=n,corner_abs=float(abs(ka)),forced_zero=bool(n%3)))

# Input validation is counted separately from mathematical identities.
for bad in (0,-1,2.5):
    caught=False
    try: matrix({},bad)
    except ValueError: caught=True
    check(f"reject invalid matrix order {bad}",caught,"software input validation")

for name, rows in (("plateau_diagnostics.csv",plateau_rows),("smooth_corner_diagnostics.csv",smooth_rows)):
    with (OUT/name).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

summary={"passed":sum(x["passed"] for x in checks),"failed":sum(not x["passed"] for x in checks),
         "total":len(checks),"environment":{"python":platform.python_version(),"numpy":np.__version__,
         "scipy":scipy.__version__,"sympy":sp.__version__,"mpmath":mp.__version__},
         "certification_boundary":"Written arguments establish the infinite claims; these tests do not. Floating-point eigenvalues are not certified.",
         "checks":checks}
(OUT/'validation.json').write_text(json.dumps(summary,indent=2))
(OUT/'validation_summary.tex').write_text(
    f"\\textbf{{Executed new checks: {summary['passed']} of {summary['total']} passed; {summary['failed']} failures.}}\n")
tex=['\\begin{tabular}{r r r r}\\toprule',r'$n$ & $\\mathcal E_n$ & $n^{-1}\\log|\\det A_n|$ & $|\\kappa_n|$ \\']
# Avoid escaped math macros twice in emitted TeX.
tex=[r'\begin{tabular}{rrrr}\toprule',r'$n$ & $\mathcal E_n$ & $n^{-1}\log|\det A_n|$ & $|\kappa_n|$ \\']
for r0 in plateau_rows:
    tex.append(f"{r0['n']} & {r0['energy_deficit']:.6f} & {r0['log_determinant_per_n']:.6f} & {r0['corner_abs']:.6g} \\\\")
tex += [r'\bottomrule\end{tabular}']
(OUT/'plateau_table.tex').write_text('\n'.join(tex)+'\n')
print(json.dumps({k:summary[k] for k in ('passed','failed','total','environment')},indent=2))
if summary['failed']:
    for x in checks:
        if not x['passed']: print('FAILED:',x)
    sys.exit(1)
