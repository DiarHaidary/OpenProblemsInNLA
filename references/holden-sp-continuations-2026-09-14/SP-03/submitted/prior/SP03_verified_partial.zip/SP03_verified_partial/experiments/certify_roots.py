"""Exact dyadic contraction certificates for the SP-03 polynomial system.
The verifier uses integer arithmetic for every proof inequality.  NumPy is only
used to store data and (in certificate generation) propose approximate inverses.
A successful certificate proves distinct simple zeros, NOT completeness.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import numpy as np
import json,sys,time
BASE=Path(__file__).resolve().parent

def dyadic(z, exponent=None):
    z=np.asarray(z,dtype=np.complex128)
    rs=[float(v).as_integer_ratio() for v in z.real.ravel()]
    ims=[float(v).as_integer_ratio() for v in z.imag.ravel()]
    ee=max([b.bit_length()-1 for a,b in rs+ims],default=0)
    if exponent is None:exponent=ee
    if exponent<ee:raise ValueError('Insufficient common binary exponent')
    rr=np.asarray([a << (exponent-(b.bit_length()-1)) for a,b in rs],dtype=object).reshape(z.shape)
    ii=np.asarray([a << (exponent-(b.bit_length()-1)) for a,b in ims],dtype=object).reshape(z.shape)
    return rr,ii,exponent

def cdot(ar,ai,br,bi):return ar@br-ai@bi,ar@bi+ai@br

def exact_system(x,u,n):
    both=np.concatenate([x.ravel(),u.ravel()]);rr,ii,e=dyadic(both)
    m=n//2;xr=rr[:n*n].reshape(n,n);xi=ii[:n*n].reshape(n,n)
    ur=rr[n*n:].reshape(n,n);ui=ii[n*n:].reshape(n,n)
    jr=np.concatenate([xr[m:],-xr[:m]],axis=0);ji=np.concatenate([xi[m:],-xi[:m]],axis=0)
    kr=np.concatenate([-xr[:,m:],xr[:,:m]],axis=1);ki=np.concatenate([-xi[:,m:],xi[:,:m]],axis=1)
    cr,ci=cdot(xr.T,xi.T,jr,ji)
    vr,vi=cdot((ur-xr).T,(ui-xi).T,kr,ki)
    fr=np.empty(n*n,dtype=object);fi=np.empty_like(fr)
    ar=np.zeros((n*n,n*n),dtype=object);ai=np.zeros_like(ar);row=0
    for i in range(n):
        for j in range(i+1,n):
            fr[row]=cr[i,j]-(1<<(2*e) if i<m and j==i+m else 0);fi[row]=ci[i,j]
            for a in range(n):
                ar[row,a*n+i]+=jr[a,j];ai[row,a*n+i]+=ji[a,j]
                ar[row,a*n+j]-=jr[a,i];ai[row,a*n+j]-=ji[a,i]
            row+=1
    for i in range(n):
        for j in range(i,n):
            fr[row]=vr[i,j]+vr[j,i];fi[row]=vi[i,j]+vi[j,i]
            bj=j+m if j<m else j-m;bi=i+m if i<m else i-m
            sj=-1 if j<m else 1;si=-1 if i<m else 1
            for a in range(n):
                ar[row,a*n+i]-=kr[a,j];ai[row,a*n+i]-=ki[a,j]
                ar[row,a*n+j]-=kr[a,i];ai[row,a*n+j]-=ki[a,i]
                ar[row,a*n+bj]+=sj*(ur[a,i]-xr[a,i]);ai[row,a*n+bj]+=sj*(ui[a,i]-xi[a,i])
                ar[row,a*n+bi]+=si*(ur[a,j]-xr[a,j]);ai[row,a*n+bi]+=si*(ui[a,j]-xi[a,j])
            row+=1
    return fr,fi,ar,ai,e

def pow2(e):return Fraction(1<<e,1) if e>=0 else Fraction(1,1<<(-e))

def check_one(x,u,Y,n):
    fr,fi,ar,ai,e=exact_system(x,u,n);yr,yi,ey=dyadic(Y)
    er,ei=cdot(yr,yi,fr,fi)
    eta=Fraction(int(max(abs(er)+abs(ei))),1<<(ey+2*e))
    br,bi=cdot(yr,yi,ar,ai)
    for j in range(n*n):br[j,j]-=1<<(e+ey)
    z0=Fraction(int(max(np.sum(abs(br)+abs(bi),axis=1))),1<<(e+ey))
    yn=Fraction(int(max(np.sum(abs(yr)+abs(yi),axis=1))),1<<ey)
    z2=4*n*yn
    r=pow2(eta.numerator.bit_length()-eta.denominator.bit_length()+3) if eta else pow2(-80)
    contraction=z0+z2*r
    inclusion=eta+z0*r+z2*r*r/2
    ok=contraction<1 and inclusion<r
    return ok,r,eta,z0,z2

def disjoint(roots,radii):
    if len(roots)<2:return True,None
    rr,ii,e=dyadic(roots);ints=np.concatenate([rr,ii],axis=1)
    vals=np.concatenate([roots.real,roots.imag],axis=1)
    bound=2*max(radii)*(1<<e);best=None
    for i in range(len(roots)):
        for j in range(i):
            ix=int(np.argmax(abs(vals[i]-vals[j])))
            gap=abs(int(ints[i,ix]-ints[j,ix]))
            if gap*bound.denominator<=bound.numerator:return False,(i,j)
            if best is None or gap<best:best=gap
    return True,float(Fraction(best,1<<e))

def verify(path):
    path=Path(path);z=np.load(path);roots=z['roots'];Y=z['inverses'];U=z['U'];n=int(round(np.sqrt(roots.shape[1])))
    radii=[];eta=[];z0=[];z2=[];start=time.time()
    for i in range(len(roots)):
        ok,r,a,b,c=check_one(roots[i],U,Y[i],n)
        if not ok:raise AssertionError(f'Contraction certificate {i} failed')
        radii.append(r);eta.append(float(a));z0.append(float(b));z2.append(float(c))
    separated,gap=disjoint(roots,radii)
    if not separated:raise AssertionError(f'Non-disjoint certified balls: {gap}')
    report=dict(m=n//2,certified_distinct_simple_roots=len(roots),completeness_proved=False,arithmetic='exact Python integers and fractions',maximum_radius=float(max(radii)),maximum_eta=max(eta),maximum_z0=max(z0),maximum_z2=max(z2),minimum_selected_coordinate_separation=gap,verification_seconds=time.time()-start)
    print(json.dumps(report,indent=2));return report

def refine_high_precision(x,u,n):
    """Improve a proposal only; no high-precision calculation is trusted as proof."""
    import mpmath as mp
    with mp.workdps(85):
        m=n//2
        xx=mp.matrix([mp.mpc(float(a.real),float(a.imag)) for a in x])
        uu=mp.matrix(n,n)
        for a in range(n):
            for b in range(n):
                z=u[a*n+b];uu[a,b]=mp.mpc(float(z.real),float(z.imag))
        for iteration in range(6):
            X=mp.matrix(n,n)
            for a in range(n):
                for b in range(n):X[a,b]=xx[a*n+b]
            JX=mp.matrix(n,n);XJ=mp.matrix(n,n)
            for a in range(n):
                for b in range(n):
                    JX[a,b]=X[a+m,b] if a<m else -X[a-m,b]
                    XJ[a,b]=-X[a,b+m] if b<m else X[a,b-m]
            AA=uu-X;C=X.T*JX;V=AA.T*XJ
            F=mp.matrix(n*n,1);Jac=mp.matrix(n*n,n*n);row=0
            for i in range(n):
                for j in range(i+1,n):
                    F[row]=C[i,j]-(1 if i<m and j==i+m else 0)
                    for a in range(n):
                        Jac[row,a*n+i]+=JX[a,j];Jac[row,a*n+j]-=JX[a,i]
                    row+=1
            for i in range(n):
                for j in range(i,n):
                    F[row]=V[i,j]+V[j,i]
                    bj=j+m if j<m else j-m;bi=i+m if i<m else i-m
                    sj=-1 if j<m else 1;si=-1 if i<m else 1
                    for a in range(n):
                        Jac[row,a*n+i]-=XJ[a,j];Jac[row,a*n+j]-=XJ[a,i]
                        Jac[row,a*n+bj]+=sj*AA[a,i];Jac[row,a*n+bi]+=si*AA[a,j]
                    row+=1
            delta=mp.lu_solve(Jac,F);xx-=delta
            if max(abs(z) for z in delta)<mp.mpf('1e-65'):break
        return np.asarray([complex(z) for z in xx],dtype=np.complex128)

def generate(m,limit=None):
    from full_monodromy import evaluate
    src=BASE/f'full_m{m}.npz'
    if not src.exists():
        from bigcell_monodromy import lift,basis
        z=np.load(BASE/f'bigcell_m{m}.npz');I=np.eye(m);P=np.block([[I,1j*I],[1j*I,I]])/np.sqrt(2);Pi=np.linalg.inv(P)
        U=(P@z['U']@Pi).ravel();roots=np.asarray([(P@lift(a,z['U'],basis(m))[0]@Pi).ravel() for a in z['roots']])
    else:
        z=np.load(src);U=z['U'];roots=z['roots']
    n=2*m;good=[];inverses=[];failed=[];zero=np.zeros_like(U)
    for i,x in enumerate(roots[:limit] if limit else roots):
        x=x.copy()
        for j in range(3):
            F,A,Pt=evaluate(x,U,zero,n)
            x-=np.linalg.solve(A,F)
        F,A,Pt=evaluate(x,U,zero,n);Y=np.linalg.inv(A)
        ok,*bounds=check_one(x,U,Y,n)
        if not ok:
            try:
                x=refine_high_precision(x,U,n)
                F,A,Pt=evaluate(x,U,zero,n);Y=np.linalg.inv(A)
                ok,*bounds=check_one(x,U,Y,n)
            except (ValueError,ZeroDivisionError,np.linalg.LinAlgError):
                ok=False
        if ok:good.append(x);inverses.append(Y)
        else:failed.append(i)
    dst=BASE/f'certificates_m{m}.npz'
    np.savez_compressed(dst,roots=np.asarray(good),inverses=np.asarray(inverses),U=U)
    print('Generated',len(good),'certificates; rejected',failed,flush=True)
    report=verify(dst);report['rejected_input_indices']=failed
    (BASE/f'certificate_report_m{m}.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':
    if len(sys.argv)>2 and sys.argv[1]=='verify':verify(sys.argv[2])
    elif len(sys.argv)>1:generate(int(sys.argv[1]),int(sys.argv[2]) if len(sys.argv)>2 else None)
    else:raise SystemExit('Usage: certify_roots.py M [LIMIT] | verify CERTIFICATE.npz')
