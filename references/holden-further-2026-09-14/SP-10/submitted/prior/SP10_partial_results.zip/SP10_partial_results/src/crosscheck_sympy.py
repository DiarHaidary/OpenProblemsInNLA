#!/usr/bin/env python3
"""Second exact certificate check, without importing sp10's matrix routines.

Requires SymPy. This is implementation diversity, not independent peer review.
The input certificate is checked from its integer vectors, not trusted ranks.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy
from sympy.polys.matrices import DomainMatrix


def check(record: dict) -> tuple[int, int]:
    n = record['n']
    if type(n) is not int or n < 1:
        raise ValueError('Bad graph order.')
    edge_set = set()
    for u, v in record['edges']:
        if not (type(u) is int and type(v) is int and 0 <= u < v < n):
            raise ValueError('Expected sorted, valid edge endpoints.')
        edge_set.add((u, v))
    ranks = []
    for side, key in enumerate(('gram_G', 'gram_complement')):
        v = record[key]
        if len(v) != n or not v:
            raise ValueError('Bad row count.')
        d = len(v[0])
        if any(len(row) != d or any(type(x) is not int for x in row) for row in v):
            raise ValueError('Bad integer vectors.')
        # Direct integer dot products, rather than the primary verifier's Gram.
        a = [[sum(v[i][k] * v[j][k] for k in range(d))
              for j in range(n)] for i in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                expected_nonzero = ((i, j) in edge_set) != bool(side)
                if bool(a[i][j]) != expected_nonzero:
                    raise ValueError(f'Wrong support on side {side}, pair {(i,j)}.')
        # SymPy exact-domain elimination; no floating arithmetic.
        r = int(DomainMatrix.from_Matrix(sympy.Matrix(a)).rank())
        ranks.append(r)
    rg, rb = ranks
    for field, value in [('rank_G', rg), ('rank_complement', rb),
                         ('rank_sum', rg + rb), ('target', n + 2)]:
        if record.get(field) != value:
            raise ValueError(f'Wrong recorded {field}.')
    expected = 'CERTIFIED' if rg + rb <= n + 2 else 'UNKNOWN'
    if record.get('status') != expected:
        raise ValueError('Wrong status.')
    return rg, rb


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('paths', type=Path, nargs='+')
    args = p.parse_args()
    counts = {}
    for path in args.paths:
        text = path.read_text()
        records = ([json.loads(s) for s in text.splitlines() if s.strip()]
                   if path.suffix == '.jsonl' else [json.loads(text)])
        for record in records:
            check(record)
        counts[path.name] = len(records)
    print(json.dumps({'sympy_version': sympy.__version__,
                      'verified_records_by_file': counts,
                      'verified_records_total': sum(counts.values()),
                      'rank_method': 'SymPy DomainMatrix exact-domain elimination',
                      'limitations': 'Second implementation, not independent review or formal proof.'},
                     indent=2))


if __name__ == '__main__':
    main()
