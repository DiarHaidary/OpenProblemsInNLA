# Executed verification record

All results below were executed against the delivered code and certificate data.
The final complete run is recorded in `full_verification.log` and ended with
`PASS all requested audits. The unrestricted constant is not determined.`

## Complete entry point

```sh
python verify_all.py --symbolic --numerical --prior
```

This successfully ran:

- The new exact rank-one checker with third-party site packages disabled: four
  polynomial identities, all AM–GM weights and exponent barycenters, the unique
  equality point, and the extremal pair in Q(sqrt(-3)).
- All nine exact and corruption-rejection tests, both normally and under Python
  optimization (`-O`).
- The separate direct SymPy reconstruction: all nine checks passed.
- All six numerical regression groups, including the finite moment reductions.
- The inherited n=5 and n=193 certificates, each by both exact positivity methods
  and with third-party site packages disabled. Each was extracted from the retained
  prior ZIP into a temporary directory before execution.

`prior_rerun_n5.json` and `prior_rerun_n193.json` are the final aggregate run's
machine-readable outputs. The `reverified_*` outputs document separate earlier
successful executions in this continuation. They are not additional examples.

An initial aggregate launch was stopped by an execution time limit during the
large inherited check; its partial log is retained as
`full_verification_interrupted.log`. It did not report a mathematical test failure.
The complete command was relaunched and finished successfully. The final log,
not the interrupted attempt, supports the complete-run claim.

## Archive smoke test

`archive_smoke_test.log` records extraction of a staged complete ZIP into a fresh
temporary directory, validation of every staged manifest hash, and a successful
run of the new exact audit and rejection tests with site packages disabled.
The final archive adds that smoke-test log and this record, then regenerates its
manifest. The final ZIP's CRC and manifest were also checked after creation.

## Limits

Integer and rational acceptance checks are distinguished from numerical tests.
The latter do not certify a general bound. Arithmetic checks are not an external
mathematical review or proof-assistant formalization. General dimension-reduction,
geometric, and inertia arguments are given in `REPORT.pdf`.

The environment used for the optional checks is recorded in `environment.json`.
The new exact audit and tests need only the Python standard library.
