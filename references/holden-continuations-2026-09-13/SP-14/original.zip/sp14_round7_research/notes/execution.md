# Execution record

## New suite

The final seventh-note suite passed 246 of 246 checks with zero failures. The first run, before the finite-certificate additions, passed 212 checks; 34 finite-certificate and software checks were then added. No tolerance was enlarged to remove a failed mathematical check. The detailed final record is `results/validation.json`.

Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0, and mpmath 1.3.0 were used. High-precision calculations use 100 decimal digits. BLAS/OpenMP thread counts were set to one for reproducible finite checks. These tests are not certified interval arithmetic or a formal proof checker.

## Earlier suites

All six prior suites were executed in extracted working copies, not in the archived ZIP bytes. Their counts, newest to oldest, are 373/373, 560/560, 464/464, 309/309, 178/178, and 53/53. Each archived input had the same SHA-256 before and after the rerun. The report is `results/prior_rerun.json`. These are repeated consistency checks, not independent mathematical reviews.

A first attempt to run the rerun command in a streaming container session was rejected because streaming sessions were unavailable. It executed no commands. A subsequent directory check confirmed that no prior archive had yet been copied. The ordinary synchronous command then copied the archive, created the rerunner, and completed all six suites successfully. This operational issue did not change mathematical tests or tolerances.

## Manuscript

The manuscript was compiled with pdfLaTeX. The final-pass log is `results/build.log`. The inspected PDF has 16 pages. All 16 pages were rendered at 135 dpi and visually checked, including theorem displays, the diagnostic table, the appendix, and references. No clipping, unresolved references, or overfull boxes were seen in the inspected version. Render hashes and the inspected PDF hash are recorded in `results/artifact_verification.json`.

Intermediate `.aux`, `.log`, `.out`, and `.toc` files are removed from the delivery manuscript directory; the final-pass build log is retained in `results/`. Rebuilding generates new intermediates and may change metadata. The supplied manifest describes the delivered bytes only.

## Claims

No independent referee review, formal proof-assistant verification, certified general inverse-corner routine, or full universal SP-14 proof is claimed. The code returns explicit uncertified flags for floating-point boundary and certificate diagnostics. The symbolic identities and written analytic arguments have different verification roles and are not conflated.
