# Sources and provenance

Public pages were read directly through web access; no GitHub connector/plugin
was used. Source check date: 13 September 2026.

1. Canonical SP-07 statement:
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/eigenvalues-and-inverse-problems/SP-07/README.md
   Used for the exact all-dimension target and the distinction between supporting
   subclasses and a complete solution. The page still displayed Open.
2. Qiyue Tang, *A Truncated Singular-Value Bound for Spectral Variation of Normal
   Matrices*, arXiv:2609.09177v1:
   https://arxiv.org/html/2609.09177v1
   Used for the reported literature upper bound, the Krause attribution and ratio,
   and the distinction from the auxiliary Fourier extremal problem. No new global
   upper bound is derived from this source.
3. Repository contribution/status guidance:
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/CONTRIBUTING.md
   Used only for the distinction between a supporting result and completed status.
4. The supplied preceding ZIP and REPORT.pdf. The ZIP is retained byte-for-byte
   in `prior/`. The n=5 and n=193 exact certificates were rerun in this continuation.
   Their original search outputs are not promoted to upper-bound evidence.
5. R. Bhatia, *Perturbation Bounds for Matrix Eigenvalues*, Chapter IX, Section 33:
   https://epubs.siam.org/doi/10.1137/1.9780898719079.ch9
   The publisher's chapter excerpt was read directly for the Krause construction,
   attribution, and exact original ratio. No full reading of the book is claimed.
6. The classical Hall marriage theorem and the min–max/Schur-complement facts are
   used with their needed arguments supplied in the report. The conic compression
   argument is proved directly rather than relying on a black-box moment theorem.

A bounded search for combinations of normal matrices, spectral variation,
reflection, Householder, Krause, rank one, and spectral matching did not establish
historical priority for the new theorem. Lack of a search hit is not evidence of
novelty. Several broad search hits were irrelevant and were not used.

The previous Fourier/continuum heuristic and generic inverse-Sylvester norms were
not used as proof of an unrestricted value. No third-party paper is included in
full. No publication, repository update, or external review occurred.
