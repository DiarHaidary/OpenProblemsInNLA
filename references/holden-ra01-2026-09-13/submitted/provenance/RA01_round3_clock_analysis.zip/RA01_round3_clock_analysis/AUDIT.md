# Scope audit

- The requested universal RPCholesky pivot bound is not proved or disproved.
- The arrival-time and block results concern the specified pivot law; volume sampling is not substituted for it.
- The Poisson envelope with an absolute linear-rank shift is a sufficient hypothesis, not a proved fact.
- The finite count counterexample excludes the leading term exactly `r`; it does not exclude `a*r` with an absolute `a>1`.
- The finite count counterexamples have order `r+1`, so exact termination satisfies the dimension-capped RA-01 target on these examples.
- The conditional-hazard example disproves a blanket comparison, not a comparison restricted to large oversampling.
- The ridge generator inequality is an upper bound on the magnitude of the downward drift, not a lower bound.
- The block result requires actual coordinate blocks. A unitary diagonalization is not a valid transfer of that result.
- The new finite calculations use exact rational arithmetic. General arguments have not been checked by a proof assistant or independently reviewed.
- The previous package is retained, when available, without alteration. Its mathematical claims are not silently relabeled as new results.
- No new assertion about current repository status or literature priority is made.
