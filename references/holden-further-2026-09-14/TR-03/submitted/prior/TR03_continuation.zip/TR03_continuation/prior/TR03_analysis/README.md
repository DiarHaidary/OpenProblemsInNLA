# TR-03: rigorous bounds and an exact spectral family

## Completion status

**This package is not a full solution of TR-03.** It does not determine the sharp joint dependence of `R_{n,k}` on `n,k` up to universal constants. It contains self-contained analytic proofs of partial results, including an exact nontrivial spectral family, and reproducible numerical and symbolic checks.

No claim of novelty, priority, independent peer review, or proof-assistant verification is made. Numerical searches and sampled checks are not presented as global proofs.

## Proved results

For decreasing positive eigenvalues, write `m = n-k`, `tau_k = sum_{i>k} lambda_i`, and `h_k = (k+1)/(sum_{i<=k+1} 1/lambda_i)`.

* `x_k(lambda) >= max(tau_k, h_k)` and `R_{n,k} <= min(k+1, n-k)`.
* `R_{n,1}=1`, with attribution to the repository's existing one-column note; `R_{n,k}>1` for every `2 <= k <= n-2`.
* For the spectrum consisting of `k` copies of `L` and `m` copies of `1`, the limit of `x_k` as `L` tends to infinity is exactly the square-basis inverse-Frobenius frame minimax `F(n,m)`. Singular square bases have cost **infinity**, not pseudoinverse cost.
* For every `L >= 1`,

  `x_2(L,L,1,1) = [3(L+1) + sqrt((L+1)(5L-3))]/(L+3)`.

  The report proves the upper bound for **every** real orientation and constructs one orientation attaining it. Consequently `F(4,2)=3+sqrt(5)` and `R_{4,2} >= 6/(3+sqrt(5))`, approximately `1.1458980337503155`.

The last constant is the exact supremum within the displayed two-level family. It is **not** asserted to be the supremum over all four-dimensional spectra.

## Contents

- `TR03_report.pdf`: complete mathematical write-up, with proofs, exact extremizers, scope limitations, and references.
- `TR03_report.tex`: editable LaTeX source.
- `code/tr03.py`: numerical utilities, equal-diagonal construction, residual evaluation, frame costs, and exact four-dimensional extremizers.
- `code/verify.py`: deterministic reproduction of the recorded checks; uses seed `20260912`.
- `results/verification.json`: executed test results, environment versions, and verification limitations.
- `results/flat_4_2.csv`: values of the exact four-dimensional formulas.
- `sources.md`: primary references and the mathematical role of each.
- `requirements.txt`: tested Python dependency versions.
- `SHA256SUMS`: checksums for the packaged files, excluding the checksum file itself.

## Reproduce the checks

The recorded environment used Python 3.13.5. Use Python 3.13 to reproduce that environment; precise library versions are recorded in `results/verification.json`.

```bash
python -m venv .venv
# Activate the environment using the command appropriate to your operating system.
python -m pip install -r requirements.txt
python code/verify.py
```

The verification script itself makes no network calls. It reconstructs `results/verification.json` and `results/flat_4_2.csv` and raises an assertion error if a check fails. Installing dependencies may require network access.

The recorded run passed all test groups, including six symbolic identities, exact-extremizer checks at ten values of `L`, and 2,000 random-plane checks. These corroborate the analytic derivation but do not constitute formal verification. Exhaustive subset enumeration is restricted to small matrices and has a safety cap.

## Rebuild the PDF

A LaTeX distribution with the packages named in the preamble is needed.

```bash
pdflatex -interaction=nonstopmode -halt-on-error TR03_report.tex
pdflatex -interaction=nonstopmode -halt-on-error TR03_report.tex
```

## What remains unresolved in this work

The bounds `1 < R_{n,k} <= min(k+1,n-k)` do not match when both `k` and `n-k` grow. A sharp estimate for the frame minimax would resolve the two-level limiting subproblem, but a separate comparison with all other spectra would still be needed to settle TR-03. The report explicitly maintains this distinction and the original adversary-before-subset quantifier order.

Prepared 12 September 2026, America/New_York.
