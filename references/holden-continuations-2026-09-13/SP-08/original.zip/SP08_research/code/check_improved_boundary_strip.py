#!/usr/bin/env python3
"""Exact identities plus supplementary numerical checks for the new strip."""
from pathlib import Path
import json,math,time
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
n,c,L=s.symbols('n c L',real=True);r=1-c
for eps in [0,1]:
 C=(n-eps)**2-(L-n)**2
 balanced=n*n+r*r*(n-eps)**2+2*r*eps*(n-eps)
 diff=s.expand(balanced-(c*n+r*L)**2-r*((2-eps)-c*C))
 assert s.rem(s.Poly(diff,L),s.Poly(L*L-2*n*n+2,L)).is_zero
count=0;minimum=math.inf
for n0 in range(2,10001):
 c0=(1+math.sqrt(2))/(2*n0*n0);eps=n0%2;L0=math.sqrt(2*n0*n0-2)
 C0=(n0-eps)**2-(L0-n0)**2
 bracket=2-eps-c0*C0
 assert bracket>0
 k=(n0-eps)//2;target=n0/(2+2*c0)
 assert abs(k-target)<=.5+1e-12
 minimum=min(minimum,bracket);count+=1
report={'status':'PASS','exact_comparison_identities':2,'numerical_dimension_checks':count,'minimum_comparison_bracket':minimum,'warning':'The dimension sweep is supplementary. The proof for all dimensions is analytic.'}
(ROOT/'checks'/'improved_boundary_strip_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
