# Dimension reductions established in this continuation

These are written mathematical proofs, not claims that the universal constant has been evaluated. No novelty or external peer-review claim is made.

## 1. Rank-one reflections reduce to dimension three

Let D be diagonal normal, v a unit vector, P=vv*, Q=I-P, and J=I-2P. Put t=max(|v*Dv|, ||QDQ||), so ||D+JDJ||=2t. Suppose d∞(D,-D)>2t.

At most two diagonal entries of D have modulus greater than t. Otherwise, in the coordinate subspace E of three such entries, there is a nonzero x satisfying v*x=0 and v*Dx=0, since these are only two linear equations. Then QDQx=Dx and ||Dx||>t||x||, a contradiction.

Normality gives Hausdorff coverage at radius 2t: every z_i has some z_j with |z_i+z_j|<=2t. With no exterior entry, use all self-matches. With one exterior entry, exchange it with its covered partner and self-match the others. Thus a violating example has exactly two exterior entries a,b.

Set h=min(2|a|,2|b|,|a+b|). The matching distance is at most max(2t,h). If h=|a+b|, exchange a and b. If h=2|a|, self-match a and exchange b with a covered partner; when that partner is a, exchange a and b instead. All other entries self-match. The case h=2|b| is symmetric. Therefore h>=d∞>2t.

Let E0 be the span of the two exterior coordinate eigenvectors. The component v0 of v in E0-perp is nonzero: otherwise D and J split into a two-dimensional normal pair and scalar self-matches, whose total ratio is at most one. Let T have columns e_a,e_b,v0/||v0||. Then T is an isometry, v belongs to range(T), and D'=T*DT is diagonal with entries a,b,c, where c is a weighted average of the remaining entries. Let v'=T*v and J'=I-2v'v'*. We have JT=TJ' and

D'+J'D'J'=T*(D+JDJ)T.

Its norm does not increase. In dimension three the two-by-two Hall block on a,b has gap h, so d∞(D',-D')>=h>=d∞(D,-D). The new pair dominates the original ratio. Thus the supremum over all rank-one reflection pairs, in all dimensions, equals the supremum over size-three rank-one reflection pairs. This does not determine that supremum and does not cover arbitrary-rank reflections.

## 2. Two spectral values on each side of a Hall witness reduce to dimension three

Let E and F be spectral subspaces of normal A and B with dim(E)+dim(F)>n. Assume A|E has at most two distinct eigenvalues and B|F has at most two distinct eigenvalues, and every cross-distance between those values is at least delta>||A-B||.

Choose a unit x in E intersection F. Neither its A-spectral decomposition nor its B-spectral decomposition can have only one nonzero term: otherwise the corresponding eigenvector argument gives ||(A-B)x||>=delta. Write x=x1+x2=y1+y2 with nonzero mutually orthogonal A-eigencomponents x1,x2 and B-eigencomponents y1,y2. The subspace L=span(x1,x2,y1,y2) has dimension at most three.

Both compressions A_L and B_L are normal. For A_L, the two orthogonal eigenvectors x1,x2 remain eigenvectors; their orthogonal complement in L has dimension at most one, and is reducing for the compression because A is normal. The same argument applies to B_L. The norm of A_L-B_L is at most ||A-B||. Their spectra retain the two values on each side of the separated two-by-two Hall block, so their bottleneck distance is at least delta. Dimension two would contradict the elementary constant-one size-two result, so L has dimension exactly three.

## 3. Arbitrary multiplicities with at most three spectral values on each side

If A and B each have at most three distinct eigenvalues and d∞(A,B)>||A-B||, take a maximizing Hall witness. It cannot include every distinct A-value: any B-value in its opposite side has an A-value within ||A-B|| by normality. Similarly it cannot include every distinct B-value. Hence each side uses at most two values, and Result 2 applies. Consequently the supremum over this entire arbitrary-multiplicity subclass equals the unrestricted size-three constant c3. This does not determine c3.

## 4. A distinct-value refinement of the truncated singular-value estimate

If A and B have k_A,k_B distinct eigenvalues, set r=max(1,min(floor((n+1)/2),k_A-1,k_B-1)). Then

d∞(A,B)^2 <= sum_{j=1}^r s_j(A-B)^2.

When d∞<=s1 this is immediate. Otherwise choose a maximizing Hall witness and a unit x in the intersection of its spectral subspaces. Group x's nonzero components by distinct A-eigenvalues and by distinct B-eigenvalues, and normalize each component. Their column matrices U and V are isometries; their numbers of columns a,b satisfy a<=k_A-1, b<=k_B-1, and a+b<=n+1. Since x belongs to both column spaces, ||U*V||=1. Entrywise U*(A-B)V equals (alpha_i-beta_j)(U*V)_ij, so its squared Frobenius norm is at least d∞^2. Singular-value monotonicity under compressions bounds that squared Frobenius norm by sum_{j=1}^{min(a,b)} s_j(A-B)^2, which is at most the displayed sum. This yields a spectral-norm bound sqrt(r), not a dimension-independent sharp value when spectral complexity is unbounded.
