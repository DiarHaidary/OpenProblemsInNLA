# SP-08: centered rank-two sign matrices

**Status.** This is a proved subclass result, not a proof of unrestricted SP-08.
The nonnegative-parameter step uses an exact, independently checked polynomial
certificate. The reduction to that certificate and the negative-parameter step
are analytic. A possible unrestricted counterexample is not excluded when its
centered sign matrix and its deficit both have rank at least three.

## Statement and normalization

Let n >= 2, -1 <= a < 1, d=1-a, c=(1+a)/2, and r=(1-a)/2.
Let J denote the all-ones matrix, and let

    F(k) = n^2 + d (2 n k - (a+3) k^2),
    M_n(a)^2 = max_{1 <= k < n, k integer} F(k).

The matrix B_k = J-d z z^T, where z is the indicator of k indices, has rank two
and spread squared F(k). Its two nonzero eigenvalues have opposite signs.
Completing the square gives

    F(t) = 4 n^2/(a+3) - d(a+3)(t-n/(a+3))^2.

**Theorem.** If A is a symmetric endpoint matrix, with entries in {a,1}, and

    S = (A-cJ)/r

has rank at most two, then spread(A) <= M_n(a). In particular this entire class
contains no counterexample to SP-08. The theorem is valid in every dimension
and throughout the normalized parameter interval.

The integer block sizes in this theorem are retained during the reduction.
It does not follow from a relaxation to arbitrary real block masses.

## 1. Classification and three-dimensional compression

A symmetric rank-two sign matrix is indefinite. It has both positive and
negative diagonal entries: otherwise all its principal 2-by-2 minors vanish,
contradicting a nonzero product of its two nonzero eigenvalues. Choose one
positive and one negative diagonal position and switch a coordinate sign to
make their principal matrix [[1,1],[1,-1]]. Its inverse is half itself. The
vanishing Schur complement shows that every remaining column has, on those
two positions, either plus or minus (1,1), or plus or minus (1,-1). Consequently,
up to permutation and diagonal sign switching,

    S = Delta [[J_p, J_pq], [J_qp, -J_q]] Delta,  p+q=n, p,q>=1.

Put P=sum of the switching signs in the first group and Q=sum in the second.
For actual matrices these are integers, |P|<=p, |Q|<=q, with the respective
parities of p and q. Define

    R0 = n - P^2/p - Q^2/q,
    K  = P^2 + 2 P Q - Q^2.

The nonzero spectrum of A is contained in that of

    T = r [[p,sqrt(pq),0],[sqrt(pq),-q,0],[0,0,0]] + c v v^T,
    v = (P/sqrt(p), Q/sqrt(q), sqrt(R0)).

The same compression is defined for all real |P|<=p and |Q|<=q. Extra zero
eigenvalues cannot invalidate any upper bound obtained from this compression.
For c,r>0 and R0>0 its eigenvalues have the form lambda >= eta > 0 > -mu.
Write s=lambda+mu. Its characteristic polynomial is

    f(z)=z^3-t z^2+e2 z+D,
    t=c n+r(p-q),
    e2=-2 r^2 p q+c r (n(p-q)-K),
    D=2 c r^2 p q R0.

Degenerate boundary cases follow by continuity.

## 2. Aligning the switching sums

At fixed R0, increasing K decreases e2 and increases both lambda and mu:

    d lambda/dK = c r lambda / (s(lambda-eta)),
    d mu/dK     = c r mu     / (s(mu+eta)).

These signs also show that the relevant three-real-root branch continues
without a collision as e2 decreases: the extreme roots move outwards while
the middle positive root moves downwards. Thus replacing (P,Q) by (|P|,|Q|)
cannot decrease spread. We henceforth take P,Q>=0.

## 3. A lower bound for the negative eigenvalue

Let gamma be minus the minimum eigenvalue of S compressed to the orthogonal
complement of the all-ones vector. Since the cJ term vanishes on that space,
Rayleigh's principle gives mu>=r gamma. The two potentially nonzero eigenvalues
of this compression have trace and product

    T0 = p-q-K/n,       E0 = -2 p q R0/n.

Therefore gamma is the positive root of

    h(g)=g^2+T0 g-2 p q R0/n.

For P+Q>0, set g0=qP/(P+Q). Then h(g0)<=0 and hence

    mu >= r q P/(P+Q).                                      (1)

Here is an explicit algebraic certificate for the sign. Put x=p-P>=0,
y=q-Q>=0, and N=P+Q. Direct expansion yields

    n N^2 h(g0) = -[ P^2 N Q^2
      + P Q (2P^2+5PQ+4Q^2) x
      + P Q (4P^2+9PQ+6Q^2) y
      + N Q (P+2Q) x^2
      + P (P^2+4PQ+5Q^2) y^2
      + 2(P^3+4P^2Q+6PQ^2+2Q^3) x y
      + N(P+2Q) x^2 y
      + (P^2+4PQ+2Q^2) x y^2
      + P Q y^3 ].

Every term in brackets is nonnegative. The identity is checked independently
by the supplied analytic-identity verifier. At P=Q=0 the desired monotonicity
below follows by continuity.

## 4. Saturating one sign group without changing the other

Differentiate the extreme roots with respect to P, keeping Q,p,q fixed. With

    C=2 lambda mu+eta(lambda-mu),     W=lambda-mu-2eta,

one obtains

    ds/dP = 2cr [ C(P+Q)-2rqP W ]
            / [ s(lambda-eta)(mu+eta) ].

The denominator is positive. Also C>0: if lambda>=mu this is immediate; if
lambda<mu, use eta<=lambda to get C>=lambda mu+lambda eta>0.
If W<=0, the numerator is nonnegative. If W>0, then lambda>mu and C>=2lambda mu.
Using (1),

    C(P+Q) >= 2lambda r q P >= 2r q P W.

Thus spread is nondecreasing in P on [0,p], at fixed Q. We may set P=p.
This is crucial: Q remains its original integer, and consequently

    y=(q+Q)/2,       z=(q-Q)/2

remain integers. The resulting three-type endpoint matrix has base

    A_type = [[1,1,a],[1,a,1],[a,1,a]]

and multiplicities (p,y,z). If z=0 it is B_q. Otherwise p,z>=1 and y>=1.
It remains to bound this three-type matrix.

## 5. Analytic bound for -1 <= a <= 0

Let q=y+z, n=p+q, b=1+a, d=1-a, and t=p+a q. The compressed characteristic
polynomial has coefficients

    e2 = -d p q + d b z(p-q+z),
    e3 = -b d^2 p y z.

Its eigenvalues are lambda >= eta >= 0 > -mu, and

    s^2 = F(q)-4dbz(p-q+z)+2t eta-3eta^2.                    (2)

A useful bound, in fact valid for all -1<=a<1, is

    eta <= h0 := dbz.                                       (3)

To prove it, let R be the principal compression on the p and z groups:

    R=[[p,a sqrt(pz)],[a sqrt(pz),a z]],
    g(w)=w^2-(p+a z)w+a d p z.

Its smaller eigenvalue is at most h0. For a<=0 it is nonpositive. For a>=0,
a Rayleigh quotient orthogonal to (sqrt(p),sqrt(z)) gives an upper bound
 d p z/(p+z)<=d z<=dbz.
Interlacing gives eta<=lambda_max(R), while direct substitution gives

    f(h0)=h0 [ g(h0)-d b^2 y z ].

Were 0<h0<eta, the bracket would be nonpositive by the location of h0 between
the eigenvalues of R, whereas f(h0)>0 between zero and its first positive root.
This contradiction proves (3); zero or degenerate cases follow by continuity.

If t>=0, put V=(1-b)F(q)+bF(y). Using (2),

    V-s^2 = 2t(h0-eta)+d^2 b z^2+3eta^2 >=0.

For a in [-1,0], b in [0,1], so V is a convex combination of two candidate
values. If t<0, then p<q. Write Delta=q-p. A different exact identity is

    F(p)-s^2 = db [4(z-Delta/2)^2+2p Delta]-2t eta+3eta^2 >=0.

Thus s^2<=max(F(p),F(q),F(y)). All relevant sizes are integers. If y=0,
F(0)=n^2<=M_n(a)^2. This proves the negative-parameter part without a
computer-assisted inequality.

## 6. Exact certificate for 0 <= a < 1

For the three-type compression with real p,z>=1 and y>=0, define

    U=4n^2/(a+3)-(1-a)(a+3)/4.

The certificate proves s^2<=U. Since an allowed integer lies within distance
1/2 of n/(a+3), U<=M_n(a)^2 for integer n>=2. This explicitly absorbs the
integer-rounding loss; merely proving the continuous bound would not suffice.

For any real symmetric 3-by-3 matrix with characteristic coefficients t,e2,e3,
let D0=t^2-3e2 and let Disc be the cubic discriminant:

    Disc=t^2 e2^2-4e2^3-4t^3 e3-27e3^2+18t e2 e3.

Its three pairwise squared eigenvalue differences are the roots of

    q(u)=u(u-D0)^2-Disc.

The largest difference s^2 is at least D0, and q is increasing on [D0,infinity).
Consequently U>=D0 and U(U-D0)^2>=Disc imply s^2<=U.

The supplied certificate proves nonnegativity of the two polynomials

    B=4(a+3)(U-D0)/(1-a),
    Q=64(a+3)^3 [U(U-D0)^2-Disc]/(1-a)^2.

It covers the domain by two charts, with u,v,w,T nonnegative and a=T/(1+T):

    plus:  p=(a+2)v+u,   y=v,                 z=1+w;
    minus: p=1+v,        y=(1+v+u)/(a+2),     z=1+w.

The first chart covers p>=(a+2)y; the second covers p<=(a+2)y, p>=1.
After multiplying by the recorded positive denominators, the plus polynomials
have entirely positive coefficients. The minus polynomials are written as
sums of binomial squares with positive monomial multipliers, plus polynomials
with positive coefficients. Every number in these certificates is rational.

A square entry (alpha,beta,gamma,k,w) represents

    w [4^k X^alpha + 4^(-k) X^beta - 2 X^gamma],
    alpha+beta=2gamma, w>0.

If m is the coordinatewise minimum of alpha and beta, this is exactly

    w X^m [2^k X^((alpha-m)/2)-2^(-k) X^((beta-m)/2)]^2.

The half-exponents are nonnegative integers. The verifier regenerates the
spectral polynomials independently using only Python's standard-library
integer and rational arithmetic, checks the chart identities, then expands
all squares and checks coefficientwise equality. Floating-point optimization
was used only to discover a certificate, not to verify the theorem.

## 7. Rank-one sign matrices and completion of the subclass theorem

If S=ss^T is rank one, A=cJ+r ss^T is positive semidefinite with trace n, so its
spread is at most n. If S=-ss^T, its two-dimensional spread is bounded by

    n^2-4cr(1^T s)^2 <= n^2

after squaring; any degenerate case has spread at most n as well. Since
F(1)>n^2 for n>=2 and a<1, these matrices cannot exceed M_n(a).
Combining this observation with Sections 1-6 proves the stated theorem.

## What is not proved

No argument here forces a global endpoint maximizer to have rank(S)<=2.
The endpoint reduction follows from convexity, but it gives no such rank
restriction. Nor does the rank-two Rayleigh difference xx^T-yy^T imply that
its entrywise sign or endpoint-selection matrix has rank two.

The supplied earlier work treats positive-semidefinite deficits, binary
rank-at-most-two deficits, and a boundary strip near a=-1. Those results and
the present theorem still leave arbitrary higher-rank indefinite deficits.
The exact universal comparison remains

    spread(J-(1-a)H) <= M_n(a)

for every symmetric binary H, all n>=2, and all -1<=a<1. It has not been
established in this package.
