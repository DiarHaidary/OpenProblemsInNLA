# SP-07: certified continuation

**This package is not a full solution of SP-07.** The exact dimension-independent sharp constant has not been determined. A sharp universal upper bound and matching extremality argument are missing.

The continuation does establish a substantial change from the supplied prior archive:

\[
\boxed{C_{\mathrm{normal}}>1.03077.}
\]

This is an **exact rational certificate**, not an inference from optimizer output. In particular, the earlier possible candidate `sqrt(28/27)` is **false as a universal value**. The classical upper estimate cited in the report remains `C_normal < 2.9038872828`; this continuation does not improve that upper estimate.

Start with **[paper/sp07_continuation_report.pdf](paper/sp07_continuation_report.pdf)**. The 13-page report includes the full rational input of the strongest construction, a finite exact positivity certificate, written dimension-reduction proofs, and a precise statement of what is still missing. Its editable LaTeX source is included.

## Certified matrix results

| Construction | Dimension | Strict certified ratio lower bound | Arithmetic checks |
|---|---:|---:|---|
| First continuation example | 5 | 1.019558 | Standard-library fractions and SymPy; all 120 matchings also enumerated |
| Stronger five-dimensional example | 5 | 1.02671 | Independent standard-library and SymPy implementations |
| Strongest displayed example | 7 | 1.03077 | Independent standard-library and SymPy implementations |

The strongest numerical Hall-gap-to-norm ratio for the rational seven-dimensional input is approximately `1.030770922019103778...`. This is **not claimed to be an optimal constant**. The proof uses the simpler strict rational bound `1.03077`.

### How the exact certificate works

All decimal strings in the input JSON files denote exact rational numbers. For a rational real matrix `X`, set

\[
Y=\begin{pmatrix}I_r\\X\end{pmatrix},\quad
P=Y(Y^TY)^{-1}Y^T,\quad S=I-2P,\quad
A=\operatorname{diag}(z),\quad B=-SAS.
\]

The identity block makes `Y` full column rank. Thus `P` is exactly an orthogonal projection, `S` is exactly real orthogonal, and both `A` and `B` are exactly normal. Their spectra are `z` and `-z` with multiplicities retained.

For the seven-dimensional certificate, the one-based Hall index sets are `I = J = {1,3,4,5}`; their sizes sum to eight. Every matching crosses this block. The exact checks prove its squared gap is greater than `(q*t)^2`, where `q = 1.03077` and `t = 1.0000001`. They separately prove

\[
t^2I-(A-B)^*(A-B)=L\operatorname{diag}(d_k)L^*>0
\]

by exact rational arithmetic and strictly positive pivots. Therefore the **full** norm is less than `t`, and the matching-to-norm ratio is greater than `q`. Normality is not inferred from small residuals; the operator norm is not replaced with a rectangular block norm.

JSON indices are zero-based; mathematical indices in the report are one-based.

## Written reductions

The report proves the following statements, without claiming prior-literature novelty:

1. An arbitrary-dimensional **rank-one reflection** pair with ratio greater than one is dominated by a three-dimensional rank-one reflection pair. The rank-one supremum is thereby reduced to size three, but is not evaluated.
2. A deficient Hall witness involving at most two distinct spectral values on each side has a dominating three-dimensional normal compression. Consequently, the arbitrary-dimensional class in which **both matrices have at most three distinct eigenvalues**, with unrestricted multiplicities, has supremum exactly `c_3`. This does not determine `c_3`.
3. If the two matrices have `k_A` and `k_B` distinct values, the truncated singular-value estimate holds with
   `r = max(1, min(floor((n+1)/2), k_A-1, k_B-1))`.

None of these results reduces unrestricted, growing-rank reflection pairs to rank one or fixes a universal finite dimension.

## Reproduce the exact proof with the standard library only

From the package root, using ordinary Python 3 with assertions enabled:

```sh
mkdir -p rechecked
python -S code/check_certificate.py \
  results/certificate_seven.json \
  rechecked/seven_standard_library.json
```

The `-S` switch disables site-package loading, demonstrating that this verifier does not require NumPy, SciPy, or SymPy. **Do not use Python's assertion-disabling `-O` switch.**

The corresponding size-five check is:

```sh
python -S code/check_certificate.py \
  results/certificate_five_stronger.json \
  rechecked/five_standard_library.json
```

To run both independent arithmetic implementations, install `sympy` and run:

```sh
make verify
```

This copies the two general certificate inputs into `rechecked/`, runs the standard-library implementation, then checks the same inputs with SymPy and compares the exact pivots. The first five-dimensional certificate is separately checked by its two implementations. Shipped input and verification records are not overwritten by these targets.

## Numerical work and its limits

The package contains **1,128 saved campaign records**, including the **25 runs whose final optimizer status was not success**. An independent saved-record audit reconstructs all full matrices and recomputes their norms, bottleneck matchings, ratios, and parameterizations. Two polished smaller examples are audited separately.

A new test suite passed **1,044 numerical assertions across 384 cases** exercising the written reduction results. Two rational certificate matrices were also checked at 80-digit working precision. Those numerical tests and eigensolver outputs are consistency evidence; **they are not the proof of any universal upper bound**. The lower-bound proofs use exact rational arithmetic.

The records cover the saved campaigns, not every exploratory calculation or failed execution in the conversation. Local convergence, repeated recovery of an example, and absence of a better sampled point do not prove extremality or stabilization in dimension seven.

Install the numerical requirements and run:

```sh
python -m pip install -r requirements.txt
make audit tests highprecision
```

For another full run of the nine saved campaign configurations, use:

```sh
bash code/run_searches.sh
```

This writes to `rechecked/searches/` and uses the shipped starting records. Seeds, coordinates, and final matrices are saved. Optimizer results need not be bitwise identical across platforms or library versions. Exact certificate verification, in contrast, uses fixed rational inputs and is independent of numerical optimization.

## Build the report

With `pdflatex` and the packages named in the LaTeX source installed:

```sh
make pdf
```

The report data tables are regenerated directly from the verified JSON files before compilation. The supplied PDF can be read without Python or LaTeX.

## Main files

| Location | Contents |
|---|---|
| `paper/` | Report PDF, editable LaTeX, and generated exact-data tables |
| `results/certificate_seven.json` | Full rational seven-dimensional input |
| `results/certificate_five_stronger.json` | Full rational stronger five-dimensional input |
| `results/*_verification.json` | Exact arithmetic checks and rational pivot data |
| `results/*_symbolic_audit.json` | Independent SymPy cross-checks |
| `code/check_certificate.py` | Standard-library general reflection-certificate checker |
| `code/crosscheck_symbolic.py` | Independent symbolic checker |
| `code/search*.py` | Local numerical search methods, always evaluated with the full norm |
| `code/test_reductions.py` | Numerical consistency checks of the written theorems |
| `code/audit_records.py` | Independent reconstruction of saved campaign outputs |
| `notes/` | Source attribution, theorem status, and provenance notes |
| `STATUS.json` | Machine-readable completion and proof status |
| `prior/sp07_partial_results/` | Supplied earlier archive, retained unchanged apart from exclusion of runtime cache files |
| `MANIFEST.sha256` | SHA-256 integrity hashes for all shipped files except the manifest itself |

The prior archive's historical lower bound and unevaluated candidate are not updated in place. The root report and status file describe the continuation's stronger results.

On systems with `sha256sum`, verify the delivered files using:

```sh
sha256sum -c MANIFEST.sha256
```

Rebuilding the report changes its bytes and therefore its hash. Reproduction outputs are normally written to `rechecked/` so that the shipped records remain intact.

## Completion boundary

The requested exact universal constant, the exact fixed-dimensional constants, global extremality of the displayed examples, and any finite-dimensional stabilization theorem are **not established**. A dimension-uniform sharp upper inequality plus matching sharpness evidence is still required. No external peer review or proof-assistant formalization is claimed.
