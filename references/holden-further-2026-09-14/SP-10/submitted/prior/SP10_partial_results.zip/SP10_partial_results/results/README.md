# Recorded results

`final_verification_summary.json` gives the final aggregate checks. The supporting outputs are:

- `exact_verification.json`: 1,252 atlas records checked by the standard-library verifier.
- `bull_verification.json` and `path_verification.json`: 1 and 17 explicit-family records checked by that verifier.
- `sympy_crosscheck.json`: all 1,270 records checked by the separate SymPy implementation.
- `atlas_coverage.json`: all 1,252 records matched to NetworkX source edge lists and graph6 identifiers.
- `combinatorial_checks.json`: the finite degree/MCS comparisons, including the 22 entries left uncovered by the combined sufficient bound.
- `atlas_summary.csv`: one row per atlas entry, with graph parameters and certified rank upper bounds.
- `unit_tests.log`: the final successful run of 12 unit tests.
- `custom_search_smoke.json`: successful execution of the README's bull-input search example.
- `explicit_families.log`: output from constructing the bull and path witnesses.
- `experiment_summary.json`, `generation.log`, and `generation_resume.log`: generation metadata and progress. The initial run was interrupted after 1,047 saved records. The resumed run reused and reverified them, then completed the set. Its elapsed time is explicitly invocation-specific, not total research or generation time.

All certificates are successful finite-instance rank upper bounds. No file reports a proof of SP-10 for arbitrary graphs, and no search failure is interpreted as a counterexample.
