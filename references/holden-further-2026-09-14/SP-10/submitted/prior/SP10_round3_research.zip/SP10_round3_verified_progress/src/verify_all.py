"""Verify every newly generated witness without trusting its recorded ranks."""
from pathlib import Path
import json
from exact_tools import verify_pair,read_records,edges,complement,verify_peeling
ROOT=Path(__file__).resolve().parents[1]

def main():
    results=[]
    for name in ('layered_pairs.jsonl','cubic_tree_pairs.jsonl','J9_rank_pair.json'):
        for record in read_records(ROOT/'certificates'/name):results.append(verify_pair(record))
    dc=json.loads((ROOT/'certificates'/'false_degeneracy_NG_9.json').read_text())
    dcs=[dc]+json.loads((ROOT/'certificates'/'degeneracy_blowups.json').read_text())
    for c in dcs:
        n=c['n'];E=edges(n,c['edges'])
        a=verify_peeling(n,E,c['G']);b=verify_peeling(n,complement(n,E),c['complement'])
        assert a+b<(2*n-2+2)//3
    summary={'verified_rank_pairs':len(results),'verified_degeneracy_pairs':len(dcs),'rank_pairs':results,
             'arithmetic':'Python fractions.Fraction, no floating-point rank tolerances'}
    (ROOT/'results'/'exact_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
