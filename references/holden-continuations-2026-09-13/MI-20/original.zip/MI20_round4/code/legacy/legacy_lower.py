#!/usr/bin/env python3
"""Build and verify exact lower-bound certificates for the MI-20 cyclic form.

Verification needs Python 3.10+ and only its standard library. All acceptance
steps use integers and fractions. NumPy is imported only by the optional
``build`` command, to propose witnesses; no numerical proposal is trusted.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
import json
from pathlib import Path
from typing import Any

IntMatrix = list[list[int]]

def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)

def integer(x: Any) -> int:
    need(isinstance(x, (str, int)) and not isinstance(x, bool), 'Integer data required')
    if isinstance(x, str):
        need(x.strip() == x and x not in ('', '+', '-'), 'Malformed integer')
    return int(x)

def matrix(data: Any, rows: int, cols: int) -> IntMatrix:
    need(isinstance(data, list) and len(data) == rows, 'Wrong matrix height')
    need(all(isinstance(row, list) and len(row) == cols for row in data), 'Wrong matrix width')
    return [[integer(x) for x in row] for row in data]

def transpose(a: IntMatrix) -> IntMatrix:
    return [list(x) for x in zip(*a)]

def product(a: IntMatrix, b: IntMatrix) -> IntMatrix:
    need(bool(a) and bool(b) and len(a[0]) == len(b), 'Product dimension mismatch')
    bt = transpose(b)
    return [[sum(x*y for x,y in zip(row,col)) for col in bt] for row in a]

def row_bound(a: IntMatrix) -> int:
    return max(sum(abs(v) for v in row) for row in a)

def root_ceiling(x: int, degree: int) -> int:
    need(x >= 0 and degree >= 1, 'Invalid integer root')
    if x < 2:
        return x
    lo,hi=0,1 << ((x.bit_length()+degree-1)//degree)
    while lo+1 < hi:
        mid=(lo+hi)//2
        if mid**degree >= x:
            hi=mid
        else:
            lo=mid
    need(hi**degree >= x and (hi-1)**degree < x, 'Integer root check failed')
    return hi

def upper_rational_power(x: Fraction, q: int, digits: int=24) -> Fraction:
    """A rational upper bound for x**(q/(q-1)), verified by integer powers."""
    need(x >= 0 and q >= 3, 'Invalid power enclosure')
    scale=10**digits
    num=scale**(q-1)*x.numerator**q
    den=x.denominator**q
    z=(num+den-1)//den
    h=Fraction(root_ceiling(z,q-1),scale)
    need(h**(q-1) >= x**q, 'Rational power check failed')
    return h

def spectral_upper(snum: IntMatrix, proposal: dict[str,Any], scale: int, q: int):
    """Enclose eigenvalues of the exact PSD matrix snum / scale**2."""
    k=len(snum)
    z=matrix(proposal['basis'],k,k)
    d=[integer(x) for x in proposal['values']]
    need(len(d)==k and d==sorted(d) and min(d)>=0, 'Invalid proposed spectrum')
    gram=product(transpose(z),z)
    delta_num=row_bound([[gram[i][j]-(scale*scale if i==j else 0) for j in range(k)] for i in range(k)])
    delta=Fraction(delta_num,scale*scale)
    need(delta < 1, 'Eigenbasis proposal not certified nonsingular')
    zd=[[z[i][j]*d[j] for j in range(k)] for i in range(k)]
    reconstructed=product(zd,transpose(z))
    e0=Fraction(row_bound([[snum[i][j]*scale-reconstructed[i][j] for j in range(k)] for i in range(k)]),scale**3)
    eta=e0+delta*(2+delta)*Fraction(max(d),scale)
    upper=[Fraction(di,scale)+eta for di in d]
    trace_bound=sum((upper_rational_power(x,q) for x in upper),Fraction(0))
    return trace_bound,eta,delta

def verify(data: dict[str,Any]) -> dict[str,Any]:
    need(data.get('schema')=='mi20.cyclic.integer.v1','Unsupported certificate schema')
    m,k,q=[integer(data[name]) for name in ('m','k','q')]
    need(m>=2 and k>=1 and q>=3,'Invalid m, k, or q')
    n=m*k
    need(integer(data['n'])==n,'Dimension mismatch')
    need(data.get('p')==f'{q}/{q-1}','Exponent mismatch')
    scale=integer(data['scale'])
    need(scale>=1,'Invalid scale')
    need(len(data['blocks'])==m and len(data['spectral_proposals'])==m,'Block count mismatch')
    blocks=[matrix(b,k,k) for b in data['blocks']]
    r=[integer(x) for x in data['r']]
    need(len(r)==n and min(r)>0,'R must be positive definite and correctly sized')
    f=[row for block in blocks for row in block]
    h=product(f,transpose(f))
    w=matrix(data['witness'],n,n)
    wtw=product(transpose(w),w)
    a=root_ceiling(row_bound(wtw),2)
    need(a>0,'Zero trace-norm witness')
    # ||w/a||_op <= 1, proved by a symmetric maximum-row-sum bound.
    need(row_bound(wtw)<=a*a,'Contraction check failed')
    numint=sum(w[i][j]*r[i]*h[i][j] for i in range(n) for j in range(n))
    numerator=Fraction(numint,a*scale**3)
    need(numerator>0,'Nonpositive numerator lower bound')
    total=Fraction(0);etas=[];deltas=[]
    for block,proposal in zip(blocks,data['spectral_proposals']):
        snum=product(block,transpose(block))
        bound,eta,delta=spectral_upper(snum,proposal,scale,q)
        total+=bound;etas.append(eta);deltas.append(delta)
    need(total>0,'Degenerate denominator')
    hq=Fraction(sum(x**q for x in r),scale**q)
    target=Fraction(data['strict_lower_bound'])
    need(target>1,'Expected a nontrivial target')
    left=numerator**q
    right=target**q*hq*total**(q-1)
    need(left>right,'Claimed strict lower bound is NOT proved')
    # All statements controlling acceptance above are exact. The decimals below
    # are display-only diagnostics, never inputs to any acceptance decision.
    return {
        'status':'PASS', 'acceptance_arithmetic':'integers and exact fractions only',
        'form':'cyclic square-block dual normal form', 'm':m,'k':k,'n':n,'p':data['p'],
        'strict_lower_bound':data['strict_lower_bound'],
        'exact_strict_lower_bound_fraction':str(target),
        'certified_quotient_lower_display_only':float(left/(hq*total**(q-1)))**(1/q),
        'relative_power_margin_display_only':float(left/right-1),
        'witness_normalization_display_only':float(Fraction(a,scale)),
        'spectral_radii_display_only':[float(x) for x in etas],
        'orthogonality_errors_display_only':[float(x) for x in deltas],
        'claim_scope':'A feasible lower bound, not an optimality certificate.'
    }

def build(candidate_path: Path, output: Path, q: int, target: str, digits: int=18):
    import numpy as np  # Proposal generation only.
    source=json.loads(candidate_path.read_text())
    blocks=np.asarray(source['L'],dtype=float)
    m,k,k2=blocks.shape
    need(k==k2,'Candidate blocks must be square')
    r=np.asarray(source['r'],dtype=float).reshape(-1)
    need(r.size==m*k and np.min(r)>0,'Invalid candidate R')
    scale=10**digits
    def encode(x):
        if np.ndim(x)==0:
            return str(round(float(x)*scale))
        return [encode(v) for v in x]
    encoded_blocks=encode(blocks);encoded_r=encode(r)
    # Recompute proposals from the rounded inputs, not the unrounded candidate.
    rounded=np.array(encoded_blocks,dtype=float)/scale
    rr=np.array(encoded_r,dtype=float)/scale
    f=rounded.reshape(m*k,k)
    h=f@f.T
    u,_,vh=np.linalg.svd(rr[:,None]*h,full_matrices=True)
    witness=u@vh  # Full orthogonal completion, so its Gram matrix is near I.
    proposals=[]
    for b in rounded:
        d,z=np.linalg.eigh(b@b.T)
        proposals.append({'values':encode(np.maximum(d,0)),'basis':encode(z)})
    data={'schema':'mi20.cyclic.integer.v1','m':m,'k':k,'n':m*k,'p':f'{q}/{q-1}','q':q,
          'scale':str(scale),'blocks':encoded_blocks,'r':encoded_r,'witness':encode(witness),
          'spectral_proposals':proposals,'strict_lower_bound':target,
          'candidate_file':candidate_path.name,
          'note':'All integers define exact rational data after division by scale. Proposals are independently checked.'}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(data,indent=2)+'\n')
    return verify(data)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='command',required=True)
    v=sub.add_parser('verify');v.add_argument('certificate',type=Path);v.add_argument('--output',type=Path)
    b=sub.add_parser('build');b.add_argument('candidate',type=Path);b.add_argument('certificate',type=Path);b.add_argument('--q',type=int,required=True);b.add_argument('--target',required=True);b.add_argument('--digits',type=int,default=18);b.add_argument('--output',type=Path)
    args=ap.parse_args()
    if args.command=='verify':
        result=verify(json.loads(args.certificate.read_text()))
    else:
        result=build(args.candidate,args.certificate,args.q,args.target,args.digits)
    text=json.dumps(result,indent=2)+'\n';print(text,end='')
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text)

if __name__=='__main__':
    main()
