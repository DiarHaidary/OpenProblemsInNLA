"""Rebuild the manuscript with pdflatex; no third-party Python dependency."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    source = root / "IE20_bounds_and_counterexamples.tex"
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdflatex was not found. Install a LaTeX distribution first.")
    if not source.is_file():
        raise SystemExit(f"Missing source file: {source}")
    with tempfile.TemporaryDirectory(prefix="ie20-pdf-") as directory:
        for index in range(1, 4):
            print(f"LaTeX pass {index}/3", flush=True)
            result = subprocess.run(
                [executable, "-interaction=nonstopmode", "-halt-on-error",
                 f"-output-directory={directory}", source.name],
                cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, errors="replace", check=False,
            )
            if result.returncode:
                raise SystemExit("LaTeX compilation failed:\n" + result.stdout[-12000:])
        built = Path(directory) / source.with_suffix(".pdf").name
        if not built.is_file():
            raise SystemExit("pdflatex returned without producing the expected PDF.")
        destination = root / built.name
        shutil.copy2(built, destination)
        print(f"Built {destination}")


if __name__ == "__main__":
    main()
