# Claim-by-claim proof audit

## Completed claims

1. **Exact inverse-row increment.** The first inverse row is solved with the transpose, not the adjoint. The block equation is exact. The symbol norm bounds the last row and the stable inverse norm bounds its multiplier. Eventual invertibility is sufficient; undefined small orders are discarded.
2. **Analytic localization.** Riesz projections are used on L2, where they are bounded. No assertion that a continuous symbol has continuous positive and negative Riesz projections is made. The quotient of analytic functions is meromorphic beyond the circle. An H2 radial evaluation bound excludes boundary poles; compactness and isolated zeros provide a larger pole-free disk.
3. **Inverse-corner extension equivalence.** The difficult direction needs a geometric upper bound at every sufficiently large order to sum inverse-row increments. The converse uses radial diagonal similarity inside a nonvanishing analytic collar and the fixed-cutoff singular-value theorem. It does not identify the numerical decay rate with the raw Fourier radius.
4. **Pointwise determinant limsup.** Index +1 produces one inverse corner of a stable zero-index core. Multiplication by z and subtraction of the spectral parameter preserve the relevant extension question. The equality is a limsup, allowing exact determinant zeros at infinitely many orders.
5. **Singular-value comparison.** The comparison is a finite matrix inequality. A column permutation puts the removed minor in the upper-left block; a Schur complement proves one side and a column of the inverse proves the other, including a zero corner. All constants are independent of n once the zero-index cores are stable.
6. **Finite unimodular certificate.** The core is a contraction. Its Frobenius leakage bounds its logarithmic determinant, and the cofactor plus 1-r^2 <= -2 log r bounds the original eigenvalue deficit. A supplied lower bound for the corner must be certified to turn a numerical calculation into a certificate. The delivered numerical evaluator is explicitly uncertified.
7. **General-index boundary reduction.** Jacobi's identity includes the parity (-1)^(np). Min-max gives a uniform lower bound for all but p singular values. Truncating the reflected half-line kernel produces p singular values tending to zero. The determinant of the inverse boundary block remains uncontrolled under nonextension for p>1.
8. **Canonical subsequence.** Choose orders attaining the determinant limsup at one interior anchor. Every cluster of that selected sequence has the canonical potential throughout that component by the maximum principle, and in all zero-index components by stability. Measure uniqueness then gives one common canonical cluster. The chosen orders depend on the symbol and anchor; no rate or gap bound is claimed.
9. **Jordan curves of positive area.** The external input is Walsh's uniform rational approximation theorem for an arbitrary Jordan curve, verified on printed page 9. Equality of exterior potentials gives equal rational moments and support on the curve. Area-zero is not silently assumed.
10. **Strict deficit under an extension.** Radial evaluation gives identical finite spectra by diagonal similarity but lowers the canonical potential by p log(1/r) on an interior disk. The two potential upper bounds on every cluster, integrated over a disk, yield a positive lower energy deficit. Both potential inequalities are needed to prevent cancellation outside the selected interior disk.
11. **Exact subsequential dichotomy.** Combining the previous two results characterizes the existence of a canonical subsequence at Jordan range and winding +/-1. It does not characterize full-sequence convergence under nonextension.

## Unproved claims that must not be inferred

- A root limsup equal to one is not a root limit equal to one.
- An exponentially small inverse corner along a subsequence is not an eventual geometric envelope.
- Pointwise limsup equality at every spectral parameter is not local L1 convergence of potentials.
- A canonical subsequence does not rule out a noncanonical second subsequence.
- Individual scalar-corner information is not a bound on a larger inverse boundary determinant.
- Separate anchors in several components need not have a common good subsequence.
- A finite diagnostic table cannot establish any of these missing infinite quantifiers.

The manuscript therefore retains partial status. The earlier conversational 70% estimate has no rigorous calibration and is not a measure of the distance to a universal proof.
