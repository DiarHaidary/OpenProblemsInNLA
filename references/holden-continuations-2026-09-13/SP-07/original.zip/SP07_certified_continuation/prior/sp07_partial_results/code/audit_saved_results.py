"""Recompute saved search ratios and matrix identities without rerunning an optimizer.

This audits consistency of floating-point records; it does not certify exact
normality, exact spectral norms, or a universal mathematical bound.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from matching import bottleneck
from search import Model


def complex_list(value: list) -> np.ndarray:
    values = np.asarray(value, dtype=float)
    if values.ndim != 2 or values.shape[1] != 2 or not np.all(np.isfinite(values)):
        raise ValueError('Invalid real/imaginary spectral list.')
    return values[:, 0] + 1j*values[:, 1]


def audit(directory: Path) -> dict:
    paths = sorted(directory.glob('search_*.json'))
    if not paths:
        raise FileNotFoundError(f'No search_*.json files in {directory}')
    count = 0
    maxima = dict(ratio_record_error=0.0, norm_record_error=0.0,
                  bottleneck_record_error=0.0, unitarity_residual=0.0,
                  normality_relative_residual=0.0, full_norm_identity_error=0.0,
                  parameter_reconstruction_error=0.0)
    best = 0.0
    for path in paths:
        data = json.loads(path.read_text(encoding='utf-8'))
        for record in data['records']:
            a, b = complex_list(record['a']), complex_list(record['b'])
            n = record['n']
            U = np.asarray(record['U_real']) + 1j*np.asarray(record['U_imag'])
            if len(a) != n or len(b) != n or U.shape != (n, n):
                raise RuntimeError(f'Invalid dimensions in {path.name}')
            A, B = np.diag(a), U @ np.diag(b) @ U.conj().T
            M = (a[:, None]-b[None, :])*U
            norm = float(np.linalg.norm(M, 2))
            distance, _ = bottleneck(a, b)
            ratio = distance/norm
            perm = np.asarray(record['matching'], dtype=int)
            if sorted(perm.tolist()) != list(range(n)):
                raise RuntimeError(f'Invalid saved matching in {path.name}')
            matched_distance = float(np.max(abs(a-b[perm])))
            if abs(matched_distance-distance) > 1e-10*max(1., distance):
                raise RuntimeError(f'Saved matching is not optimal in {path.name}')
            model = Model(n, record['p'], record['complex_unitary'])
            model.rho = record['rho']
            _, (aa, bb, UU, _, _) = model.calculate(np.array(record['x']))
            errors = dict(
                ratio_record_error=abs(ratio-record['actual_ratio']),
                norm_record_error=abs(norm-record['norm'])/max(1., norm),
                bottleneck_record_error=abs(distance-record['bottleneck'])/max(1., distance),
                unitarity_residual=float(np.linalg.norm(U.conj().T@U-np.eye(n), 2)),
                normality_relative_residual=float(np.linalg.norm(B@B.conj().T-B.conj().T@B, 2)/max(1., np.linalg.norm(B, 2)**2)),
                full_norm_identity_error=abs(float(np.linalg.norm(A-B, 2))-norm)/max(1., norm),
                parameter_reconstruction_error=max(float(np.max(abs(a-aa))),float(np.max(abs(b-bb))),float(np.max(abs(U-UU))))
            )
            for key, value in errors.items():
                maxima[key] = max(maxima[key], value)
            if max(errors.values()) > 1e-8:
                raise RuntimeError(f'Consistency error in {path.name}: {errors}')
            if record['cut_ratio'] > ratio + 1e-9:
                raise RuntimeError('A Hall cut ratio exceeded the true bottleneck ratio.')
            count += 1
            best = max(best, ratio)
    return dict(status='Saved floating-point records pass consistency audit; not an exact or global certificate.',
                files=len(paths), records=count, maximum_recomputed_ratio=best, maxima=maxima)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path, nargs='?', default=Path('results'))
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = audit(args.directory)
    text = json.dumps(result, indent=2)+'\n'
    print(text, end='')
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
