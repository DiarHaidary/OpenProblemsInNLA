"""Exact bootstrapping of dimension-independent cubic Gram bounds.

The only initial bound is Lambda < 483/50, proved from the retained
interpolation endpoint. Every improved operator bound is justified by the
preceding exactly accepted stage, never by a numerical optimizer output.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys
from moment_model import model
from exact_global_bound import need,rational,positive_definite

SCOPE='all dimensions, p=4/3, m=2'

def _stage(data,cap):
    """Internal: cap must be a proved bound from the enclosing chain."""
    need(data.get('format')=='MI20-homogeneous-cubic-Gram-v1','Incorrect stage format')
    need(data.get('scope')==SCOPE,'Incorrect stage scope')
    lam=rational(data['lambda0']);h=rational(data['h'])
    need(F(8)<=lam<=cap,'Stage target outside the preceding enclosure')
    need(h>F(1,2) and (1+h)**3/h>cap,'Unjustified operator upper bound')
    mdl=model(lam,h);mats=mdl['matrices'];eq=mdl['equations'];nv=len(mdl['keys'])
    raw=data['gram_matrices'];need(len(raw)==len(mats),'Gram count mismatch')
    w=[rational(x) for x in data['multipliers']]
    need(len(w)==10 and w[-1]==-1,'Invalid normalization multiplier')
    lhs=[F(0)]*nv
    for rawz,mat in zip(raw,mats):
        n=len(mat);need(len(rawz)==n and all(len(row)==n for row in rawz),'Gram order mismatch')
        Z=[[rational(x) for x in row] for row in rawz];positive_definite(Z)
        for i in range(n):
            for j in range(n):
                for k in range(nv):lhs[k]+=Z[i][j]*mat[i][j][k]
    rhs=[sum(w[i]*eq[i][k] for i in range(10)) for k in range(nv)]
    need(lhs==rhs,'Nonexact Gram identity')
    hi=max(w[0],w[3])+max(w[1],w[5])+max(F(0),(w[2]+w[4])/2)
    lo=min(w[0],w[3])+min(w[1],w[5])+min(F(0),(w[2]+w[4])/2)
    need(hi<=0 and lo<0,'Coefficient bounds do not exclude the upper interval')
    # For Lambda<lam, the identity has RHS <= ((Lambda-lam)*lo-1) z.
    # Consequently any positive cubic solution has Lambda <= lam+1/lo.
    improved=lam+1/lo
    need(F(8)<=improved<lam,'Invalid strengthened bound')
    return {'status':'PASS','lambda0':str(lam),'h':str(h),
            'preceding_cap':str(cap),'coefficient_lower_bound':str(lo),
            'coefficient_upper_bound':str(hi),'new_lambda_cap':str(improved),
            'gram_matrices':len(mats),'coefficient_identities':nv}

def verify(data):
    need(data.get('format')=='MI20-cubic-Gram-chain-v1','Incorrect chain format')
    need(data.get('scope')==SCOPE,'Incorrect chain scope')
    stages=data.get('stages');need(isinstance(stages,list) and 0<len(stages)<=100,'Invalid chain length')
    cap=F(483,50);out=[]
    for stage in stages:
        res=_stage(stage,cap);out.append(res);cap=F(res['new_lambda_cap'])
    rounded=rational(data['reported_lambda_upper'])
    need(cap<=rounded<F(483,50),'Reported upper bound is not justified')
    return {'status':'PASS','scope':SCOPE,'stages':out,
            'exact_lambda_cap':str(cap),'reported_lambda_upper':str(rounded),
            'universal_upper_fourth_power':str(rounded/8),
            'upper_bound_expression':f'({rounded/8})^(1/4)',
            'acceptance_arithmetic':'integers and exact fractions only',
            'problem_solved':False}

if __name__=='__main__':
    p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'certificates/global_p4_3_m2_chain.json'
    print(json.dumps(verify(json.loads(p.read_text())),indent=2))
