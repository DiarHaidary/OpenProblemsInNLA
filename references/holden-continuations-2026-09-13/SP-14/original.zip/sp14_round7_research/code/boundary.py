"""Finite Toeplitz boundary diagnostics for the seventh SP-14 research note.

Floating-point outputs are diagnostics, not certified lower bounds or proofs of
infinite-sequence statements. Indices are zero based and T_n(a)[i,j] = a[i-j].
"""
from __future__ import annotations
from collections.abc import Callable, Mapping
import numpy as np
from numpy.typing import NDArray
from scipy.linalg import toeplitz, solve, svdvals, eigvals

CoefficientSource = Mapping[int, complex] | Callable[[int], complex]


def _get(source: CoefficientSource, k: int) -> complex:
    value = source(k) if callable(source) else source.get(k, 0.0)
    z = complex(value)
    if not np.isfinite(z.real) or not np.isfinite(z.imag):
        raise ValueError(f"Nonfinite Fourier coefficient at index {k}")
    return z


def matrix(source: CoefficientSource, n: int) -> NDArray[np.complex128]:
    if not isinstance(n, (int, np.integer)) or n < 1:
        raise ValueError("n must be a positive integer")
    col = [_get(source, j) for j in range(n)]
    row = [_get(source, -j) for j in range(n)]
    return np.asarray(toeplitz(col, row), dtype=np.complex128)


def first_inverse_row(C: NDArray[np.complex128]) -> NDArray[np.complex128]:
    C = np.asarray(C, dtype=np.complex128)
    if C.ndim != 2 or C.shape[0] != C.shape[1] or not C.size:
        raise ValueError("C must be a nonempty square matrix")
    if not np.all(np.isfinite(C)):
        raise ValueError("C must have finite entries")
    e = np.zeros(C.shape[0], dtype=complex)
    e[0] = 1
    # Transpose, not conjugate transpose: these are the row entries themselves.
    return solve(C.T, e, assume_a="gen", check_finite=True)


def corner(source: CoefficientSource, n: int) -> complex:
    """Return (T_{n+1}(c)^(-1))[0,n], evaluated in floating point."""
    if n < 1:
        raise ValueError("n must be positive")
    return complex(first_inverse_row(matrix(source, n + 1))[-1])


def row_increment(source: CoefficientSource, n: int) -> dict[str, float | complex | bool]:
    """Check the bordering identity between sizes n and n+1."""
    C = matrix(source, n)
    D = matrix(source, n + 1)
    y = first_inverse_row(C)
    z = first_inverse_row(D)
    v = D[-1, :-1]
    vCinv = solve(C.T, v, assume_a="gen")
    actual = z - np.r_[y, 0j]
    predicted = z[-1] * np.r_[-vCinv, 1 + 0j]
    return {
        "n": n,
        "corner": complex(z[-1]),
        "increment_norm": float(np.linalg.norm(actual)),
        "identity_residual": float(np.linalg.norm(actual - predicted)),
        "predicted_norm": float(abs(z[-1]) * np.sqrt(1 + np.linalg.norm(vCinv) ** 2)),
        "certified": False,
    }


def boundary_block(source: CoefficientSource, n: int, p: int) -> NDArray[np.complex128]:
    """Top-right p by p block of T_{n+p}(c)^(-1)."""
    if p < 1 or n < 1:
        raise ValueError("n and p must be positive")
    C = matrix(source, n + p)
    rhs = np.eye(n + p, dtype=complex)[:, n:n + p]
    return solve(C, rhs, assume_a="gen")[:p, :]


def spectral_deficit(source: CoefficientSource, n: int, canonical_energy: float) -> float:
    if not np.isfinite(canonical_energy) or canonical_energy < 0:
        raise ValueError("canonical_energy must be finite and nonnegative")
    ev = eigvals(matrix(source, n), check_finite=True)
    return float(canonical_energy - np.mean(np.abs(ev) ** 2))


def unit_index_singular_diagnostic(source: CoefficientSource, n: int) -> dict[str, float | bool]:
    """Compare the corner with s_min(T_n(z*c)). No numerical certification."""
    C = matrix(source, n + 1)
    A = C[:n, 1:]
    sC = svdvals(C)
    k = abs(first_inverse_row(C)[-1])
    s = float(svdvals(A)[-1])
    M = float(sC[0])
    K = 1 / float(sC[-1])
    return {
        "n": n,
        "corner_abs": float(k),
        "smallest_singular_value": s,
        "lower_bound_diagnostic": float(k / (2 * K * K)),
        "upper_bound_diagnostic": float(2 * M * M * k),
        "certified": False,
    }


def unimodular_certificate_diagnostic(
    source: CoefficientSource,
    n: int,
    c1_upper: float,
) -> dict[str, float | bool]:
    """Evaluate the explicit inverse-corner certificate for c = z^(-1) a.

    Assumptions, which this routine cannot verify: |c| = 1 on the circle and
    sum_k |k| |c_k|^2 <= c1_upper < 1. Under exact evaluation these give the
    uniform lower bound gamma^2 = 1-c1_upper. The floating-point corner here
    is NOT a certified lower enclosure. A zero diagnostic corner is rejected.
    """
    if not np.isfinite(c1_upper) or not 0 <= c1_upper < 1:
        raise ValueError("c1_upper must be a finite number in [0, 1)")
    k = abs(corner(source, n))
    if k == 0:
        raise ValueError("Computed corner is zero; no finite certificate reported")
    gamma2 = 1.0 - c1_upper
    bound = c1_upper / (n * gamma2) + 2 * max(0.0, -float(np.log(k))) / n
    return {
        "n": n,
        "corner_abs": float(k),
        "analytic_gamma_squared_under_assumptions": float(gamma2),
        "energy_upper_bound_diagnostic": float(bound),
        "certified": False,
    }
