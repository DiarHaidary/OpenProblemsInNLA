# Status

SP-07 remains unresolved by this package.

## Proved here

- The exact sharp constant sqrt(28/27) for normal rank-one-reflection anti-pairs,
  in arbitrary dimension. The upper proof and the attaining example are both supplied.
- The sharp local three-coordinate reflection inequality used in that theorem.
- An explicit 35-positive-monomial / 3-negative-monomial AM–GM certificate with
  43 nonzero rational allocations. Exact polynomial and barycenter checks pass.
- A real rank-r finite-dimensional reduction to n <= 3r^2 + 7r − 1.
- A nondecreasing reflection-rank hierarchy whose supremum is the unrestricted
  constant, using the previous package's universal real-reflection embedding.

## Rechecked, not new

The prior n=5 and n=193 rational counterexamples passed both exact positivity
methods again. They certify larger lower bounds than the sharp rank-one constant.
The global bracket remains unchanged in this continuation.

## Not established

No exact value of the unrestricted constant; no sharp all-rank upper bound;
no exact unrestricted c_3; no exact rank-two constant; no proof of chain-family
extremality; no rank cutoff or convergence rate for the reflection hierarchy.

The general proofs were checked within this work session, with the supplied
arithmetic and regression audits. Independent external mathematical review and
proof-assistant verification have not been obtained. Historical novelty is not claimed.
This work is not a basis for marking the repository's problem solved.
