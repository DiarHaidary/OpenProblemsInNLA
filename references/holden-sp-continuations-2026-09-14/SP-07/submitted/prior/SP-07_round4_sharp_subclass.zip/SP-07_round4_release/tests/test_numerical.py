from pathlib import Path
import sys, itertools, unittest, json
import numpy as np
from scipy.linalg import null_space
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from numerical import reflection,residual,bottleneck,matching,independent_hall,compress_moments,moment_columns
ROOT=Path(__file__).resolve().parents[1]

class NumericalTests(unittest.TestCase):
    def test_disk_identity(self):
        rng=np.random.default_rng(72019)
        for _ in range(1500):
            m,b,y=rng.normal(size=3)+1j*rng.normal(size=3)
            t=float(np.linalg.norm([[m,b],[b,y]],2))*rng.uniform(.8,1.2)
            R=t*t-abs(m)**2
            if R<=0:continue
            det=np.linalg.det(t*t*np.eye(2)-np.array([[m,b],[b,y]]).conj().T@np.array([[m,b],[b,y]])).real
            formula=R*(t*t*(1-abs(b)**2/R)**2-abs(y+np.conj(m)*b*b/R)**2)
            self.assertAlmostEqual(det,formula,delta=1e-10*(1+abs(det)))

    def test_rank_one_sharp_bound(self):
        rng=np.random.default_rng(773)
        worst=0
        for n in [2,3,4,5,8,13,21]:
            for _ in range(80):
                a=rng.normal(size=n)+1j*rng.normal(size=n)
                v=rng.normal(size=n)+1j*rng.normal(size=n);v/=np.linalg.norm(v)
                eps=np.linalg.norm(residual(a,v[:,None]),2)
                ratio=bottleneck(a)/eps;worst=max(worst,ratio)
                self.assertLessEqual(ratio,np.sqrt(28/27)+1e-10)
        a0=np.array([1,(4+5j*np.sqrt(3))/7,(2-1j*np.sqrt(3))/7]);v0=np.sqrt([1/4,5/8,1/8])
        self.assertAlmostEqual(bottleneck(a0)/np.linalg.norm(residual(a0,v0[:,None]),2),np.sqrt(28/27),places=13)
        for _ in range(300):
            a=a0+1e-3*(rng.normal(size=3)+1j*rng.normal(size=3));v=v0+1e-3*rng.normal(size=3);v/=np.linalg.norm(v)
            self.assertLessEqual(bottleneck(a)/np.linalg.norm(residual(a,v[:,None]),2),np.sqrt(28/27)+1e-10)

    def test_pinching_outliers(self):
        rng=np.random.default_rng(97034)
        for r in [1,2,3,4]:
            for n in [2*r+1,4*r+3,8*r+5]:
                for _ in range(25):
                    a=rng.normal(size=n)+1j*rng.normal(size=n)
                    F=np.linalg.qr(rng.normal(size=(n,r)))[0];Q=null_space(F.T)
                    ep=np.linalg.norm(residual(a,F),2)
                    pin=2*max(np.linalg.norm(F.T@(a[:,None]*F),2),np.linalg.norm(Q.T@(a[:,None]*Q),2))
                    self.assertAlmostEqual(ep,pin,delta=2e-10*(1+ep))
                    self.assertLessEqual(np.sum(abs(a)>ep/2+1e-9),2*r)

    def test_symmetric_hall_reduction(self):
        cases=0
        for n in [1,2,3,4]:
            positions=[(i,j) for i in range(n) for j in range(i,n)]
            for bits in range(1<<len(positions)):
                E=np.zeros((n,n),dtype=bool)
                for k,(i,j) in enumerate(positions):E[i,j]=E[j,i]=bool(bits&(1<<k))
                res=independent_hall(E);has=np.all(matching(E)[0]>=0)
                self.assertEqual(res is None,has)
                if res is not None:
                    S,N=res;self.assertLess(len(N),len(S));self.assertFalse(E[np.ix_(S,S)].any())
                cases+=1
        self.assertEqual(cases,1098)

    def test_rank_one_compression(self):
        rng=np.random.default_rng(41892)
        base=np.array([1,(4+5j*np.sqrt(3))/7,(2-1j*np.sqrt(3))/7]);v0=np.sqrt([1/4,5/8,1/8])
        count=0
        for n in [4,6,11,20,35]:
            for _ in range(20):
                a=np.r_[base,.979+1e-4*(rng.normal(size=n-3)+1j*rng.normal(size=n-3))]
                v=np.r_[v0,1e-4*rng.normal(size=n-3)];v/=np.linalg.norm(v)
                ep=np.linalg.norm(residual(a,v[:,None]),2);d=bottleneck(a)
                self.assertGreater(d,ep)
                O=np.flatnonzero(abs(a)>ep/2)
                self.assertEqual(len(O),2)
                V=np.zeros((n,3));V[O[0],0]=1;V[O[1],1]=1
                rest=v.copy();rest[O]=0;rest/=np.linalg.norm(rest);V[:,2]=rest
                ac=np.diag(V.T@(a[:,None]*V));vc=V.T@v
                delta=np.min(abs(ac[:2,None]+ac[None,:2]))
                self.assertGreaterEqual(delta,d-1e-10)
                self.assertLessEqual(np.linalg.norm(residual(ac,vc[:,None]),2),ep+1e-10)
                count+=1
        self.assertEqual(count,100)

    def test_finite_moment_reduction(self):
        rng=np.random.default_rng(23307);logs=[]
        for r,n in [(1,24),(2,45),(3,80)]:
            for rep in range(5):
                a=rng.normal(size=n)+1j*rng.normal(size=n)
                F=np.linalg.qr(rng.normal(size=(n,r)))[0]
                ep=np.linalg.norm(residual(a,F),2);t=ep*.505
                keep=np.flatnonzero(abs(a)>t)
                an,Fn,log=compress_moments(a,F,t,keep)
                self.assertLessEqual(len(an),3*r*(r+1)+len(keep))
                self.assertLess(np.linalg.norm(residual(an,Fn),2),2*t+1e-7)
                G0=F.T@F;G1=Fn.T@Fn
                self.assertLess(np.linalg.norm(G0-G1),1e-7)
                self.assertLess(np.linalg.norm(F.T@(a[:,None]*F)-Fn.T@(an[:,None]*Fn)),1e-7)
                log.update({'original_norm':float(ep),'new_norm':float(np.linalg.norm(residual(an,Fn),2)),'two_t':float(2*t)})
                logs.append(log)
        # A nontrivial matching obstruction is retained, not just the moments.
        n=30;a=np.r_[np.array([1,(4+5j*np.sqrt(3))/7,(2-1j*np.sqrt(3))/7]),np.full(n-3,.979)]
        v=np.r_[np.sqrt([1/4,5/8,1/8]),1e-4*rng.normal(size=n-3)];v/=np.linalg.norm(v);F=v[:,None]
        ep=np.linalg.norm(residual(a,F),2);t=ep/2+1e-4;delta=1.97
        self.assertGreater(delta,2*t)
        S,N=independent_hall(abs(a[:,None]+a[None,:])<=delta)
        keep=sorted(set(np.flatnonzero(abs(a)>t))|set(N))
        an,Fn,log=compress_moments(a,F,t,keep)
        self.assertLessEqual(len(an),9)
        self.assertGreater(bottleneck(an),delta)
        self.assertLess(np.linalg.norm(residual(an,Fn),2),2*t+1e-7)
        log.update({'retained_Hall_threshold':delta,'new_matching_distance':bottleneck(an),'two_t':float(2*t)})
        logs.append(log)
        (ROOT/'results/numerical_moment_reductions.json').write_text(json.dumps(logs,indent=2))

if __name__=='__main__':unittest.main(verbosity=2)
