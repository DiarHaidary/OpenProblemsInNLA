# Internal proof audit

This records an author-side audit, not independent review.

## The structural replacement

- The old bound protected q whole right directions of a D_l-row matrix, costing
  D_l*q scalar constraints. The new constraints protect q Frobenius directions of
  the entire output matrix. Each is exactly one scalar equation. They do not fix
  whole columns, and the proof no longer demands the same full operator bound.
- Two Gaussian quantities are kept distinct: E[ZZ^T] controls the Frobenius mean of
  L_V Z; Cov(vec Z) controls its largest covariance eigenvalue. Neither is inferred
  from the other. Full-covariance truncation is justified by both range orthogonality
  and coefficient-projection domination.
- The norm on k-by-k matrices is (sum omega_i ||V B_i||^(2l))^(1/(2l)). It is a norm
  because B_i span. The norming net is deterministic and has exp(O_l(k^2)) points
  in this norm. No Euclidean condition-number comparison appears.
- Polarization bounds the multilinear norm by l^l/l! times the polynomial supremum.
  The net extension works for matrix outputs. Gaussian norm concentration uses
  both covariance trace and operator norm. A union bound introduces k, not D_l.
- The arbitrary output dimension is reduced using V^T V and an isometry of ranges.
  Odd l has vector output; that output is not falsely treated as scalar/rank one.
- In the mixed trace error, ||LZ||_F ||J||_F replaces ||Z||_op ||L||_F ||J||_F.
  The new exponent follows from l+j+c=s+a-d<=2s-1, with j+c<=s-1.

## Compression and quantifiers

- Head and mixed tensor metrics use positive ranges only. Zero head rows, zero
  tails, and singular covariance matrices are accounted for. Normalizations are
  proof devices; returned weights remain on original rows.
- The head is an exact optimal rank-k subspace of the fixed pre-reduced input.
  This is permitted for an existence theorem with no runtime target. Its tail
  cost is a lower bound for every compressed positive-contraction query.
- Every monomial in the even-power expansion is assigned a case. Pure tails are
  recombined before scalar comparison. Balanced and one-cross terms retain their
  separately proved variance/anisotropic bounds.
- At each inner step, scalar invariants and the current output directions are
  imposed simultaneously. The output eigenspaces may change at the next step.
  Only scalar invariants must persist exactly; output-error bounds are summed.
- Gaussian estimates use the full pre-round positive measure and fixed common
  mass. A fractional subset removes positive covariance terms; coefficient
  projection contracts them. The intermediate fractional measure need not obey
  a fresh matrix invariant.
- Actual partial-coloring outputs lie in [-1,1]. Fractions are frozen with positive
  weights. Full entries double mass and their count at least halves. Frozen entries
  remain in every state invariant. The measure is not assumed pointwise dominated
  by the original measure.
- Geometric sums of eta and sqrt(eta) bound all outer errors and close the matrix
  induction. m0 contains L^4; frozen exceptions add only one more logarithm.
- Preliminary original-row reduction removes log(original n) and log(ambient d).
  Positive weight composition at epsilon/8 twice stays within epsilon. Zero
  optimum is treated separately through head-only linear-form preservation and
  Gaussian averaging, including zero-cost queries.

## Lower bounds

- The variable-density core uses actual query directions and a rectangular stable
  evaluation matrix. Spectral truncation selects columns only; it does not invent
  linear combinations as legal nonlinear cost queries.
- Random auxiliary vectors are independent between entire Haar bases, not within
  one basis. Each whole basis is orthonormal, allowing support conversion without
  a sparse-subset cutoff. The density-dependent cost factor is retained.
- The unbounded-noise construction has arbitrarily many auxiliary coordinates,
  but every query rank remains k. Its finite interpolation uses even powers.
- Small ranks are handled with a separate explicit positive-weight block example
  and fixed-exponent constants, not by assuming an asymptotic threshold is uniform.
- The maximum of the two lower families matches the claimed minimum-of-sums rate
  by the two cases epsilon >= k^(-3/2) and epsilon <= k^(-3/2).

## Limits

The finite tests do not verify imported theorems, certify a large-rank random
realization, implement the full existence construction, or prove a uniform
probability statement by sampling. The exact certificate is a moment coreset,
not an implementation of constrained partial coloring. No non-even result is
inferred from even moments or continuity. See STATUS.md.
