from pathlib import Path
import json, shutil, zipfile, hashlib, subprocess, sys, textwrap
ROOT=Path('/mnt/data/SP10_round2_results')
(ROOT/'src').mkdir(parents=True, exist_ok=True)
(ROOT/'certificates').mkdir(exist_ok=True)
(ROOT/'tests').mkdir(exist_ok=True)
report=r'''# SP-10, second continuation: substitution theorems and sharp half graphs

**Status: partial mathematical progress, not a complete solution of SP-10.**

The statement still to be proved or refuted for an arbitrary finite simple graph is

\[
\operatorname{mr}(G)+\operatorname{mr}(\overline G)\le |V(G)|+2.
\]

No theorem in this report establishes that universal statement. In particular, an arbitrary graph need not have the modules required by the substitution theorem below. The complete proofs in this continuation concern specified classes, a sharp auxiliary dimension bound, and a precise obstruction to a proposed shortcut. No claim of priority or independent referee verification is made.

## 1. Definitions and the retained first-round work

For a graph G on n vertices, S(G) consists of the real symmetric n by n matrices A with A_ij nonzero exactly at the edges, for distinct i,j. Diagonal entries are unrestricted. Write mr(G) for the minimum rank in S(G), and mr_+(G) for the corresponding positive-semidefinite minimum.

It is important to distinguish the parameter

\[
\rho(G)=\min\{\operatorname{rank}A:A\in S(G),\ A\succeq0,\ A_{vv}>0\text{ for every }v\}.
\]

Thus rho uses a faithful Gram representation in which every vertex vector is nonzero. If i(G) is the number of isolated vertices, then

\[
\rho(G)=\operatorname{mr}_+(G)+i(G).
\]

Indeed, isolated nonzero vectors must be mutually orthogonal and orthogonal to all other vectors. On the graph with its isolated vertices removed, a faithful PSD representation automatically has no zero rows. Throughout this report,

\[
\operatorname{mr}(G)\le\operatorname{mr}_+(G)\le\rho(G).
\]

The first-round archive is retained, unmodified, when available, under `prior/SP10_partial_results.zip`. Its report derived the square-root universal estimate using Hall's Delta Theorem; provided exact path and bull constructions; and supplied finite graph-atlas certificates. Those results and their recorded limitations remain part of the research record. This continuation does not retroactively turn their finite checks into a general proof.

The new self-contained results in Sections 2--7 do **not** depend on Hall's January 2026 preprint. Section 8 separately records the stronger external-input route discussed during this continuation.

## 2. Two elementary ingredients

### Lemma 2.1: a nonzero representation with one rank saving

If a graph H of order t has at least one edge, then rho(H) <= t-1. More precisely, if c_e(H) is the number of connected components containing an edge, then

\[
\rho(H)\le t-c_e(H).
\]

**Proof.** On each nontrivial connected component, use its Laplacian. This is PSD, has positive diagonal, has exactly the required off-diagonal support, and has rank one less than its order. Use the scalar matrix (1) for each isolated vertex. Their direct sum proves the assertion. This also gives a rational Gram factor: oriented edge-incidence rows, with one extra coordinate for each isolated vertex. No rank-minimality claim is needed. QED.

### Lemma 2.2: the chromatic Nordhaus--Gaddum inequality

For every graph H of order t >= 1,

\[
\chi(H)+\chi(\overline H)\le t+1.
\]

**Proof.** Induct on t. If some vertex v can be deleted without reducing one of the two chromatic numbers, apply induction to H-v and add at most one for reinserting v on the other side. Otherwise both graphs are vertex-critical for their respective chromatic numbers. A vertex-critical k-chromatic graph has every degree at least k-1: otherwise a coloring after deleting a lower-degree vertex could be extended. For any vertex v, this gives

\[
\chi(H)+\chi(\overline H)-2
 \le \deg_H(v)+\deg_{\overline H}(v)=t-1.
\]

This proves the claim. QED.

A proper coloring of the complement of H is equivalently a partition of V(H) into cliques of H.

## 3. A three-dimensional subspace construction

Fix a graph H on t vertices. Choose nonzero faithful Gram vectors u_i for H in a space of dimension rho(H). Partition V(H) into c=chi(complement H) cliques, and write C(i) for the clique containing i. Add a private two-dimensional coordinate space E_C for each clique in the partition. All these spaces are orthogonal to one another and to the original Gram space. Define

\[
S_i=\operatorname{span}(u_i)\oplus E_{C(i)}.
\]

Then each S_i has dimension three. If ij is a nonedge of H, the vectors u_i,u_j are orthogonal and the two clique coordinate spaces are different. Therefore S_i and S_j are orthogonal. If ij is an edge, the bilinear pairing between S_i and S_j is nonzero, because the pairing of u_i and u_j is nonzero. The ambient dimension is

\[
\rho(H)+2\chi(\overline H).
\]

The construction does not assert that every pair of nonzero vectors from adjacent subspaces has nonzero inner product. The finite-avoidance argument in the next theorem is necessary to obtain that stronger requirement for the actual vertex vectors.

## 4. The substitution theorem

Let H[F_1,...,F_t] denote graph substitution: replace vertex i of H by F_i, and put all possible edges between modules i,j exactly when ij is an edge of H. Complementation commutes with this operation:

\[
\overline{H[F_1,\ldots,F_t]}
 =\overline H[\overline{F_1},\ldots,\overline{F_t}].
\]

### Theorem 4.1: a general rank-sharing bound

Suppose each F_i has a faithful nonzero Gram representation of rank r_i >= 3. Then

\[
\boxed{\rho(H[F_1,\ldots,F_t])
 \le \sum_i(r_i-3)+\rho(H)+2\chi(\overline H).}
\]

**Proof.** Use the subspaces S_i from Section 3. Add a private space P_i of dimension r_i-3 for each module; these spaces are orthogonal to all other summands. The space T_i=S_i direct-sum P_i has dimension r_i, so the selected Gram representation of F_i can be embedded isometrically into T_i. This preserves all inner products inside F_i.

The remaining choice is the orthogonal orientation of each embedded representation within T_i. For a required edge between modules i and j, and a fixed vertex in each module, their inner product is a real-analytic function of the two orientations. This function is not identically zero: both vertex vectors are nonzero, orthogonal transformations can send each to any vector of the same length, and the pairing between T_i,T_j is not zero. A proper real-analytic zero set has empty interior on the product of the relevant special orthogonal groups, which are connected because r_i >= 3. Equivalently, one may make successive choices while avoiding finitely many proper algebraic conditions. There are only finitely many required pairs. Orientations avoiding every zero condition therefore exist.

For a nonedge of H, the whole spaces T_i,T_j are orthogonal, so every forbidden cross-module product remains zero. Thus the resulting representation has exactly the support of the substituted graph. The stated ambient dimension bounds its rank. QED.

### Corollary 4.2: complementary module pairs

If, in addition, complement F_i has a faithful nonzero representation of rank s_i >= 3, then

\[
\begin{split}
\rho(H[F_i])+\rho(\overline H[\overline{F_i}])
\le &\sum_i(r_i+s_i-6)\\
 &+\rho(H)+\rho(\overline H)
 +2\chi(H)+2\chi(\overline H).
\end{split}
\]

In particular, suppose |V(F_i)|=n_i, r_i+s_i <= n_i+2, and N=sum n_i. If H is neither complete nor edgeless, then both H and its complement contain an edge, and Lemmas 2.1--2.2 give

\[
\boxed{\rho(H[F_i])+\rho(\overline{H[F_i]})\le N.}
\]

Indeed, the four contributions are bounded by N-4t, 2t-2, and 2(t+1), respectively. If H is complete or edgeless, the corresponding bound is

\[
\boxed{\rho(H[F_i])+\rho(\overline{H[F_i]})\le N-t+3,}
\]

because the sum of the two rho values and the sum of the two chromatic numbers both equal t+1. Consequently, for any quotient H with t >= 3, these module hypotheses imply the stronger rank-sum bound N. For t=2 the bound is N+1, and for t=1 it is N+2.

This theorem permits an arbitrary quotient graph. It does not permit arbitrary modules: the rank hypotheses on every module are essential.

## 5. Path modules, and up to two singleton modules

For m >= 4, a path has faithful nonzero PSD rank m-1, and its complement has faithful nonzero PSD rank three. The first statement follows from the tridiagonal kernel recurrence and the path Laplacian. For the second, the induced first four vertices give a rank-three lower bound, and the following construction gives the upper bound.

Choose nonzero, pairwise nonparallel vectors v_1,...,v_m in R^3 with consecutive vectors perpendicular and all other distinct pairs nonperpendicular. Start with (1,0,0), (0,1,0), (1,0,1). At the next step, choose a vector in the two-dimensional perpendicular plane of the last vector, avoiding the finitely many lines that would create any other perpendicularity or parallelism. The excluded sets are proper because earlier vectors are pairwise nonparallel. Rational choices, followed by clearing denominators, are possible. The first three vectors already span R^3.

### Theorem 5.1: arbitrary quotients with path modules

Let every vertex of an arbitrary t-vertex graph H be replaced by a path P_(m_i), with m_i >= 4. Put N=sum m_i. Then

\[
\operatorname{mr}_+(G)+\operatorname{mr}_+(\overline G)
\le\rho(G)+\rho(\overline G)
\le
\begin{cases}
N+2,&t=1,\\
N+1,&t=2,\\
N,&t\ge3.
\end{cases}
\]

This is an immediate application of Corollary 4.2 with r_i=m_i-1 and s_i=3. No external minimum-degree theorem is needed.

### Theorem 5.2: allowing up to two unexpanded vertices

Let p >= 1 quotient vertices be replaced by such paths and let q other quotient vertices remain singletons. If q <= 2, the resulting graph satisfies the PSD graph complement conjecture.

**Proof.** Write S for the p expanded quotient vertices and t=p+q. Give an expanded module its three-dimensional subspace, using clique partitions of H[S] and its complement. A singleton only uses the nonzero line span(u_i), with no added clique coordinates. Let N be the total order. The private-dimension contribution from both sides is N-q-4p. The total bound is therefore

\[
\rho(G)+\rho(\overline G)
\le N-q-4p+\rho(H)+\rho(\overline H)
 +2\chi(H[S])+2\chi(\overline{H[S]}).
\]

If H is neither complete nor edgeless, this is at most N+q, by the same two elementary lemmas. This is at most N+2. If H is complete or edgeless, the bound is N-p+3, again at most N+2 because p>=1. QED.

This extension is not a way to represent every graph: external vertices of a substituted module must have uniform adjacency to the whole module, and the number of singleton modules is restricted.

## 6. Half graphs: an additional exact sharp family

For k >= 2, let H_k have vertices a_1,...,a_k,b_1,...,b_k, with edges a_i b_j exactly when i <= j. There are no edges within either part.

### Theorem 6.1

\[
\boxed{\operatorname{mr}(H_k)=\operatorname{mr}_+(H_k)
 =\operatorname{mr}(\overline{H_k})
 =\operatorname{mr}_+(\overline{H_k})=k+1.}
\]

Thus both complement rank sums equal 2k+2=|V(H_k)|+2.

**Upper bound for H_k.** Work in R^(k+1) with orthonormal basis e_0,...,e_k. Assign

\[
x_{a_i}=e_i,\qquad
x_{b_j}=e_0+\sum_{h=1}^{j-1}e_h-j e_j.
\]

The a-vectors are mutually orthogonal. If j<ell, the inner product of the two b-vectors is 1+(j-1)-j=0. Moreover, the product of a_i with b_j equals 1 for i<j, -j for i=j, and zero for i>j. This gives precisely H_k. The a-vectors span the last k coordinates and every b-vector has first coordinate one, so the rank is k+1.

**Upper bound for the complement.** Assign

\[
y_{a_i}=e_0-\sum_{h=i}^{k}e_h,\qquad y_{b_j}=e_0+e_j.
\]

Different b-vectors have product one. Different a-vectors have product 1+k-max(i,ell)+1, which is positive. The cross product equals zero for i<=j and one for i>j, exactly as required. The b-vectors are independent, and the nonzero a_1-vector is orthogonal to all of them. Hence the rank is k+1.

**Why the lower bounds apply to indefinite symmetric matrices too.** Any real symmetric matrix of rank r has a factorization X J X^T, where J is a nonsingular diagonal matrix with diagonal entries +1 or -1. We can therefore reason about vertex vectors in an r-dimensional nondegenerate symmetric bilinear space, rather than assume positive semidefiniteness.

For H_k, the cross block is upper triangular with nonzero diagonal, so r>=k. If r=k, the a-vectors form an orthogonal basis of the entire bilinear space. Each has nonzero squared length, since an isotropic vector orthogonal to the other basis vectors would belong to the radical. The vector b_1 is orthogonal to a_2,...,a_k, so it is a nonzero multiple of a_1. But b_2 has nonzero product with a_1, forcing a nonzero product between b_1,b_2, contrary to their nonadjacency. Thus r>=k+1.

For the complement, suppose sum c_j b_j=0 in a faithful representation. Pair successively with a_2,a_3,...,a_k. The strictly triangular cross pattern gives c_1=...=c_(k-1)=0. The vector b_k is nonzero because it has an edge to another b-vertex, so c_k=0 as well. Thus the b-vectors are independent. The nonzero a_1-vector is orthogonal to all of them. An ambient dimension at most k would force a_1 to be zero, because the bilinear form is nondegenerate. Hence r>=k+1. QED.

The case k=1 is deliberately excluded: H_1 is K_2 and does not have these rank values.

## 7. A sharp degeneracy bound, and why a tempting completion fails

Let d(G) be degeneracy: the largest minimum degree of an induced subgraph.

### Theorem 7.1

For every nonempty graph G,

\[
\boxed{\rho(\overline G)\le 2d(G)+1.}
\]

**Proof.** Order the vertices so that each vertex has at most d earlier neighbors in G. In dimension 2d+1, construct the vectors in this order, maintaining linear independence of every set of at most d+1 chosen vectors. For a new vertex, let W be the span of its at most d earlier neighbors. The permitted space W-perpendicular has dimension at least d+1.

For any earlier nonneighbor vector v, its inner product must be nonzero. The forbidden hyperplane v-perpendicular cannot contain W-perpendicular: otherwise v belongs to W, violating the maintained independence of at most d+1 vectors. To preserve that independence at the next step, avoid the span of every set of at most d earlier vectors. None of these spans can contain the permitted space, by the dimension bound. A finite union of proper linear subspaces cannot cover the permitted space. Choose outside this union. All required and forbidden products, as well as the independence invariant, are preserved. This proves the induction. The same argument works over rational coordinates before passing to real Gram matrices. QED.

### Proposition 7.2: sharpness and a failed bridge

The half graph has

\[
d(H_k)=\left\lfloor\frac{k+1}{2}\right\rfloor.
\]

To see the lower bound, use the complete bipartite subgraph with a-indices 1,...,d and b-indices d,...,k. For the upper bound, take an induced subgraph of positive minimum degree delta. It has at least delta a-vertices. Its largest a-index is therefore at least delta, and that vertex has at most k-delta+1 possible b-neighbors. Thus delta<=k-delta+1.

For k=2d, Theorem 6.1 gives rho(complement H_(2d))=2d+1, so Theorem 7.1 is exactly sharp for every d>=1. In particular, the proposed stronger bridge

\[
\operatorname{mr}_+(\overline G)\le d(G)+2
\]

is false, even with mr rather than mr_+ on the left. It fails for every H_k with k>=4; the gap grows without bound. Combining Hall's rank bound with that false bridge would appear to prove SP-10, but this family rules out that argument.

For forests, d<=1, the construction gives rho(complement G)<=3. A Laplacian on every component gives mr_+(G)<=n-c, where c is the number of components, including isolated vertices. Hence all nonempty forests satisfy the PSD graph complement conjecture. This is a class-specific proof, not an extension to larger degeneracy.

## 8. Separately recorded external-input route

The preceding continuation identified the stronger universal estimate

\[
\operatorname{mr}_+(G)+\operatorname{mr}_+(\overline G)
 \le\left\lfloor\frac{4n+2}{3}\right\rfloor.
\]

Here is the exact dependency, rather than a claim that the self-contained arguments above prove it. Assume the two external inputs:

1. Hall's Delta Theorem and minor monotonicity of the PSD Strong-Arnold parameter, yielding mr_+(G)<=n-d(G).
2. The degeneracy Nordhaus--Gaddum inequality attributed in the preceding continuation to Mitchell:
   d(G)+d(complement G)>=ceil((2n-2)/3).

Adding the rank bounds gives 2n-ceil((2n-2)/3)=floor((4n+2)/3). The same bound holds for rho: apply the Hall/degeneracy argument to a nontrivial component attaining positive degeneracy, and use direct sums and positive scalar matrices on isolated vertices. If the graph is edgeless, rho=n and d=0 directly.

The algebraic implication is complete, but it still has coefficient 4/3 rather than one. Its external attribution is recorded separately from the self-contained contribution. This reconstruction does not manufacture missing bibliographic details for Mitchell's primary source. The exact version and bibliographic record should be retained from the earlier source audit rather than guessed.

Conditional on those two inputs, the mixed-module estimate in Theorem 5.2 improves to

\[
\rho(G)+\rho(\overline G)
 \le N+2+\left\lfloor\frac{q-2p+2}{3}\right\rfloor.
\]

Thus q<=2p suffices for SP-10 in that mixed-module family. The self-contained q<=2 assertion does not require either external input.

## 9. Computational artifacts and their limits

The included source generates the two explicit integer Gram factors for half graphs, and rational Gram factors for selected path-substitution graphs. The latter uses oriented incidence representations for the quotient, exact clique colorings on expanded quotient vertices, weighted local path representations, and rational plane rotations. A bounded orientation search is allowed to fail; failure is not treated as a counterexample.

Every delivered successful record is checked by exact rational inner products at every distinct vertex pair and exact rational Gaussian elimination. The verifier ignores any claimed ranks and recomputes them. A saved execution log, when present, records the completed checks. No finite computation is a substitute for the universal proofs of the stated families. No floating-point rank tolerance is used.

The formula proofs in Sections 4--7 stand independently of whether the optional generation program succeeds on every requested fixture. The original archive's old graph-atlas logs are not claimed to be new tests of this continuation.

## 10. The precise remaining gap

To finish SP-10 one still needs an argument for an arbitrary graph lacking the module structure above. Theorem 4.1 does not yield a graph decomposition, and assigning every vertex to a singleton removes its dimension savings. Theorem 7.1 cannot simply be improved from 2d+1 to d+2: the exact half-graph lower bound disproves that proposed improvement. The externally recorded 4n/3 estimate likewise does not imply n+2.

Accordingly, this report must not be submitted or described as a complete proof or disproof of SP-10. Its contributions are the fully specified substitution statements and proofs, the additional sharp family, the sharp auxiliary degeneracy bound, and reproducible exact constructions.

## Source record

- User-specified SP-10 repository entry: https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/eigenvalues-and-inverse-problems/SP-10
- First-round report and archive, retained under `prior/` when available.
- H. Tracy Hall, *The Delta Theorem: A dimension bound for faithful orthogonal graph representations*, arXiv:2601.01211v1, January 3, 2026: https://arxiv.org/html/2601.01211v1
- F. Barioli, S. M. Fallat, H. Gupta, Z. Li, *The weak version of the graph complement conjecture and partial results for the delta conjecture*, arXiv:2505.24577v1: https://arxiv.org/html/2505.24577v1
- C. Erickson, L. Gan, J. Kritschgau, J. C.-H. Lin, S. Spiro, *Complementary Vanishing Graphs*, arXiv:2207.07294v1: https://arxiv.org/html/2207.07294v1

These references supply context and the separately identified external inputs. No claim that they establish the full conjecture is made. The self-contained proofs above do not require an unreported current repository status or a guessed publication update.
'''
(ROOT/'REPORT.md').write_text(report)
code=r'''#!/usr/bin/env python3
"""Exact SP-10 family constructions. Python standard library only.

Search failure is inconclusive. Verification recomputes every support and rank.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import argparse, json, math, random


def normalize(n, edges):
    if not isinstance(n,int) or isinstance(n,bool) or n<1:
        raise ValueError('n must be a positive integer')
    E=set()
    for a,b in edges:
        if not (isinstance(a,int) and isinstance(b,int) and 0<=a<n and 0<=b<n and a!=b):
            raise ValueError('invalid edge')
        E.add(tuple(sorted((a,b))))
    return E


def complement(n,E):
    return set(combinations(range(n),2))-set(E)


def dot(x,y):
    return sum((a*b for a,b in zip(x,y)),F(0))


def rank(M):
    if not M: return 0
    A=[[F(x) for x in row] for row in M]
    n,m=len(A),len(A[0]); r=0
    if any(len(row)!=m for row in A): raise ValueError('ragged matrix')
    for c in range(m):
        p=next((i for i in range(r,n) if A[i][c]),None)
        if p is None: continue
        A[r],A[p]=A[p],A[r]
        a=A[r][c]; A[r]=[x/a for x in A[r]]
        for i in range(r+1,n):
            a=A[i][c]
            if a: A[i]=[x-a*y for x,y in zip(A[i],A[r])]
        r+=1
        if r==n: break
    return r


def encode(M): return [[str(F(x)) for x in row] for row in M]


def verify(rec):
    n=rec['n']; E=normalize(n,rec['edges'])
    target=rec.get('target',n+2)
    if not isinstance(target,int) or isinstance(target,bool) or target<0 or target>n+2:
        raise ValueError('target must be an integer between zero and n+2')
    ranks=[]
    for key,T in [('V',E),('W',complement(n,E))]:
        M=[[F(x) for x in row] for row in rec[key]]
        if len(M)!=n or not M or not M[0] or any(len(r)!=len(M[0]) for r in M):
            raise ValueError('invalid dimensions')
        if any(not any(row) for row in M):
            raise ValueError('this certificate format requires nonzero vectors')
        for i,j in combinations(range(n),2):
            if bool(dot(M[i],M[j])) != ((i,j) in T):
                raise ValueError(f'{key}: support mismatch at {i},{j}')
        ranks.append(rank(M))
    if sum(ranks)>rec.get('target',n+2):
        raise ValueError(f'rank sum {sum(ranks)} exceeds target')
    return ranks


def halfgraph(k):
    if k<2: raise ValueError('half-graph theorem requires k >= 2')
    V=[]; W=[]
    for i in range(1,k+1):
        v=[0]*(k+1); v[i]=1; V.append(v)
        w=[1]+[0]*k
        for h in range(i,k+1): w[h]=-1
        W.append(w)
    for j in range(1,k+1):
        v=[1]+[0]*k
        for h in range(1,j): v[h]=1
        v[j]=-j; V.append(v)
        w=[1]+[0]*k; w[j]=1; W.append(w)
    E=[(i-1,k+j-1) for i in range(1,k+1) for j in range(i,k+1)]
    rec={'family':'half_graph','k':k,'n':2*k,'edges':E,'V':encode(V),'W':encode(W),'target':2*k+2}
    rec['checked_ranks']=verify(rec)
    if rec['checked_ranks'] != [k+1,k+1]: raise AssertionError('unexpected family rank')
    return rec


def degeneracy(n,E):
    remaining=set(range(n)); ans=0
    while remaining:
        deg={v:sum(tuple(sorted((v,w))) in E for w in remaining if w!=v) for v in remaining}
        v=min(remaining,key=lambda x:(deg[x],x)); ans=max(ans,deg[v]); remaining.remove(v)
    return ans


def optimal_coloring(vertices,E):
    vertices=list(vertices)
    if not vertices: return {}
    order=sorted(vertices,key=lambda v:-sum(tuple(sorted((v,w))) in E for w in vertices if w!=v))
    for k in range(1,len(vertices)+1):
        C={}
        def visit(idx):
            if idx==len(order): return True
            v=order[idx]
            forbidden={C[w] for w in C if tuple(sorted((v,w))) in E}
            for c in range(k):
                if c not in forbidden:
                    C[v]=c
                    if visit(idx+1): return True
                    del C[v]
            return False
        if visit(0): return dict(C)
    raise AssertionError('coloring not found')


def quotient_vectors(t,E):
    if len(E)==t*(t-1)//2:
        return [[F(1)] for _ in range(t)]
    edges=sorted(E); iso=[i for i in range(t) if not any(i in e for e in edges)]
    U=[[F(0)]*(len(edges)+len(iso)) for _ in range(t)]
    for c,(i,j) in enumerate(edges): U[i][c]=F(1); U[j][c]=F(-1)
    for z,i in enumerate(iso): U[i][len(edges)+z]=F(1)
    return U


def weighted_dot(x,y,weights): return sum((a*b*c for a,b,c in zip(x,y,weights)),F(0))


def parallel(x,y):
    return all(x[i]*y[j]==x[j]*y[i] for i,j in combinations(range(len(x)),2))


def complement_path(m,d):
    weights=[F(d),F(1),F(1)]
    V=[[F(1),F(0),F(0)],[F(0),F(1),F(0)],[F(1),F(0),F(1)]]
    while len(V)<m:
        normal=[a*b for a,b in zip(V[-1],weights)]
        p=next(i for i,a in enumerate(normal) if a)
        basis=[]
        for j in range(3):
            if j!=p:
                b=[F(0)]*3; b[j]=normal[p]; b[p]=-normal[j]; basis.append(b)
        found=False
        for t in range(2*len(V)+4):
            x=[a+t*b for a,b in zip(basis[0],basis[1])]
            if (any(x) and all(weighted_dot(x,y,weights) for y in V[:-1])
                    and all(not parallel(x,y) for y in V)):
                V.append(x); found=True; break
        if not found: raise AssertionError('finite avoidance bound failed')
    return V


def local_path(m,d,comp):
    if comp: return complement_path(m,d)
    V=[[F(0)]*(m-1) for _ in range(m)]
    for i in range(m-1): V[i][i]=F(1); V[i+1][i]=F(-1)
    return V


def rotated(V,weights,rng):
    X=[row[:] for row in V]
    r=len(weights)
    for a,b in combinations(range(r),2):
        t=F(rng.choice([-4,-3,-2,-1,1,2,3,4]),rng.choice([1,2,3]))
        den=1+weights[a]*weights[b]*t*t
        c=(1-weights[a]*weights[b]*t*t)/den
        qa=2*weights[a]*t/den; qb=-2*weights[b]*t/den
        for row in X:
            x,y=row[a],row[b]
            row[a]=c*x+qb*y; row[b]=qa*x+c*y
    return X


def substituted_edges(t,E,sizes,comp_modules=False):
    starts=[]; N=0
    for m in sizes: starts.append(N); N+=m
    out=set()
    for i,m in enumerate(sizes):
        for a,b in combinations(range(m),2):
            if ((b==a+1) != comp_modules): out.add((starts[i]+a,starts[i]+b))
    for i,j in E:
        for a in range(sizes[i]):
            for b in range(sizes[j]): out.add((starts[i]+a,starts[j]+b))
    return N,out


def substitution_factor(t,E,sizes,comp_modules,seed):
    U=quotient_vectors(t,E); udim=len(U[0])
    S=[i for i,m in enumerate(sizes) if m>=4]
    colors=optimal_coloring(S,complement(t,E))
    c=1+max(colors.values()) if colors else 0
    priv={}; dim=udim+2*c
    for i,m in enumerate(sizes):
        r=1 if m==1 else (3 if comp_modules else m-1)
        priv[i]=dim; dim+=max(0,r-3)
    prior=[]; owners=[]; rng=random.Random(seed)
    for i,m in enumerate(sizes):
        d=dot(U[i],U[i])
        if m==1:
            row=U[i]+[F(0)]*(dim-udim); prior.append(row); owners.append(i); continue
        base=local_path(m,d,comp_modules); r=len(base[0]); weights=[d]+[F(1)]*(r-1)
        chosen=None
        for attempt in range(256):
            X=rotated(base,weights,rng)
            if any(not x[0] for x in X): continue
            embedded=[]
            for x in X:
                row=[F(0)]*dim
                for a,u in enumerate(U[i]): row[a]=x[0]*u
                row[udim+2*colors[i]]=x[1]; row[udim+2*colors[i]+1]=x[2]
                for j in range(3,r): row[priv[i]+j-3]=x[j]
                embedded.append(row)
            if all(dot(x,y) for x in embedded for y,j in zip(prior,owners)
                   if tuple(sorted((i,j))) in E):
                chosen=embedded; break
        if chosen is None: raise RuntimeError('UNKNOWN: bounded rational orientation search failed')
        prior.extend(chosen); owners.extend([i]*m)
    return prior


def substitution(t,edges,sizes,seed=20260913):
    if len(sizes)!=t or any(m!=1 and m<4 for m in sizes): raise ValueError('sizes must be 1 or >=4')
    E=normalize(t,edges)
    N,A=substituted_edges(t,E,sizes)
    V=substitution_factor(t,E,sizes,False,seed)
    W=substitution_factor(t,complement(t,E),sizes,True,seed+1)
    q=sum(m==1 for m in sizes)
    target=N if q==0 and t>=3 else (N+1 if q==0 and t==2 else N+2)
    rec={'family':'path_substitution','quotient_n':t,'quotient_edges':sorted(E),
         'module_sizes':sizes,'n':N,'edges':sorted(A),'V':encode(V),'W':encode(W),'target':target}
    rec['checked_ranks']=verify(rec)
    return rec


def generate(out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    with (out/'halfgraphs.jsonl').open('w') as f:
        for k in range(2,21):
            rec=halfgraph(k)
            assert degeneracy(2*k,set(map(tuple,rec['edges'])))==(k+1)//2
            f.write(json.dumps(rec,separators=(',',':'))+'\n')
            print('HALFGRAPH',k,rec['checked_ranks'],flush=True)
    fixtures=[(1,[],[4]),(2,[(0,1)],[4,5]),(3,[],[4,4,4]),
              (3,[(0,1),(0,2),(1,2)],[4,4,4]),
              (4,[(0,1),(1,2),(2,3)],[4,4,4,4]),
              (4,[(0,1),(1,2),(2,3)],[4,1,4,1]),
              (5,[(0,1),(1,2),(2,3),(3,4),(0,4)],[4,4,4,4,4])]
    with (out/'substitutions.jsonl').open('w') as f:
        for idx,(t,E,sizes) in enumerate(fixtures):
            rec=substitution(t,E,sizes,20260913+100*idx)
            f.write(json.dumps(rec,separators=(',',':'))+'\n')
            print('SUBSTITUTION',idx,'n',rec['n'],'ranks',rec['checked_ranks'],'target',rec['target'],flush=True)


def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    g=sub.add_parser('generate'); g.add_argument('out')
    v=sub.add_parser('verify'); v.add_argument('files',nargs='+')
    args=ap.parse_args()
    if args.cmd=='generate': generate(args.out)
    else:
        count=0
        for name in args.files:
            for line in Path(name).read_text().splitlines():
                if line.strip(): verify(json.loads(line)); count+=1
        print(json.dumps({'verified_records':count,'arithmetic':'exact rational'}))

if __name__=='__main__': main()
'''
(ROOT/'src'/'exact_families.py').write_text(code)
tests=r'''import sys, unittest
from pathlib import Path
from fractions import Fraction as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import exact_families as e

class ExactTests(unittest.TestCase):
    def test_halfgraph_small(self):
        self.assertEqual(e.verify(e.halfgraph(2)),[3,3])
    def test_halfgraph_eight(self):
        rec=e.halfgraph(4)
        self.assertEqual(e.verify(rec),[5,5])
        self.assertEqual(e.degeneracy(8,set(map(tuple,rec['edges']))),2)
    def test_degeneracy_formula(self):
        for k in range(2,9):
            r=e.halfgraph(k)
            self.assertEqual(e.degeneracy(2*k,set(map(tuple,r['edges']))),(k+1)//2)
    def test_reject_corruption(self):
        r=e.halfgraph(2); r['V'][0]=['0']*3
        with self.assertRaises(ValueError): e.verify(r)
    def test_rank(self):
        self.assertEqual(e.rank([[1,2,3],[2,4,6],[0,1,1]]),2)
    def test_weighted_rotation(self):
        import random
        X=[[F(1),F(2),F(3)],[F(-2),F(1),F(0)]]; weights=[F(3),F(1),F(1)]
        Y=e.rotated(X,weights,random.Random(7))
        for i in range(2):
            for j in range(2):
                self.assertEqual(e.weighted_dot(X[i],X[j],weights),e.weighted_dot(Y[i],Y[j],weights))
    def test_weighted_complement_path(self):
        X=e.complement_path(7,F(3)); w=[F(3),F(1),F(1)]
        for i in range(7):
            for j in range(i+1,7): self.assertEqual(bool(e.weighted_dot(X[i],X[j],w)),j-i!=1)
    def test_path_substitution(self):
        r=e.substitution(3,[(0,1),(1,2)],[4,4,4],11)
        self.assertLessEqual(sum(e.verify(r)),12)
    def test_mixed_substitution(self):
        r=e.substitution(3,[(0,1),(1,2)],[4,1,1],19)
        self.assertLessEqual(sum(e.verify(r)),8)

if __name__=='__main__': unittest.main()
'''
(ROOT/'tests'/'test_exact.py').write_text(tests)
readme='''# SP-10: second continuation (PARTIAL)

Read **REPORT.md** first. This archive does not prove or disprove the full graph complement conjecture.

The self-contained report proves a path-substitution theorem for arbitrary quotient graphs, a mixed path/singleton extension, exact complementary minimum ranks of half graphs, and a sharp 2d+1 auxiliary dimension theorem. The previous archive is retained unmodified when available.

## Reproduce the exact checks

```sh
python -m unittest discover -s tests -v
python src/exact_families.py generate certificates
python src/exact_families.py verify certificates/halfgraphs.jsonl certificates/substitutions.jsonl
```

Python's standard library is sufficient. The optional construction searches only for rational orientations, reports UNKNOWN on bounded search failure, and never interprets a search failure as a counterexample. Verification uses rational arithmetic, checks every off-diagonal zero and nonzero, and recomputes ranks rather than trusting stored values.

`EXECUTION_LOG.txt` and `execution_status.json`, when present, describe the actual local executions. Read those files rather than assuming success from the existence of a source file. Source files and theorem proofs are distinct from finite verification outcomes.

No repository edit or full-resolution status change is included.
'''
(ROOT/'README.md').write_text(readme)
(ROOT/'CLAIMS.json').write_text(json.dumps({
 'full_SP10_resolved':False,
 'self_contained_theorems':['Rank-sharing substitution bound','PSD GCC for arbitrary quotients with path modules of order at least four','Mixed path modules with at most two singleton modules','Exact minimum symmetric and PSD ranks of half graphs','Sharp complementary nonzero PSD dimension bound 2d+1'],
 'external_input_result':'4n/3 universal bound, with dependencies and bibliographic limitation explicit in REPORT.md section 8',
 'originality_claim':False,
 'finite_search_failure_means':'UNKNOWN, not counterexample'
},indent=2))
prior=Path('/mnt/data/SP10_partial_results.zip')
if prior.is_file():
 (ROOT/'prior').mkdir(exist_ok=True)
 shutil.copy2(prior,ROOT/'prior'/'SP10_partial_results.zip')
print('WROTE',ROOT,flush=True)
