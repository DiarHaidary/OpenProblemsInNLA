# Status and evidence

**Original RA-05 target: PARTIAL, subject to review.**

**Completed subtarget in this manuscript:** every fixed even p=2s>=4, arbitrary
input rank and ambient dimension, every query rank and every allowed accuracy,
nonnegative weights on original rows, joint optimal size up to logarithms.

**Still missing:** a matching joint classification for real p>2 which are not even
integers. No interpolation, continuity argument, or degree-growing approximation
is asserted to supply it. See REMAINING_GAP.md.

The manuscript is an internally checked proof claim. Reproducible numerical and
exact certificates are supplementary. No independent review or formal verification
is claimed. Prior manuscripts are preserved unchanged for provenance, not treated
as independent verification of the new lemmas. No repository update was performed.
