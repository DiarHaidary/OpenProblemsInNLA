# RA-01 — Third-round clock analysis

**Status: partial results; unrestricted RA-01 is not solved by this archive.**

The report is `paper/round3_report.md`. It contains complete written arguments for an inverse-arrival-time inequality, a conditional sufficient Poisson comparison, a sharper coordinate-block aggregation bound, and exact obstructions to several clock-based shortcuts. It does not provide the missing general-spectrum constant-factor bound.

The new block estimate is `E T_k <= k/(k-r) E B` for every integer `k>r`, under the explicitly stated coordinate-block construction. This does not extend through an arbitrary spectral rotation.

To reproduce the finite exact checks, run from this directory:

```sh
python code/verify_exact.py
```

The Python program uses only the standard library. Results are written to `verification/exact_results.json`. The `verification/run_log.txt` file records the initial execution. Exact finite checks do not establish unrestricted theorems or replace an independent mathematical review.

When present, `provenance/RA01_round2_proof_package.zip` is an unchanged copy of the preceding package. Its inclusion is for provenance, not a claim that all previous proofs and checks were independently re-verified in this round.

`SHA256SUMS.txt` describes the delivered snapshot. Re-running code can regenerate the result files. No repository files were edited.
