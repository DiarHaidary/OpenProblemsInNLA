# Sources and exact dependencies

Public sources checked September 13, 2026. No GitHub plugin was used. External papers are referenced, not bundled or presented as original work.

## The requested problem

OpenProblemsInNLA, SP-10:

https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/eigenvalues-and-inverse-problems/SP-10

Raw text used for the exact statement:

https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/eigenvalues-and-inverse-problems/SP-10/README.md

The statement requires exact off-diagonal support, real symmetry, and no diagonal restriction. It asks for the sum of two minimum ranks to be at most `n+2`. The retrieved entry says “Partially resolved,” checked September 10, 2026.

## Main external mathematical input

H. Tracy Hall, *The Delta Theorem: A dimension bound for faithful orthogonal graph representations*, arXiv:2601.01211v1, submitted January 3, 2026.

https://arxiv.org/html/2601.01211v1

https://arxiv.org/abs/2601.01211

Exact uses: Theorem 3.20 and Corollary 3.21, together with the comparison to `nu`, give `g(G) <= nu(G)`. Corollary 3.22 gives `delta(G) <= nu(G)`. Section 3.1.2 recalls minor monotonicity of `nu`; Section 3.6 defines the MCS/greedegree convention. Definitions 2.1 and 2.3 confirm that isolated-vertex zero vectors are compatible with the matrix parameters.

This package does not reproduce Hall's long proof or claim an independent validation of it. All corollaries invoking this input are identified accordingly.

## The existing degeneracy argument

F. Barioli, S. M. Fallat, H. Gupta, and Z. Li, *The weak version of the graph complement conjecture and partial results for the delta conjecture*, Discrete Mathematics 349 (2026), 114861. Primary arXiv manuscript: 2505.24577v1, May 2025.

https://arxiv.org/html/2505.24577v1

https://doi.org/10.1016/j.disc.2025.114861

Exact uses: the edge-count/degeneracy argument in Section 3, its square-root bound in Theorem 3.7, and the conditional coefficient-sqrt(2) consequence in Proposition 3.11. Hall's later theorem supplies the needed strong Delta input. The report retains the finite square-root expression and integer rounding. This is attributed combination and exposition, not a claim to have invented the published method.

## Prior finite-range result and stronger variants

C. Erickson, L. Gan, J. Kritschgau, J. C.-H. Lin, and S. Spiro, *Complementary Vanishing Graphs*, arXiv:2207.07294v1, 2022.

https://arxiv.org/html/2207.07294v1

https://arxiv.org/abs/2207.07294

Its introduction reports that the graph complement conjecture was already known through order ten. Thus the supplied order-seven atlas certificates are not a new verification range. Its definition of complementary vanishing (`AB = 0` with both exact supports) is stronger than the target; the package does not claim every graph has that property.

## Graph-atlas input

NetworkX 3.6.1 official documentation, `graph_atlas_g`:

https://networkx.org/documentation/stable/reference/generated/networkx.generators.atlas.graph_atlas_g.html

The source atlas is R. C. Read and R. J. Wilson, *An Atlas of Graphs*, Oxford University Press, 1998. NetworkX documents 1,253 entries of orders zero through seven. Excluding the order-zero graph gives 1,252 entries, with counts `1,2,4,11,34,156,1044` for orders one through seven.

The local coverage checker separately matches every saved certificate to the actual NetworkX edge list and graph6 identifier. Atlas completeness is taken from the documented atlas, while matrix admissibility and ranks are checked exactly by the provided verifiers.
