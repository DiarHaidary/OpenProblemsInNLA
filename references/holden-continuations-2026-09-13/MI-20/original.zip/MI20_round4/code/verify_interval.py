"""Exact interval-exclusion acceptance, conditional on a proved preceding cap."""
from fractions import Fraction as F
from pathlib import Path
import json,sys
from homogeneous_model import interval_equations
from exact_arithmetic import require,rational,positive_definite,sparse_model,gram_coefficients
FORMAT='MI20-cubic-interval-Gram-v1'
SCOPE='all finite dimensions, p=4/3, m=2'

def verify(data,cap):
    cap=F(cap)
    require(data.get('format')==FORMAT,'Incorrect certificate format')
    require(data.get('scope')==SCOPE,'Incorrect scope')
    degree=data.get('degree');m=data.get('m')
    require(type(degree) is int and degree in (4,6,8) and type(m) is int and m==2,'Unsupported degree or summand count')
    l,u,h=[rational(data[k]) for k in ('left','right','h')]
    require(F(8)<=l<=cap<=u,'Certificate interval does not cover the preceding upper tail')
    require(h>F(1,2) and (1+h)**3/h>cap,'Operator upper bound is not justified')
    a,b,eq=interval_equations(l,u,h,degree,m);n=len(a['keys']);count=len(a['matrices'])
    raw=data.get('gram_matrices')
    require(isinstance(raw,list) and len(raw)==2*count,'Incorrect Gram count')
    grams=[]
    for index,z in enumerate(raw):
        order=len(a['matrices'][index%count])
        require(isinstance(z,list) and len(z)==order and all(isinstance(row,list) and len(row)==order for row in z),'Incorrect Gram order')
        Z=[[rational(v) for v in row] for row in z];positive_definite(Z);grams.append(Z)
    w=[rational(v) for v in data['multipliers']]
    require(len(w)==len(eq) and w[-1]==-1,'Incorrect multiplier count or normalization')
    sparse=sparse_model(a['matrices'])
    left=gram_coefficients(grams[:count],sparse,n);right=gram_coefficients(grams[count:],sparse,n)
    rhs=[sum(wi*row[k] for wi,row in zip(w,eq)) for k in range(2*n)]
    require(left+right==rhs,'Trace-polynomial coefficient identity failed')
    return {'status':'PASS','scope':SCOPE,'degree':degree,'excluded_closed_interval':[str(l),str(u)],'preceding_lambda_cap':str(cap),'operator_h':str(h),'new_lambda_cap':str(l),'universal_upper_fourth_power':str(l/8),'upper_bound_expression':f'({l/8})^(1/4)','positive_definite_Gram_matrices':len(grams),'coefficient_identities':2*n,'acceptance_arithmetic':'integers and exact fractions only','problem_solved':False}

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: python verify_interval.py CERTIFICATE PROVED_PRECEDING_CAP')
    print(json.dumps(verify(json.loads(Path(sys.argv[1]).read_text()),F(sys.argv[2])),indent=2))
