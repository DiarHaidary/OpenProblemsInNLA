#!/usr/bin/env python3
"""Small, reproducible diagnostics. Reduced constants are NOT certified."""
from __future__ import annotations
import ast
from dataclasses import asdict
import json
import platform
from pathlib import Path
import sys
import time
import numpy as np
import sympy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from ra11_hierarchy import (
    RealProductOracle, ComplexSimulation, NoisyPartialOracle,
    ExperimentalSchedule, experimental_hierarchy, noisy_approximation,
    phase_factors, kron_all, partial_trace, lift, metric_median, theorem_schedule)

rng=np.random.default_rng(20260913)
records=[]

def psd(N,seed,rank=None):
    g=np.random.default_rng(seed).normal(size=(N,rank or N))
    A=g@g.T
    return A/np.trace(A)

def report(name,**data):records.append({'check':name,**data})

# Only the original real-product apply method may use unknown matrix entries.
tree=ast.parse((ROOT/'src'/'ra11_hierarchy.py').read_text())
access=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Attribute) and node.attr=='_matrix':access.append(node.lineno)
assert len(access)==2
report('Unknown-matrix access audit',passed=True,private_matrix_attribute_lines=access)

for q in range(2,7):
    n=2;M=psd(n**q,10+q)
    base=RealProductOracle(M,n,q);sim=ComplexSimulation(base)
    fs=[rng.normal(size=n)+1j*rng.normal(size=n) for _ in range(q)]
    y=sim.apply(fs);truth=M@kron_all(fs)
    err=float(np.linalg.norm(y-truth)/max(np.linalg.norm(truth),1e-300))
    assert base.calls==q+1 and sim.calls==1 and err<1e-8
    try:base.apply(fs);raise AssertionError('Complex call was not rejected')
    except ValueError:pass
    report('Numerical interpolation',q=q,relative_response_error=err,real_calls=base.calls,passed=True)

# Full-subset, noiseless two-sided recovery when the sampled range captures A.
for seed in range(8):
    n,q=4,2;M=psd(n**q,800+seed,rank=2)
    base=RealProductOracle(M,n,q);sim=ComplexSimulation(base)
    gen=np.random.default_rng(seed)
    no=NoisyPartialOracle(sim,np.zeros_like(M),(0,1),1,gen)
    sch=ExperimentalSchedule(rank_target=2,range_columns=5,regression_columns=12,
                             outside_averages=1,candidates=1,residual_samples=4)
    Ahat=noisy_approximation(no,sch,gen)
    err=float(np.linalg.norm(Ahat-M,'fro')/np.linalg.norm(M,'fro'))
    assert err<1e-9 and base.calls==(q+1)*sim.calls
    report('Noiseless low-rank regression',seed=seed,relative_F_error=err,real_calls=base.calls,passed=True)

zero=RealProductOracle(np.zeros((8,8)),2,3)
sch0=ExperimentalSchedule(rank_target=1,range_columns=2,regression_columns=4,
                          outside_averages=2,candidates=3,residual_samples=8)
z,counts=experimental_hierarchy(zero,sch0,seed=50)
assert z==0 and counts['real_calls']==4*counts['complex_calls']
report('Zero input',estimate=z,passed=True,**counts)

# Exact basis path (floating-point reproduction of the exact identities).
M=psd(8,97)
base=RealProductOracle(M,2,3)
sch=ExperimentalSchedule(rank_target=8,range_columns=2,regression_columns=2,
                         outside_averages=2,candidates=1,residual_samples=4)
t,counts=experimental_hierarchy(base,sch,seed=900)
assert abs(t-1)<1e-10
report('Basis-fallback hierarchy',absolute_trace_error=abs(t-1),passed=True,**counts)

# Candidate selection has no access to the unknown target or success radius.
A=np.diag([1.,2.,3.]).astype(complex)
good=[A+(j-2)*0.01*np.eye(3) for j in range(5)]
bad=[A+100*np.ones((3,3)),A-100*np.eye(3)]
chosen=metric_median(good+bad)
sigma=max(np.linalg.norm(x-A,'fro') for x in good)
assert np.linalg.norm(chosen-A,'fro')<=3*sigma+1e-12
report('Metric-median selection',passed=True,error=float(np.linalg.norm(chosen-A,'fro')),good_radius=float(sigma))

experiments=[]
for n,q in [(4,2),(2,3)]:
    N=n**q
    u=np.random.default_rng(100+n+q).normal(size=n);u/=np.linalg.norm(u)
    first=np.outer(u,u)
    Mprod=first
    for _ in range(q-1):Mprod=np.kron(Mprod,np.eye(n)/n)
    families={'dense_PSD':psd(N,1000+N),'rank_two':psd(N,1300+N,2),
              'product_projector_identity':Mprod,
              'diagonal_PSD':np.diag(np.arange(1,N+1,dtype=float))/(N*(N+1)/2)}
    sch=ExperimentalSchedule(rank_target=1,range_columns=3,regression_columns=9,
                             outside_averages=2,candidates=3,residual_samples=40)
    for name,M in families.items():
        estimates=[];calls=[];partial_errors=[]
        for seed in range(12):
            base=RealProductOracle(M,n,q)
            stages=[]
            def audit(S,B):
                R=M-B
                stages.append({'keep':list(S),'current_partial_F_error':float(np.linalg.norm(partial_trace(R,n,q,S),'fro'))})
            t,info=experimental_hierarchy(base,sch,seed=seed+200,callback=audit)
            assert np.isfinite(t) and info['real_calls']==(q+1)*info['complex_calls']
            estimates.append(t);calls.append(info['real_calls']);partial_errors.append(stages)
        truth=float(np.trace(M));errors=np.array(estimates)/truth-1
        experiments.append({'family':name,'n':n,'q':q,'trials':12,'true_trace':truth,
                            'settings':asdict(sch),'estimates':estimates,
                            'relative_bias':float(errors.mean()),'relative_RMSE':float(np.sqrt(np.mean(errors**2))),
                            'fraction_within_10_percent':float(np.mean(np.abs(errors)<=.1)),
                            'minimum_estimate':float(min(estimates)),
                            'real_calls_min':int(min(calls)),'real_calls_max':int(max(calls)),
                            'first_trial_stage_diagnostics':partial_errors[0],
                            'certified_constants_used':False})

# Direct confirmation of the restricted PSD-control variance obstruction.
variance_examples=[]
for n in (4,8,16):
    alpha=3*n/(n+2)
    for k in (0,1,n//2):
        D=np.diag([0.]*k+[1.]*(n-k))
        tau=n-k
        Ey2=n/(n+2)*(tau*tau+2*np.trace(D@D))
        variance=alpha*Ey2-tau*tau
        lower=(alpha-1)*tau*tau
        assert variance+1e-10>=lower
        variance_examples.append({'n':n,'control_rank':k,'exact_single_probe_variance':float(variance),'proved_lower':float(lower)})
report('PSD Nystrom-control variance obstruction',passed=True,examples=variance_examples,scope='Variance statement for this estimator family, not a minimax probability lower bound')

out={'all_assertions_passed':True,'checks':records,'experiments':experiments,
     'limitations':['Monte Carlo settings are far smaller than the certified schedule.',
                    'These finite-precision diagnostics do not prove a uniform probability guarantee.',
                    'Query counts in these small tests can exceed exact basis reconstruction.',
                    'Floating-point SVD and pseudoinverse are demonstration routines; the proof uses exact elimination.']}
(ROOT/'results'/'numerical_checks.json').write_text(json.dumps(out,indent=2)+'\n')
(ROOT/'results'/'environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'sympy':sympy.__version__},indent=2)+'\n')
print(json.dumps(out,indent=2))
