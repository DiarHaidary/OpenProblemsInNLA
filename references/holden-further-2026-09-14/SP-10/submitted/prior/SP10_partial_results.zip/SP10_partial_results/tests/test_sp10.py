import copy
import random
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import sp10


class ExactTests(unittest.TestCase):
    def test_complement(self):
        a = sp10.from_edges(4, [[0, 1], [1, 2], [2, 3]])
        self.assertEqual(a, sp10.complement(sp10.complement(a)))

    def test_validation(self):
        for args in [(0, []), (2, [[0, 0]]), (2, [[0, 2]])]:
            with self.assertRaises(ValueError):
                sp10.from_edges(*args)
        with self.assertRaises(ValueError):
            sp10.validate_graph([2, 0])

    def test_nullspace(self):
        a = [[1, 2, 3, 4], [2, 4, 6, 8], [0, 1, 0, 1]]
        basis = sp10.nullspace(a, 4)
        self.assertEqual(len(basis), 2)
        self.assertTrue(all(sp10.dot(row, b) == 0 for row in a for b in basis))

    def test_rank(self):
        self.assertEqual(sp10.rank([[1, 2], [2, 4]]), 1)
        self.assertEqual(sp10.rank([[0, 0], [0, 0]]), 0)
        self.assertEqual(sp10.rank([[0, 1], [1, 0]]), 2)

    def test_laplacian(self):
        a = sp10.from_edges(5, [[0, 1], [1, 2], [2, 3]])
        self.assertEqual(sp10.check_gram(a, sp10.laplacian_vectors(a)), 3)

    def test_empty(self):
        a = sp10.from_edges(3, [])
        cert = sp10.search_pair(a, trials=20)
        self.assertEqual(sp10.verify_pair(cert)['status'], 'CERTIFIED')
        self.assertEqual(cert['rank_G'], 0)

    def test_bull(self):
        a = sp10.from_edges(5, [[0, 1], [0, 2], [1, 2], [2, 3], [0, 4]])
        v = [[1, 1, 0], [0, 1, 0], [0, 1, 1], [0, 0, 1], [1, 0, 0]]
        self.assertEqual(sp10.check_gram(a, v), 3)
        ga, oa = sp10.best_mcs(a)
        gb, ob = sp10.best_mcs(sp10.complement(a))
        self.assertEqual((ga, gb), (1, 1))
        self.assertTrue(sp10.check_mcs(a, oa))
        self.assertTrue(sp10.check_mcs(sp10.complement(a), ob))
        cert = sp10.search_pair(a, trials=80, seed=20260913)
        self.assertEqual(sp10.verify_pair(cert)['status'], 'CERTIFIED')

    def test_bad_certificate(self):
        a = sp10.from_edges(4, [[0, 1], [1, 2], [2, 3]])
        cert = sp10.search_pair(a, trials=20, seed=7)
        self.assertEqual(sp10.verify_pair(cert)['status'], 'CERTIFIED')
        wrong = copy.deepcopy(cert)
        wrong['rank_G'] = 0
        with self.assertRaises(ValueError):
            sp10.verify_pair(wrong)
        with self.assertRaises(ValueError):
            sp10.check_matrix(a, [[0] * 4 for _ in range(4)])

    def test_path_sharp(self):
        a = sp10.from_edges(6, [[i, i + 1] for i in range(5)])
        cert = sp10.search_pair(a, trials=96, seed=99)
        self.assertEqual(cert['rank_sum'], 8)

    def test_zero_trials_not_counterexample(self):
        a = sp10.from_edges(7, [[i, (i + 1) % 7] for i in range(7)])
        cert = sp10.search_pair(a, trials=0)
        self.assertEqual(cert['status'], 'UNKNOWN')
        self.assertEqual(sp10.verify_pair(cert)['status'], 'UNKNOWN')

    def test_integer_bound(self):
        self.assertEqual([sp10.universal_bound(n) for n in range(1, 8)], [2, 3, 4, 6, 7, 8, 10])

    def test_degeneracy(self):
        a = sp10.from_edges(4, [[0, 1], [1, 2], [2, 0], [2, 3]])
        self.assertEqual(sp10.degeneracy(a), 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
