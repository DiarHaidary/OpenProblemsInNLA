# Sources and provenance

The public repository and primary references were read through the website and its raw-text/HTML representations. This package does not redistribute the source papers or the repository's proof notes.

1. **OpenProblemsInNLA, TR-03.** The canonical problem, its exact max-min quantifiers, its asymptotic target, and the recorded one-column partial resolution. Checked 12 September 2026.
   - https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/randomized-and-low-rank-approximation/TR-03
   - Text representation read: https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/TR-03/README.md

2. **Amsel et al., _Linear Systems and Eigenvalue Problems: Open Questions from a Simons Workshop_, arXiv:2602.05394v3 (2026).** Section 4.2, Problem 4.7 and equations (15)-(16), source formulation.
   - https://arxiv.org/html/2602.05394v3

3. **Mark Fornace and Michael Lindsey, _Column and Row Subset Selection Using Nuclear Scores: Algorithms and Theory for Nyström Approximation, CUR Decomposition, and Graph Laplacian Reduction_, arXiv:2407.01698v2.** Background on determinantal sampling and elementary-symmetric-polynomial identities. The residual-average identity is proved directly in the report.
   - https://arxiv.org/html/2407.01698v2

4. **Sidney Holden, one-column TR-03 note, 12 September 2026.** Existing equality `x_1=y_1`; attributed rather than claimed as a new result.
   - https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/references/holden-tr03-2026-09-12
   - Text representation read: https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/references/holden-tr03-2026-09-12/one-column.tex

5. **Kozyrev and Osinsky, _Subset selection for matrices in spectral norm_, arXiv:2507.20435 (2025).** Equation (1) defines the orthonormal-row minimax `t_xi(m,k,n)`. The report's `F(n,r)` is its square-subset Frobenius instance `t_F(r,r,n)^2`.
   - https://arxiv.org/html/2507.20435

The frame-limit reduction, strict-gap argument, and exact `(L,L,1,1)` derivation are written out in this package. Their proofs do not assume the conclusion of the original open problem or any unproved conjecture. This is not an assertion that these observations have never appeared elsewhere: no exhaustive novelty determination was completed.
