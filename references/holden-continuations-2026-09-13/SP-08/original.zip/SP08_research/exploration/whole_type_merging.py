"""Exploratory test of whole-type merging; not a certificate."""
import numpy as np,json,time
from pathlib import Path
rng=np.random.default_rng(90413);root=Path(__file__).resolve().parents[1]
def spec(K,m):
 D=np.sqrt(m);return np.linalg.eigh(K*D[:,None]*D[None,:])
def spread(K,m):
 e,_=spec(K,m);return max(e[-1],0)-min(e[0],0)
def Hmake(runs,z):
 n=sum(runs)+int(z);H=np.zeros((n,n));off=0
 for r in runs:
  ii=np.minimum(np.arange(r)[:,None],np.arange(r)[None,:]);H[off:off+r,off:off+r]=(ii%2==0);off+=r
 return H
out=[];st={'samples':0,'stationary':0,'no_merging_improvement':0};start=time.monotonic()
for trial in range(400000):
 runs=[int(rng.integers(1,7)) for _ in range(int(rng.integers(1,3)))];zz=bool(rng.integers(2));H=Hmake(runs,zz)
 if len(H)<3:continue
 m=rng.integers(1,80,len(H));a=float(rng.choice([0,.01,.1,.25,.4,.5,.75,.9,.99]));K=1-(1-a)*H
 e,V=spec(K,m);s=e[-1]-e[0];x=V[:,-1]/np.sqrt(m);y=V[:,0]/np.sqrt(m);C=np.outer(x,x)-np.outer(y,y)
 st['samples']+=1
 if np.any((K-a)*C < -1e-9) or np.any((1-K)*C>1e-9):continue
 st['stationary']+=1;gain=-1e100;best=None
 for i in range(len(m)):
  for j in range(len(m)):
   if i==j:continue
   mm=m.copy();mm[j]+=mm[i];mm[i]=0;v=spread(K,mm)
   if v-s>gain:gain=v-s;best=[i,j,v]
 if gain<-1e-9:
  st['no_merging_improvement']+=1
  n=int(sum(m));ks=np.arange(1,n);F=n*n+(1-a)*(2*n*ks-(a+3)*ks*ks);M=float(np.sqrt(max(F)))
  rr={'runs':runs,'zero':zz,'m':m.tolist(),'a':a,'spread':float(s),'candidate':M,'best_merge':best,'gain':float(gain),'eigenvalues':e.tolist()}
  if len(out)<20:out.append(rr);print('trap',rr,flush=True)
  if len(out)>=20:break
 if trial%50000==0:print(trial,st,flush=True)
result={'status':'EXPLORATORY_NOT_PROOF','statistics':st,'counterexamples_to_merging':out,'seconds':time.monotonic()-start};(root/'checks'/'whole_type_merging.json').write_text(json.dumps(result,indent=2));print(st,flush=True)
