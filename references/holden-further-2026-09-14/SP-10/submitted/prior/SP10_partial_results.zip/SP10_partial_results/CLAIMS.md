# Claim ledger

**Overall status: PARTIAL. SP-10 itself is not resolved by this package.**

The manuscript uses `mr_+` for minimum positive-semidefinite rank, `nu` for maximum PSD nullity with the Strong Arnold Property, `g` for Hall's maximal final MCS degree, and `d` for degeneracy.

| Claim | Status | Basis / location |
|---|---|---|
| `mr(G) + mr(complement(G)) <= n + 2` for every graph | **NOT PROVED OR DISPROVED** | Remaining target in manuscript Sections 1 and 9 |
| `delta(G) <= g(G) <= nu(G) <= M_+(G)` | **IMPORTED EXTERNAL THEOREM** for the nontrivial comparison | Hall, arXiv:2601.01211v1, Theorem 3.20 and Corollaries 3.21–3.22 |
| Minor monotonicity of `nu` | **IMPORTED STANDARD RESULT** | Recalled in Hall Section 3.1.2 |
| `nu(G) >= d(G)` | **PROVED GIVEN THE IMPORTED INPUT** | Manuscript Lemma 3.1 |
| Rank sum at most `floor(1 + sqrt(2*n*n - 2*n + 1))` | **PROVED GIVEN THE IMPORTED INPUT** | Theorem 3.3; existing BFFGL degeneracy method, with constants retained |
| Rank sum at most `n + 1 + Delta - delta` | **PROVED GIVEN THE IMPORTED INPUT** | Proposition 4.1 |
| Rank sum at most `n + 1 + d_(n-1) - d_2` | **PROVED GIVEN THE IMPORTED INPUT** | Proposition 4.2, degrees sorted increasingly |
| Clique-prefix bound `n + 1 + b(G) - a(G)` | **PROVED GIVEN THE IMPORTED INPUT** | Theorem 4.4; `a,b` precisely defined there |
| Every path of order `n >= 4` has complement rank sum exactly `n+2` | **ELEMENTARY PROOF PROVIDED** | Theorem 5.1; no Hall dependence |
| Universal inequality `g(G)+g(complement(G)) >= n-2` | **FALSE** | Bull graph, Proposition 6.1; both greedegrees are 1, order is 5 |
| The bull graph is a counterexample to SP-10 | **FALSE; NOT CLAIMED** | Both minimum ranks are 3, so the sum is 6, below target 7 |
| 1,252 nonempty atlas entries have PSD matrix pairs meeting the target | **EXACT FINITE CERTIFICATES** | JSONL witnesses, two rank verifiers, separate coverage checker |
| All recorded atlas ranks are minimum ranks | **NOT CLAIMED** | Most records are upper bounds only |
| Path and bull ranks stated in the report are exact minima | **PROVED** | Gram upper bounds and induced-path/tridiagonal lower bounds |
| Bounded witness search solves arbitrary inputs | **NOT CLAIMED** | It may return `UNKNOWN`; exact MCS preprocessing is exponential |
| A failed search proves a counterexample or infeasibility | **FALSE; EXPLICITLY REJECTED** | `UNKNOWN` is inconclusive |
| Saved Gram matrices have SAP | **NOT TESTED OR CLAIMED** | Verifiers check exact support and PSD rank, not SAP |
| The report has formal proof-assistant verification | **NOT CLAIMED** | No Lean/Coq/Isabelle proof included |
| An independent human referee has reviewed the proof | **NOT CLAIMED** | The second implementation is a computational cross-check only |
| These results establish new research priority | **NOT CLAIMED** | Sources and prior finite-range results are acknowledged |

The code and certificates are useful even without accepting Hall's preprint: their finite-instance conclusions and the elementary path/bull proofs do not depend on that external theorem. The general and degree-based corollaries do depend on it.
