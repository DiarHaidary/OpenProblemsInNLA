"""Create small exact examples, not an exhaustive search or a general solver."""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction as F
from collections import deque
from itertools import combinations
import json,sys,time
from exact_tools import *
from layered_substitution import *

ROOT=Path(__file__).resolve().parents[1]


def mod(kind,n):return {'kind':kind,'n':n}


def quotient(kind,n):
    if n==1:return set(),[[F(1)]],[[F(1)]]
    if kind=='cycle':
        E={(i,i+1) for i in range(n-1)}|{(0,n-1)}
        return E,incidence(n,E),incidence(n,complement(n,E))
    m=mod(kind,n)
    return module_edges(m),local_vectors(m,0,F(1)),local_vectors(m,1,F(1))


def degeneracy_example(n,h):
    E=set();labels=[0]*n
    for i in range(1,n):
        chosen=set(sorted(range(i),key=lambda j:(-labels[j],j))[:h])
        for j in range(i):
            if j in chosen:E.add((j,i))
            else:labels[j]+=1
    return E


def independent_blowup(n,E,s):
    return n*s,{(i*s+a,j*s+b) for i,j in E for a in range(s) for b in range(s)}


def cubic_tree(k):
    if k<6:raise ValueError('Use at least six internal vertices')
    E={(i,i+1) for i in range(k-1)};leaves={};n=k
    for i in range(k):
        leaves[i]=[]
        for _ in range(2 if i in (0,k-1) else 1):
            E.add((i,n));leaves[i].append(n);n+=1
    paths=[[leaves[i][0],i,i+1,leaves[i+1][0]] for i in (0,2,4)]
    return n,E,paths


def forest_complement(n,E):
    adj=[[] for _ in range(n)]
    for a,b in E:adj[a].append(b);adj[b].append(a)
    order=[];parents={};seen=set()
    for root in range(n):
        if root in seen:continue
        seen.add(root);parents[root]=None;q=deque([root])
        while q:
            v=q.popleft();order.append(v)
            for w in sorted(adj[v]):
                if w not in seen:seen.add(w);parents[w]=v;q.append(w)
    V={}
    for v in order:
        p=parents[v]
        if p is None:
            if not V:z=[F(1),F(0),F(0)]
            else:
                for t in range(10*len(V)+10):
                    z=[F(1),F(t),F(t*t)]
                    if all(dot(z,y) and not parallel(z,y) for y in V.values()):break
                else:raise AssertionError('Root finite avoidance failed')
        else:
            u,w=plane_basis(V[p])
            for t in range(2*len(V)+5):
                z=[a+t*b for a,b in zip(u,w)]
                if all(dot(z,y) for j,y in V.items() if j!=p) and all(not parallel(z,y) for y in V.values()):break
            else:raise AssertionError('Tree finite avoidance failed')
        V[v]=primitive(z)
    return [V[i] for i in range(n)]


def write_json(path,obj):
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')


def main():
    start=time.monotonic();out=ROOT/'certificates';out.mkdir(exist_ok=True)
    import legacy_sp10 as legacy
    J=degeneracy_example(9,2)
    expected={(0,1),(0,2),(0,3),(0,4),(0,6),(1,2),(1,3),(1,5),(1,7),(2,4),(2,5),(2,7),(3,6),(3,8),(4,8)}
    assert J==expected
    jdata={'id':'false_degeneracy_NG_J9','n':9,'edges':sorted(J),
           'G':peeling(9,J),'complement':peeling(9,complement(9,J)),
           'false_lower_bound':(2*9-2+2)//3}
    assert [jdata[x]['degeneracy'] for x in ('G','complement')]==[2,3]
    for side,E in [('G',J),('complement',complement(9,J))]:verify_peeling(9,E,jdata[side])
    write_json(out/'false_degeneracy_NG_9.json',jdata)
    pair=legacy.search_pair(legacy.from_edges(9,sorted(J)),trials=64,seed=9102026)
    U=[[F(x) for x in r] for r in pair['gram_G']];W=[[F(x) for x in r] for r in pair['gram_complement']]
    jrecord={'id':'J9_is_not_a_GCC_counterexample','n':9,'edges':sorted(J),'gram_G':serialize(U),'gram_complement':serialize(W)}
    jrecord['verified']=verify_pair(jrecord)
    write_json(out/'J9_rank_pair.json',jrecord)
    fixtures=[]
    for kind,n in [('clique',3),('independent',3),('path',3),('path',5),('half',6)]:
        E,A,B=quotient('clique',1);fixtures.append(('single_'+kind+'_'+str(n),1,E,A,B,[mod(kind,n)]))
    E,A,B=quotient('path',4)
    fixtures.append(('mixed_over_P4',4,E,A,B,[mod('clique',2),mod('independent',3),mod('path',3),mod('path',4)]))
    E,A,B=quotient('half',8)
    ms=[mod('clique',2),mod('independent',2),mod('path',3),mod('path',4),mod('clique',3),mod('half',4),mod('path',3),mod('independent',3)]
    fixtures.append(('mixed_over_H4',8,E,A,B,ms))
    fixtures.append(('twins_over_J9',9,J,U,W,[mod('independent' if i%2==0 else 'clique',2) for i in range(9)]))
    E,A,B=quotient('half',10)
    fixtures.append(('twins_over_H5',10,E,A,B,[mod('independent' if i%2==0 else 'clique',2) for i in range(10)]))
    ms=[mod('clique',2),mod('independent',2),mod('path',3),mod('path',4),mod('half',4)]
    for kind in ('clique','independent'):
        E,A,B=quotient(kind,5);fixtures.append(('mixed_over_'+kind+'_5',5,E,A,B,ms))
    for typ in ('clique','independent','mixed'):
        E,A,B=quotient('cycle',5)
        ms=[mod(typ if typ!='mixed' else ('independent' if i%2==0 else 'clique'),2) for i in range(5)]
        fixtures.append(('twins_'+typ+'_over_C5',5,E,A,B,ms))
    results=[]
    with (out/'layered_pairs.jsonl').open('w') as f:
        for i,(identifier,t,E,A,B,ms) in enumerate(fixtures):
            record=construct(identifier,t,E,A,B,ms,20260913+100*i)
            f.write(json.dumps(record,sort_keys=True)+'\n');results.append(record['verified'])
    trees=[]
    with (out/'cubic_tree_pairs.jsonl').open('w') as f:
        for k in (6,8,10):
            n,E,paths=cubic_tree(k)
            record={'id':f'cubic_caterpillar_{n}','n':n,'edges':sorted(E),'gram_G':serialize(incidence(n,E)),
                    'gram_complement':serialize(forest_complement(n,E)),'three_disjoint_induced_P4':paths}
            record['verified']=verify_pair(record)
            assert record['verified']['ranks']==[n-1,3]
            f.write(json.dumps(record,sort_keys=True)+'\n');trees.append(record['verified'])
    examples=[]
    base=degeneracy_example(14,4)
    assert peeling(14,base)['degeneracy']==4 and peeling(14,complement(14,base))['degeneracy']==4
    for s in (1,2,3):
        n,E=independent_blowup(14,base,s)
        rec={'id':f'J14_independent_blowup_{s}','n':n,'s':s,'edges':sorted(E),'G':peeling(n,E),'complement':peeling(n,complement(n,E))}
        for side,ee in [('G',E),('complement',complement(n,E))]:verify_peeling(n,ee,rec[side])
        assert rec['G']['degeneracy']==4*s and rec['complement']['degeneracy']==5*s-1
        examples.append(rec)
    write_json(out/'degeneracy_blowups.json',examples)
    summary={'layered_pairs':results,'cubic_tree_pairs':trees,'J9_pair':jrecord['verified'],
             'exact_rank_pair_records':len(results)+len(trees)+1,'degeneracy_records':1+len(examples),
             'elapsed_seconds':time.monotonic()-start,
             'scope':'Illustrative exact witnesses, not exhaustive graph coverage and not a proof of arbitrary-graph SP-10.'}
    write_json(ROOT/'results'/'generation_summary.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
