"""Exact rational certificate for a five-dimensional SP-07 lower bound.
Every decimal in INPUT is an exact terminating rational. No floating-point
calculation is used to prove the lower bound. This is not an upper-bound proof.
"""
from __future__ import annotations
import argparse,itertools,json,time
from pathlib import Path
import sympy as s
INPUT={'z':[['1.4223377736','0'],['-0.5481288963','-0.5246504403'],['-0.4371044386','0.2623252201'],['-0.5348211611','-0.3933679879'],['-0.1140326107','0.2205009204']],
'X':[['0.2113749472','-0.6800914025'],['-1.0430520192','0.3802184713'],['-0.0209231689','0.5372112754']], 'strict_lower_bound':'1.019558'}
def canonical(a):return s.cancel(s.expand_complex(a))
def exact_ldl(H):
 n=H.rows;L=s.eye(n);piv=[]
 for k in range(n):
  dk=canonical(H[k,k]-sum(L[k,j]*s.conjugate(L[k,j])*piv[j] for j in range(k)))
  if dk.is_Rational is not True or dk<=0:raise AssertionError(f'Bad pivot {k}: {dk}')
  piv.append(dk)
  for i in range(k+1,n):L[i,k]=canonical((H[i,k]-sum(L[i,j]*s.conjugate(L[k,j])*piv[j] for j in range(k)))/dk)
 return L,piv

def run(output):
 started=time.monotonic();z=[s.Rational(a)+s.I*s.Rational(b) for a,b in INPUT['z']]
 X=s.Matrix([[s.Rational(x) for x in row] for row in INPUT['X']]);Y=s.eye(2).col_join(X)
 P=Y*(Y.T*Y).inv()*Y.T;J=s.eye(5)-2*P
 assert J.T==J
 assert (J*J-s.eye(5)).applyfunc(s.cancel)==s.zeros(5)
 A=s.diag(*z);B=-J*A*J;M=(A-B).applyfunc(canonical)
 H=(s.eye(5)-M.conjugate().T*M).applyfunc(canonical)
 assert H==H.conjugate().T
 L,piv=exact_ldl(H)
 assert (H-L*s.diag(*piv)*L.conjugate().T).applyfunc(canonical)==s.zeros(5)
 costs=s.Matrix(5,5,lambda i,j:canonical((z[i]+z[j])*s.conjugate(z[i]+z[j])))
 gap=min(costs[i,j] for i in range(3) for j in range(3))
 dist,perm=min((max(costs[i,p[i]] for i in range(5)),p) for p in itertools.permutations(range(5)))
 low=s.Rational(INPUT['strict_lower_bound']);assert gap>low**2;assert dist>=gap;assert low**2>s.Rational(28,27)
 def rat(x):return {'numerator':str(s.numer(x)),'denominator':str(s.denom(x)),'decimal':str(s.N(x,35))}
 result={'status':'Exact arithmetic lower-bound certificate passed; no universal upper bound.', 'inputs':INPUT,'dimension':5,'reflection_rank':2,'strict_norm_upper_bound':'1','strict_ratio_lower_bound':str(low), 'all_ldl_pivots_positive':True,'ldl_pivots':[rat(x) for x in piv], 'hall_witness_rows':[0,1,2],'hall_witness_columns':[0,1,2], 'hall_gap_squared':rat(gap),'bottleneck_squared':rat(dist),'matching':list(perm),'permutations_checked':120,'improvement_over_krause_squared':rat(low**2-s.Rational(28,27)),'exact_factorization_reconstruction_passed':True,'elapsed_seconds':time.monotonic()-started}
 output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,indent=2)+'\n')
 print('Exact certificate passed. C_normal >',low,'=',s.N(low,20))
 print('Hall gap:',s.N(s.sqrt(gap),30));print('LDL pivots:',[str(s.N(x,16)) for x in piv]);print('Seconds:',time.monotonic()-started)
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.output)
