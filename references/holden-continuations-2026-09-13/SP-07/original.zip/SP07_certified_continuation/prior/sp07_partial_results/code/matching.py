"""Bottleneck matching and Hall witnesses for finite complex spectra.

Distances are computed in floating point. These routines are numerical tests,
not interval-arithmetic certificates. Multiplicities are represented by repeated
array entries and are never discarded.
"""
from __future__ import annotations
from itertools import combinations
import numpy as np
from numpy.typing import ArrayLike


def cost_matrix(alpha: ArrayLike, beta: ArrayLike) -> np.ndarray:
    a = np.asarray(alpha, dtype=np.complex128).reshape(-1)
    b = np.asarray(beta, dtype=np.complex128).reshape(-1)
    if len(a) == 0 or len(a) != len(b):
        raise ValueError('Spectra must have the same positive length.')
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError('Spectral entries must be finite.')
    return np.abs(a[:, None] - b[None, :])


def threshold_matching(cost: np.ndarray, threshold: float) -> np.ndarray | None:
    """Return a perfect matching using costs <= threshold, or None."""
    cost = np.asarray(cost, dtype=float)
    if cost.ndim != 2 or cost.shape[0] == 0 or cost.shape[1] != cost.shape[0]:
        raise ValueError('The cost matrix must be nonempty and square.')
    if not np.all(np.isfinite(cost)) or np.any(cost < 0):
        raise ValueError('Costs must be finite and nonnegative.')
    if np.isnan(threshold):
        raise ValueError('The threshold must not be NaN.')
    n = cost.shape[0]
    adjacent = [np.flatnonzero(cost[i] <= threshold).tolist() for i in range(n)]
    col_owner = [-1] * n

    def augment(i: int, seen: list[bool]) -> bool:
        for j in adjacent[i]:
            if seen[j]:
                continue
            seen[j] = True
            if col_owner[j] == -1 or augment(col_owner[j], seen):
                col_owner[j] = i
                return True
        return False

    for i in sorted(range(n), key=lambda k: len(adjacent[k])):
        if not augment(i, [False] * n):
            return None
    permutation = np.empty(n, dtype=int)
    for j, i in enumerate(col_owner):
        permutation[i] = j
    return permutation


def bottleneck(alpha: ArrayLike, beta: ArrayLike) -> tuple[float, np.ndarray]:
    """Compute min_permutation max_i |alpha_i-beta_permutation(i)|."""
    cost = cost_matrix(alpha, beta)
    thresholds = np.unique(cost)
    lo, hi = 0, len(thresholds) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        if threshold_matching(cost, float(thresholds[mid])) is None:
            lo = mid + 1
        else:
            hi = mid
    value = float(thresholds[lo])
    permutation = threshold_matching(cost, value)
    if permutation is None:
        raise RuntimeError('Internal matching inconsistency.')
    return value, permutation


def hall_value(alpha: ArrayLike, beta: ArrayLike) -> tuple[float, tuple[int, ...], tuple[int, ...]]:
    """Exhaustively evaluate the Hall min-max formula; intended for n <= 8."""
    cost = cost_matrix(alpha, beta)
    n = len(cost)
    if n > 8:
        raise ValueError('Exhaustive Hall enumeration is limited to n <= 8.')
    best, best_i, best_j = -1.0, (), ()
    for p in range(1, n + 1):
        q = n + 1 - p
        for rows in combinations(range(n), p):
            for cols in combinations(range(n), q):
                value = float(np.min(cost[np.ix_(rows, cols)]))
                if value > best:
                    best, best_i, best_j = value, rows, cols
    return best, best_i, best_j
