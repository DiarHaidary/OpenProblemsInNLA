#!/usr/bin/env python3
"""Independent exact verification of the infinite-parameter Type A theorem.

Python standard library only. This program regenerates the spectral inequalities
as sparse rational polynomials, checks the chart identities, and checks every
binomial-square/remainder identity. It does not import the search/generator.
"""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,time
from typing import Dict,Tuple
Exponent=Tuple[int,int,int,int]
Polynomial=Dict[Exponent,F]
ZERO=(0,0,0,0)
ROOT=Path(__file__).resolve().parents[1]
def const(c:int|F)->Polynomial:
 return {} if not c else {ZERO:F(c)}
def var(i:int)->Polynomial:
 m=[0]*4;m[i]=1;return {tuple(m):F(1)}
def add(*args:Polynomial)->Polynomial:
 out=defaultdict(F)
 for p in args:
  for m,c in p.items():out[m]+=c
 return {m:c for m,c in out.items() if c}
def scale(p:Polynomial,c:int|F)->Polynomial:
 return {m:x*c for m,x in p.items() if x*c}
def mul(p:Polynomial,q:Polynomial)->Polynomial:
 out=defaultdict(F)
 for a,x in p.items():
  for b,y in q.items():out[tuple(i+j for i,j in zip(a,b))]+=x*y
 return {m:c for m,c in out.items() if c}
def power(p:Polynomial,k:int)->Polynomial:
 if k<0:raise ValueError('Negative polynomial exponent')
 out=const(1)
 for _ in range(k):out=mul(out,p)
 return out
def read_terms(rows:list)->Polynomial:
 out={}
 for m,c in rows:
  assert len(m)==4 and all(isinstance(i,int) and i>=0 for i in m)
  m=tuple(m);assert m not in out,'Duplicate monomial'
  val=F(c);assert val!=0,'Explicit zero coefficient'
  out[m]=val
 return out

def regenerate(chart:str)->tuple[Polynomial,Polynomial,Polynomial,Polynomial]:
 u,v,w,t=[var(i) for i in range(4)];one=const(1)
 L=add(one,t);R=add(const(3),scale(t,4));M2=add(const(2),scale(t,3))
 if chart=='plus':
  massden=L
  pn=add(mul(M2,v),mul(L,u));yn=mul(L,v);zn=mul(L,add(one,w))
  qfactor=power(L,3);bfactor=L
 elif chart=='minus':
  massden=M2
  pn=mul(M2,add(one,v));yn=mul(L,add(one,v,u));zn=mul(M2,add(one,w))
  qfactor=power(M2,2);bfactor=M2
 else:raise ValueError('Unknown chart')
 nn=add(pn,yn,zn)
 tn=add(mul(L,pn),mul(t,add(yn,zn)))
 e2=add(scale(mul(L,mul(pn,yn)),-1),mul(t,mul(pn,zn)),scale(mul(add(L,t),mul(yn,zn)),-1))
 e3=scale(mul(add(L,t),mul(pn,mul(yn,zn))),-1)
 D=add(power(tn,2),scale(e2,-3))
 disc=add(mul(power(tn,2),power(e2,2)),scale(power(e2,3),-4),scale(mul(power(tn,3),e3),-4),scale(power(e3,2),-27),scale(mul(tn,mul(e2,e3)),18))
 un=add(scale(mul(power(L,3),power(nn,2)),16),scale(mul(power(massden,2),power(R,2)),-1))
 wn=add(un,scale(mul(R,D),-4))
 qn=add(mul(un,power(wn,2)),scale(mul(power(R,3),disc),-64))
 return qn,wn,qfactor,bfactor

def check_squares(poly:Polynomial,cert:dict)->dict:
 calc={};cnt=0
 for sq in cert['squares']:
  aa=tuple(sq['alpha']);bb=tuple(sq['beta']);gg=tuple(sq['gamma']);k=sq['k'];weight=F(sq['weight'])
  assert weight>0 and isinstance(k,int)
  assert len(aa)==len(bb)==len(gg)==4
  assert all(isinstance(e,int) and e>=0 for m in [aa,bb,gg] for e in m)
  assert tuple(i+j for i,j in zip(aa,bb))==tuple(2*i for i in gg)
  rr=F(4)**k
  calc=add(calc,{aa:weight*rr},{bb:weight/rr},{gg:-2*weight});cnt+=1
 rem=read_terms(cert['nonnegative_remainder']);assert all(c>0 for c in rem.values())
 calc=add(calc,rem);assert calc==poly,'Square expansion mismatch'
 return {'binomial_squares':cnt,'positive_remainder_monomials':len(rem)}

def main()->None:
 start=time.monotonic();report={'status':'PASS','arithmetic':'Python standard-library exact integer and rational arithmetic','scope':'Type A bound for every real p>=1, z>=1, y>=0 and 0<=a<1; integer multiplicities imply the SP-08 candidate bound','charts':{}}
 for chart in ['plus','minus']:
  qn,wn,qfac,bfac=regenerate(chart);row={}
  for label,numerator,factor in [('Q',qn,qfac),('B',wn,bfac)]:
   path=ROOT/'exploration'/f'typeA_{chart}_{label}.json'
   raw=path.read_bytes();data=json.loads(raw);poly=read_terms(data['terms'])
   assert mul(poly,factor)==numerator,f'Independent spectral identity failed: {chart}/{label}'
   if chart=='plus':
    assert all(c>0 for c in poly.values());stats={'binomial_squares':0,'positive_remainder_monomials':len(poly)}
   else:
    cp=ROOT/'checks'/f'typeA_{chart}_{label}_certificate.json'
    cert=json.loads(cp.read_text());assert read_terms(cert['polynomial']['terms'])==poly
    stats=check_squares(poly,cert);stats['certificate_sha256']=hashlib.sha256(cp.read_bytes()).hexdigest()
   stats['regenerated_polynomial_monomials']=len(poly);stats['polynomial_sha256']=hashlib.sha256(raw).hexdigest();row[label]=stats
  report['charts'][chart]=row
 report['seconds']=time.monotonic()-start
 out=ROOT/'checks'/'typeA_independent_verification.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
