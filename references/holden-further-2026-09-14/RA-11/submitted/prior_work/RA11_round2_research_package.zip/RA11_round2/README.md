# RA-11, round 2: linear accuracy dependence for arbitrary PSD inputs

**Status: stronger partial resolution, not a full solution of RA-11.**

This package builds on the included first-round archive. It supplies a new upper
bound for **every real positive-semidefinite input matrix**, without assuming
that the matrix is a tensor product. Together with a self-contained ordinary-
oracle lower bound, it determines the dependence on dimension and accuracy for
each fixed tensor order. The constants still depend on the tensor order, and
that dependence does not match the available lower bound.

Start with `manuscript/ra11_linear_accuracy.pdf` (editable LaTeX alongside it).
The manuscript contains the proofs, oracle implementation, constants, and scope
limitations. No independent reviewer or formal proof assistant has certified it.

## Main result

Let `N = n**q`, with integers `n,q >= 2` and `0 < epsilon < 1/2`. The unknown
matrix is an arbitrary real symmetric PSD matrix of order N. One call returns
`M @ kron(v_1,...,v_q)` for specified **real** local vectors. Only calls count;
finite arithmetic, memory, and query conditioning are unrestricted.

Put

    K = 2**q - 1
    H = (3 - 1/n)**q - 1
    D = ceil(sqrt(H)).

The manuscript proves the sufficient worst-case bound

    Q(n,q,epsilon) <= min(N, ceil(2**71 * q*(q+1)*K*D / epsilon)),

with success probability at least 5/6. All algorithmic randomness can be
implemented with finitely many fair bits. Every original oracle call is a real
product-vector call; internal complex products cost q+1 real calls each.

Consequently,

    Q(n,q,epsilon) = Theta_q(min(n**q, 1/epsilon)).

The subscript q is essential: the two constants may depend on q. This is not the
universal-constant, simultaneous three-parameter characterization requested by
RA-11. For example, the new result gives `Theta(sqrt(n))` at fixed `q=2` and
`epsilon=n**(-1/2)` as n grows; the first package's general upper envelope only
gave `O(n)` there.

The explicit constant 2**71 is deliberately conservative. The construction is
a query-complexity proof, not a practical runtime, storage, or stability claim.
It can store dense matrices and perform exhaustive column-subset selection.

## What changed from round 1

The first package characterized the promised PSD tensor-product subclass and
proved interpolation, a projection-conjecture counterexample, and general
upper/lower bounds that did not match. It did not obtain the all-PSD fixed-order
rate above. The new construction learns low-rank controls for the original PSD
partial traces. A decomposition into orthogonal identity/traceless components
bounds both subsequent noisy contractions and final trace-estimator variance
by the accumulated squared approximation errors.

The first archive is preserved byte-for-byte at `prior/RA11_round1.zip`.
Its PDF is also copied to `prior/ra11_round1_partial_results.pdf` for convenience.
The new manuscript does not promote the old product promise to arbitrary PSD
matrices and does not import a scalar-oracle lower bound into the stronger
full-vector model.

## Remaining gap

The retained lower bound is

    Q >= (1/80000) * max_{1<=b<=q}
         min(n**b, sqrt(floor(q/b))/epsilon).

Take the minimum of the new upper bound and all four upper bounds in round 1.
For instance, at `n=2`, `epsilon=1/4`, that envelope still has lower scale
`sqrt(q/log(q))` and upper scale `q*(4/3)**q` for large q. No matching
q-dependence is established here. See `STATUS.md` and `PROOF_AUDIT.md`.

## Package contents

| Location | Purpose |
| --- | --- |
| `manuscript/` | Main PDF and editable LaTeX, including the fixed-order lower-bound proof. |
| `src/ra11_exact_reference.py` | Gaussian-rational implementation of the certified prescription, with a preflight query limit. |
| `src/ra11_hierarchy.py` | Smaller floating-point experiments and exact arithmetic for the theorem's schedule calculation. |
| `tests/`, `results/` | Three executed test suites, JSON evidence, logs, and environment information. |
| `notes/PROOF_GUIDE.md` | Public mathematical outline of the partial-trace hierarchy and interaction accounting. |
| `prior/` | Unchanged first-round ZIP and its manuscript PDF. |
| `SOURCE_NOTES.md` | Primary-source references and the distinction between prior work and this package. |

## Reproduce the checks

Tested environment: Python 3.13.5, NumPy 2.3.5, SymPy 1.14.0. Exact versions are
recorded in `results/environment.json`.

```bash
python -m pip install -r requirements.txt
bash run_checks.sh
bash build.sh
```

The test script stops on any failed assertion and regenerates the JSON/log
files. The build script requires `pdflatex` with the packages named in the
manuscript preamble; it uses a temporary build directory.

A minimal exact example, run from the package root:

```python
import sys
from fractions import Fraction
import sympy as sp
sys.path.insert(0, 'src')
from ra11_exact_reference import MatrixOracle, estimate_trace

u = sp.Matrix([1, 2, 3, 4])
oracle = MatrixOracle(u * u.T, n=2, q=2)
trace, audit = estimate_trace(oracle, Fraction(1, 10), max_queries=100)
assert trace == 30
assert audit['real_calls'] == 4
print(trace, audit)
```

The certified prescription chooses the cheaper exact basis branch in this
small example. For large problems the hierarchy's sufficient constants can be
prohibitive. The exact reference checks its complete upper budget **before**
making any call and raises an error rather than silently substituting smaller
parameters. The rational matrix adapter assumes PSD and checks shape, rational
entries, and symmetry; the mathematical theorem is not restricted to rational
inputs.

The experimental implementation and some exact subroutine tests deliberately
use smaller constants. Their outputs are labeled accordingly. They do not
certify the universal success probability. The enormous full certified hierarchy
was not executed; exact basis runs, algebraic subroutines, finite identities,
and reduced-constant numerical runs were executed.

## Validation scope

All three bundled suites passed. The exact suite includes exhaustive four-phase
checks, Gaussian-rational projection/ownership identities, real interpolation,
column-subset determinant identities, and integer/rational schedule checks.
The numerical suite contains 96 reduced-constant trials and an oracle-access
audit. The exact reference suite checks the complete basis branch, preflight
rejection, exact regression identities, column selection, and metric medians.
These are finite tests, not formal verification of the all-parameter theorem.
The PDF was rendered and visually checked. `MANIFEST.sha256` describes the
packaged files before any user rebuild or test rerun.
