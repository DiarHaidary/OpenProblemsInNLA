# SP-07: exact certificates and partial results

**This archive is not a full solution of SP-07.** It does not determine the exact dimension-independent spectral-matching constant. In particular, it does not prove that the classical Krause ratio is extremal, even in dimension three. The failed sharp-bound approaches and the exact missing inequality are documented rather than presented as completed proofs.

Read **`paper/sp07_report.pdf`** first. Its editable LaTeX source is included.

## Mathematical target

For normal complex matrices with eigenvalues counted with multiplicity, the problem asks for

\[
C_{\rm normal}=\sup_{n\ge2}\sup_{A\ne B}
\frac{\min_{\pi\in S_n}\max_i|\alpha_i-\beta_{\pi(i)}|}{\|A-B\|_2}.
\]

The report retains the cited interval

\[
\sqrt{28/27}\le C_{\rm normal}<2.9038872828.
\]

The upper bound is a literature input, not a new result of this work. The lower bound comes from an established example, not a newly discovered one. Sources and their precise scope are recorded in `notes/sources.md`.

## What the package establishes

The report supplies complete proofs of the Hall-witness formulation, the rectangular-compression estimate and its truncated-singular-value consequence, the sharp constant-one result when one input has at most two distinct eigenvalues, and exact dimension-enlarging reductions to real-orthogonal and balanced-reflection realizations. No novelty is claimed for these statements.

The classical Krause construction is certified algebraically. For its matrix difference, after a unitary right factor, the report gives

\[
M^*M=(108I-ww^*)/52,\qquad w^*w=92.
\]

This proves that the squared spectral norm is `27/13`, while a finite matching calculation gives squared matching distance `28/13`. All entries and the identity are checked with exact SymPy expressions.

An explicit two-by-two counterexample also disproves an attempted inference from an entrywise spectral gap to an operator-norm Sylvester lower bound. The report explains why a small rectangular block norm cannot simply be extended to an equally small full normal-pair difference.

## What is not established

The universal sharp value, the exact size-three constant, global extremality of the Krause example, and stabilization in any finite dimension are not established. The balanced-reflection reduction is an exact reformulation, not an evaluation of the remaining supremum.

For the candidate `sqrt(28/27)`, the missing proof would have to establish, for every dimension, every unitary `U`, every two spectral lists, and every `p+q=n+1`,

\[
\|D_\alpha U-UD_\beta\|_2^2
\ge \frac{27}{28}\min_{i\le p,j\le q}|\alpha_i-\beta_j|^2.
\]

That inequality is **not asserted to be true**. A counterexample to it would refute the candidate without necessarily evaluating the universal constant.

## Files

| Location | Contents |
|---|---|
| `paper/sp07_report.pdf` | Mathematical report, proofs, failed routes, computational methods, and references |
| `paper/sp07_report.tex` | Editable report source |
| `code/verify_exact.py` | Exact algebraic verification of the two displayed certificates |
| `code/matching.py` | Multiplicity-preserving bottleneck matching and small-size Hall enumeration |
| `code/test_results.py` | Numerical consistency tests for matching and proved identities |
| `code/search.py` | Seeded real/complex Givens-parameterized local searches |
| `code/audit_saved_results.py` | Recomputes saved ratios, matchings, normality residuals, and parameter reconstructions |
| `code/summarize_searches.py` | Aggregates the saved search records |
| `results/` | Full numerical records, symbolic-check outputs, audits, and environment versions |
| `notes/proof_obligations.md` | Established statements versus missing claims |
| `notes/sources.md` | Primary web sources and attribution |
| `STATUS.json` | Machine-readable statement of the incomplete status |
| `MANIFEST.sha256` | SHA-256 hashes of the shipped files, excluding the manifest itself |

## Saved numerical work

The archive contains **288 local searches** in dimensions 3, 4, 5, 6, 7, and 9. Both real-orthogonal and complex-unitary parameters were explored, including a separate random-start campaign. The final optimizer returned success in 286 runs; the two other runs remain in the data.

The largest recomputed ratio was `1.0183500170599045`, below the exact Krause value `1.018350154434631...`. No stronger example was obtained. In fact, the independent random starts did not recover even the known nontrivial example. This illustrates the limitations of the local search; it is not evidence sufficient to claim a global upper bound.

A separate suite passed **637 numerical consistency checks**. A further saved-record audit recomputed all 288 records without rerunning an optimizer. These floating-point checks are not interval certificates, exact normality proofs for numerical output, or global optimization certificates. The symbolic certificates are explicitly separated from them.

## Reproduce the checks

Tested environment: Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0. Use an isolated Python environment, then run from this directory:

```sh
python -m pip install -r requirements.txt
python code/verify_exact.py --output results/exact_verification.json
python code/test_results.py --output results/numerical_tests.json
python code/audit_saved_results.py results --output results/saved_results_audit.json
python code/summarize_searches.py results
```

Alternatively, `make verify audit summary` runs those stages. To repeat all five saved search campaigns, run `make search`. This overwrites the corresponding saved-result files. The Makefile fixes BLAS/OpenMP thread counts at one. Fixed seeds do not guarantee bitwise-identical optimizer behavior across every platform or library build.

To rebuild the PDF, use `make pdf` with a LaTeX installation providing the packages named in the report source. The PDF can be read without installing Python or LaTeX.

On a system with `sha256sum`, the unmodified shipped files can be checked with:

```sh
sha256sum -c MANIFEST.sha256
```

Rerunning experiments or rebuilding the PDF changes files and will therefore change their hashes.

## Provenance and limitations

The requested repository and cited primary sources were consulted as public web pages. The package contains generated code and exposition, not full copies of third-party papers or font files. Written proofs and exact algebraic checks were prepared in this interaction; no independent human peer review or proof-assistant formalization is claimed.

The original request was to fully solve the problem. **This package does not meet that mathematical completion condition.** Its purpose is to preserve the verified work and make the remaining gap explicit.
