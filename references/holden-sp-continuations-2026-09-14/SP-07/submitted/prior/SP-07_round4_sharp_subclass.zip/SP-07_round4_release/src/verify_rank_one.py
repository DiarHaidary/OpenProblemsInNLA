"""Exact arithmetic audits for the sharp rank-one-reflection theorem.

Run from the archive root with Python 3.10 or later. No third-party packages
are used. The general mathematical proof is in REPORT.pdf / REPORT.tex;
these checks verify its finite polynomial and extremal-example identities.
"""
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import json
from polynomial import Poly

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def proof_polynomials():
    u,s,h,e = [Poly.var(4,i) for i in range(4)]
    v = 1-u
    q = 1-e
    M = 1-4*v*(2*u-1)*h
    K = -(1-2*s)*e+4*(1-s)**2*v*(2*u-1)*h
    N = 1+4*u*(2*u-1)*h
    L = 4*s*s*v*h
    T = -e+4*v*(2*u-1-2*s*s*u)*h
    P = K*K*N+2*K*L*(1-2*u*h)+L*L-q*T*T
    A2 = 16*u*(s-1)**2*(u-1)*(2*s*u-2*u+1)*(2*s*u-2*s-2*u+1)
    A1 = -4*(2*s*u-2*u+1)*(-2*e*s*u+2*e*u-e+4*s*s*u-4*s*s-4*s*u+4*s)
    A0 = e*(e+4*s*s-4*s)
    Q = A2*h*h+A1*h+A0
    require(P == (M-q)*Q, 'disk-feasibility factorization failed')
    a = 2*u*(1-s)-1
    b = 2*(1-s)*(1-u)
    Q2 = -4*a*(a+1)*b*(1-b)*h*h+4*a*(a*e+b*(1-a-b))*h+e*(e-1+(a+b)**2)
    require(Q == Q2, 'change of variables failed')

    a,b,j = [Poly.var(3,i) for i in range(3)]
    w = a+b
    f = (a+1)*(1-b)*(1+w)**2*(1+j)**2 \
        -4*a*(a+28*b*(1-w))*(1+w)*(1+j)-4*a*b*(28*w*w-27)
    ee = F(1,28)
    G = 4*a*b
    H = ee*(1+w)*(1+j)
    Qnum = -4*a*(a+1)*b*(1-b)*H*H \
        +4*a*(a*ee+b*(1-a-b))*H*G+ee*(ee-1+(a+b)**2)*G*G
    require(ee*ee*G*f+Qnum == 0, 'row-slack substitution failed')

    x,y,z = [Poly.var(3,i) for i in range(3)]
    S = 1+x+2*y
    compact = (S+x)*(1+x)*(2*S-1)**2*(7+5*z)**2 \
        -28*x*(x*S+56*y)*(2*S-1)*(7+5*z) \
        -392*x*y*(28*(S-1)**2-27*S*S)
    expanded = Poly.const(3,0)
    for (ia,ib,ij),c in f.terms.items():
        require(ia+ib <= 4, 'unexpected projective degree')
        expanded += c*49*(2**ib)*F(5,7)**ij*x**ia*y**ib*z**ij*S**(4-ia-ib)
    require(compact == expanded, 'projective polynomial identity failed')
    require(compact.evaluate([1,1,1]) == 0, 'equality point failed')
    return compact


def check_amgm(path=None):
    poly = proof_polynomials()
    data = json.loads(Path(path or ROOT/'certificates/rank_one_amgm.json').read_text())
    pos = [(tuple(ex), F(c)) for ex,c in data['positive']]
    neg = [(tuple(ex), F(c)) for ex,c in data['negative']]
    require(len(set(ex for ex,c in pos)) == len(pos), 'duplicate positive exponents')
    require(len(set(ex for ex,c in neg)) == len(neg), 'duplicate negative exponents')
    require(all(c>0 for ex,c in pos+neg), 'invalid coefficient sign')
    rebuilt = Poly(3, dict(pos))-Poly(3, dict(neg))
    require(rebuilt == poly, 'certificate does not represent the derived polynomial')
    weights = [[F(t) for t in row] for row in data['flow']]
    require(len(weights)==len(neg), 'wrong group count')
    require(all(len(row)==len(pos) for row in weights), 'wrong group width')
    require(all(t>=0 for row in weights for t in row), 'negative AM-GM weight')
    for i,(ex,c) in enumerate(pos):
        require(sum(row[i] for row in weights)==c, 'positive coefficient allocation failed')
    for (ex,c),row in zip(neg,weights):
        require(sum(row)==c, 'AM-GM weight total failed')
        for dim in range(3):
            require(sum(t*pe[dim] for (pe,_),t in zip(pos,row))==c*ex[dim],
                    'AM-GM exponent barycenter failed')
    # Group 3 forces x=y=z=1 at equality in the positive orthant.
    group = weights[2]
    support = {ex for (ex,_),t in zip(pos,group) if t>0}
    require({(0,0,0),(0,0,1),(0,1,0),(2,0,1)} <= support,
            'claimed equality characterization is not certified')
    return {'polynomial_identities':4,'positive_monomials':len(pos),
            'negative_monomials':len(neg),'amgm_groups':len(weights),
            'nonzero_allocations':sum(t>0 for row in weights for t in row),
            'all_weight_and_exponent_equalities_exact':True,
            'unique_positive_equality_point':[1,1,1]}

# Q(sqrt(-3)), represented without decimal numbers.
class Quad:
    def __init__(self, a=0, b=0):
        self.a, self.b = F(a), F(b)
    def _c(self,o): return o if isinstance(o,Quad) else Quad(o)
    def __add__(self,o):
        o=self._c(o); return Quad(self.a+o.a,self.b+o.b)
    __radd__=__add__
    def __neg__(self): return Quad(-self.a,-self.b)
    def __sub__(self,o): return self+(-self._c(o))
    def __rsub__(self,o): return self._c(o)+(-self)
    def __mul__(self,o):
        o=self._c(o);return Quad(self.a*o.a-3*self.b*o.b,self.a*o.b+self.b*o.a)
    __rmul__=__mul__
    def conj(self):return Quad(self.a,-self.b)
    def __truediv__(self,o):
        o=self._c(o);den=o.a*o.a+3*o.b*o.b
        if not den:raise ZeroDivisionError()
        v=self*o.conj();return Quad(v.a/den,v.b/den)
    def __eq__(self,o):
        o=self._c(o);return self.a==o.a and self.b==o.b
    def norm2(self):return self.a*self.a+3*self.b*self.b


def mm(A,B):
    return [[sum((A[i][k]*B[k][j] for k in range(len(B))),Quad())
             for j in range(len(B[0]))] for i in range(len(A))]


def check_extremizer():
    t=[F(1,4),F(5,8),F(1,8)]
    require(sum(t)==1 and all(v>0 for v in t),'invalid extremal weights')
    diag=[Quad(1),Quad(F(4,7),F(5,7)),Quad(F(2,7),F(-1,7))]
    R=[[Quad(int(i==j)-2*t[j]) for j in range(3)] for i in range(3)]
    Id=[[Quad(int(i==j)) for j in range(3)] for i in range(3)]
    require(mm(R,R)==Id,'reflection identity failed')
    require(all(t[i]*R[i][j]==t[j]*R[j][i] for i in range(3) for j in range(3)),
            'weighted self-adjointness failed')
    H=[[(diag[i]+diag[j])*R[i][j] for j in range(3)] for i in range(3)]
    Hadj=[[H[j][i].conj()*t[j]/t[i] for j in range(3)] for i in range(3)]
    G=mm(Hadj,H)
    C27=[[7*G[i][j]-27*Id[i][j] for j in range(3)] for i in range(3)]
    C4=[[7*G[i][j]-4*Id[i][j] for j in range(3)] for i in range(3)]
    require(all(v==0 for row in mm(C27,C4) for v in row),'Gram polynomial failed')
    require(sum((G[i][i] for i in range(3)),Quad())==F(58,7),'Gram trace failed')
    distances=[[(diag[i]+diag[j]).norm2() for j in range(3)] for i in range(3)]
    require(all(distances[i][j]>=4 for i in range(2) for j in range(2)),
            'Hall obstruction failed')
    costs=[max(distances[i][p[i]] for i in range(3)) for p in permutations(range(3))]
    require(min(costs)==4,'attaining matching failed')
    require(F(4,1)/F(27,7)==F(28,27),'extremal ratio failed')
    return {'normality_from_diagonal_and_reflection':True,
            'squared_matching_distance':'4',
            'squared_singular_values':['27/7','27/7','4/7'],
            'squared_ratio':'28/27',
            'all_six_permutation_costs':[str(x) for x in costs],
            'squared_distance_table':[[str(x) for x in row] for row in distances]}


def main():
    out={'status':'PASS','arithmetic':'integers and fractions only',
         'amgm':check_amgm(),'extremizer':check_extremizer()}
    print(json.dumps(out,indent=2))
    return out

if __name__=='__main__':main()
