# Source ledger

Sources were read through public webpages; no GitHub connector was used. Access date: 2026-09-13. Search did not establish an all-rank formula or a rigorous counterexample.

## Target

OpenProblemsInNLA, SP-03, “Euclidean distance degree of symplectic groups.”
https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/eigenvalues-and-inverse-problems/SP-03

This is the exact target. The conjectural expression is not a premise used in any proof or verifier.

## Published critical-point counts and the compatible-coordinate change

Jasmijn A. Baaijens and Jan Draisma, *Euclidean distance degrees of real algebraic groups*, Linear Algebra and its Applications 467 (2015), 174–187. DOI: 10.1016/j.laa.2014.11.012. Section 5, especially pp. 186–187.
https://pure.tue.nl/ws/files/3846347/391917266748824.pdf
https://arxiv.org/abs/1405.0422

Inputs used: the problem's ED-degree convention; the compatible basis change; the published table 4, 24, 544. No copy of the publisher PDF is redistributed in this package. The accompanying certificates independently prove only the lower bounds stated in the verification output.

## Ordinary degree of the symplectic group

M. Brandt, J. Bruce, T. Brysiewicz, R. Krone, and E. Robeva, *The degree of SO(n)*, arXiv:1701.03200v2 (2017), Section 3, symplectic degree formula.
https://arxiv.org/abs/1701.03200
https://arxiv.org/html/1701.03200v2

Input used: the ordinary degree of the rank-m symplectic group is det[binomial(2i+2j−2, 2i−1)]. The report derives a separate ED upper bound from that ordinary degree. These two kinds of degree are never identified.

## Preceding SP-03 reduction

Sidney Holden, supporting SP-03 multiplier reduction, repository note dated 2026-09-12.
https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/references/holden-spectral-2026-09-12/SP-03/proof.md

Already present in that note: the skew normal multiplier, the saturated quartic system, generic exclusion of det(I+K²)=0, and the rank-one quartic check. Those are used and attributed, not claimed as new.

The m²-variable Schur reduction, the symmetry-assisted ED upper-bound argument, the block-product lower-bound argument, and the provided exact-dyadic certificates are developed in this package. No priority or literature-wide novelty claim is made, and the written proofs have not had an independent audit.

## Repository scope rules

OpenProblemsInNLA, CONTRIBUTING.md.
https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/CONTRIBUTING.md

A complete resolution must settle the original quantifiers and target. The present package does not meet that full-resolution criterion and makes no repository edits.
