"""80-digit numerical cross-checks of exact rational certificates.
These eigensolver outputs are NOT the proof: the exact LDL check is the proof.
"""
import argparse,json
from pathlib import Path
import mpmath as mp

def run(folder,output):
    mp.mp.dps=80;records=[]
    for name in ['certificate_five_stronger','certificate_seven']:
        data=json.loads((folder/(name+'.json')).read_text());z=[mp.mpc(a,b) for a,b in data['z']];n=len(z)
        X=mp.matrix([[mp.mpf(a) for a in row] for row in data['X']]);r=X.cols;Y=mp.matrix(n,r)
        for i in range(r):Y[i,i]=1
        for i in range(X.rows):
            for j in range(r):Y[r+i,j]=X[i,j]
        P=Y*(Y.T*Y)**-1*Y.T;S=mp.eye(n)-2*P;D=mp.diag(z);M=D+S*D*S
        eig,_=mp.eighe(M.H*M);norm=mp.sqrt(eig[eig.rows-1])
        gap=min(abs(z[i]+z[j]) for i in data['I'] for j in data['J'])
        q=mp.mpf(data['ratio_lower_bound']);t=mp.mpf(data['norm_upper_bound'])
        if not norm<t or not gap>q*t:raise AssertionError('High-precision check disagrees with certificate')
        records.append(dict(certificate=name,precision_digits=80,norm=mp.nstr(norm,65),hall_gap=mp.nstr(gap,65),
                            hall_ratio=mp.nstr(gap/norm,65),smallest_norm_certificate_eigenvalue=mp.nstr(t*t-eig[eig.rows-1],65)))
    result=dict(status='Numerical high-precision cross-checks only; exact LDL is the proof.',records=records)
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--folder',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.folder,a.output)
