#!/bin/sh
set -eu
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
python code/check_manifest.py
python code/check_exact_certificate.py
python code/verify.py
