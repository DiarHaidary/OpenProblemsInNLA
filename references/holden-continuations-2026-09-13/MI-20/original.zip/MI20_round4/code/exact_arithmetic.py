"""Standard-library exact acceptance primitives."""
from fractions import Fraction as F

def require(condition,message):
    if not condition:raise ValueError(message)

def rational(value):
    require(isinstance(value,(str,int)) and not isinstance(value,bool),'Exact rational strings or integers required')
    try:return F(value)
    except (ValueError,ZeroDivisionError) as exc:raise ValueError('Invalid rational number') from exc

def positive_definite(matrix):
    n=len(matrix)
    require(n>0 and all(len(row)==n for row in matrix),'Non-square Gram matrix')
    require(all(matrix[i][j]==matrix[j][i] for i in range(n) for j in range(i)),'Non-symmetric Gram matrix')
    a=[row[:] for row in matrix]
    for k in range(n):
        pivot=a[k][k];require(pivot>0,'Gram matrix is not positive definite')
        for i in range(k+1,n):
            for j in range(i,n):a[j][i]=a[i][j]=a[i][j]-a[i][k]*a[k][j]/pivot
    return True

def sparse_model(matrices):
    return [[[[ (k,c) for k,c in enumerate(cell) if c] for cell in row] for row in mat] for mat in matrices]

def gram_coefficients(grams,sparse,n):
    out=[F(0)]*n
    for Z,M in zip(grams,sparse):
        for i,row in enumerate(M):
            for j,cell in enumerate(row):
                for k,c in cell:out[k]+=Z[i][j]*c
    return out
