#!/usr/bin/env python3
"""Exact, certificate-oriented tools for the SP-10 graph complement problem.

This is NOT an algorithm claimed to resolve SP-10 for arbitrary graphs.
A bounded witness search reports failure as UNKNOWN, never as a counterexample.
All returned matrix certificates are checked with rational arithmetic.
The mathematical core and verifier use only the Python standard library.
"""
from __future__ import annotations
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
from math import gcd, lcm, isqrt
import argparse
import json
import random
from pathlib import Path
from typing import Sequence

IntMatrix = list[list[int]]


def validate_graph(adj: Sequence[int]) -> tuple[int, ...]:
    a = tuple(adj)
    n = len(a)
    if n < 1:
        raise ValueError('A graph must have at least one vertex.')
    for i, row in enumerate(a):
        if not isinstance(row, int) or row < 0 or row >= 1 << n or row >> i & 1:
            raise ValueError('Invalid adjacency bit mask or a loop.')
        for j in range(i):
            if (row >> j & 1) != (a[j] >> i & 1):
                raise ValueError('The graph must be undirected.')
    return a


def from_edges(n: int, edges: Sequence[Sequence[int]]) -> tuple[int, ...]:
    if n < 1:
        raise ValueError('n must be positive.')
    a = [0] * n
    for edge in edges:
        if len(edge) != 2:
            raise ValueError('Every edge must have two endpoints.')
        u, v = edge
        if not (isinstance(u, int) and isinstance(v, int) and 0 <= u < n and 0 <= v < n) or u == v:
            raise ValueError('Invalid edge.')
        a[u] |= 1 << v
        a[v] |= 1 << u
    return validate_graph(a)


def edges(adj: Sequence[int]) -> list[list[int]]:
    return [[i, j] for j in range(len(adj)) for i in range(j) if adj[i] >> j & 1]


def complement(adj: Sequence[int]) -> tuple[int, ...]:
    a = validate_graph(adj)
    full = (1 << len(a)) - 1
    return tuple(full ^ row ^ (1 << i) for i, row in enumerate(a))


def dot(u: Sequence[int], v: Sequence[int]) -> int:
    return sum(x * y for x, y in zip(u, v))


def rref(rows: Sequence[Sequence[int | Fraction]], ncols: int) -> tuple[list[list[Fraction]], list[int]]:
    if ncols < 0 or any(len(row) != ncols for row in rows):
        raise ValueError('Inconsistent matrix dimensions.')
    a = [[Fraction(x) for x in row] for row in rows]
    pivots: list[int] = []
    r = 0
    for c in range(ncols):
        p = next((i for i in range(r, len(a)) if a[i][c]), None)
        if p is None:
            continue
        a[r], a[p] = a[p], a[r]
        pivot = a[r][c]
        a[r] = [x / pivot for x in a[r]]
        for i in range(len(a)):
            if i != r and a[i][c]:
                factor = a[i][c]
                a[i] = [x - factor * y for x, y in zip(a[i], a[r])]
        pivots.append(c)
        r += 1
        if r == len(a):
            break
    return a, pivots


def primitive(v: Sequence[int | Fraction]) -> list[int]:
    w = [Fraction(x) for x in v]
    denominator = 1
    for x in w:
        denominator = lcm(denominator, x.denominator)
    z = [int(x * denominator) for x in w]
    common = 0
    for x in z:
        common = gcd(common, abs(x))
    if common:
        z = [x // common for x in z]
        first = next(x for x in z if x)
        if first < 0:
            z = [-x for x in z]
    return z


def nullspace(rows: Sequence[Sequence[int]], ncols: int) -> IntMatrix:
    reduced, pivots = rref(rows, ncols)
    basis = []
    for f in range(ncols):
        if f not in pivots:
            v = [Fraction(0)] * ncols
            v[f] = Fraction(1)
            for r, p in enumerate(pivots):
                v[p] = -reduced[r][f]
            basis.append(primitive(v))
    return basis


def rank(rows: Sequence[Sequence[int]], ncols: int | None = None) -> int:
    if ncols is None:
        ncols = len(rows[0]) if rows else 0
    return len(rref(rows, ncols)[1])


def gram(vectors: Sequence[Sequence[int]]) -> IntMatrix:
    return [[dot(x, y) for y in vectors] for x in vectors]


def check_matrix(adj: Sequence[int], matrix: Sequence[Sequence[int]]) -> int:
    a = validate_graph(adj)
    n = len(a)
    if len(matrix) != n or any(len(row) != n for row in matrix):
        raise ValueError('Certificate matrix has the wrong shape.')
    if any(type(x) is not int for row in matrix for x in row):
        raise ValueError('This verifier accepts integer matrix entries only.')
    for i in range(n):
        for j in range(i):
            if matrix[i][j] != matrix[j][i]:
                raise ValueError('Certificate matrix is not symmetric.')
            if bool(matrix[i][j]) != bool(a[i] >> j & 1):
                raise ValueError(f'Incorrect off-diagonal support at ({i},{j}).')
    return rank(matrix)


def check_gram(adj: Sequence[int], vectors: Sequence[Sequence[int]]) -> int:
    a = validate_graph(adj)
    if len(vectors) != len(a):
        raise ValueError('Wrong number of Gram vectors.')
    d = len(vectors[0])
    if any(len(v) != d or any(type(x) is not int for x in v) for v in vectors):
        raise ValueError('Malformed integer Gram vectors.')
    matrix = gram(vectors)
    r = check_matrix(a, matrix)
    if r != rank(vectors, d):
        raise AssertionError('Exact Gram-rank identity failed.')
    return r


def degeneracy(adj: Sequence[int]) -> int:
    a = validate_graph(adj)
    s = (1 << len(a)) - 1
    best = 0
    while s:
        v = min((v for v in range(len(a)) if s >> v & 1), key=lambda v: (a[v] & s).bit_count())
        best = max(best, (a[v] & s).bit_count())
        s ^= 1 << v
    return best


def best_mcs(adj: Sequence[int]) -> tuple[int, tuple[int, ...]]:
    """Exact maximal final degree and a maximizing MCS order; exponential."""
    a = validate_graph(adj)
    n = len(a)
    if n > 22:
        raise ValueError('Exact MCS subset enumeration is limited to n <= 22.')
    full = (1 << n) - 1

    @lru_cache(None)
    def solve(s: int) -> tuple[int, tuple[int, ...]]:
        remaining = full ^ s
        if remaining & (remaining - 1) == 0:
            v = remaining.bit_length() - 1
            return a[v].bit_count(), (v,)
        candidates = [v for v in range(n) if remaining >> v & 1]
        label = max((a[v] & s).bit_count() for v in candidates)
        results = []
        for v in candidates:
            if (a[v] & s).bit_count() == label:
                value, tail = solve(s | 1 << v)
                results.append((value, (v,) + tail))
        return max(results)

    return solve(0)


def check_mcs(adj: Sequence[int], order: Sequence[int]) -> bool:
    a = validate_graph(adj)
    n = len(a)
    if sorted(order) != list(range(n)):
        return False
    s = 0
    for v in order:
        if (a[v] & s).bit_count() != max((a[u] & s).bit_count() for u in range(n) if not (s >> u & 1)):
            return False
        s |= 1 << v
    return True


def degree_threshold_bound(adj: Sequence[int]) -> tuple[int, int, int]:
    """Return a, b, n+1+b-a for a nonempty, noncomplete graph.

    a = min over nonedges of max endpoint degree;
    b = max over edges of min endpoint degree.
    The bound uses Hall's theorem (not an elementary standalone theorem).
    """
    g = validate_graph(adj)
    n = len(g)
    deg = [v.bit_count() for v in g]
    edge_values, nonedge_values = [], []
    for u, v in combinations(range(n), 2):
        if g[u] >> v & 1:
            edge_values.append(min(deg[u], deg[v]))
        else:
            nonedge_values.append(max(deg[u], deg[v]))
    if not edge_values or not nonedge_values:
        raise ValueError('Use direct witnesses for complete or empty graphs.')
    a, b = min(nonedge_values), max(edge_values)
    return a, b, n + 1 + b - a


def universal_bound(n: int) -> int:
    if n < 1:
        raise ValueError('n must be positive.')
    return 1 + isqrt(2 * n * n - 2 * n + 1)


def sequential_gram(adj: Sequence[int], d: int, order: Sequence[int], rng: random.Random) -> IntMatrix | None:
    """Try one exact sequential orthogonal construction.

    Zero vectors are allowed only for isolated vertices. A forced extra zero
    is a failed search branch, NOT a mathematical infeasibility certificate.
    """
    a = validate_graph(adj)
    n = len(a)
    if d < 0 or sorted(order) != list(range(n)):
        raise ValueError('Invalid dimension or order.')
    vectors: list[list[int] | None] = [None] * n
    visited: list[int] = []
    for v in order:
        if not a[v]:
            vectors[v] = [0] * d
            visited.append(v)
            continue
        constraints = [vectors[u] for u in visited if not (a[v] >> u & 1)]
        basis = nullspace(constraints, d)  # type: ignore[arg-type]
        if not basis:
            return None
        neighbors = [u for u in visited if a[v] >> u & 1]
        # No choice in this subspace can repair a forced extra orthogonality.
        if any(all(dot(b, vectors[u]) == 0 for b in basis) for u in neighbors):  # type: ignore[arg-type]
            return None
        chosen = None
        for _ in range(24):
            coeff = [rng.randint(-3, 3) for _ in basis]
            candidate = primitive([sum(c * b[j] for c, b in zip(coeff, basis)) for j in range(d)])
            if any(candidate) and all(dot(candidate, vectors[u]) for u in neighbors):  # type: ignore[arg-type]
                chosen = candidate
                break
        if chosen is None:
            # A moment-curve choice avoids a finite union of proper hyperplanes.
            k = len(basis)
            for t in range((len(neighbors) + 1) * max(k - 1, 1) + 2):
                candidate = primitive([sum((t ** i) * b[j] for i, b in enumerate(basis)) for j in range(d)])
                if any(candidate) and all(dot(candidate, vectors[u]) for u in neighbors):  # type: ignore[arg-type]
                    chosen = candidate
                    break
        if chosen is None:
            raise AssertionError('Finite-hyperplane avoidance unexpectedly failed.')
        vectors[v] = chosen
        visited.append(v)
    return vectors  # type: ignore[return-value]


def laplacian_vectors(adj: Sequence[int]) -> IntMatrix:
    """A deterministic integer Gram certificate of rank n-components."""
    a = validate_graph(adj)
    e = edges(a)
    v = [[0] * len(e) for _ in a]
    for k, (u, w) in enumerate(e):
        v[u][k] = 1
        v[w][k] = -1
    return v


def search_gram(adj: Sequence[int], d: int, trials: int = 96, seed: int = 0,
                preferred_orders: Sequence[Sequence[int]] = ()) -> IntMatrix | None:
    a = validate_graph(adj)
    if trials < 0 or d < 0:
        raise ValueError('Negative trial count or dimension.')
    if not any(a):
        return [[] for _ in a]
    rng = random.Random(seed)
    for t in range(trials):
        if t < len(preferred_orders):
            order = list(preferred_orders[t])
        else:
            order = list(range(len(a)))
            rng.shuffle(order)
        result = sequential_gram(a, d, order, rng)
        if result is not None:
            check_gram(a, result)
            return result
    return None


def search_pair(adj: Sequence[int], trials: int = 96, seed: int = 0) -> dict:
    a = validate_graph(adj)
    b = complement(a)
    n = len(a)
    certificates: list[IntMatrix] = [laplacian_vectors(a), laplacian_vectors(b)]
    current_ranks = [check_gram(a, certificates[0]), check_gram(b, certificates[1])]
    orders = []
    for g in (a, b):
        if n <= 22:
            _, order = best_mcs(g)
            orders.append([order, tuple(reversed(order))])
        else:
            orders.append([])
    attempts = []
    for side, g in enumerate((a, b)):
        # Search below the current certificate rank, from low to high.
        for d in range(1, current_ranks[side]):
            result = search_gram(g, d, trials=trials, seed=seed + 1009 * side + 101 * d,
                                 preferred_orders=orders[side])
            attempts.append({'side': side, 'dimension': d, 'found': result is not None})
            if result is not None:
                certificates[side] = result
                current_ranks[side] = check_gram(g, result)
                break
    success = sum(current_ranks) <= n + 2
    return {'n': n, 'edges': edges(a), 'status': 'CERTIFIED' if success else 'UNKNOWN',
            'gram_G': certificates[0], 'gram_complement': certificates[1],
            'rank_G': current_ranks[0], 'rank_complement': current_ranks[1],
            'rank_sum': sum(current_ranks), 'target': n + 2,
            'attempts': attempts}


def verify_pair(certificate: dict) -> dict:
    a = from_edges(certificate['n'], certificate['edges'])
    b = complement(a)
    rg = check_gram(a, certificate['gram_G'])
    rb = check_gram(b, certificate['gram_complement'])
    for field, value in [('rank_G', rg), ('rank_complement', rb), ('rank_sum', rg + rb),
                         ('target', len(a) + 2)]:
        if certificate.get(field) != value:
            raise ValueError(f'Incorrect recorded value for {field}.')
    certified = rg + rb <= len(a) + 2
    expected = 'CERTIFIED' if certified else 'UNKNOWN'
    if certificate.get('status') != expected:
        raise ValueError('Incorrect certificate status.')
    return {'n': len(a), 'rank_G': rg, 'rank_complement': rb, 'rank_sum': rg + rb,
            'status': expected}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('verify', help='Verify a JSON certificate or JSONL collection exactly.')
    p.add_argument('path', type=Path)
    p = sub.add_parser('search', help='Search for a certificate for a supplied graph JSON.')
    p.add_argument('path', type=Path, help='JSON with n and edges (zero-based vertices).')
    p.add_argument('--trials', type=int, default=96)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'verify':
        content = args.path.read_text()
        records = [json.loads(line) for line in content.splitlines() if line.strip()] if args.path.suffix == '.jsonl' else [json.loads(content)]
        results = [verify_pair(c) for c in records]
        print(json.dumps({'verified': len(results), 'certified': sum(r['status'] == 'CERTIFIED' for r in results),
                          'unknown': sum(r['status'] == 'UNKNOWN' for r in results)}, indent=2))
    else:
        source = json.loads(args.path.read_text())
        a = from_edges(source['n'], source['edges'])
        result = search_pair(a, trials=args.trials, seed=args.seed)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(verify_pair(result), indent=2))


if __name__ == '__main__':
    main()
