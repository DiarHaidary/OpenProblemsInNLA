# SP-10: corrected bounds and nontrivial-module closure

**Status: PARTIAL. This archive does not prove or disprove SP-10 for arbitrary graphs.**

Read `manuscript/report.pdf` for the complete mathematical report. Its editable source is `manuscript/report.tex`.

## Results

The preceding report used the false inequality

    d(G) + d(complement G) >= ceil((2n - 2)/3).

A nine-vertex counterexample is proved by hand and certified by exact deletion orders and induced cores. An infinite family of counterexamples to the same auxiliary inequality is also provided. None is a counterexample to SP-10.

The numerical bound `rho(G) + rho(complement G) <= floor((4n+2)/3)` survives by a corrected proof. Here rho requires every Gram vector to be nonzero. The proof combines Hall's Delta Theorem and minor monotonicity with the independently proved bound `rho(complement G) <= 2d(G)+1`; it does not use the false degeneracy inequality. Both asymmetric bounds `2rho(G)+rho(complement G)<=2n+1` and its swapped version are retained.

The main extension is a layered substitution theorem. Assuming Hall's input, a graph obtained by replacing every vertex of an arbitrary quotient by a module of order at least two satisfies the stronger rho version of SP-10 whenever every module individually satisfies that version. Modules with complementary ranks one, two, or at least three may be mixed. The quotient itself is not assumed to satisfy SP-10. A module is a set with uniform adjacency to each outside vertex; an arbitrary partition is not a module decomposition.

Singleton modules remain excluded. Taking the entire graph as one module is circular, and taking every vertex as a singleton loses the required savings. Thus the closure theorem is not a solution for arbitrary graphs.

Finally, an infinite cubic-caterpillar family has `D(G)+D(complement G)=n-3`, where D is the maximum minimum degree among all minors. The same family satisfies the PSD rank-sum target with equality. This rules out a specific all-minor minimum-degree shortcut; it does not rule out all-minor MCS arguments or other methods.

No originality claim is made. In particular, the ordinary all-twin case has prior complementary-vanishing results. The two earlier archives are retained unmodified, including their original statements, limitations, and logs. The new report explicitly supersedes the incorrect premise in Section 8 of the second report.

## Package map

- `manuscript/report.pdf` and `report.tex`: complete proofs, dependency statements, exact examples, and the remaining gap.
- `src/layered_substitution.py`: bounded rational construction for selected module/quotient witnesses.
- `src/exact_tools.py`, `src/verify_all.py`: standard-library rational support, rank, and degeneracy checks.
- `src/crosscheck_sympy.py`: second implementation, not importing the primary matrix routines.
- `src/generate_certificates.py`: deterministic fixtures, including mixed substitutions and cubic trees.
- `src/legacy_sp10.py`: preserved first-round exact search implementation, used for the nine-vertex quotient witness only.
- `certificates/`: exact rational Gram factors and integer degeneracy certificates.
- `tests/`: unit tests and corruption checks.
- `results/`: actual exit codes, verification summaries, execution logs, and environment metadata.
- `claims.json`: dependency and limitation ledger.
- `sources.json`: source inventory; the report contains inline numbered references.
- `prior/`: byte-for-byte copies of the first and second research ZIPs.
- `SHA256SUMS`: checksums for the delivered files other than the checksum file itself.

## Reproduce

From this directory:

```sh
python -m unittest discover -s tests -v
python src/generate_certificates.py
python src/verify_all.py
python -m pip install -r requirements-optional.txt
python src/crosscheck_sympy.py
```

The first three commands need only Python's standard library. The pinned optional dependency is the SymPy version actually used for the second check. `python src/run_checks.py` runs the full sequence, records exit codes, and regenerates the paper's table. Compile the paper by running `pdflatex report.tex` twice from `manuscript/`.

Every delivered successful rank certificate is checked at every off-diagonal position and by exact rational rank computation. A claimed rank field is never trusted. Floating-point rank thresholds are not used. Counts in the results refer to saved records, not necessarily distinct graph isomorphism classes.

The bounded constructor is not guaranteed to find optimal quotient factors or an admissible orientation for an arbitrary input. A failed search, exception, or exceeded budget is inconclusive, never a counterexample. The verifiers certify supplied matrices; they do not determine minimum ranks in general or test the Strong Arnold Property.

**The remaining research target is still the coefficient-one bound for an arbitrary graph. This package must not be labeled a complete solution.**
