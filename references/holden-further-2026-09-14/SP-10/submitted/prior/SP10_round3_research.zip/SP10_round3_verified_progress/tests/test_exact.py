import unittest,sys,json,random
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from exact_tools import *
from layered_substitution import *
from generate_certificates import degeneracy_example,cubic_tree,forest_complement,mod

class ExactTests(unittest.TestCase):
    def test_rank_dependent(self):self.assertEqual(rank([[1,2,3],[2,4,6],[0,1,1]]),2)
    def test_rank_fractions(self):self.assertEqual(rank([['1/3','1/7'],['2/3','2/7']]),1)
    def test_rank_zero(self):self.assertEqual(rank([[0,0],[0,0]]),0)
    def test_reject_float(self):
        with self.assertRaises(ValueError):matrix([[0.5]])
    def test_reject_bool(self):
        with self.assertRaises(ValueError):edges(2,[(False,1)])
    def test_reject_loop(self):
        with self.assertRaises(ValueError):edges(2,[(1,1)])
    def test_reject_ragged(self):
        with self.assertRaises(ValueError):matrix([[1],[2,3]])
    def test_reject_duplicate_edge(self):
        with self.assertRaises(ValueError):edges(2,[(0,1),(1,0)])
    def test_J9(self):
        E=degeneracy_example(9,2);self.assertEqual([peeling(9,e)['degeneracy'] for e in (E,complement(9,E))],[2,3])
    def test_J14(self):
        E=degeneracy_example(14,4);self.assertEqual([peeling(14,e)['degeneracy'] for e in (E,complement(14,E))],[4,4])
    def test_degeneracy_verifier(self):
        E=degeneracy_example(9,2);self.assertEqual(verify_peeling(9,E,peeling(9,E)),2)
    def test_bad_core(self):
        E=degeneracy_example(9,2);c=peeling(9,E);c['core']=[0]
        with self.assertRaises(ValueError):verify_peeling(9,E,c)
    def test_weighted_rotation(self):
        X=[[F(1),F(2),F(3)],[F(4),F(-1),F(2)]];w=[F(3,2),F(1),F(1)];Y=rotate(X,w,random.Random(8))
        for i in range(2):
            for j in range(2):self.assertEqual(sum(X[i][k]*X[j][k]*w[k] for k in range(3)),sum(Y[i][k]*Y[j][k]*w[k] for k in range(3)))
    def test_local_patterns(self):
        for kind,ns in [('clique',[2,3,4]),('independent',[2,3,4]),('path',[2,3,4,6]),('half',[4,6,8])]:
            for n in ns:
                m=mod(kind,n);E=module_edges(m)
                for side in (0,1):
                    for d in (F(1),F(3,2),F(5)):
                        X=local_vectors(m,side,d);w=[d]+[F(1)]*(len(X[0])-1);EE=E if not side else complement(n,E)
                        for i in range(n):
                            for j in range(i+1,n):self.assertEqual(bool(sum(X[i][k]*X[j][k]*w[k] for k in range(len(w)))),(i,j) in EE)
    def test_coloring_clique(self):self.assertEqual(len(set(color_induced(range(5),set(combinations(range(5),2))).values())),5)
    def test_coloring_cycle(self):self.assertEqual(len(set(color_induced(range(5),{(0,1),(1,2),(2,3),(3,4),(0,4)}).values())),3)
    def test_singleton_rejected(self):
        with self.assertRaises(ValueError):validate_module(mod('clique',1))
    def test_zero_budget_unknown(self):
        with self.assertRaises(RuntimeError):side_factor(1,set(),[[F(1)]],[mod('clique',2)],0,max_trials=0)
    def test_tree_factors(self):
        n,E,paths=cubic_tree(6);V=incidence(n,E);W=forest_complement(n,E)
        r={'n':n,'edges':sorted(E),'gram_G':serialize(V),'gram_complement':serialize(W)}
        self.assertEqual(verify_pair(r)['ranks'],[n-1,3])
        self.assertEqual(len(set(sum(paths,[]))),12)
    def test_recomputed_ranks(self):
        r={'n':2,'edges':[[0,1]],'gram_G':[['1'],['1']],'gram_complement':[['1','0'],['0','1']],'verified':{'ranks':[0,0]}}
        self.assertEqual(verify_pair(r)['ranks'],[1,2])
    def test_support_corruption(self):
        r={'n':2,'edges':[],'gram_G':[['1'],['1']],'gram_complement':[['1'],['1']]}
        with self.assertRaises(ValueError):verify_pair(r)
    def test_zero_row_rejected(self):
        r={'n':2,'edges':[],'gram_G':[['0','0'],['0','1']],'gram_complement':[['1'],['1']]}
        with self.assertRaises(ValueError):verify_pair(r)
    def test_bookkeeping(self):
        for q in range(8):
            for l in range(8):
                for p in range(8):
                    t=q+l+p
                    if not t:continue
                    excess=-2*q-3*l-4*p+2*t+2+(p+1 if p else 0)
                    self.assertEqual(excess,3-p-l if p else 2-l)
                    self.assertLessEqual(excess,2)
    def test_scalar_relaxation(self):
        for k in range(1,12):
            n=3*k+1;d=k;r=2*k+1
            self.assertEqual(r,n-d);self.assertEqual(r,2*d+1);self.assertEqual(2*r,(4*n+2)//3)

if __name__=='__main__':unittest.main()
