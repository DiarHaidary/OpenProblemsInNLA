"""Independent exact five-dimensional certificate checker (standard library only).
Uses Fraction and Gaussian-rational arithmetic; does not import NumPy or SymPy.
Every comparison supporting the mathematical claim is exact.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from pathlib import Path
import argparse,itertools,json,time

ZDATA=[['1.4223377736','0'],['-0.5481288963','-0.5246504403'],['-0.4371044386','0.2623252201'],['-0.5348211611','-0.3933679879'],['-0.1140326107','0.2205009204']]
XDATA=[['0.2113749472','-0.6800914025'],['-1.0430520192','0.3802184713'],['-0.0209231689','0.5372112754']]
@dataclass(frozen=True)
class G:
    a:F=F(0)
    b:F=F(0)
    @staticmethod
    def cast(x):return x if isinstance(x,G) else G(F(x))
    def __add__(self,y):y=G.cast(y);return G(self.a+y.a,self.b+y.b)
    __radd__=__add__
    def __neg__(self):return G(-self.a,-self.b)
    def __sub__(self,y):return self+-G.cast(y)
    def __rsub__(self,y):return G.cast(y)+-self
    def __mul__(self,y):y=G.cast(y);return G(self.a*y.a-self.b*y.b,self.a*y.b+self.b*y.a)
    __rmul__=__mul__
    def conj(self):return G(self.a,-self.b)
    def abs2(self):return self.a*self.a+self.b*self.b
    def __truediv__(self,y):
        y=G.cast(y);d=y.abs2()
        if not d:raise ZeroDivisionError
        z=self*y.conj();return G(z.a/d,z.b/d)

def run(output):
    start=time.monotonic();z=[G(F(a),F(b)) for a,b in ZDATA]
    Y=[[F(1),F(0)],[F(0),F(1)]]+[[F(q) for q in row] for row in XDATA]
    T=[[sum(Y[k][i]*Y[k][j] for k in range(5)) for j in range(2)] for i in range(2)]
    det=T[0][0]*T[1][1]-T[0][1]*T[1][0];assert det>0
    Ti=[[T[1][1]/det,-T[0][1]/det],[-T[1][0]/det,T[0][0]/det]]
    P=[[sum(Y[i][a]*Ti[a][b]*Y[j][b] for a in range(2) for b in range(2)) for j in range(5)] for i in range(5)]
    S=[[F(i==j)-2*P[i][j] for j in range(5)] for i in range(5)]
    assert all(sum(S[i][k]*S[k][j] for k in range(5))==F(i==j) for i in range(5) for j in range(5))
    M=[[z[i]*F(i==j)+sum((S[i][k]*z[k]*S[k][j] for k in range(5)),G()) for j in range(5)] for i in range(5)]
    H=[[G(F(i==j))-sum((M[k][i].conj()*M[k][j] for k in range(5)),G()) for j in range(5)] for i in range(5)]
    assert all(H[i][j]==H[j][i].conj() for i in range(5) for j in range(5))
    L=[[G(F(i==j)) for j in range(5)] for i in range(5)];piv=[]
    for k in range(5):
        dk=H[k][k]-sum((L[k][j]*piv[j]*L[k][j].conj() for j in range(k)),G())
        assert dk.b==0 and dk.a>0;piv.append(dk.a)
        for i in range(k+1,5):L[i][k]=(H[i][k]-sum((L[i][j]*piv[j]*L[k][j].conj() for j in range(k)),G()))/dk
    assert all(H[i][j]==sum((L[i][k]*piv[k]*L[j][k].conj() for k in range(5)),G()) for i in range(5) for j in range(5))
    costs=[[(z[i]+z[j]).abs2() for j in range(5)] for i in range(5)]
    gap=min(costs[i][j] for i in range(3) for j in range(3));low=F('1.019558')
    dist,perm=min((max(costs[i][p[i]] for i in range(5)),p) for p in itertools.permutations(range(5)))
    assert dist>=gap>low*low>F(28,27)
    # Integer interval endpoints are verified exactly, not rounded estimates.
    scale=10**12;intervals=[{'lower_numerator':str(q.numerator*scale//q.denominator),'upper_numerator':str(q.numerator*scale//q.denominator+1),'denominator':str(scale)} for q in piv]
    for q,r in zip(piv,intervals):assert F(int(r['lower_numerator']),scale)<q<F(int(r['upper_numerator']),scale)
    result={'status':'Independent standard-library exact certificate passed.','strict_lower_bound':str(low),'orthogonality_passed':True,'ldl_factorization_passed':True,'positive_pivots':True,'pivot_intervals':intervals,'pivot_exact':[str(q) for q in piv],'matching_squared':str(dist),'hall_gap_squared':str(gap),'matching':list(perm),'permutations_checked':120,'elapsed_seconds':time.monotonic()-start}
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,indent=2)+'\n')
    print('Independent exact verification passed: C_normal > 509779/500000.')
    print('Positive pivot enclosures:',intervals)
    print('Seconds:',time.monotonic()-start)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.output)
