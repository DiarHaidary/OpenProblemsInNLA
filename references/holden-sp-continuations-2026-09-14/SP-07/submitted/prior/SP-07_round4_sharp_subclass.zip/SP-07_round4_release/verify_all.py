#!/usr/bin/env python3
"""Run the new audits and, optionally, the retained exact prior certificates."""
from pathlib import Path
import argparse,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parent


def run(args,cwd=ROOT):
    print('+ '+' '.join(map(str,args)),flush=True)
    subprocess.run(list(map(str,args)),cwd=cwd,check=True)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--prior',action='store_true',help='rerun the inherited n5 and n193 exact certificates with both methods')
    p.add_argument('--numerical',action='store_true',help='run NumPy/SciPy regression tests')
    p.add_argument('--symbolic',action='store_true',help='run the separate SymPy reconstruction')
    a=p.parse_args()
    run([sys.executable,'-S','verify_rank_one.py'])
    run([sys.executable,'-S','-m','unittest','discover','-s','tests','-p','test_exact.py','-v'])
    run([sys.executable,'-S','-O','-m','unittest','discover','-s','tests','-p','test_exact.py','-v'])
    if a.symbolic:run([sys.executable,'src/symbolic_audit.py'])
    if a.numerical:run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_numerical.py','-v'])
    if a.prior:
        archive=ROOT/'prior/SP-07_round3_certified_progress.zip'
        with tempfile.TemporaryDirectory(prefix='sp07-prior-') as td:
            base=Path(td).resolve()
            with zipfile.ZipFile(archive) as z:
                for name in z.namelist():
                    dest=(base/name).resolve()
                    if base not in dest.parents and dest!=base:
                        raise ValueError('Unsafe ZIP member path')
                z.extractall(base)
            prior=base/'SP-07_round3_bundle'
            for ident in ['n5','n193']:
                run([sys.executable,'-S','verify_all.py','--ldl','--only',ident,
                     '--output',ROOT/f'results/prior_rerun_{ident}.json'],cwd=prior)
    print('PASS all requested audits. The unrestricted constant is not determined.',flush=True)

if __name__=='__main__':main()
