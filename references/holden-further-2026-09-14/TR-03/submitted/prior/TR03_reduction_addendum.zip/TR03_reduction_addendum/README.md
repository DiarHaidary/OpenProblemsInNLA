# TR-03: finite-spectrum reductions

**Completion status: partial. This is not a full solution of TR-03.**

This addendum contains self-contained proofs of a spectral balance inequality, a finite-to-infinite comparison, and a harmonic-block lower bound. It also proves a conditional reduction from an oversampled infinite-leading inequality to an all-spectrum O(sqrt(k)) upper bound. The hypothesis of that conditional reduction is not established here. No matching dimension-dependent lower bound for the original supremum is established.

Read `REPORT.md` for the mathematical arguments. No compiled PDF is claimed in this package. Run `python code/verify.py` from this directory for the exact-arithmetic checks. Results, when successfully generated, are saved in `results/verification.json`.

Previous ZIPs and the interrupted round-three files are preserved when available in the runtime. Their inclusion is not a certification of their proofs. See `PROOF_AUDIT.md` and `PROVENANCE.json`.
