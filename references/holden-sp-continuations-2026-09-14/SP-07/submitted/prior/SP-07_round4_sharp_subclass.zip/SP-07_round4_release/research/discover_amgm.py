"""Find a numerical AM-GM allocation, then check its rational reconstruction.

This is discovery code, not the trusted certificate checker. The report and
src/verify_rank_one.py use the fixed delivered certificate instead.

Dependencies: SymPy, NumPy, SciPy. Run from any directory:
    python research/discover_amgm.py --output results/rediscovered_amgm.json
"""
from pathlib import Path
from fractions import Fraction
import argparse,json
import numpy as np
import sympy as S
from scipy.optimize import linprog


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,
        default=Path(__file__).resolve().parents[1]/'results/rediscovered_amgm.json')
    args=ap.parse_args()
    x,y,z=S.symbols('x y z');den=1+x+2*y
    expression=(den+x)*(1+x)*(2*den-1)**2*(7+5*z)**2 \
        -28*x*(x*den+56*y)*(2*den-1)*(7+5*z) \
        -392*x*y*(28*(den-1)**2-27*den**2)
    poly=S.Poly(expression,x,y,z)
    pos=[(ex,int(c)) for ex,c in poly.terms() if c>0]
    neg=[(ex,int(-c)) for ex,c in poly.terms() if c<0]
    n,m=len(pos),len(neg);A=[];rhs=[]
    for k,(ex,c) in enumerate(pos):
        row=np.zeros(m*n);row[k::n]=1;A.append(row);rhs.append(c)
    for k,(ex,c) in enumerate(neg):
        row=np.zeros(m*n);row[k*n:(k+1)*n]=1;A.append(row);rhs.append(c)
        for d in range(3):
            row=np.zeros(m*n);row[k*n:(k+1)*n]=[pe[d] for pe,_ in pos]
            A.append(row);rhs.append(c*ex[d])
    answer=linprog(np.zeros(m*n),A_eq=np.array(A),b_eq=np.array(rhs),bounds=(0,None),method='highs')
    if not answer.success:raise RuntimeError(answer.message)
    weights=[Fraction(float(v)).limit_denominator(10**6) for v in answer.x]
    for row,b in zip(A,rhs):
        if sum(Fraction(int(a))*w for a,w in zip(row,weights))!=b:
            raise RuntimeError('Rational reconstruction failed; numerical LP is not a certificate.')
    if any(w<0 for w in weights):raise RuntimeError('Negative reconstructed weight')
    data={'positive':pos,'negative':neg,'flow':[[str(w) for w in weights[k*n:(k+1)*n]] for k in range(m)],'exact':True}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(data,indent=2))
    print(f'Exact allocation written to {args.output}')
    print('Allocation need not be identical across optimizer versions; run check_amgm on the output.')

if __name__=='__main__':main()
