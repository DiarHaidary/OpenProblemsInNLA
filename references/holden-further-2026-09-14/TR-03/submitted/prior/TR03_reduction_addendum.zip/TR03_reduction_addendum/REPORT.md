# TR-03: finite-spectrum reductions

**Status.** This report does not give a full solution. Its unconditional conclusions are the inequalities proved below. Section 6 is explicitly conditional: its hypothesis is an additional, unproved inequality, not a consequence of the preceding sections. In particular, neither an all-spectrum square-root bound nor a matching lower bound for the original ratio is asserted as an unconditional result.

## 1. Problem and notation

Let 1 <= k < n, let m=n-k, and let lambda_1 >= ... >= lambda_n > 0. Write e_l(lambda) for the elementary symmetric polynomial of degree l, with e_0=1. For a real orthogonal U, set A=U diag(lambda) U^T. For a k-element set S, the Nyström trace error is

\[
E_S(A)=\operatorname{tr}\bigl(A-A_{:S}A_{SS}^{-1}A_{S:}\bigr).
\]

The adversary first chooses U; the subset is chosen afterwards. The relevant quantities are

\[
x_k(\lambda)=\sup_{U\in O(n)}\min_{|S|=k}E_S(A),\qquad
y_k(\lambda)=(k+1)\frac{e_{k+1}(\lambda)}{e_k(\lambda)},\qquad
R_{n,k}=\sup_{\lambda>0}\frac{y_k(\lambda)}{x_k(\lambda)}.
\]

The statement being investigated asks for matching dimension-dependent estimates of R, uniformly over positive spectra. These definitions are inherited from the statement and preceding packages. A fresh, readable response from the live website was not available in this run; no change in the online statement is asserted.

Let J=S^c. The Schur complement formula gives

\[
E_S(A)=\operatorname{tr}\bigl((A^{-1}_{JJ})^{-1}\bigr).                 \tag{1}
\]

For completeness, the volume-sampling average is exactly y. For each S,

\[
\det(A_{SS})E_S(A)=\sum_{i\notin S}\det(A_{S\cup\{i\},S\cup\{i\}}).
\]

Summing over S counts each (k+1)-minor k+1 times. The sums of the k- and (k+1)-principal minors are e_k(lambda) and e_{k+1}(lambda), respectively. Thus every orientation has a subset of error at most y, and x <= y.

Let tau=sum_{i>k}lambda_i. Since the Nyström approximant is positive semidefinite, has rank at most k, and is bounded above by A, its trace is at most the sum of the k largest eigenvalues of A. Consequently

\[
\tau\le x_k(\lambda)\le y_k(\lambda)\le(k+1)\tau.                    \tag{2}
\]

The last inequality follows because every (k+1)-subset contains a tail index: e_{k+1} <= sum_{i>k}lambda_i e_k(lambda without i) <= tau e_k.

## 2. A harmonic-block bound for every spectrum

**Theorem 1.** Define H_r=sum_{i=1}^r lambda_i^{-1} and tau_r=sum_{i>r}lambda_i. Then

\[
\boxed{\quad x_k(\lambda)\ge
\max_{k\le r\le n}\left\{\tau_r+\frac{r(r-k)}{H_r}\right\}.\quad}    \tag{3}
\]

At r=k the second term is zero. At r=k+1 this includes the previously used harmonic bound and adds the untouched tail after index k+1.

**Proof.** Fix r >= k. Choose an r-by-r positive definite matrix B with eigenvalues lambda_1^{-1},...,lambda_r^{-1} and constant diagonal H_r/r. Such a real orthogonal conjugation exists by the elementary equal-diagonal lemma proved below. Put

\[
A=B^{-1}\oplus\operatorname{diag}(\lambda_{r+1},\ldots,\lambda_n),
\qquad a_r=r/H_r.
\]

Suppose S selects s indices outside the leading block, so k-s indices are selected inside it. The complement in the block has size l=r-k+s. If l>0, (1) and the scalar arithmetic-harmonic mean inequality for the eigenvalues give

\[
\operatorname{tr}(B_{JJ}^{-1})\ge \frac{l^2}{\operatorname{tr}B_{JJ}}
=l a_r.
\]

For l=0 the same lower bound is zero. The outside residual is tau_r minus the sum of the s outside eigenvalues selected. Each such eigenvalue is at most lambda_r, and a_r >= lambda_r because a_r is the harmonic mean of the first r eigenvalues. Therefore the total error is at least

\[
(r-k+s)a_r+\tau_r-s a_r=(r-k)a_r+\tau_r.
\]

The bound holds for every subset S in this one fixed orientation. Maximizing over r proves (3).

**Equal-diagonal lemma.** Every real symmetric r-by-r matrix M has an orthogonal conjugate with all diagonal entries tr(M)/r. Subtract the mean times the identity, obtaining a trace-zero matrix N. Its minimum and maximum eigenvalues bracket zero, so a unit vector v satisfies v^T N v=0. The compression to v-perp also has trace zero. Induction supplies an orthonormal basis of v-perp with zero quadratic forms, and adjoining v proves the claim.

A useful consequence is an independent recovery of the basic dimension bound. Let H=H_{k+1}. For any (k+1)-set T, sum_{i=1}^{k+1}lambda_i^{-1} <= sum_{i in T}lambda_i^{-1}. Multiply by the product over T and sum. Each k-fold product occurs n-k times, so H e_{k+1} <= (n-k)e_k. Combining this with (3) and (2) yields

\[
1\le R_{n,k}\le\min\{k+1,n-k\}.                                  \tag{4}
\]

This proof does not give a matching lower bound for interior k.

## 3. Spectral balance and the number of small leading eigenvalues

Set

\[
t=\frac{e_{k+1}(\lambda)}{e_k(\lambda)},\qquad
u=\frac{e_{k-1}(\lambda)}{e_k(\lambda)}.
\]

**Theorem 2.** For every positive spectrum,

\[
\boxed{\quad
\sum_{i=1}^k\frac{t}{\lambda_i+t}\le\tau\nu\le\frac{\tau}{t}.
\quad}                                                            \tag{5}
\]

Consequently, for every a>0,

\[
\boxed{\quad
\#\{i\le k:\lambda_i\le a\}\le\frac{\tau(a+t)}{t^2}.
\quad}                                                            \tag{6}
\]

For each 1<=q<=k one also has

\[
q t^2\le\tau\bigl(\lambda_{k-q+1}+t\bigr),                         \tag{7}
\]

and hence the explicit bound

\[
y_k(\lambda)\le\frac{k+1}{2q}
\left(\tau+\sqrt{\tau^2+4q\tau\lambda_{k-q+1}}\right).              \tag{8}
\]

**Proof.** Consider the distribution on k-subsets with probabilities proportional to the products of their eigenvalues. Let p_i be the inclusion probability. With e_l^{(i)} denoting e_l after deleting lambda_i,

\[
p_i=\frac{\lambda_i e_{k-1}^{(i)}}{e_k},\qquad
1-p_i=\frac{e_k^{(i)}}{e_k}.
\]

The ordinary log-concavity inequality e_{k+1}^{(i)}e_{k-1}^{(i)} <= (e_k^{(i)})^2 implies

\[
t=\frac{\lambda_i e_k^{(i)}+e_{k+1}^{(i)}}
        {\lambda_i e_{k-1}^{(i)}+e_k^{(i)}}
\le\frac{e_k^{(i)}}{e_{k-1}^{(i)}}.
\]

It follows that 1-p_i >= t/(lambda_i+t). Exactly k indices are selected, so the expected number missed from the first k equals the expected number selected from the tail. Moreover p_i <= lambda_i nu. Summing gives the first inequality in (5). Log-concavity for the full spectrum gives t nu <=1, proving the second.

Each term indexed by lambda_i<=a contributes at least t/(a+t), proving (6). Apply this to the q smallest entries among the first k to obtain (7); solving the resulting quadratic in t gives (8).

The log-concavity used here is the unnormalized consequence of Newton's inequalities for elementary symmetric polynomials. It also follows from real-rootedness of product_i(z+lambda_i), by differentiation and Rolle's theorem. Only the weaker unnormalized inequality is required.

**Interpretation.** A large volume-sampling error relative to tau limits the number of leading eigenvalues that can lie below a prescribed threshold. This is a rank-counting statement, not an assertion that the original spectrum may be replaced by a two-level spectrum without loss.

## 4. Infinite-leading profiles with extra selections

Let 0<=q<=k-1, j=k-q, and let sigma_1>=...>=sigma_{m+q}>0. Define

\[
\mathcal X_{n,k,q}(\sigma)
=\lim_{L\to\infty}x_k(L^{[j]},\sigma).
                                                                    \tag{9}
\]

The limit exists because increasing the leading eigenvalues increases every shorted trace for a fixed orientation, and therefore increases x. It is finite: the volume identity bounds it by

\[
\mathcal X_{n,k,q}(\sigma)
\le(k+1)\frac{e_{q+1}(\sigma)}{e_q(\sigma)}.                         \tag{10}
\]

A precision matrix for the limiting orientation has j zero eigenvalues and the remaining eigenvalues sigma_i^{-1}. For each m-subset J, define its limiting cost as the trace of the inverse of the principal compression, or +infinity when the compression is singular. Then (9) is the supremum over orientations of the minimum of these limiting costs.

There is no unjustified interchange of a maximum and a limit here. For each fixed orientation, a finite minimum of increasing costs commutes with their increasing limit. The two suprema, over L and over orientations, then commute. No continuity assertion at a singular compression is needed.

For q=0 and sigma=(1,...,1), (9) becomes the square-frame quantity from the previous reports:

\[
\mathcal X_{n,k,0}(1^{[m]})
=\sup_{Q^TQ=I_m}\min_{|J|=m}\operatorname{tr}((Q_JQ_J^T)^{-1}),
\]

with singular sets assigned infinite cost. When q>0, Q has m+q columns while J still has m rows. This is genuinely a different, rectangular problem. A theorem proved only for square bases does not automatically settle it.

## 5. A finite-to-infinite comparison

**Theorem 3.** Let 1<=j<=k, put q=k-j, and set sigma=(lambda_{j+1},...,lambda_n). For every 0<a<=lambda_j,

\[
\boxed{\quad
x_k(\lambda)\ge
\frac{a\,\mathcal X_{n,k,q}(\sigma)}
     {a+\mathcal X_{n,k,q}(\sigma)}.
\quad}                                                            \tag{11}
\]

**Proof.** Fix an orientation U and let P be the projection onto its first j eigendirections. Define

\[
B_\infty=U\operatorname{diag}(0^{[j]},\sigma^{-1})U^T,
\qquad B_a=B_\infty+a^{-1}P.
\]

For every J, (B_a)_{JJ} <= (B_infinity)_{JJ}+a^{-1}I. If the latter limiting compression is nonsingular and its inverse eigenvalues are z_1,...,z_m, inversion reverses the Loewner inequality and gives

\[
E_J(B_a^{-1})\ge\sum_{i=1}^m\frac{a z_i}{a+z_i}
\ge\frac{a\sum_i z_i}{a+\sum_i z_i}.                              \tag{12}
\]

For the second inequality, replace each denominator a+z_i by the larger denominator a+sum z_i. If the limiting compression is singular, a unit vector in its kernel has Rayleigh quotient at most 1/a under (B_a)_{JJ}; thus the finite inverse trace is at least a. This is the continuous limiting value of the right side of (12) when the limiting trace is infinite.

The map h -> a h/(a+h) is increasing. Taking the minimum over J and then the supremum over U proves (11) for the spectrum (a^{[j]},sigma). Increasing those first j eigenvalues to their prescribed values only increases the error in the same orientation, completing the proof.

This theorem handles singular limiting subsets explicitly. It also explains a limitation: a trace-only comparison can saturate at a, rather than at m a. Stronger finite-regularization conclusions require additional information about the distribution of inverse eigenvalues or a different construction.

## 6. Conditional reduction to a robust limiting inequality

The following hypothesis is **not proved in this report**:

**Robust limiting hypothesis H(c).** For some universal 0<c<=1, for every relevant n,k, every integer 0<=q<k/4, and every positive decreasing sigma of length m+q,

\[
\mathcal X_{n,k,q}(\sigma)
\ge c\,\frac{k+1}{q+\sqrt{k}}
\sum_{i=q+1}^{m+q}\sigma_i.                                       \tag{H}
\]

The previously reported q=0 results do not supply the cases q>0.

**Theorem 4 (conditional).** If H(c) holds, then for every positive spectrum and k>=2,

\[
x_k(\lambda)\ge\frac{c}{16\sqrt{k}}y_k(\lambda),
\qquad R_{n,k}\le\frac{16}{c}\sqrt{k}.                            \tag{13}
\]

Together with (4) this would give R <= min(n-k,16 sqrt(k)/c). The theorem alone would still not supply a matching lower bound or the sharper sqrt(n-k) dependence in the strongly unbalanced regime.

**Proof.** Set b=y_k(lambda)/sqrt(k). If tau>=b/16, the baseline x>=tau proves (13). Otherwise tau<b/16. Let q be the number of the first k eigenvalues strictly below b. By (6), using t=b sqrt(k)/(k+1),

\[
q\le\frac{\tau(b+t)}{t^2}
=\frac{\tau}{b}\left(k+2+k^{-1}+\sqrt{k}+k^{-1/2}\right)
\le\frac{4k\tau}{b}<\frac{k}{4}.                                 \tag{14}
\]

The numerical coefficient bound holds for every k>=2, as is seen by dividing by k and observing that each nonconstant term decreases with k; at k=2 their sum is less than 4.

Put j=k-q. Then lambda_j>=b, and the tail sigma=(lambda_{j+1},...,lambda_n) has residual mass sum_{i>q}sigma_i=tau. From y<=(k+1)tau,

\[
\sqrt{k}\le\frac{(k+1)\tau}{b},\qquad
q+\sqrt{k}\le\frac{5(k+1)\tau}{b}.
\]

Hypothesis (H) therefore gives X>=c b/5. Apply (11) with a=b:

\[
x_k(\lambda)\ge\frac{bX}{b+X}
\ge\frac{c b}{5+c}\ge\frac{c b}{6}.
\]

This is stronger than the claimed c b/16 in the second case. Combining the two cases proves (13).

The reduction is useful because it identifies exactly which stronger limiting theorem would suffice. It is not legitimate to delete the words “if H(c) holds.” Doing so would turn a conditional argument into an unsupported claim of an all-spectrum result.

## 7. Boundary cases and checks

For k=n-1, (3) with r=n gives x>=n/sum lambda_i^{-1}; this equals y. Hence R_{n,n-1}=1.

For k=1, put c_0=sum lambda_i^2/sum lambda_i. The symmetric matrix diag(lambda_i^2-c_0 lambda_i) has trace zero. By the equal-diagonal lemma choose U so that A^2-c_0 A has zero diagonal. Then every singleton has error tr A-(A^2)_{ii}/A_{ii}=tr A-c_0=y_1. Thus x_1=y_1 and R_{n,1}=1.

The accompanying verification program uses exact rational arithmetic. It tests (5)--(8), the harmonic-block construction, the volume identity, and the finite comparison, including singular limiting compressions. These are finite checks of implementations and identities, not a formal proof certification or a test of hypothesis (H). The symbolic arguments above are the mathematical justification.

## 8. Completion audit

Unconditionally established here: equations (3), (5)--(8), (10)--(12), the endpoint equalities, and the basic upper bound (4). The statements are proved independently of the unavailable interrupted notes.

Established conditionally: (13), assuming (H).

Not established here: (H) for the full required range, a uniform all-spectrum O(sqrt(min(k,n-k))) upper bound, or a matching growing lower bound for R. In particular, this report does not assert any sharp joint order for R_{n,k}.

The preceding packages contained further claimed partial results. They are preserved for continuity, not silently re-certified. The inability to read usable tool responses in this run prevents a fresh audit of those files. No verification count from an earlier package is presented as a verification of this addendum.
