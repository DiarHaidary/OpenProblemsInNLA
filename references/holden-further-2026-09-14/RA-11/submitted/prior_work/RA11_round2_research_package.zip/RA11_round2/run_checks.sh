#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PYTHON="${PYTHON:-python}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
mkdir -p results
for suite in exact_checks numerical_checks exact_reference_checks; do
  echo "Running $suite"
  "$PYTHON" "tests/${suite}.py" | tee "results/${suite}.log"
done
"$PYTHON" - <<'PYENV'
import json, platform, sys
from pathlib import Path
import numpy, sympy
Path('results/environment.json').write_text(json.dumps({
  'python': sys.version, 'platform': platform.platform(),
  'numpy': numpy.__version__, 'sympy': sympy.__version__
}, indent=2)+'\n')
PYENV
echo "All three suites completed without failed assertions."
