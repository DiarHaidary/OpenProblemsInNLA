"""Seeded local Grassmann searches for normal reflection pairs.
Exploratory floating-point search only: no global upper-bound certificate.
"""
from __future__ import annotations
import argparse,json,time,sys
from pathlib import Path
import numpy as np
from scipy.linalg import null_space
from scipy.special import logsumexp
from scipy.optimize import minimize
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prior'/'sp07_partial_results'/'code'))
from matching import bottleneck
from certify_five import INPUT
class Model:
 def __init__(self,n,r,I,J,O=None,complex_chart=False):
  self.n=n;self.r=r;self.I=np.array(I);self.J=np.array(J);self.cplx=complex_chart;self.O=np.eye(n) if O is None else O
  self.ns=2*n-1;self.nx=r*(n-r);self.nv=self.ns+self.nx*(2 if complex_chart else 1)+1;self.rho=500.
  self.dz=np.zeros((self.ns,n),complex);self.dz[0,0]=1
  for i in range(1,n):self.dz[2*i-1,i]=1;self.dz[2*i,i]=1j
 def decode(self,x):
  n,r=self.n,self.r;z=x[:self.ns]@self.dz;X=x[self.ns:self.ns+self.nx].reshape(n-r,r)
  if self.cplx:X=X+1j*x[self.ns+self.nx:-1].reshape(n-r,r)
  Y=self.O@np.vstack([np.eye(r),X]);Bi=np.linalg.solve(Y.conj().T@Y,Y.conj().T);P=Y@Bi;Q=np.eye(n)-P;D=np.diag(z);M=2*(P@D@P+Q@D@Q)
  return z,Y,Bi,P,Q,D,M
 def calc(self,x,jac=False):
  n,r=self.n,self.r;z,Y,Bi,P,Q,D,M=self.decode(x);lam,V=np.linalg.eigh(M.conj().T@M);val=logsumexp(self.rho*lam)/self.rho;L=z[self.I,None]+z[None,self.J];d=x[-1]
  c=np.r_[1-val,(abs(L)**2-d*d).ravel()]
  if not jac:return c
  Jmat=np.zeros((len(c),self.nv));weights=np.exp(self.rho*(lam-val));G=((M@V)*weights)@V.conj().T
  dMs=2*(np.einsum('ij,kj,jl->kil',P,self.dz,P)+np.einsum('ij,kj,jl->kil',Q,self.dz,Q))
  K=Q@self.O[:,r:];dP0=np.einsum('ai,jb->ijab',K,Bi).reshape(self.nx,n,n);dP=dP0+dP0.conj().transpose(0,2,1)
  if self.cplx:dP=np.concatenate([dP,1j*(dP0-dP0.conj().transpose(0,2,1))])
  S=2*P-np.eye(n);dMx=2*(dP@D@S+S@D@dP)
  Jmat[0,:self.ns]=-2*np.einsum('ij,kij->k',G.conj(),dMs).real;Jmat[0,self.ns:-1]=-2*np.einsum('ij,kij->k',G.conj(),dMx).real
  ds=self.dz[:,self.I,None]+self.dz[:,None,self.J];Jmat[1:,:self.ns]=(2*(L.conj()[None,:,:]*ds).real).reshape(self.ns,-1).T;Jmat[1:,-1]=-2*d
  return Jmat
 def record(self,x):
  z,Y,Bi,P,Q,D,M=self.decode(x);norm=float(np.linalg.norm(M,2));gap=float(np.min(abs(z[self.I,None]+z[None,self.J])));distance,perm=bottleneck(z,-z)
  return dict(n=self.n,r=self.r,I=self.I.tolist(),J=self.J.tolist(),complex_chart=self.cplx,x=x.tolist(),z=np.column_stack([z.real,z.imag]).tolist(),P_real=P.real.tolist(),P_imag=P.imag.tolist(),norm=norm,gap=gap,cut_ratio=gap/norm,bottleneck=float(distance),ratio=float(distance/norm),matching=perm.tolist(),minimum_constraint=float(np.min(self.calc(x))),rho=self.rho,projection_residual=float(np.linalg.norm(P@P-P,2)),O_real=self.O.real.tolist(),O_imag=self.O.imag.tolist())
 def optimize(self,x,maxiter=250,rhos=(100.,1000.,15000.,250000.)):
  for rho in rhos:
   self.rho=rho
   out=minimize(lambda a:-a[-1],x,jac=lambda a:np.r_[np.zeros(self.nv-1),-1.],method='SLSQP',bounds=[(.00001,30)]+[(-30,30)]*(self.ns-1)+[(-15,15)]*(self.nv-self.ns-1)+[(.02,3)],constraints=[dict(type='ineq',fun=self.calc,jac=lambda a:self.calc(a,True))],options=dict(maxiter=maxiter,ftol=2e-10))
   x=out.x
  return out

def initial_five():
 z=np.array([[float(q) for q in pair] for pair in INPUT['z']])@np.array([1,1j]);X=np.array(INPUT['X'],float);Y=np.vstack([np.eye(2),X]);P=Y@np.linalg.solve(Y.T@Y,Y.T)
 return z,P,[0,1,2]

def main(args):
 rng=np.random.default_rng(args.seed);start=time.monotonic();records=[]
 if args.base:
  b=json.loads(args.base.read_text());zbase=np.array(b['z'])@np.array([1,1j]);Pbase=np.array(b['P_real'])+1j*np.array(b['P_imag']);Ibase=b['I']
 else:zbase,Pbase,Ibase=initial_five()
 nb=len(zbase);rb=(nb-1)//2;ev,OO=np.linalg.eigh(Pbase);Wbase=OO[:,ev>.5]
 args.output.parent.mkdir(parents=True,exist_ok=True)
 for n in args.sizes:
  if n<nb or (n-nb)%2:raise ValueError('Each dimension must equal base size plus a nonnegative even number.')
  for k in range(args.runs):
   r=(n-1)//2;W=np.zeros((n,r),complex);W[:nb,:rb]=Wbase;R=[1,2,3,6][k%4]*np.exp(1j*rng.uniform(-np.pi,np.pi));zs=[zbase]
   for i in range((n-nb)//2):W[nb+2*i:nb+2*i+2,rb+i]=[1/np.sqrt(2),-1/np.sqrt(2)];RR=R*(1+.3*i);zs.append(np.array([RR,-RR]))
   z=np.concatenate(zs);O=np.column_stack([W,null_space(W.conj().T)]);I=Ibase+list(range(nb,n,2));mod=Model(n,r,I,I,O,args.complex)
   x=np.zeros(mod.nv);x[0]=z[0].real
   for i in range(1,n):x[2*i-1:2*i+1]=[z[i].real,z[i].imag]
   x[-1]=.99*float(np.min(abs(zbase[np.array(Ibase),None]+zbase[None,np.array(Ibase)])))
   noise=[.02,.1,.3,.7][(k//4)%4];x[:-1]+=noise*rng.normal(size=mod.nv-1);x[0]=max(.01,x[0])
   err=None
   if k==0:
    t=x+.001*rng.normal(size=len(x));h=1e-6;fd=np.column_stack([(mod.calc(t+h*e)-mod.calc(t-h*e))/(2*h) for e in np.eye(len(x))]);err=float(np.max(abs(mod.calc(t,True)-fd)))
    if err>1e-4:raise RuntimeError(f'Jacobian check failed: {err}')
   out=mod.optimize(x,args.maxiter);rec=mod.record(out.x);rec.update(initialization=f'{nb}_plus_pairs',run=k,seed=args.seed,noise=noise,success=bool(out.success),message=str(out.message),iterations=int(out.nit),jacobian_error=err);records.append(rec)
   print(n,k,rec['ratio'],rec['minimum_constraint'],rec['success'],flush=True)
   args.output.write_text(json.dumps(dict(status='Exploratory floating-point local optimization; no global certificate.',elapsed_seconds=time.monotonic()-start,arguments={k:str(v) for k,v in vars(args).items()},records=records),indent=2)+'\n')
 if records:print('BEST',max(r['ratio'] for r in records),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sizes',nargs='+',type=int,default=[7,9,11,13]);p.add_argument('--runs',type=int,default=32);p.add_argument('--seed',type=int,default=31415926);p.add_argument('--complex',action='store_true');p.add_argument('--maxiter',type=int,default=250);p.add_argument('--base',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a)
