#!/usr/bin/env python3
"""Exercise exact-rational code paths; certified large hierarchies are not run."""
import json
from pathlib import Path
import random
import sys
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from ra11_exact_reference import (MatrixOracle,ComplexSimulation,NoisyPartialOracle,
    noisy_approximation,estimate_trace,selected_columns,frobenius_squared,metric_median)

results=[]
u=sp.Matrix([1,2,3,4]);M=u*u.T
oracle=MatrixOracle(M,2,2)
trace,info=estimate_trace(oracle,'0.1',bits=random.Random(1).getrandbits)
assert trace==sp.trace(M) and info['real_calls']==4
results.append({'check':'Certified exact-basis branch','trace':str(trace),**info})

# The complete estimator must not secretly replace a certified plan with a
# smaller experimental schedule when its budget exceeds the user's limit.
blocked=MatrixOracle(M,2,2)
try:
    estimate_trace(blocked,'0.1',max_queries=3)
    raise AssertionError('Preflight should have failed.')
except ValueError:
    assert blocked.calls==0
results.append({'check':'Preflight budget rejection before queries','real_calls':blocked.calls})

# Reduced embedding constant tests the exact algebra, NOT the theorem schedule.
for seed in range(4):
    oracle=MatrixOracle(M,2,2);sim=ComplexSimulation(oracle)
    bits=random.Random(seed+20).getrandbits
    noisy=NoisyPartialOracle(sim,sp.zeros(4,4),(0,1),1,bits)
    Ahat=noisy_approximation(noisy,1,bits,embedding_constant=1)
    assert Ahat==M and oracle.calls==3*sim.calls
    results.append({'check':'Exact noiseless two-sided reconstruction','seed':seed,
                    'squared_error':'0','real_calls':oracle.calls,
                    'certified_parameters':False,'embedding_constant':1})

# A genuinely complex Hermitian matrix is used for the internal column lemma.
F=sp.Matrix([[sp.I**(i*j)/2 for j in range(4)] for i in range(4)])
Y=sp.diag(4,3,2,1)*F
C=selected_columns(Y,1);P=C*(C.conjugate().T*C).inv()*C.conjugate().T
err=frobenius_squared(Y-P*Y)
assert C.cols==2 and err<=2*(9+4+1)
results.append({'check':'Exact exhaustive selected columns','columns':C.cols,'squared_residual':str(err)})

A=sp.diag(1,2);candidates=[A,A+sp.eye(2)/10,A-sp.eye(2)/10,A+100*sp.eye(2),A-100*sp.eye(2)]
choice=metric_median(candidates)
assert frobenius_squared(choice-A)<=sp.Rational(18,100)
results.append({'check':'Exact metric median','squared_error':str(frobenius_squared(choice-A))})

out={'all_passed':True,'checks':results,
     'limitations':'The full massive certified hierarchy was not executed. Basis and exact algebraic subroutines were executed; low-rank tests explicitly used a reduced embedding constant.'}
(ROOT/'results'/'exact_reference_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
