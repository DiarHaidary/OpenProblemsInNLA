"""Reproducible exact witnesses for the layered module construction.
A bounded orientation search may fail. Such failure is UNKNOWN, not infeasibility.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
import random
from exact_tools import dot,rank,complement,plane_basis,parallel,primitive,serialize,verify_pair,incidence


def validate_module(m):
    n=m['n'];k=m['kind']
    if type(n) is not int or n<2:
        raise ValueError('The closure theorem excludes singleton modules')
    if k not in ('clique','independent','path','half'):
        raise ValueError('Unsupported module')
    if k=='half' and (n<4 or n%2):
        raise ValueError('Half graphs must have even order at least four')


def module_edges(m):
    validate_module(m);n=m['n'];k=m['kind']
    if k=='clique':return set(combinations(range(n),2))
    if k=='independent':return set()
    if k=='path':return {(i,i+1) for i in range(n-1)}
    q=n//2
    return {(i,q+j) for i in range(q) for j in range(q) if i<=j}


def path_complement(n,d=F(1)):
    weights=[d,F(1),F(1)]
    V=[[F(1),F(0),F(0)],[F(0),F(1),F(0)],[F(1),F(0),F(1)]]
    def inner(u,v):return sum(a*b*w for a,b,w in zip(u,v,weights))
    while len(V)<n:
        u,w=plane_basis(V[-1],weights)
        for t in range(2*len(V)+5):
            z=[a+t*b for a,b in zip(u,w)]
            if all(inner(z,v) for v in V[:-1]) and all(not parallel(z,v) for v in V):
                V.append(primitive(z));break
        else:raise AssertionError('Finite-avoidance construction failed')
    return V


def local_vectors(m,side,d):
    validate_module(m);d=F(d)
    if d<=0:raise ValueError('Quotient vector must have positive squared length')
    n=m['n'];k=m['kind']
    if k=='path' and n==2:k='clique'
    if k in ('clique','independent'):
        clique=(k=='clique') != bool(side)
        return [[F(1)] for _ in range(n)] if clique else [[F(int(i==j)) for j in range(n)] for i in range(n)]
    if k=='path':
        if n==3:
            rows=[[1,0],[1,1],[0,1]] if not side else [[1,0],[0,1],[1,0]]
            return [[F(x) for x in r] for r in rows]
        return path_complement(n,d) if side else incidence(n,module_edges(m))
    q=n//2;A=[];B=[]
    for i in range(1,q+1):
        a=[F(0)]*(q+1);b=[F(0)]*(q+1)
        if not side:
            a[i]=F(1);b[0]=F(1)
            for h in range(1,i):b[h]=F(1)
            b[i]=-(d+i-1)
        else:
            a[0]=F(1)
            for h in range(i,q+1):a[h]=-d
            b[0]=F(1);b[i]=F(1)
        A.append(a);B.append(b)
    return A+B


def module_class(m):
    r=len(local_vectors(m,0,F(1))[0]);s=len(local_vectors(m,1,F(1))[0])
    if min(r,s)==1:return 'T',(1 if r==1 else 2),(1 if s==1 else 2)
    if min(r,s)==2:return 'L',2,2
    return 'P',3,3


def color_induced(vertices,E):
    vertices=list(vertices)
    if not vertices:return {}
    if len(vertices)>14:raise ValueError('Exact coloring fixture limit is fourteen quotient vertices')
    adj={v:{w for w in vertices if w!=v and (min(v,w),max(v,w)) in E} for v in vertices}
    order=sorted(vertices,key=lambda v:(-len(adj[v]),v))
    for k in range(1,len(vertices)+1):
        assigned={}
        def visit(p,used):
            if p==len(order):return dict(assigned)
            v=order[p];forbidden={assigned[w] for w in adj[v] if w in assigned}
            for c in range(min(k,used+1)):
                if c not in forbidden:
                    assigned[v]=c;ans=visit(p+1,max(used,c+1))
                    if ans is not None:return ans
                    del assigned[v]
            return None
        result=visit(0,0)
        if result is not None:return result
    raise AssertionError('No coloring')


def rotate(V,weights,rng):
    X=[r[:] for r in V]
    pairs=list(combinations(range(len(weights)),2));rng.shuffle(pairs)
    for a,b in pairs:
        t=F(rng.choice((-2,-1,1,2)),rng.choice((1,2,3)))
        den=1+weights[a]*weights[b]*t*t
        c=(1-weights[a]*weights[b]*t*t)/den
        pa=2*weights[a]*t/den;pb=-2*weights[b]*t/den
        for x in X:
            xa,xb=x[a],x[b]
            x[a]=c*xa+pb*xb;x[b]=pa*xa+c*xb
    return X


def substitute_edges(t,E,mods):
    offsets=[0]
    for m in mods:offsets.append(offsets[-1]+m['n'])
    out=set()
    for i,m in enumerate(mods):
        out.update((offsets[i]+a,offsets[i]+b) for a,b in module_edges(m))
    for i,j in E:
        out.update((a,b) for a in range(offsets[i],offsets[i+1]) for b in range(offsets[j],offsets[j+1]))
    return offsets[-1],out


def side_factor(t,E,U,mods,side,seed=0,max_trials=256):
    if max_trials<1:raise RuntimeError('UNKNOWN: no orientation trials authorized')
    if len(U)!=t or not U or not all(any(r) for r in U):raise ValueError('Invalid nonzero quotient representation')
    if len(mods)!=t:raise ValueError('One module per quotient vertex is required')
    C=complement(t,E);ds=[dot(u,u) for u in U]
    local=[local_vectors(m,side,ds[i]) for i,m in enumerate(mods)]
    shares=[module_class(m)[1+side] for m in mods]
    width=len(U[0]);layers={};color_records=[]
    for ell in range(1,max(shares)):
        active=[i for i in range(t) if shares[i]>=ell+1]
        colors=color_induced(active,C);c=max(colors.values(),default=-1)+1
        for i in active:layers[i,ell]=width+colors[i]
        color_records.append({'layer':ell,'colors':colors,'number':c});width+=c
    private={}
    for i,V in enumerate(local):
        private[i]=list(range(width,width+len(V[0])-shares[i]));width+=len(private[i])
    rng=random.Random(seed);result=[];owners=[];attempts=[]
    for i,V in enumerate(local):
        weights=[ds[i]]+[F(1)]*(len(V[0])-1)
        for attempt in range(max_trials):
            X=rotate(V,weights,rng)
            if any(not x[0] for x in X):continue
            embedded=[]
            for x in X:
                z=[F(0)]*width
                for c,u in enumerate(U[i]):z[c]=x[0]*u
                for ell in range(1,shares[i]):z[layers[i,ell]]=x[ell]
                for j,c in enumerate(private[i]):z[c]=x[shares[i]+j]
                embedded.append(z)
            if all(dot(z,y) for z in embedded for owner,y in zip(owners,result) if (min(owner,i),max(owner,i)) in E):
                result.extend(embedded);owners.extend([i]*len(embedded));attempts.append(attempt+1);break
        else:raise RuntimeError(f'UNKNOWN: bounded orientation search failed at module {i}')
    return result,{'ambient_dimension':width,'orientation_attempts':attempts,'layers':color_records,'shares':shares}


def construct(identifier,t,E,U,W,mods,seed=0):
    V,meta0=side_factor(t,E,U,mods,0,seed)
    Z,meta1=side_factor(t,complement(t,E),W,mods,1,seed+100003)
    n,out=substitute_edges(t,E,mods)
    record={'id':identifier,'n':n,'edges':sorted(out),'gram_G':serialize(V),'gram_complement':serialize(Z),
            'quotient':{'n':t,'edges':sorted(E)},'modules':mods,'construction':[meta0,meta1],'seed':seed,
            'claim':'Exact PSD rank upper bounds; no general minimality assertion'}
    record['verified']=verify_pair(record)
    return record
