"""Reproduce the report's symbolic and numerical checks.

Run from any directory: python /path/to/code/verify.py
No network calls. No claim of formal verification or global numerical proof.
"""
from __future__ import annotations
import csv
import json
import platform
from pathlib import Path
import numpy as np
import scipy
import sympy as sp
from tr03 import (subsets, elementary, volume_mean, direct_errors, precision_errors,
                  frame_costs, zero_diagonal_basis, harmonic_block, flat_x4,
                  flat_y4, extremal_frame4, flat_precision)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
SEED = 20260912
rng = np.random.default_rng(SEED)
checks: list[dict] = []


def record(name: str, count: int, max_error: float = 0.0, note: str = '') -> None:
    checks.append({'name': name, 'cases': int(count), 'status': 'PASS',
                   'maximum_absolute_or_normalized_error': float(max_error), 'note': note})
    print(f'PASS {name}: {count} cases; maximum error {max_error:.3e}')


# 1. Schur-complement identity, determinant-weighted expectation, and elementary bounds.
max_inv = max_vol = max_bound = 0.0
count = 0
for n in range(3, 9):
    for k in range(1, n):
        for _ in range(3):
            lam = np.exp(rng.uniform(-2, 2, n))
            q = np.linalg.qr(rng.normal(size=(n, n)))[0]
            K = (q * lam) @ q.T
            H = (q * (1/lam)) @ q.T
            inds, errors = direct_errors(K, k)
            inv_inds, inv_costs = precision_errors(H, n-k)
            inverse_map = dict(zip(inv_inds, inv_costs))
            complement_errors = np.array([inverse_map[tuple(j for j in range(n) if j not in i)] for i in inds])
            max_inv = max(max_inv, float(np.max(np.abs(errors-complement_errors))))
            dets = np.array([np.linalg.det(K[np.ix_(i,i)]) for i in inds])
            y = volume_mean(lam, k)
            max_vol = max(max_vol, abs(float(dets@errors/dets.sum())-y))
            tail = np.sort(lam)[::-1][k:].sum()
            h = (k+1)/sum(1/np.sort(lam)[::-1][:k+1])
            assert errors.min() >= tail - 1e-9
            assert y <= (k+1)*tail + 1e-9
            assert y <= (n-k)*h + 1e-9
            count += 1
assert max_inv < 1e-9 and max_vol < 1e-9
record('Schur complement = inverse principal block', count, max_inv)
record('Volume-sampling expectation identity', count, max_vol)
record('Tail and complementary polynomial inequalities', count)

# 2. Isospectral block construction for the complementary upper bound on R.
max_error = 0.0
count = 0
for n in range(3, 10):
    for k in range(1, n):
        lam = np.exp(rng.uniform(-2, 2, n))
        K, h = harmonic_block(lam, k)
        _, costs = direct_errors(K, k)
        assert costs.min() >= h - 1e-8
        err = np.max(np.abs(np.linalg.eigvalsh(K)-np.sort(lam)))
        max_error = max(max_error, float(err))
        count += 1
assert max_error < 1e-9
record('Harmonic-block spectrum and every-subset lower bound', count, max_error)

# 3. One-column equalization.
max_error = 0.0
count = 0
for n in range(3, 12):
    for _ in range(5):
        lam = np.exp(rng.uniform(-2, 2, n))
        c = sum(lam*lam)/sum(lam)
        z = zero_diagonal_basis(np.diag(lam*lam-c*lam))
        K = (z.T * lam) @ z
        _, errors = direct_errors(K, 1)
        max_error = max(max_error, float(np.max(np.abs(errors-volume_mean(lam, 1)))))
        count += 1
assert max_error < 1e-8
record('One-column equalization', count, max_error)

# 4. Frame cofactor/Johnson-graph identity and complementary-rank duality.
max_graph = max_dual = 0.0
count = 0
for n in range(4, 9):
    for r in range(1, n):
        V = np.linalg.qr(rng.normal(size=(n, n)))[0]
        Q, U = V[:, :r], V[:, r:]
        inds, costs = frame_costs(Q)
        other_inds, other_costs = frame_costs(U)
        other = dict(zip(other_inds, other_costs))
        weights = np.array([np.linalg.det(Q[list(i)])**2 for i in inds])
        for j, i in enumerate(inds):
            neighbors = [l for l, s in enumerate(inds) if len(set(i)&set(s)) == r-1]
            rhs = r + weights[neighbors].sum()/weights[j]
            max_graph = max(max_graph, abs(rhs-costs[j])/max(1.0, costs[j]))
            comp = tuple(t for t in range(n) if t not in i)
            target = other[comp] + 2*r-n
            max_dual = max(max_dual, abs(costs[j]-target)/max(1.0, costs[j]))
        assert costs.min() <= r*(n-r+1) + 1e-9
        count += 1
assert max_graph < 1e-7 and max_dual < 1e-7
record('Johnson-graph cofactor identity', count, max_graph)
record('Complementary-rank inverse-Frobenius duality', count, max_dual)

# 5. Symbolic algebra supporting the exact four-dimensional theorem.
a, t = sp.symbols('a t', real=True)
b = 1-a
poly = (1+3*a)*t**2 - 4*t - (1-a)
expr = b*b*t*(t+1) - (1-a*t)*(b*(t+1)+4*t)
assert sp.expand(expr-poly) == 0
at = (-t*t+4*t+1)/(3*t*t+1)
z = (t*t-1)/(4*t*t)
assert sp.factor(at+(1-at)*z-1/t) == 0
assert sp.factor((1+at)/(at+(1-at)**2*(1-z)/4) - (1+t)) == 0
ratio = sp.factor(6*(1+at)/(1+4*at+at**2)/(1+t))
D = -t**4 + 20*t**3 + 14*t**2 + 12*t + 3
P = 3*t**5 + 9*t**4 - 6*t**3 + 30*t**2 + 19*t + 9
assert sp.factor(ratio-1-(t-1)**2*(t*t+3)/D) == 0
assert sp.factor(sp.diff(ratio,t)-6*(t-1)*P/D**2) == 0
alpha, beta, C, c = sp.symbols('alpha beta C c', real=True, nonzero=True)
g = (C*(alpha+beta)-(alpha-beta)*sp.sqrt(C*C-4*alpha*beta*c*c))/(2*alpha*beta)
gpp = 2*(alpha-beta)*C*C/(C*C-4*alpha*beta*c*c)**sp.Rational(3,2)
assert sp.simplify(sp.diff(g,c,2)-gpp) == 0
record('Exact symbolic identities (SymPy)', 6, note='Symbolic algebra checks, not formal proof verification.')

# 6. Four-dimensional exact extremizers, and random-plane checks of the global bound.
max_attain = 0.0
max_random_excess = 0.0
count = 0
Lvalues = [1.0, 1.001, 1.1, 1.5, 2.0, 3.0, 10.0, 100.0, 1e4, 1e7]
for L in Lvalues:
    Q = extremal_frame4(L)
    assert np.allclose(Q.T@Q, np.eye(2), atol=1e-13)
    _, costs = precision_errors(flat_precision(Q,L), 2)
    exact = flat_x4(L)
    max_attain = max(max_attain, abs(costs.min()-exact))
    for _ in range(200):
        R = np.linalg.qr(rng.normal(size=(4,2)))[0]
        _, random_costs = precision_errors(flat_precision(R,L), 2)
        max_random_excess = max(max_random_excess, random_costs.min()-exact)
        assert random_costs.min() <= exact + 1e-8
        count += 1
assert max_attain < 1e-8
record('Exact flat-spectrum extremizer attains the formula', len(Lvalues), max_attain)
record('Random-plane checks of the analytic global upper bound', count, max_random_excess,
       'Random checks do not establish a universal bound; the proof is analytic.')

# 7. Singular-minor convention and F(4,2)=3+sqrt(5).
Q = extremal_frame4(float('inf'))
inds, costs = frame_costs(Q)
assert sum(np.isinf(costs)) == 1
assert abs(costs.min()-(3+np.sqrt(5))) < 1e-12
assert np.max(np.abs(costs[np.isfinite(costs)]-(3+np.sqrt(5)))) < 1e-12
record('Limiting extremizer and its one singular basis', 1,
       float(abs(costs.min()-(3+np.sqrt(5)))))

# Reproducible numerical table for the exact family.
with (OUT/'flat_4_2.csv').open('w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['L','exact_x','exact_y','exact_y_over_x'])
    for L in [1,1.01,1.1,1.5,2,3,5,10,30,100,1000,10000,1e6,float('inf')]:
        writer.writerow([L,flat_x4(L),flat_y4(L),flat_y4(L)/flat_x4(L)])

payload = {
    'status': 'ALL_CHECKS_PASSED',
    'scope': 'Partial results only; sharp joint n,k dependence has not been established.',
    'verification_type': 'Deterministic floating-point tests and symbolic algebra, not a proof assistant or independent review.',
    'seed': SEED,
    'environment': {'python': platform.python_version(), 'numpy': np.__version__,
                    'scipy': scipy.__version__, 'sympy': sp.__version__},
    'checks': checks,
    'flat_family_limit': float(6/(3+np.sqrt(5))),
}
(OUT/'verification.json').write_text(json.dumps(payload, indent=2)+'\n')
print(f'Wrote {OUT / "verification.json"}')
