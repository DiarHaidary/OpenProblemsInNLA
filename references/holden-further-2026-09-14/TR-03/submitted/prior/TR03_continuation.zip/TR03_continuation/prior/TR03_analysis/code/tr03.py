"""Numerical utilities for the accompanying TR-03 partial-results report.

These routines check identities and examples. Floating-point enumeration and
local optimization are not proofs of global extremality. The analytic proofs
are in TR03_report.pdf / TR03_report.tex.
"""
from __future__ import annotations

from itertools import combinations
from math import comb, isinf
import numpy as np
from numpy.typing import ArrayLike, NDArray

FloatArray = NDArray[np.float64]


def subsets(n: int, k: int, max_count: int = 2_000_000) -> list[tuple[int, ...]]:
    if not 0 <= k <= n:
        raise ValueError("Require 0 <= k <= n.")
    if comb(n, k) > max_count:
        raise ValueError("Exhaustive enumeration would exceed max_count.")
    return list(combinations(range(n), k))


def spectrum(values: ArrayLike) -> FloatArray:
    lam = np.asarray(values, dtype=float)
    if lam.ndim != 1 or not len(lam) or not np.all(np.isfinite(lam)) or np.any(lam <= 0):
        raise ValueError("The spectrum must be a nonempty finite positive vector.")
    return lam


def elementary(values: ArrayLike) -> FloatArray:
    """All elementary symmetric polynomials, including e_0=1."""
    v = np.asarray(values, dtype=float)
    if v.ndim != 1 or not np.all(np.isfinite(v)):
        raise ValueError("Expected a finite one-dimensional array.")
    e = np.zeros(len(v) + 1)
    e[0] = 1.0
    for count, x in enumerate(v, start=1):
        e[1:count+1] += x * e[:count].copy()
    return e


def volume_mean(values: ArrayLike, k: int) -> float:
    lam = spectrum(values)
    if not 0 <= k < len(lam):
        raise ValueError("Require 0 <= k < n.")
    scale = float(lam.max())
    e = elementary(lam / scale)
    if e[k] <= 0:
        raise FloatingPointError("Symmetric-polynomial denominator underflowed.")
    return float(scale * (k + 1) * e[k+1] / e[k])


def precision_errors(H: ArrayLike, m: int) -> tuple[list[tuple[int, ...]], FloatArray]:
    """tr(H_JJ^{-1}) for all m-subsets J; input H must be positive definite."""
    h = np.asarray(H, dtype=float)
    if h.ndim != 2 or h.shape[0] != h.shape[1]:
        raise ValueError("Expected a square precision matrix.")
    np.linalg.cholesky(h)
    inds = subsets(len(h), m)
    costs = np.array([np.trace(np.linalg.solve(h[np.ix_(j, j)], np.eye(m))) for j in inds])
    return inds, costs


def direct_errors(K: ArrayLike, k: int) -> tuple[list[tuple[int, ...]], FloatArray]:
    """Direct Schur-complement errors, intended for moderate condition numbers."""
    K = np.asarray(K, dtype=float)
    np.linalg.cholesky(K)
    n = len(K)
    inds = subsets(n, k)
    vals = []
    for i in inds:
        j = tuple(t for t in range(n) if t not in i)
        jj, ji, ii = K[np.ix_(j, j)], K[np.ix_(j, i)], K[np.ix_(i, i)]
        vals.append(np.trace(jj - ji @ np.linalg.solve(ii, ji.T)))
    return inds, np.array(vals)


def frame_costs(Q: ArrayLike, singular_tolerance: float = 1e-12) -> tuple[list[tuple[int, ...]], FloatArray]:
    """Square-basis inverse-Frobenius costs; numerically singular bases get +inf.

    The threshold is a numerical convention, not a symbolic rank certificate.
    """
    q = np.asarray(Q, dtype=float)
    if q.ndim != 2:
        raise ValueError("Q must be a two-dimensional array.")
    n, r = q.shape
    if not 1 <= r <= n:
        raise ValueError("Require 1 <= r <= n.")
    if singular_tolerance <= 0:
        raise ValueError("singular_tolerance must be positive.")
    if not np.allclose(q.T @ q, np.eye(r), atol=1e-9, rtol=1e-9):
        raise ValueError("Q must have orthonormal columns.")
    inds = subsets(n, r)
    sv = np.linalg.svd(q[np.array(inds)], compute_uv=False)
    good = sv[:, -1] > singular_tolerance
    costs = np.full(len(inds), np.inf)
    costs[good] = np.sum(1.0 / sv[good]**2, axis=1)
    return inds, costs


def zero_diagonal_basis(H: ArrayLike) -> FloatArray:
    """Orthogonal Z with diag(Z.T @ H @ Z) approximately zero, for trace-zero H.

    Uses a Rayleigh-zero vector and recursion on its orthogonal complement.
    Tiny trace corrections compensate floating-point roundoff only.
    """
    h = np.asarray(H, dtype=float)
    if h.ndim != 2 or h.shape[0] != h.shape[1] or not np.allclose(h, h.T):
        raise ValueError("H must be real symmetric.")
    scale = max(1.0, np.linalg.norm(h, ord=2))
    if abs(np.trace(h)) > 1e-9 * len(h) * scale:
        raise ValueError("H must have zero trace, up to roundoff.")

    def recurse(a: FloatArray) -> FloatArray:
        n = len(a)
        a = (a + a.T) / 2
        a = a - np.eye(n) * np.trace(a) / n
        if n == 1:
            return np.ones((1, 1))
        d, v = np.linalg.eigh(a)
        if np.max(np.abs(d)) < 1e-14 * scale:
            return np.eye(n)
        lo, hi = float(d[0]), float(d[-1])
        if not lo < 0 < hi:
            raise FloatingPointError("Lost the trace-zero sign bracket.")
        c = np.sqrt(hi / (hi - lo))
        s = np.sqrt(-lo / (hi - lo))
        first = c * v[:, 0] + s * v[:, -1]
        last = -s * v[:, 0] + c * v[:, -1]
        rest = np.column_stack((v[:, 1:-1], last))
        return np.column_stack((first, rest @ recurse(rest.T @ a @ rest)))

    return recurse(h)


def equal_diagonal_matrix(values: ArrayLike) -> FloatArray:
    lam = np.asarray(values, dtype=float)
    z = zero_diagonal_basis(np.diag(lam - np.mean(lam)))
    return (z.T * lam) @ z


def harmonic_block(values: ArrayLike, k: int) -> tuple[FloatArray, float]:
    """Construct the isospectral block matrix proving x_k >= h_k."""
    lam = np.sort(spectrum(values))[::-1]
    if not 1 <= k < len(lam):
        raise ValueError("Require 1 <= k < n.")
    h = (k + 1) / np.sum(1.0 / lam[:k+1])
    Htop = equal_diagonal_matrix(1.0 / lam[:k+1])
    K = np.diag(lam)
    K[:k+1, :k+1] = np.linalg.solve(Htop, np.eye(k+1))
    return K, float(h)


def flat_x4(L: float) -> float:
    """Exact x_2(L,L,1,1), including its L=+infinity limiting value."""
    if np.isnan(L) or L < 1:
        raise ValueError("Require L >= 1.")
    a = 0.0 if isinf(L) else 1.0 / L
    t = (2.0 + np.sqrt(5.0 + 2*a - 3*a*a)) / (1.0 + 3*a)
    return float(1.0 + t)


def flat_y4(L: float) -> float:
    if np.isnan(L) or L < 1:
        raise ValueError("Require L >= 1.")
    a = 0.0 if isinf(L) else 1.0 / L
    return float(6.0 * (1.0 + a) / (1.0 + 4*a + a*a))


def extremal_frame4(L: float) -> FloatArray:
    """Columns span the eigenvalue-1 eigenspace of an exact extremizer."""
    t = flat_x4(L) - 1.0
    z = (t - 1.0) * (t + 1.0) / (4.0 * t*t)
    aa, bb, cc = np.sqrt(z / 2), np.sqrt(0.5), np.sqrt((1-z) / 2)
    return np.array([[aa, bb], [cc, 0.0], [aa, -bb], [cc, 0.0]])


def flat_precision(Q: ArrayLike, L: float) -> FloatArray:
    q = np.asarray(Q, dtype=float)
    if not np.isfinite(L) or L < 1:
        raise ValueError("Require finite L >= 1.")
    p = q @ q.T
    return p + (np.eye(len(p)) - p) / L
