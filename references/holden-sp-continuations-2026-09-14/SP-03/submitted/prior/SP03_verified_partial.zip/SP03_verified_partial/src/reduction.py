"""The regular big-cell reduction for SP-03.

All transposes and pairings are complex bilinear, not Hermitian. The data matrix
is in the Q-metric coordinates described in the accompanying report. These
floating-point routines do not certify roots, invertibility, or completeness.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from numpy.typing import ArrayLike, NDArray

ComplexMatrix = NDArray[np.complex128]

@dataclass(frozen=True)
class ReducedPoint:
    value: complex
    gradient: ComplexMatrix
    hessian: ComplexMatrix | None
    symplectic_matrix: ComplexMatrix
    S: ComplexMatrix
    T: ComplexMatrix
    L: ComplexMatrix


def standard_forms(m: int) -> tuple[ComplexMatrix, ComplexMatrix, ComplexMatrix]:
    """Return J, the symmetric Gram matrix Q, and the basis-change matrix P."""
    if not isinstance(m, int) or m < 1:
        raise ValueError("m must be a positive integer")
    eye = np.eye(m, dtype=np.complex128)
    zero = np.zeros_like(eye)
    J = np.block([[zero, eye], [-eye, zero]])
    Q = np.block([[zero, eye], [eye, zero]])
    P = np.block([[eye, 1j * eye], [1j * eye, eye]]) / np.sqrt(2.0)
    return J, Q, P


def to_q_coordinates(U: ArrayLike) -> ComplexMatrix:
    """Convert an ordinary-Frobenius data matrix to the Q-metric coordinates."""
    U = np.asarray(U, dtype=np.complex128)
    if U.ndim != 2 or U.shape[0] != U.shape[1] or U.shape[0] % 2:
        raise ValueError("U must be square with positive even size")
    _, _, P = standard_forms(U.shape[0] // 2)
    return np.linalg.solve(P, U @ P)


def symmetric_basis(m: int) -> list[ComplexMatrix]:
    """Unnormalized basis E_ii and E_ij + E_ji, ordered lexicographically."""
    result = []
    for i in range(m):
        for j in range(i, m):
            E = np.zeros((m, m), dtype=np.complex128)
            E[i, j] = E[j, i] = 1.0
            result.append(E)
    return result


def reduce_at(A: ArrayLike, U: ArrayLike, *, hessian: bool = True) -> ReducedPoint:
    """Evaluate phi_U and recover the unique stationary S,T for a regular A.

    Raises ValueError for incompatible shapes and numpy.linalg.LinAlgError if a
    required inverse cannot be computed. Near-singular matrices may still cause
    severe floating-point error. No numerical determinant threshold certifies
    membership in the generic regular locus.
    """
    A = np.asarray(A, dtype=np.complex128)
    U = np.asarray(U, dtype=np.complex128)
    if A.ndim != 2 or A.shape[0] != A.shape[1] or A.shape[0] == 0:
        raise ValueError("A must be a nonempty square matrix")
    m = A.shape[0]
    if U.shape != (2 * m, 2 * m):
        raise ValueError("U must have shape (2*m, 2*m)")
    if not np.isfinite(A).all() or not np.isfinite(U).all():
        raise ValueError("All entries must be finite")
    Ua, Ub = U[:m, :m], U[:m, m:]
    Uc, Ud = U[m:, :m], U[m:, m:]
    inverse_A = np.linalg.inv(A)
    E = symmetric_basis(m)
    k = len(E)
    L = np.empty((k, k), dtype=np.complex128)
    b = np.empty(k, dtype=np.complex128)
    c = np.empty(k, dtype=np.complex128)
    for i, Ei in enumerate(E):
        b[i] = np.trace(A @ Ei @ Uc.T)
        c[i] = np.trace(Ei @ A @ Ub.T)
        for j, Ej in enumerate(E):
            L[i, j] = (2 * np.trace(A @ Ei @ A.T @ Ej)
                       - np.trace(Ej @ A @ Ei @ Ua.T))
    t = np.linalg.solve(L, b)
    s = np.linalg.solve(L.T, c)
    S = sum((s[i] * E[i] for i in range(k)), np.zeros_like(A))
    T = sum((t[i] * E[i] for i in range(k)), np.zeros_like(A))
    value = (-np.trace(A @ Ud.T) - np.trace(Ua @ inverse_A)
             - c.T @ t)
    Y = inverse_A.T
    V = 4 * A - Ua
    W = Y @ Ua.T @ Y
    gradient = T @ V @ S - Uc @ S - T @ Ub - Ud + W
    X = np.block([[A, A @ S], [T @ A, T @ A @ S + Y]])
    H = None
    if hessian:
        HS = np.column_stack([((T @ V - Uc) @ Ei).ravel() for Ei in E])
        HT = np.column_stack([(Ei @ (V @ S - Ub)).ravel() for Ei in E])
        H0 = np.empty((m * m, m * m), dtype=np.complex128)
        for j in range(m * m):
            delta = np.zeros_like(A)
            delta.flat[j] = 1.0
            H0[:, j] = (4 * T @ delta @ S - Y @ delta.T @ W
                        - W @ delta.T @ Y).ravel()
        R = HT @ np.linalg.solve(L, HS.T)
        H = H0 - R - R.T
    return ReducedPoint(complex(value), gradient, H, X, S, T, L)
