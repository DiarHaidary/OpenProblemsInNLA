"""Numerical diagnostics only; the proofs and exact audits are separate."""
from __future__ import annotations
import numpy as np
from scipy.optimize import linprog


def matching(edges):
    edges=np.asarray(edges,dtype=bool)
    if edges.ndim!=2 or edges.shape[0]!=edges.shape[1]:
        raise ValueError('square graph required')
    n=len(edges); right=np.full(n,-1,dtype=int)
    def aug(i,seen):
        for j in np.flatnonzero(edges[i]):
            if seen[j]:continue
            seen[j]=True
            if right[j]<0 or aug(right[j],seen):
                right[j]=i;return True
        return False
    for i in range(n):aug(i,np.zeros(n,dtype=bool))
    left=np.full(n,-1,dtype=int)
    for j,i in enumerate(right):
        if i>=0:left[i]=j
    return left,right


def bottleneck(a):
    a=np.asarray(a,dtype=complex)
    costs=np.abs(a[:,None]+a[None,:]); vals=np.unique(costs)
    lo,hi=0,len(vals)-1
    while lo<hi:
        mid=(lo+hi)//2
        if np.all(matching(costs<=vals[mid])[0]>=0):hi=mid
        else:lo=mid+1
    return float(vals[lo])


def independent_hall(edges):
    """Return an independent deficient set in a symmetric graph, or None."""
    edges=np.asarray(edges,dtype=bool)
    if not np.array_equal(edges,edges.T):raise ValueError('symmetric graph required')
    left,right=matching(edges)
    roots=np.flatnonzero(left<0)
    if not len(roots):return None
    I=set(map(int,roots)); N=set(); stack=list(I)
    while stack:
        i=stack.pop()
        for jj in np.flatnonzero(edges[i]):
            j=int(jj)
            if j in N:continue
            N.add(j)
            ii=int(right[j])
            if ii>=0 and ii not in I:I.add(ii);stack.append(ii)
    NI=set(map(int,np.flatnonzero(edges[list(I)].any(axis=0))))
    S=sorted(I-NI)
    NS=sorted(map(int,np.flatnonzero(edges[S].any(axis=0))))
    if not S or len(NS)>=len(S) or edges[np.ix_(S,S)].any():
        raise RuntimeError('Hall reduction failed')
    return S,NS


def reflection(F):
    F=np.asarray(F)
    if F.ndim!=2 or len(F)<F.shape[1]:raise ValueError('invalid basis')
    return np.eye(len(F))-2*F@np.linalg.solve(F.conj().T@F,F.conj().T)


def residual(a,F):
    U=reflection(F);a=np.asarray(a,dtype=complex)
    return (a[:,None]+a[None,:])*U


def moment_columns(a,F,t):
    """Six symmetric matrix moments for a real reflection basis."""
    a=np.asarray(a,dtype=complex);F=np.asarray(F,dtype=float)
    r=F.shape[1]; tri=np.triu_indices(r)
    gap=t*t-abs(a)**2
    if np.any(gap==0):raise ValueError('spectrum meets the certification circle')
    scalars=np.array([np.ones(len(a)),a.real,a.imag,1/gap,a.real/gap,a.imag/gap]).T
    return np.array([np.outer(s,(np.outer(row,row))[tri]).ravel()
                     for s,row in zip(scalars,F)]).T


def compress_moments(a,F,t,protected):
    """Numerical conic reduction. Not an exact norm certificate.

    Protected indices must include all points outside |z|<t. To retain a
    matching obstruction, the caller also protects its entire neighborhood.
    The theorem proves exact existence; this routine checks floating errors.
    """
    a=np.asarray(a,dtype=complex);F=np.asarray(F,dtype=float)
    n,r=F.shape;keep=sorted(set(map(int,protected)))
    outside=set(map(int,np.flatnonzero(abs(a)>t)))
    if not outside<=set(keep):raise ValueError('all exterior points must be protected')
    rem=np.array([i for i in range(n) if i not in keep],dtype=int)
    if not len(rem):return a.copy(),F.copy(),{'new_dimension':n,'moment_residual':0.0}
    A=moment_columns(a[rem],F[rem],t);target=A@np.ones(len(rem))
    norms=np.maximum(np.max(abs(A),axis=1),1e-30)
    As=A/norms[:,None];bs=target/norms
    opt=linprog(np.zeros(len(rem)),A_eq=As,b_eq=bs,bounds=(0,None),method='highs',
                options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
    if not opt.success:raise RuntimeError(opt.message)
    select=np.flatnonzero(opt.x>1e-10)
    inds=np.r_[keep,rem[select]].astype(int)
    weights=np.r_[np.ones(len(keep)),opt.x[select]]
    an=a[inds];Fn=F[inds]*np.sqrt(weights)[:,None]
    err=float(np.max(abs(As@opt.x-bs)))
    if err>1e-7:raise RuntimeError(f'unreliable moment reduction: {err}')
    return an,Fn,{'old_dimension':n,'new_dimension':len(an),'rank':r,
                 'protected_count':len(keep),'retained_interior_atoms':len(select),
                 'moment_residual':err,'selected_original_indices':inds.tolist(),
                 'weights':weights.tolist()}
