"""Numerical log-determinant phase-I SDP proposal generator. Not a verifier."""
import numpy as np

def solve(mats,A,b,verbose=False,mu_min=1e-9,store=True):
    A=np.asarray(A,float);b=np.asarray(b,float)
    U,s,V=np.linalg.svd(A,full_matrices=True);rank=np.sum(s>1e-10)
    y0=V[:rank].T@((U[:,:rank].T@b)/s[:rank]);N=V[rank:].T
    if np.linalg.norm(A@y0-b)>1e-8:raise ValueError('Inconsistent affine constraints')
    offsets=[np.einsum('ijk,k->ij',M,y0) for M in mats]
    coefs=[np.concatenate((np.einsum('ijk,kl->ijl',M,N),np.eye(M.shape[0])[:,:,None]),axis=2) for M in mats]
    dims=N.shape[1]+1;v=np.zeros(dims);v[-1]=max(1,1-min(np.linalg.eigvalsh(C)[0] for C in offsets));total=sum(len(M) for M in mats)
    def value(v,mu,deriv=False):
        val=v[-1];g=np.zeros(dims);g[-1]=1;H=np.zeros((dims,dims));inverses=[]
        for off,B in zip(offsets,coefs):
            M=off+np.einsum('ijk,k->ij',B,v);ev,Q=np.linalg.eigh((M+M.T)/2)
            if ev[0]<=0:return None
            val-=mu*np.sum(np.log(ev))
            if deriv:
                inv=(Q/ev)@Q.T;inverses.append(inv);g-=mu*np.einsum('ij,ijk->k',inv,B)
                W=np.einsum('ai,abk,bj->ijk',Q,B,Q)/np.sqrt(ev)[:,None,None]/np.sqrt(ev)[None,:,None]
                H+=mu*np.einsum('ijk,ijl->kl',W,W)
        return (val,g,H,inverses) if deriv else val
    records=[];snapshots=[];mus=[];mu=1/total
    while mu>mu_min:mus.append(mu);mu*=.2
    mus.append(mu_min)
    for mu in mus:
        for it in range(100):
            val,g,H,inv=value(v,mu,True);step=np.linalg.lstsq(H,-g,rcond=1e-14)[0]
            if -g@step<1e-19 or np.max(np.abs(g))<1e-11:break
            eta=1
            for ls in range(70):
                nv=v+eta*step;nval=value(nv,mu)
                if nval is not None and nval<=val+.01*eta*g@step:v=nv;break
                eta*=.5
            else:break
        val,g,H,inv=value(v,mu,True);Z=[mu*x for x in inv]
        lhs=sum(np.einsum('ij,ijk->k',z,M) for z,M in zip(Z,mats));w=np.linalg.lstsq(A.T,lhs,rcond=1e-11)[0];err=np.max(np.abs(lhs-A.T@w))
        rec=dict(mu=float(mu),t=float(v[-1]),dual_value=float(b@w),gap=float(total*mu),dual_residual=float(err),gradient=float(np.max(np.abs(g))),iterations=it);records.append(rec)
        if store:snapshots.append({'Z':[z.copy() for z in Z],'w':w.copy(),'record':rec})
        if verbose:print(rec,flush=True)
        if (v[-1]<-1e-5 or (b@w<-1e-7 and total*mu < -(b@w))) and err<1e-9:break
    return dict(y=y0+N@v[:-1],Z=Z,w=w,t=float(v[-1]),records=records,snapshots=snapshots)
