# Primary sources and exact dependencies

Accessed September 13, 2026, through the public websites, not a GitHub plugin.

1. OpenProblemsInNLA, canonical RA-05 entry.
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/RA-05/README.md
   Exact target: all fixed real p>2, all matrices, nonnegative original-row weights,
   query dimension at most k. Existence/size only. Live status read as Open.

2. H. Lin, V. Mirrokni, D. P. Woodruff, Nearly Optimal Strong Coresets for lp
   Subspace Approximation, arXiv:2608.26047v2 (27 August 2026).
   https://arxiv.org/html/2608.26047v2
   Theorem 1.2: baseline k^(p/2) epsilon^-2, log exponent p+5. Used as the first
   upper branch and as preliminary original-row reduction. Fixed positive success
   probability suffices. We do not claim to have proved or implemented that import.

3. T. Rothvoss, Constructive Discrepancy Minimization for Convex Sets.
   https://arxiv.org/pdf/1404.0339
   Lemma 9 (visually checked on PDF page 8): arbitrary fractional center and
   coefficient subspace. The displayed parameter is delta=(3/2)*xi*log_2(1/xi),
   xi<=1/60000. Abstract fixed constants c0,kappa0 are used in our text.

4. J. A. Tropp, User-Friendly Tail Bounds for Sums of Random Matrices.
   https://arxiv.org/html/1004.4389v7
   Theorem 1.5: rectangular Gaussian matrix series, using both left and right
   variances. Coefficient-projection and anisotropic consequences are proved here.

5. A. W. Marcus, D. A. Spielman, N. Srivastava, Interlacing Families III:
   Sharper Restricted Invertibility Estimates.
   https://arxiv.org/html/1712.07766
   Theorem 1.1 states the Spielman-Srivastava stable-rank theorem used to select
   well-conditioned columns. No unit-column assumption is added or needed.

6. OpenProblemsInNLA, resolution/status guidelines.
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/RESOLVED.md
   Used only for status interpretation, not as a mathematical premise.

7. Prior conversation artifacts, preserved unchanged in prior_work/.
   They supply provenance and historical comparisons, not independent review.
   Both lower constructions needed for the final theorem are reproved in the new
   manuscript, and the new upper theorem does not assume an earlier asymptotic claim.

The new structured Gaussian, norming, and protection lemmas are proved in this
package. No primary-source priority claim or exhaustive literature review is made.
