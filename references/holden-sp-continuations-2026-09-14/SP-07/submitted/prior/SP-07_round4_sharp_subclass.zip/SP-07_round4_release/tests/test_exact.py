from pathlib import Path
import sys, json, tempfile, unittest
from fractions import Fraction as F
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from polynomial import Poly
from verify_rank_one import check_amgm, check_extremizer, ROOT

class ExactTests(unittest.TestCase):
    def test_polynomial_operations(self):
        x,y=Poly.var(2,0),Poly.var(2,1)
        self.assertEqual((x+y)**2,x*x+2*x*y+y*y)
        self.assertEqual((x-y)*(x+y),x*x-y*y)
        self.assertEqual(((x+y)**3).evaluate([F(2,3),F(1,4)]),F(11,12)**3)
        self.assertEqual((x+y).substitute([x*x,y*y]),x*x+y*y)

    def test_exact_certificate(self):
        self.assertEqual(check_amgm()['nonzero_allocations'],43)

    def test_exact_extremizer(self):
        self.assertEqual(check_extremizer()['squared_ratio'],'28/27')

    def corrupt(self,change):
        data=json.loads((ROOT/'certificates/rank_one_amgm.json').read_text())
        change(data)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'bad.json';path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):check_amgm(path)

    def test_reject_negative_weight(self):
        self.corrupt(lambda d:d['flow'][0].__setitem__(0,'-1'))

    def test_reject_changed_weight(self):
        self.corrupt(lambda d:d['flow'][0].__setitem__(0,'201'))

    def test_reject_changed_exponent(self):
        self.corrupt(lambda d:d['negative'][0][0].__setitem__(0,3))

    def test_reject_changed_polynomial(self):
        self.corrupt(lambda d:d['positive'][0].__setitem__(1,201))

    def test_reject_missing_group(self):
        self.corrupt(lambda d:d['flow'].pop())

    def test_success_flag_is_not_trusted(self):
        data=json.loads((ROOT/'certificates/rank_one_amgm.json').read_text());data['exact']=False
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'flag.json';path.write_text(json.dumps(data))
            self.assertTrue(check_amgm(path)['all_weight_and_exponent_equalities_exact'])

if __name__=='__main__':unittest.main(verbosity=2)
