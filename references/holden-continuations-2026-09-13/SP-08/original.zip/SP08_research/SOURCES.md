# Sources and attribution

The problem statement was consulted on the public website, without the GitHub connector/plugin:

- Open Problems in Numerical Linear Algebra, SP-08 entry: https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/eigenvalues-and-inverse-problems/SP-08
- Raw problem entry: https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/eigenvalues-and-inverse-problems/SP-08/README.md
- Paper linked in the problem discussion, arXiv:2510.15919, version 1: https://arxiv.org/html/2510.15919v1

The new proofs in this package are arguments developed in this continuation, not results attributed to those sources. The earlier attached manuscripts and verification reports are preserved under `provenance/` with the limitations explained in the README. No claim about the literature's current open/closed status is inferred merely from the repository listing.
