"""Second arithmetic implementation for a reflection certificate (SymPy).
Checks the same rational input using symbolic matrix arithmetic and exact LDL.
"""
import argparse,json
from pathlib import Path
import sympy as s
from certify_five import canonical,exact_ldl

def main(a):
 d=json.loads(a.input.read_text());z=[s.Rational(x)+s.I*s.Rational(y) for x,y in d['z']];n=len(z);X=s.Matrix([[s.Rational(v) for v in row] for row in d['X']]);r=X.cols;Y=s.eye(r).col_join(X);P=Y*(Y.T*Y).inv()*Y.T;J=s.eye(n)-2*P
 assert (J*J-s.eye(n)).applyfunc(s.cancel)==s.zeros(n)
 D=s.diag(*z);M=(D+J*D*J).applyfunc(canonical);t=s.Rational(d['norm_upper_bound']);H=(t*t*s.eye(n)-M.conjugate().T*M).applyfunc(canonical);L,piv=exact_ldl(H)
 assert (H-L*s.diag(*piv)*L.conjugate().T).applyfunc(canonical)==s.zeros(n)
 gap=min(canonical((z[i]+z[j])*s.conjugate(z[i]+z[j])) for i in d['I'] for j in d['J']);q=s.Rational(d['ratio_lower_bound']);assert gap>q*q*t*t
 previous=json.loads(a.input.with_name(a.input.stem+'_verification.json').read_text());assert [str(v) for v in piv]==previous['exact_pivots'];assert str(gap)==previous['hall_gap_squared']
 out={'status':'Independent SymPy arithmetic cross-check passed.','dimension':n,'strict_ratio_lower_bound':str(q),'ldl_reconstruction_passed':True,'exact_pivots_match_standard_library_checker':True,'hall_gap_matches_standard_library_checker':True,'sympy_version':s.__version__};a.output.write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args();main(a)
