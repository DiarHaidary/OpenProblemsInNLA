#!/usr/bin/env python3
"""Elementary exact constructions used in the manuscript; no Hall dependency."""
from __future__ import annotations
from itertools import permutations
import json
from pathlib import Path
import sp10


def cross(x, y):
    return [x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0]]


def path_complement_vectors(n: int) -> list[list[int]]:
    if n < 4:
        raise ValueError('The sharp-family construction is stated for n >= 4.')
    vectors = [[1, 0, 0], [0, 1, 0], [1, 0, 1]]
    while len(vectors) < n:
        basis = sp10.nullspace([vectors[-1]], 3)
        assert len(basis) == 2
        for t in range(2 * len(vectors) + 2):
            candidate = sp10.primitive([basis[0][j] + t*basis[1][j] for j in range(3)])
            if (all(sp10.dot(candidate, u) for u in vectors[:-1])
                    and all(any(cross(candidate, u)) for u in vectors)):
                vectors.append(candidate)
                break
        else:
            raise AssertionError('The finite forbidden-parameter bound failed.')
    return vectors


def path_certificate(n: int) -> dict:
    a = sp10.from_edges(n, [[i, i+1] for i in range(n-1)])
    v, w = sp10.laplacian_vectors(a), path_complement_vectors(n)
    rg, rb = sp10.check_gram(a, v), sp10.check_gram(sp10.complement(a), w)
    cert = {'n': n, 'edges': sp10.edges(a), 'status': 'CERTIFIED',
            'gram_G': v, 'gram_complement': w,
            'rank_G': rg, 'rank_complement': rb,
            'rank_sum': rg+rb, 'target': n+2,
            'family': 'path', 'minimum_ranks_proved_in_manuscript': True}
    sp10.verify_pair(cert)
    return cert


def bull_certificate() -> dict:
    a = sp10.from_edges(5, [[0,1],[0,2],[1,2],[2,3],[0,4]])
    b = sp10.complement(a)
    v = [[1,1,0],[0,1,0],[0,1,1],[0,0,1],[1,0,0]]
    p = next(p for p in permutations(range(5)) if all(
        bool(b[i] >> j & 1) == bool(a[p[i]] >> p[j] & 1)
        for i in range(5) for j in range(i)))
    w = [v[p[i]] for i in range(5)]
    cert = {'n': 5, 'edges': sp10.edges(a), 'status': 'CERTIFIED',
            'gram_G': v, 'gram_complement': w,
            'rank_G': 3, 'rank_complement': 3, 'rank_sum': 6, 'target': 7,
            'complement_isomorphism': list(p),
            'greedegree_G': sp10.best_mcs(a)[0],
            'greedegree_complement': sp10.best_mcs(b)[0]}
    sp10.verify_pair(cert)
    return cert


def main():
    root = Path(__file__).resolve().parents[1]
    bull = bull_certificate()
    (root/'certificates'/'bull.json').write_text(json.dumps(bull, indent=2)+'\n')
    with (root/'certificates'/'paths_4_to_20.jsonl').open('w') as f:
        for n in range(4,21):
            f.write(json.dumps(path_certificate(n),separators=(',',':'))+'\n')
    print('Bull permutation:',bull['complement_isomorphism'])
    print('Bull A:',sp10.gram(bull['gram_G']))
    print('Bull B:',sp10.gram(bull['gram_complement']))
    print('Verified the bull and all 17 path certificates, n=4,...,20.')


if __name__ == '__main__':
    main()
