# SP-07 — Sharp rank-one-reflection theorem and fixed-rank reduction

**The unrestricted problem is not solved.** The complete new theorem is a sharp
bound for the rank-one-reflection anti-pair subclass. The previous global lower
bound is rechecked, not increased.

## Mathematical results

For every normal matrix A and every rank-one orthogonal projection P, with
U = I − 2P and B = −UAU,

`d_infinity(A,B) <= sqrt(28/27) * ||A-B||_op`.

The constant is sharp for this class over all dimensions. The equality pair is
a normalized version of the known Krause construction; it is not a new example.
The projection rank is **not** the rank of A−B. The result does **not** determine
the unrestricted three-dimensional constant c_3.

For real rank-r reflection anti-pairs, the supremum over all matrix orders is
unchanged by restricting the order to `n <= 3*r*r + 7*r - 1`. The rank remains
unbounded in the unrestricted SP-07 problem.

`REPORT.pdf` contains the proofs; `REPORT.tex` and `amgm_table.tex` are editable
sources. The exact AM–GM coefficient table is also supplied as JSON. The previous
ZIP is retained unchanged in `prior/`, including the earlier packages nested in it.

## Exact checks — no third-party dependencies

Python 3.10 or newer is sufficient for the new exact checker and tests:

```sh
python -S verify_rank_one.py
python verify_all.py
```

The first checks polynomial identities, the nonnegative AM–GM weights and their
exponent barycenters, the equality point, and the exact extremal matrices. It uses
integers and `fractions.Fraction`, never a floating-point tolerance. The second
also runs the nine exact/rejection tests with and without Python optimization.

The following additionally extracts a temporary copy of the retained prior ZIP
and reruns its n=5 and n=193 certificates by **both** exact positivity methods:

```sh
python verify_all.py --prior
```

The inherited checks are separate from the new AM–GM proof. Their two positivity
methods share some construction code; they are not an independent external audit.

## Optional symbolic and numerical diagnostics

Install the optional dependencies in a suitable Python environment, then run:

```sh
python -m pip install -r requirements-optional.txt
python verify_all.py --symbolic --numerical
```

`src/symbolic_audit.py` reconstructs the small radical matrices without importing
the standard-library field/matrix implementation. Numerical tests exercise disk
identities, matching and outlier reductions, and moment compression. The numerical
moment reducer uses floating-point linear programming; **it is not a proof checker**.

`research/discover_amgm.py` can rediscover an AM–GM allocation. The fixed delivered
certificate is checked independently of the optimizer, and rediscovery may return
a different valid table on another solver version.

## Scope and provenance

The new results do not change the global bracket

`20000000 / 19281027 < C_normal < 2.9038872828`.

The lower side is the retained exact 193-dimensional example. The upper side is
reported in the cited literature and is not reproved here. The rank-two example
already exceeds sqrt(28/27), so rank-one sharpness cannot be a universal answer.

See `STATUS.md`, `sources/PROVENANCE.md`, and the report's final sections. No
historical-priority claim, external peer review, formal proof-assistant validation,
or repository edit is asserted. All logs describe checks actually executed.
