# Reproduction

Run commands from the `SP08_research` directory after extracting the ZIP.

## Exact polynomial certificate

Python 3.10 or newer is sufficient; this verifier needs no third-party package:

```sh
python code/verify_typeA_certificate.py
```

The program reconstructs the spectral polynomials with rational sparse-polynomial arithmetic, verifies the clearing-of-denominator identities, and checks every stored sum-of-squares identity and nonnegative remainder. The checked scope is the Type-A three-block family, not arbitrary endpoint matrices.

## Analytic identities and supplementary tests

```sh
python -m pip install -r requirements.txt
python code/run_all_checks.py
python code/run_all_checks.py --numerical
```

The symbolic identities support the analytic proofs. Numerical sweeps are supplementary checks only. The dimension sweep in the boundary-strip checker is not a substitute for the all-dimensions inequalities in the manuscript.

The JSON reports and captured output appear in `checks/`. A nonzero exit status must be investigated, not treated as a successful verification. Re-running scripts can change report timing fields and hence their hashes; the manifest records the distributed versions.

## PDF

With a LaTeX installation providing the standard packages used in the source:

```sh
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error sp08_continuation.tex
pdflatex -interaction=nonstopmode -halt-on-error sp08_continuation.tex
```

The new manuscript is self-contained. Some historical source files under `provenance/` refer to unavailable old certificate tables and are preserved verbatim rather than represented as complete new builds.

## Certificate discovery versus verification

The discovery scripts under `exploration/` are not needed to verify the distributed certificate. They may additionally require SciPy and use floating-point optimization to propose rational identities. Only the exact reconstructed identities are used in the proof. Re-running a search is not guaranteed to reproduce the same decomposition; exact verification of the saved rational decomposition is deterministic.
