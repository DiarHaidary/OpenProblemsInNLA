# Primary sources and attribution

The public websites below were read on 13 September 2026. No GitHub connector was used. The source documents are linked, not redistributed in this package.

## Requested problem

Open Problems in Numerical Linear Algebra, **SP-07: The sharp spectral-matching constant for normal matrices**.

https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/eigenvalues-and-inverse-problems/SP-07/README.md

Used for the exact problem statement, operator-norm convention, retention of multiplicities, and distinction between a lower-bound counterexample and determination of the universal sharp constant. The entry's status is not used as a mathematical reason for the remaining gap in this attempt.

## Classical interval and truncated bound

Qiyue Tang, **A Truncated Singular-Value Bound for Spectral Variation of Normal Matrices**, arXiv:2609.09177v1.

https://arxiv.org/html/2609.09177v1

Used for the stated classical upper estimate `C_normal < 2.9038872828`, the historical Krause squared distance and norm values `28/13` and `27/13`, and the dimension-based truncated singular-value estimate. The continuation does not claim any of those as new results. The upper estimate is cited, not reproved.

## Supplied prior work

The user supplied `SP07_partial_results.zip` and `SP07_report.pdf`. The ZIP contents are retained under `prior/sp07_partial_results/`. They provide the baseline certificate, matching routines, Givens search model, earlier reductions, failure diagnostics, and historical records. Their original status files are retained rather than revised retroactively.

The continuation's exact rational certificates and proofs appear in the new root report. No first-in-the-literature priority claim, independent human peer review, or proof-assistant formalization is asserted.
