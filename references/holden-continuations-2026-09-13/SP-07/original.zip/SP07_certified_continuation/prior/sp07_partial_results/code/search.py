"""Local Hall-cut searches for SP-07; no global optimality certification.

Examples:
  OPENBLAS_NUM_THREADS=1 python code/search.py --sizes 3 4 5 --runs 12 --output results/search.json
  OPENBLAS_NUM_THREADS=1 python code/search.py --sizes 3 4 5 --runs 12 --random-start --output results/random.json

A real-orthogonal search is selected by --real; otherwise complex Givens
rotations are used. Every reported matrix ratio is recomputed using the exact
finite bottleneck-matching algorithm (in floating-point arithmetic), not the
smoothed optimizer objective. Output is checkpointed after each dimension/cut.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp
from matching import bottleneck


class Model:
    def __init__(self, n: int, p: int, complex_unitary: bool = True):
        if n < 3 or not 2 <= p <= n-1:
            raise ValueError('Use n >= 3 and 2 <= p <= n-1.')
        self.n, self.p, self.q = n, p, n+1-p
        self.complex = complex_unitary
        self.pairs = [(j, i) for j in range(n-1) for i in range(n-1, j, -1)]
        self.ns, self.m = 4*n-3, len(self.pairs)
        self.nt = self.m * (2 if complex_unitary else 1)
        self.size, self.rho = self.ns+self.nt+1, 100.0

    def unitary(self, t: np.ndarray, derivative: bool = False):
        rotations, dtheta, dphase = [], [], []
        for k, (i, j) in enumerate(self.pairs):
            theta = t[k]
            phase = t[self.m+k] if self.complex else 0.0
            c, s, e = np.cos(theta), np.sin(theta), np.exp(1j*phase)
            R = np.eye(self.n, dtype=complex)
            T = np.zeros_like(R); P = np.zeros_like(R)
            R[i, i] = R[j, j] = c; R[i, j] = -s/e; R[j, i] = s*e
            T[i, i] = T[j, j] = -s; T[i, j] = -c/e; T[j, i] = c*e
            P[i, j] = 1j*s/e; P[j, i] = 1j*s*e
            rotations.append(R); dtheta.append(T); dphase.append(P)
        left = [np.eye(self.n, dtype=complex)]
        for R in rotations:
            left.append(left[-1] @ R)
        if not derivative:
            return left[-1]
        right = [None] * (self.m+1); right[self.m] = np.eye(self.n)
        for k in range(self.m-1, -1, -1):
            right[k] = rotations[k] @ right[k+1]
        ds = [left[k] @ dtheta[k] @ right[k+1] for k in range(self.m)]
        if self.complex:
            ds += [left[k] @ dphase[k] @ right[k+1] for k in range(self.m)]
        return left[-1], np.array(ds)

    def real_angles(self, U: np.ndarray) -> np.ndarray:
        Q, angles = np.array(U, dtype=float).copy(), []
        for i, j in self.pairs:
            theta = np.arctan2(Q[j, i], Q[i, i])
            c, s = np.cos(theta), np.sin(theta)
            Q[[i, j]] = np.array([[c, s], [-s, c]]) @ Q[[i, j]]
            angles.append(theta)
        if np.max(abs(Q-np.diag(np.diag(Q)))) > 1e-7:
            raise RuntimeError('Givens decomposition failed.')
        return np.r_[angles, np.zeros(self.m)] if self.complex else np.array(angles)

    def start(self, radius: float = 2.0) -> np.ndarray:
        p, q, n = self.p, self.q, self.n
        a0 = np.array([1, (4+5j*np.sqrt(3))/13, (-1+2j*np.sqrt(3))/13])
        v = np.sqrt([5/8, 1/4, 1/8]); U0 = np.eye(3)-2*np.outer(v, v)
        a = np.r_[a0[:2], np.arange(1, p-1)*radius, a0[2:], -np.arange(1, q-1)*radius]
        b = np.r_[-a0[:2], -np.arange(1, q-1)*radius, -a0[2:], np.arange(1, p-1)*radius]
        U = np.zeros((n, n)); U[np.ix_([0, 1, p], [0, 1, q])] = U0
        for k in range(p-2):
            U[2+k, q+1+k] = 1
        for k in range(q-2):
            U[p+1+k, 2+k] = 1
        rotation = np.exp(-1j*np.angle(a[1]-a[0]))
        aa, bb = (a-a[0])*rotation, (b-a[0])*rotation
        scale = np.linalg.norm((aa[:, None]-bb[None, :])*U, 2)
        aa /= scale; bb /= scale
        gap = np.min(abs(aa[:p, None]-bb[None, :q]))
        return np.r_[aa[1].real, np.column_stack([aa[2:].real, aa[2:].imag]).ravel(),
                     np.column_stack([bb.real, bb.imag]).ravel(), self.real_angles(U), gap]

    def calculate(self, x: np.ndarray, jacobian: bool = False):
        n = self.n
        a = np.r_[0, x[0], x[1:2*n-3:2]+1j*x[2:2*n-3:2]]
        b = x[2*n-3:self.ns:2]+1j*x[2*n-2:self.ns:2]
        if jacobian:
            U, dU = self.unitary(x[self.ns:-1], True)
        else:
            U = self.unitary(x[self.ns:-1])
        L = a[:, None]-b[None, :]; M = L*U
        lam, V = np.linalg.eigh(M.conj().T @ M)
        smooth_max = logsumexp(self.rho*lam)/self.rho
        r = L[:self.p, :self.q]; delta = x[-1]
        constraints = np.r_[1-smooth_max, (abs(r)**2-delta**2).ravel()]
        if not jacobian:
            return constraints, (a, b, U, M, lam)
        dM = np.zeros((self.size, n, n), complex)
        dM[0, 1, :] = U[1, :]
        for i in range(2, n):
            k = 1+2*(i-2); dM[k, i, :] = U[i, :]; dM[k+1, i, :] = 1j*U[i, :]
        for j in range(n):
            k = 2*n-3+2*j; dM[k, :, j] = -U[:, j]; dM[k+1, :, j] = -1j*U[:, j]
        dM[self.ns:-1] = L[None, :, :]*dU
        weights = np.exp(self.rho*(lam-smooth_max))
        G = ((M @ V)*weights[None, :]) @ V.conj().T
        J = np.zeros((1+self.p*self.q, self.size))
        J[0] = -2*np.einsum('ij,kij->k', G.conj(), dM).real
        for i in range(self.p):
            for j in range(self.q):
                k = 1+i*self.q+j; re, im = r[i, j].real, r[i, j].imag
                if i == 1:
                    J[k, 0] = 2*re
                elif i > 1:
                    J[k, 1+2*(i-2)] = 2*re; J[k, 2+2*(i-2)] = 2*im
                J[k, 2*n-3+2*j] = -2*re; J[k, 2*n-2+2*j] = -2*im
                J[k, -1] = -2*delta
        return constraints, J

    def record(self, x: np.ndarray) -> dict:
        constraints, (a, b, U, M, lam) = self.calculate(x)
        gap = float(np.min(abs(a[:self.p, None]-b[None, :self.q])))
        norm = float(np.linalg.norm(M, 2))
        distance, perm = bottleneck(a, b)
        return dict(n=self.n, p=self.p, q=self.q, complex_unitary=self.complex,
                    cut_ratio=gap/norm, actual_ratio=distance/norm, gap=gap,
                    norm=norm, bottleneck=distance, matching=perm.tolist(),
                    x=x.tolist(), a=np.column_stack([a.real, a.imag]).tolist(),
                    b=np.column_stack([b.real, b.imag]).tolist(),
                    U_real=U.real.tolist(), U_imag=U.imag.tolist(),
                    rho=self.rho, minimum_constraint=float(np.min(constraints)),
                    unitarity_residual=float(np.linalg.norm(U.conj().T @ U-np.eye(self.n), 2)))

    def optimize(self, x: np.ndarray):
        for rho in (60.0, 500.0, 8000.0, 1e6):
            self.rho = rho
            result = minimize(lambda z: -z[-1], x,
                jac=lambda z: np.r_[np.zeros(self.size-1), -1.0], method='SLSQP',
                constraints=[dict(type='ineq', fun=lambda z: self.calculate(z)[0],
                                  jac=lambda z: self.calculate(z, True)[1])],
                bounds=[(1e-7, 10)]+[(-20, 20)]*(self.ns-1)+[(None, None)]*self.nt+[(.05, 3)],
                options=dict(ftol=2e-10, maxiter=200))
            x = result.x
        return result


def check_jacobian(model: Model, rng: np.random.Generator) -> float:
    x = model.start()+.07*rng.normal(size=model.size)
    _, J = model.calculate(x, True)
    h, eye = 1e-6, np.eye(model.size)
    finite_difference = np.column_stack([
        (model.calculate(x+h*eye[j])[0]-model.calculate(x-h*eye[j])[0])/(2*h)
        for j in range(model.size)])
    error = float(np.max(abs(J-finite_difference)))
    if error > 3e-6:
        raise RuntimeError(f'Jacobian check failed: {error}')
    return error


def main(args) -> dict:
    rng = np.random.default_rng(args.seed); start = time.monotonic()
    records, summary = [], []
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result = {}
    for n in args.sizes:
        for p in sorted(set([2, (n+1)//2])):
            model = Model(n, p, not args.real)
            jacobian_error = check_jacobian(model, rng)
            current = []
            for k in range(args.runs):
                radius = rng.uniform(1, 3)
                noise = [.04, .15, .3, .7, 1.5, .25][k % 6]
                x = model.start(radius)+noise*rng.normal(size=model.size)
                if args.random_start:
                    x[:model.ns] = rng.normal(size=model.ns)
                    x[0] = abs(x[0])
                    x[model.ns:-1] = rng.uniform(-np.pi, np.pi, size=model.nt)
                    x[-1] = .2
                optimum = model.optimize(x)
                record = model.record(optimum.x)
                record.update(seed=args.seed, run=k, noise=noise, radius=radius,
                              random_start=args.random_start, success=bool(optimum.success),
                              iterations=int(optimum.nit), optimizer_message=str(optimum.message))
                records.append(record); current.append(record)
            row = dict(n=n, p=p, runs=args.runs, complex_unitary=not args.real,
                       random_start=args.random_start,
                       maximum_actual_ratio=max(x['actual_ratio'] for x in current),
                       maximum_cut_ratio=max(x['cut_ratio'] for x in current),
                       count_above_1_001=sum(x['actual_ratio'] > 1.001 for x in current),
                       optimizer_successes=sum(x['success'] for x in current),
                       jacobian_error=jacobian_error)
            summary.append(row)
            print(json.dumps(row), flush=True)
            result = dict(status='Local floating-point searches, not a proof of global optimality.',
                          seed=args.seed, summary=summary, records=records,
                          elapsed_seconds=time.monotonic()-start)
            args.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sizes', nargs='+', type=int, default=[3, 4, 5])
    parser.add_argument('--runs', type=int, default=12)
    parser.add_argument('--seed', type=int, default=260913)
    parser.add_argument('--real', action='store_true')
    parser.add_argument('--random-start', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.runs <= 0 or any(n < 3 for n in args.sizes):
        parser.error('Runs must be positive and dimensions must be at least 3.')
    main(args)
