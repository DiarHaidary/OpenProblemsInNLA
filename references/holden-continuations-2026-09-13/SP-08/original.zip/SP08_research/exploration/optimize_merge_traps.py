import numpy as np,json,time,itertools
from scipy.optimize import differential_evolution
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def Hmake(rs,z):
 n=sum(rs)+int(z);H=np.zeros((n,n));off=0
 for r in rs:
  ii=np.minimum(np.arange(r)[:,None],np.arange(r)[None,:]);H[off:off+r,off:off+r]=(ii%2==0);off+=r
 return H
def spread(K,m,v=False):
 D=np.sqrt(np.maximum(m,0));T=K*D[:,None]*D[None,:]
 if v:return np.linalg.eigh(T)
 e=np.linalg.eigvalsh(T);return max(e[-1],0)-min(e[0],0)
def evaluate(z,K):
 mm=np.exp(np.r_[z,0]);m=mm/mm.sum();s=spread(K,m);mx=-1
 for i in range(len(m)):
  for j in range(len(m)):
   if i==j:continue
   w=m.copy();w[j]+=w[i];w[i]=0;mx=max(mx,spread(K,w))
 return mx-s
rows=[];start=time.monotonic()
for rs,zero in [([3],True),([4],True),([5],True),([2,1],False),([2,1],True),([2,2],False),([2,2],True),([3,1],False),([3,1],True),([3,2],False),([3,2],True),([3,3],True)]:
 H=Hmake(rs,zero)
 for a in [0,.4,.9,-.5]:
  K=1-(1-a)*H
  sol=differential_evolution(lambda z:evaluate(z,K),[(-7,7)]*(len(H)-1),seed=421,popsize=8,maxiter=90,polish=True,tol=1e-7)
  mm=np.exp(np.r_[sol.x,0]);m=mm/mm.sum();e,V=spread(K,m,True);x=V[:,-1]/np.sqrt(m);y=V[:,0]/np.sqrt(m);C=np.outer(x,x)-np.outer(y,y)
  stationary=bool(np.all((K-a)*C>=-1e-7) and np.all((1-K)*C<=1e-7))
  row={'runs':rs,'zero':zero,'a':a,'best_merge_minus_original':float(sol.fun),'m':m.tolist(),'stationary':stationary,'eig':e.tolist()};rows.append(row);print(row,flush=True)
  (root/'checks'/'optimized_merge_traps.json').write_text(json.dumps({'status':'EXPLORATION_ONLY','rows':rows,'seconds':time.monotonic()-start},indent=2))
  if sol.fun<-1e-7 and stationary:raise SystemExit('Found stationary whole-merge trap')
