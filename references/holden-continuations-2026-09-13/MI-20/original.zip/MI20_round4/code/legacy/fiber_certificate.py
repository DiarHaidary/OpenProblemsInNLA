#!/usr/bin/env python3
"""Exact two-sided bounds for one fixed cyclic orbit of MI-20 moduli.

The upper bound is NOT an upper bound for the unrestricted C_p(m).
Verification uses the standard library only. NumPy is used only by `build`
to propose data, which the exact verifier independently checks.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
from typing import Any
from legacy_lower import (need, integer, matrix, transpose, product, row_bound,
                          root_ceiling, verify as verify_lower)


def rational_power_bound(x: Fraction, numerator: int, denominator: int,
                         upper: bool, digits: int = 26) -> Fraction:
    """Enclose x**(numerator/denominator) by checked integer bisection."""
    need(x >= 0 and numerator >= 1 and denominator >= 1 and digits >= 0,
         'Invalid rational-power request')
    scale = 10**digits
    num = x.numerator**numerator * scale**denominator
    den = x.denominator**numerator
    if upper:
        h = root_ceiling((num + den - 1)//den, denominator)
        result = Fraction(h, scale)
        need(result**denominator >= x**numerator, 'Upper power check failed')
    else:
        floor_ratio = num//den
        h = root_ceiling(floor_ratio, denominator)
        if h**denominator > floor_ratio:
            h -= 1
        result = Fraction(h, scale)
        need(result**denominator <= x**numerator, 'Lower power check failed')
        need(Fraction(h+1, scale)**denominator > x**numerator,
             'Lower power enclosure is not the grid floor')
    return result


def spectral_interval(snum: list[list[int]], sden: int,
                      proposal: dict[str, Any], scale: int):
    """Weyl enclosure of a symmetric rational matrix, without eigensolvers."""
    n = len(snum)
    need(sden > 0 and snum == transpose(snum), 'Expected symmetric matrix')
    z = matrix(proposal['basis'], n, n)
    values = [integer(v) for v in proposal['values']]
    need(len(values) == n and values == sorted(values) and min(values) >= 0,
         'Invalid nonnegative spectral proposal')
    gram = product(transpose(z), z)
    delta = Fraction(row_bound([[gram[i][j] - (scale**2 if i == j else 0)
                               for j in range(n)] for i in range(n)]), scale**2)
    need(delta < 1, 'Spectral basis is not certified nonsingular')
    zd = [[z[i][j]*values[j] for j in range(n)] for i in range(n)]
    recon = product(zd, transpose(z))
    residual = [[snum[i][j]*scale**3-recon[i][j]*sden
                 for j in range(n)] for i in range(n)]
    e0 = Fraction(row_bound(residual), sden*scale**3)
    eta = e0 + delta*(2+delta)*Fraction(max(values), scale)
    lower = [max(Fraction(0), Fraction(d, scale)-eta) for d in values]
    upper = [Fraction(d, scale)+eta for d in values]
    return lower, upper, eta, delta


def trace_product(a: list[list[int]], b: list[list[int]]) -> int:
    need(len(a) == len(b), 'Trace-product dimension mismatch')
    return sum(a[i][j]*b[j][i] for i in range(len(a)) for j in range(len(a)))


def verify(data: dict[str, Any], base: dict[str, Any], base_bytes: bytes | None = None):
    need(data.get('schema') == 'mi20.fixed-orbit.upper.integer.v1', 'Wrong upper schema')
    need(data.get('scope') == 'all polar factors for these fixed cyclic moduli only',
         'Missing or incorrect scope declaration')
    if base_bytes is not None:
        need(hashlib.sha256(base_bytes).hexdigest() == data['lower_certificate_sha256'],
             'Lower-certificate content hash mismatch')
    lower_result = verify_lower(base)
    m, k, q = [integer(base[name]) for name in ('m','k','q')]
    need(q in (3,4,6), 'This verifier supports q=3,4,6 only')
    need(all(integer(data[name]) == integer(base[name]) for name in ('m','k','q','n')),
         'Upper/lower dimension or exponent mismatch')
    need(data['p'] == base['p'], 'Upper/lower p mismatch')
    scale = integer(base['scale'])
    need(integer(data['scale']) == scale, 'Scale mismatch')
    blocks = [matrix(b,k,k) for b in base['blocks']]
    knum = matrix(data['K'],k,k)
    wnum = matrix(data['inverse_factor'],k,k)
    need(knum == transpose(knum), 'K must be exactly symmetric')
    wkw = product(product(wnum,knum),transpose(wnum))
    delta = Fraction(row_bound([[wkw[i][j]-(scale**3 if i==j else 0)
                               for j in range(k)] for i in range(k)]),scale**3)
    need(delta < 1, 'K positivity / inverse majorant was not certified')
    # W K W^T >= (1-delta)I implies W invertible, K>0, and
    # K^{-1} <= W^T W/(1-delta).
    anum = [[0]*k for _ in range(k)]
    for block in blocks:
        aa = product(transpose(block),block)
        for i in range(k):
            for j in range(k):
                anum[i][j] += aa[i][j]
    wtwnum = product(transpose(wnum),wnum)
    alpha_upper = Fraction(trace_product(anum,wtwnum),scale**4)/(1-delta)
    need(alpha_upper > 0, 'Nonpositive alpha bound')
    denom_lower = Fraction(0)
    denom_errors = []
    for block,proposal in zip(blocks,base['spectral_proposals']):
        snum = product(block,transpose(block))
        low,_,eta,_ = spectral_interval(snum,scale**2,proposal,scale)
        denom_lower += sum((rational_power_bound(v,q,q-1,False) for v in low),Fraction(0))
        denom_errors.append(eta)
    need(denom_lower > 0,'Denominator lower bound is zero')
    hnums = [product(product(block,knum),transpose(block)) for block in blocks]
    hden = scale**3
    h_errors = []
    if q == 6:  # p=6/5, r=3/2
        need(len(data['H_spectral_proposals']) == m,'Wrong H proposal count')
        b_upper = Fraction(0)
        for hn,proposal in zip(hnums,data['H_spectral_proposals']):
            _,up,eta,_ = spectral_interval(hn,hden,proposal,scale)
            b_upper += sum((rational_power_bound(v,3,2,True) for v in up),Fraction(0))
            h_errors.append(eta)
        degree, alpha_degree, b_degree, denom_degree = 6,3,2,5
    elif q == 4:  # p=4/3, r=2
        need(data.get('H_spectral_proposals') == [], 'No H eigenproposal needed for r=2')
        b_upper = sum((Fraction(trace_product(h,h),hden**2) for h in hnums),Fraction(0))
        degree, alpha_degree, b_degree, denom_degree = 4,2,1,3
    else:  # q=3, p=3/2, r=3
        need(data.get('H_spectral_proposals') == [], 'No H eigenproposal needed for r=3')
        b_upper = sum((Fraction(trace_product(product(h,h),h),hden**3)
                       for h in hnums),Fraction(0))
        degree, alpha_degree, b_degree, denom_degree = 6,3,1,4
    need(b_upper > 0, 'Nonpositive beta-power bound')
    target = Fraction(data['strict_upper_bound'])
    lower = Fraction(base['strict_lower_bound'])
    need(target > lower > 1, 'Invalid claimed interval')
    lhs = alpha_upper**alpha_degree * b_upper**b_degree
    rhs = target**degree * denom_lower**denom_degree
    need(lhs < rhs, 'Claimed fixed-orbit strict upper bound is NOT proved')
    # All acceptance decisions above use exact arithmetic. Float outputs below
    # only display the already established rational inequalities.
    return {
        'status':'PASS',
        'claim_scope':data['scope'],
        'not_a_global_upper_bound_for_C_p_m':True,
        'acceptance_arithmetic':'integers and exact fractions only',
        'm':m,'k':k,'n':m*k,'p':base['p'],
        'strict_lower_bound':base['strict_lower_bound'],
        'strict_upper_bound':data['strict_upper_bound'],
        'interval_width_exact':str(target-lower),
        'power_comparison_degree':degree,
        'power_margin_exact':str(1-lhs/rhs),
        'upper_enclosure_display_only':float(lhs/denom_lower**denom_degree)**(1/degree),
        'inverse_majorant_error_display_only':float(delta),
        'denominator_spectral_errors_display_only':[float(v) for v in denom_errors],
        'H_spectral_errors_display_only':[float(v) for v in h_errors],
        'retained_lower_certificate_result':lower_result,
    }


def build(lower_path: Path, output: Path, target: str):
    import numpy as np  # Proposals only; absent from verify path.
    from legacy_inner_solver import inner_blocks
    raw = lower_path.read_bytes();base = json.loads(raw)
    scale = integer(base['scale']);m,k,q = [integer(base[x]) for x in ('m','k','q')]
    L = np.array(base['blocks'],dtype=float)/scale
    p = q/(q-1)
    res = inner_blocks(L,p,tol=1e-14,residual_tol=5e-12,iterations=500)
    K = (res['K']+res['K'].T)/2
    def encode(a):
        if np.ndim(a) == 0:return str(round(float(a)*scale))
        return [encode(v) for v in a]
    encodedK = encode(K)
    # Encode symmetric K exactly, not by independent nonsymmetric estimates.
    for i in range(k):
        for j in range(i):encodedK[i][j] = encodedK[j][i]
    Kr = np.array(encodedK,dtype=float)/scale
    w,U = np.linalg.eigh(Kr)
    need(w.min()>0,'Numerical proposal K is not positive')
    W = (U*w**(-.5))@U.T
    Hprops=[]
    if q == 6:
        for l in L:
            H = l@Kr@l.T
            eig,V = np.linalg.eigh((H+H.T)/2)
            Hprops.append({'basis':encode(V),'values':encode(np.maximum(eig,0))})
    data = {
        'schema':'mi20.fixed-orbit.upper.integer.v1',
        'scope':'all polar factors for these fixed cyclic moduli only',
        'm':m,'k':k,'n':m*k,'p':base['p'],'q':q,'scale':str(scale),
        'lower_certificate_file':lower_path.name,
        'lower_certificate_sha256':hashlib.sha256(raw).hexdigest(),
        'strict_upper_bound':target,
        'K':encodedK,'inverse_factor':encode(W),'H_spectral_proposals':Hprops,
        'proposal_diagnostics_not_used_for_acceptance':{
            'inner_ratio':res['ratio'],'inner_converged':res['converged'],
            'inner_gap':res['gap_display_only'],
            'inner_stationarity_residual':res['stationarity_residual_display_only']},
        'note':'The unchanged lower certificate defines the exact rational blocks. This upper bound optimizes their polar factors, not their moduli or their dimension.'
    }
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(data,indent=2)+'\n')
    return verify(data,base,raw)


def load_verify(path: Path):
    data=json.loads(path.read_text())
    name=data['lower_certificate_file']
    need(isinstance(name,str) and Path(name).name == name,'Unsafe lower-certificate path')
    raw=(path.parent/name).read_bytes()
    return verify(data,json.loads(raw),raw)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='command',required=True)
    b=sub.add_parser('build');b.add_argument('lower',type=Path);b.add_argument('output',type=Path);b.add_argument('--target',required=True);b.add_argument('--log',type=Path)
    v=sub.add_parser('verify');v.add_argument('certificate',type=Path);v.add_argument('--log',type=Path)
    args=ap.parse_args()
    result=build(args.lower,args.output,args.target) if args.command=='build' else load_verify(args.certificate)
    text=json.dumps(result,indent=2)+'\n'
    print(text,end='')
    if args.log:args.log.parent.mkdir(parents=True,exist_ok=True);args.log.write_text(text)
if __name__=='__main__':main()
