# SP-08: verified partial continuation

**Status: this package does not solve unrestricted SP-08.** It proves additional subclasses and a larger unrestricted parameter strip. A successful certificate check in this package is not a certificate for the entire conjecture.

## Main results

Let \(n\ge2\), \(-1\le a<1\), \(d=1-a\), and let every entry of the real symmetric matrix \(A\), including the diagonal, lie in \([a,1]\). Define

\[
 B_k=J-dz_kz_k^T,\qquad
 M_n(a)^2=\max_{1\le k<n}\{n^2+d[2nk-(a+3)k^2]\},
\]

where \(z_k\) indicates a set of size \(k\). Each \(B_k\) has rank two and its spread squared is the expression in braces.

### 1. A larger unrestricted strip (analytic proof)

For every dimension,

\[
 -1\le a\le -1+\frac{1+\sqrt2}{n^2}
 \quad\Longrightarrow\quad
 \max_A\operatorname{spread}(A)
 =\operatorname{spread}(B_{\lfloor n/2\rfloor}).
\]

The proof applies to the whole entry box, not merely endpoint matrices. Its reduction for centered sign matrices of rank at most two uses only the analytic, negative-parameter part of Result 2 below. It does not depend on the nonnegative-parameter polynomial certificate or on enumeration of dimensions.

### 2. Centered sign rank at most two (all normalized parameters)

Put \(c=(1+a)/2\), \(r=(1-a)/2\). For every endpoint matrix \(A=cJ+rS\), if the symmetric sign matrix \(S\) has rank at most two, then

\[
 \operatorname{spread}(A)\le M_n(a).
\]

**This is a hypothesis on the rank of \(S\), not on the rank of \(A\), the deficit \(J-A\), or a matrix whose entrywise sign is \(S\).** Confusing these notions would incorrectly turn this partial result into a purported solution.

The proof for \(-1\le a\le0\) is analytic. The proof for \(0\le a<1\) combines analytic reductions with an exact rational polynomial-positivity certificate. The certificate covers real multiplicities on a specified region in every dimension; it is not a finite-dimensional numerical extrapolation.

### 3. An indefinite rank-three deficit family

The reduction in Result 2 bounds blow-ups of

\[
 \begin{pmatrix}1&1&a\\1&a&1\\a&1&a\end{pmatrix}.
\]

For nonnegative \(a\), multiplicities \(p,z\ge1\), and \(y\ge0\), its spread squared is at most

\[
 \frac{4(p+y+z)^2}{a+3}-\frac{(1-a)(a+3)}4.
\]

This includes the full worst-case rounding loss in the optimal integer block size. The exact certificate uses coefficient-positive charts and rational sums of monomial-weighted binomial squares. An independently implemented, standard-library verifier reconstructs the spectral polynomials rather than merely trusting stored coefficient lists.

## The unresolved step

No argument here proves that an unrestricted maximizer must have centered sign rank at most two, or must have a positive-semidefinite or rank-at-most-two deficit. In particular, arbitrary indefinite binary deficits of rank at least three, whose centered sign matrices also have rank at least three, are not generally covered outside the unrestricted strip.

The remaining sufficient inequality is

\[
 \operatorname{spread}(J-(1-a)H)\le M_n(a)
\]

for every symmetric zero-one matrix \(H\), every dimension, and every normalized parameter. The archive contains no proof of that full statement and no counterexample to SP-08.

## Reading the package

Start with `manuscript/sp08_continuation.pdf` when available, or the self-contained LaTeX source beside it. The Markdown proofs are `proofs/centered_rank_two.md` and `proofs/improved_boundary_strip.md`.

`checks/final_reproduction_report.json` records the most recent execution of the bundled verification scripts. `CHECKS.md` distinguishes exact verification from numerical testing. `HOW_TO_REPRODUCE.md` gives commands and dependencies. `MANIFEST.json` records hashes of the distributed files.

## Prior work and provenance

The supplied manuscripts, code, reports, and prior ZIP are preserved under `provenance/`. They are evidence of the earlier continuation, not automatically re-established results of this package. In particular, the supplied dimension-11 report is not the underlying finite certificate. The large finite certificate datasets referred to in the earlier conversation were not among the supplied files; their reported dimension ranges are not claimed as independently reproduced here.

Exploratory scripts and numerical searches are kept separate from proofs. They do not establish a universal inequality, even when they find no counterexample. Failure of a proposed merging move is not a counterexample to SP-08.
