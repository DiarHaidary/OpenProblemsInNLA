# MI-20: fourth-round research package

**Status: MI-20 has not been fully solved in this work.**
The exact unrestricted function C_p(m) is not evaluated. An equivalent
positive-matrix system is not a replacement for that requested evaluation.

## New proved upper bound

For every finite matrix order,

    C_(4/3)(2) <= (861/800)^(1/4) = 1.0185404734532257...

The preceding universal bound was (43983/40000)^(1/4).
The supplied exact lower certificate gives C_(4/3)(2) > 1.0183715753553.
These bounds still do not match. Tiny fixed-moduli intervals in the retained
data are not universal upper bounds for MI-20.

Writing b=861/800 and a=(1+sqrt(2))/2, the report proves

    C_p(2) <= b^(1-1/p)                         (1 < p <= 4/3)
    C_p(2) <= b^(1/p-1/2) a^(3/2-2/p)           (4/3 <= p < 2).

## Mathematical contents

`proofs/mi20_round4_report.pdf` and its LaTeX source contain the proofs:
positive duality and cyclic-block reduction; the all-exponent positive
power-system characterization, in both directions; order constraints;
the inherited cubic-bound chain; the new entire-interval certificate;
and explicit analytic-family interpolation. The exact function C_p(m)
and a matching unrestricted extremal construction remain missing.

## Reproduction

Run from this directory with Python 3:

    python -B -S code/check_hashes.py
    python -B -S code/verify_all.py
    python -B -S code/test_exact.py

These acceptance checks use only the Python standard library. They do not
require a numerical solver or trust floating-point eigensolver output.
The aggregate verifier checks the preceding eight-stage bound before using
it as an input to the new interval proof. The new certificate checks all
184 trace-coefficient identities and 44 positive-definite Gram multipliers.

The matrix positivity and coefficient calculations are exact. The report's
interpretation of those calculations as a proof is a mathematical argument,
not a proof-assistant formalization. No independent peer review is claimed.

## Directory guide

- `certificates/`: exact rational data, including the new interval certificate.
- `code/`: exact acceptance, regression, and integrity checks.
- `code/legacy/`: preserved predecessor acceptance routines.
- `proofs/`: the full PDF report and its editable LaTeX source.
- `verification/`: actual run records, release summary, and layout checks.
- `experiments/`: optional numerical proposal and consistency code.
- `provenance/`: input hashes, primary-source references, and environment.
- `previous_round/`: unchanged predecessor artifacts retained for audit.

The new certificate excludes the entire closed parameter interval
[861/100,43983/5000], not a finite sample of parameter values. Finite-order
maximizers consequently have parameter below 861/100; taking a supremum
over orders yields a non-strict universal upper bound.

## Optional numerical work

The numerical scripts require NumPy. Their results do not replace exact
acceptance. Run proposal builders only in a copy of the package, because
regenerating data changes files covered by the integrity manifest.

    python experiments/test_power_system.py

## Provenance and audit scope

Public sources were read through the website, not through the GitHub plugin.
The preceding archive's stronger certificate passed when called directly,
although its old aggregate command omitted it. Several predecessor negative
tests expected the wrong exception type. The fourth-round aggregate checks
its actual dependencies explicitly. Preserved files and their hashes are
not a blanket endorsement of every analytic claim in earlier rounds.

The standalone PDF supplied for round three was a summary stub; a fuller
report was retained inside the preceding archive. These are distinguished
in the preserved provenance rather than silently treated as the same file.

See `verification/release_summary.json` for this release's actual results.
