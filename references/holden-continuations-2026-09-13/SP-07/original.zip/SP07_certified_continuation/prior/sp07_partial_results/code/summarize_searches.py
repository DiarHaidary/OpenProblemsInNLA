"""Summarize saved search JSON files without rerunning optimizers."""
import argparse
import csv
import json
import platform
from pathlib import Path
import numpy
import scipy
import sympy

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('directory', type=Path)
args = parser.parse_args()
p = args.directory
rows, records = [], []
for f in sorted(p.glob('search_*.json')):
    data = json.loads(f.read_text())
    current = data['records']
    records.extend(current)
    rows.append({
        'campaign': f.stem,
        'runs': len(current),
        'dimensions': ','.join(str(n) for n in sorted({x['n'] for x in current})),
        'max_ratio': max(x['actual_ratio'] for x in current),
        'optimizer_successes': sum(x['success'] for x in current),
        'unitarity_residual': max(x['unitarity_residual'] for x in current),
        'max_jacobian_error': max(x['jacobian_error'] for x in data['summary']),
    })
if not records:
    raise SystemExit('No search_*.json files with records were found.')
summary = {
    'status': 'Numerical local-search evidence only; no universal bound is certified.',
    'total_runs': len(records),
    'maximum_ratio': max(x['actual_ratio'] for x in records),
    'exact_krause_ratio': float(numpy.sqrt(28/27)),
    'runs_above_krause_plus_1e_7': int(sum(x['actual_ratio'] > numpy.sqrt(28/27)+1e-7 for x in records)),
    'optimizer_successes': sum(x['success'] for x in records),
    'max_unitarity_residual': max(x['unitarity_residual'] for x in records),
    'campaigns': rows,
}
(p/'campaign_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
with (p/'campaign_summary.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]))
    writer.writeheader(); writer.writerows(rows)
(p/'environment.json').write_text(json.dumps({
    'python': platform.python_version(), 'numpy': numpy.__version__,
    'scipy': scipy.__version__, 'sympy': sympy.__version__,
    'platform': platform.platform(),
    'arithmetic': 'Double precision for numerical tests/searches; exact algebraic expressions for symbolic certificates.',
}, indent=2)+'\n')
print(json.dumps(summary, indent=2))
