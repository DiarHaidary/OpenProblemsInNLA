# Review scope and limitations

The new report distinguishes the unrestricted constant from a fixed-moduli
optimization. The predecessor chain is interpreted using its actual
normalization tr(D^3(H1+H2)) and its full nine-word degree-two Gram basis.
Its five trace moments are bounded with both lower and upper coefficient
bounds. The new interval certificate shares the cubic multipliers between
its two endpoints and therefore excludes every point in the interval.
A finite-order strict exclusion is not stated as a strict bound on the
supremum over all orders.

The all-exponent characterization is proved in both directions in the
report, but is not described as an evaluation of the desired function.
The individual order bound uses the stated Furuta theorem; the sum bound
uses operator Jensen inequalities and an order-preserving homogeneous map.

Exact arithmetic validation checks coefficient identities and matrix
positivity. It does not constitute independent peer review or a formal
proof-assistant verification of the mathematical reductions.

The release summary and exact run records were produced from this package,
not copied from a preceding round. Contact sheets and automated PDF boundary
checks are included; no independent visual review is claimed.
