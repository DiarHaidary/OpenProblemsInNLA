#!/usr/bin/env python3
"""Exact-arithmetic consistency checks for the TR-03 reduction addendum.

Standard library only. These tests do not verify the unproved hypothesis H(c).
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json
import random

ROOT = Path(__file__).resolve().parents[1]
RNG = random.Random(3032026)
COUNTS: dict[str, int] = {}


def check(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(name)
    COUNTS[name] = COUNTS.get(name, 0) + 1


def esp(values: list[F]) -> list[F]:
    out = [F(1)] + [F(0)] * len(values)
    for x in values:
        for j in range(len(values), 0, -1):
            out[j] += x * out[j - 1]
    return out


def inverse(a: list[list[F]]) -> list[list[F]] | None:
    n = len(a)
    if n == 0:
        return []
    w = [list(row) + [F(i == j) for j in range(n)] for i, row in enumerate(a)]
    for col in range(n):
        pivot = next((r for r in range(col, n) if w[r][col]), None)
        if pivot is None:
            return None
        w[col], w[pivot] = w[pivot], w[col]
        z = w[col][col]
        w[col] = [x / z for x in w[col]]
        for r in range(n):
            if r != col and w[r][col]:
                z = w[r][col]
                w[r] = [x - z * y for x, y in zip(w[r], w[col])]
    return [row[n:] for row in w]


def determinant(a: list[list[F]]) -> F:
    n = len(a)
    w = [list(row) for row in a]
    result = F(1)
    for col in range(n):
        pivot = next((r for r in range(col, n) if w[r][col]), None)
        if pivot is None:
            return F(0)
        if pivot != col:
            w[pivot], w[col] = w[col], w[pivot]
            result = -result
        z = w[col][col]
        result *= z
        for r in range(col + 1, n):
            q = w[r][col] / z
            for c in range(col + 1, n):
                w[r][c] -= q * w[col][c]
    return result


def trace(a: list[list[F]]) -> F:
    return sum((a[i][i] for i in range(len(a))), F(0))


def principal(a: list[list[F]], indices: tuple[int, ...]) -> list[list[F]]:
    return [[a[i][j] for j in indices] for i in indices]


def conjugate(u: list[list[F]], d: list[F]) -> list[list[F]]:
    n = len(d)
    return [[sum((u[i][l] * d[l] * u[j][l] for l in range(n)), F(0))
             for j in range(n)] for i in range(n)]


def orthogonal(n: int) -> list[list[F]]:
    u = [[F(i == j) for j in range(n)] for i in range(n)]
    for _ in range(n + 2):
        i, j = RNG.sample(range(n), 2)
        c, s = F(3, 5), F(4, 5)
        a, b = list(u[i]), list(u[j])
        u[i] = [c * x - s * y for x, y in zip(a, b)]
        u[j] = [s * x + c * y for x, y in zip(a, b)]
    for i in range(n):
        for j in range(n):
            check("rational_orthogonality", sum(u[i][l] * u[j][l] for l in range(n)) == F(i == j))
    return u


def spectral_checks() -> None:
    for n in range(3, 13):
        for _ in range(20):
            lam = sorted([F(RNG.randint(1, 30), RNG.randint(1, 7)) for _ in range(n)], reverse=True)
            e = esp(lam)
            for k in range(1, n):
                tau = sum(lam[k:], F(0))
                t, nu = e[k + 1] / e[k], e[k - 1] / e[k]
                balance = sum((t / (x + t) for x in lam[:k]), F(0))
                check("spectral_balance_first", balance <= tau * nu)
                check("spectral_balance_second", tau * nu <= tau / t)
                check("volume_tail_bound", t <= tau)
                for a in (lam[0], lam[k - 1], lam[-1], F(1), F(7, 3)):
                    q = sum(x <= a for x in lam[:k])
                    check("threshold_count", q * t * t <= tau * (a + t))
                for q in range(1, k + 1):
                    check("quadratic_rank_bound", q * t * t <= tau * (lam[k - q] + t))
                h = sum((1 / x for x in lam[:k + 1]), F(0))
                check("harmonic_volume_comparison", h * e[k + 1] <= (n - k) * e[k])


def finite_checks() -> None:
    for n in range(4, 8):
        for k in range(max(2, n - 4), n - 1):
            for _ in range(2):
                lam = sorted([F(RNG.randint(1, 12)) for _ in range(n)], reverse=True)
                j = RNG.randint(1, k)
                a = lam[j - 1]
                u = orthogonal(n)
                actual_b = conjugate(u, [1 / x for x in lam])
                finite_b = conjugate(u, [1 / a] * j + [1 / x for x in lam[j:]])
                limit_b = conjugate(u, [F(0)] * j + [1 / x for x in lam[j:]])
                actual_a = conjugate(u, lam)
                finite_errors, limit_errors, actual_errors = [], [], []
                weighted, weights = F(0), F(0)
                for J in combinations(range(n), n - k):
                    finite_inv = inverse(principal(finite_b, J))
                    actual_inv = inverse(principal(actual_b, J))
                    assert finite_inv is not None and actual_inv is not None
                    f, f_actual = trace(finite_inv), trace(actual_inv)
                    finite_errors.append(f)
                    actual_errors.append(f_actual)
                    check("leading_eigenvalue_monotonicity", f_actual >= f)
                    lim_inv = inverse(principal(limit_b, J))
                    if lim_inv is None:
                        check("singular_limit_cap", f >= a)
                    else:
                        z = trace(lim_inv)
                        limit_errors.append(z)
                        check("finite_limit_pointwise", f >= a * z / (a + z))
                    S = tuple(i for i in range(n) if i not in J)
                    weight = determinant(principal(actual_a, S))
                    weighted += weight * f_actual
                    weights += weight
                assert limit_errors
                h = min(limit_errors)
                check("finite_limit_minimum", min(finite_errors) >= a * h / (a + h))
                e = esp(lam)
                y = (k + 1) * e[k + 1] / e[k]
                check("exact_volume_identity", weighted / weights == y)
                check("fixed_orientation_average_bound", min(actual_errors) <= y)


def block_checks() -> None:
    h4 = [[F(x) for x in row] for row in
          [[1, 1, 1, 1], [1, -1, 1, -1], [1, 1, -1, -1], [1, -1, -1, 1]]]
    for _ in range(8):
        lam = sorted([F(RNG.randint(1, 15)) for _ in range(6)], reverse=True)
        r, n = 4, 6
        harmonic_sum = sum((1 / x for x in lam[:r]), F(0))
        b = [[F(0) for _ in range(n)] for _ in range(n)]
        for i in range(r):
            for j in range(r):
                b[i][j] = sum((h4[i][l] * h4[j][l] / lam[l] for l in range(r)), F(0)) / r
        for i in range(r, n):
            b[i][i] = 1 / lam[i]
        for i in range(r):
            check("harmonic_block_equal_diagonal", b[i][i] == harmonic_sum / r)
        for k in range(1, r + 1):
            bound = sum(lam[r:], F(0)) + F(r * (r - k)) / harmonic_sum
            for J in combinations(range(n), n - k):
                inv = inverse(principal(b, J))
                assert inv is not None
                check("harmonic_block_all_subsets", trace(inv) >= bound)


def main() -> None:
    spectral_checks()
    finite_checks()
    block_checks()
    result = {
        "status": "passed",
        "arithmetic": "exact fractions; no floating-point tolerances",
        "seed": 3032026,
        "checks": COUNTS,
        "total_assertions": sum(COUNTS.values()),
        "unproved_hypothesis_H_tested": False,
        "formal_proof_certification": False,
        "full_TR03_solution": False,
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
